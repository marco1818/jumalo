package com.bancoazteca.srcu.spring.controladores.administracion.mantenimientoUsuariosUnificado;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.ModelAndView;

import com.bancoazteca.srcu.spring.beans.administracion.mantenimientoUsuariosUnificado.MantenimientoUsuariosUnificadoBean;
import com.bancoazteca.srcu.spring.beans.sistema.MensajeTransaccionBean;
import com.bancoazteca.srcu.spring.beans.utilerias.DatosSessionStruts;
import com.bancoazteca.srcu.spring.servicios.administracion.mantenimientoUsuariosUnificado.MantenimientoUsuariosUnificadoServicio;

@Controller
public class MantenimientoUsuariosUnificadoControlador {

	@Autowired
	MantenimientoUsuariosUnificadoServicio mantenimientoUsuariosUnificadoServicio;
	
	@InitBinder
	public void InitBinder(WebDataBinder webDataBinder, WebRequest webRequest) {
		webDataBinder.setDisallowedFields("");
	}
	
	@RequestMapping(value= {"/mantenimientoUsuariosUnificadoSRCU.htm"}, method=RequestMethod.GET)
	public ModelAndView mantenimientoUsuariosUnificado(@ModelAttribute("datosSession") DatosSessionStruts datosSessionStruts) {
		ModelAndView modelAndView = new ModelAndView();
		MantenimientoUsuariosUnificadoBean mantenimientoUsuariosUnificadoBean = new MantenimientoUsuariosUnificadoBean();
		mantenimientoUsuariosUnificadoBean.setEmpleadoOpera(datosSessionStruts.getNumeroEmpleado());
		mantenimientoUsuariosUnificadoBean.setPuestoOpera(datosSessionStruts.getPuestoOpera());
		mantenimientoUsuariosUnificadoBean.setPuestos(mantenimientoUsuariosUnificadoServicio.consulta(mantenimientoUsuariosUnificadoBean, 1).getPuestos());
		modelAndView.setViewName("administracion/mantenimientoUsuariosUnificado/mantenimientoUsuariosUnificado");
		modelAndView.addObject("mantenimientoUsuariosUnificadoBean",mantenimientoUsuariosUnificadoBean);
		
		return modelAndView;
	}
	
	@RequestMapping(value= {"/mantenimientoUsuariosUnificado.htm"}, method= RequestMethod.POST)
	public ModelAndView mantenimientoUsuariosUnificado(@ModelAttribute("mantenimientoUsuariosUnificadoBean") MantenimientoUsuariosUnificadoBean mantenimientoUsuariosUnificadoBean, @RequestParam("tipoOperacion") int tipoOperacion) {
		ModelAndView modelAndView = new ModelAndView();
		
		MensajeTransaccionBean mensajeTransaccionBean = mantenimientoUsuariosUnificadoServicio.grabaTransaccion(mantenimientoUsuariosUnificadoBean, tipoOperacion);
		
		modelAndView.setViewName("sistema/resultadoTransaccion");
		modelAndView.addObject("mensajeTransaccionBean",mensajeTransaccionBean);
		
		return modelAndView;
	}
}
