package com.bancoazteca.srcu.spring.beans.administracion.mantenimientoUsuariosSap;

import java.math.BigDecimal;

public class EmpleadosBean {
	private String	numeroEmpleado;
	private String	nombreEmpleado;
	private	int gerenciaId;
	private String descripcionDepto;
	private int puestoId;
	private String descripcionPuestoId;
	private int segmentoId;
	private String descripcionSegmentoId;
	private String fechaAlta;
	private int	esVirtual;
	
	public String getNumeroEmpleado() {
		return numeroEmpleado;
	}
	public void setNumeroEmpleado(String numeroEmpleado) {
		this.numeroEmpleado = numeroEmpleado;
	}
	public String getNombreEmpleado() {
		return nombreEmpleado;
	}
	public void setNombreEmpleado(String nombreEmpleado) {
		this.nombreEmpleado = nombreEmpleado;
	}
	public int getGerenciaId() {
		return gerenciaId;
	}
	public void setGerenciaId(int gerenciaId) {
		this.gerenciaId = gerenciaId;
	}
	public void setGerenciaId(BigDecimal gerenciaId) {
		this.gerenciaId = gerenciaId.intValue();
	}
	public int getPuestoId() {
		return puestoId;
	}
	public void setPuestoId(int puestoId) {
		this.puestoId = puestoId;
	}
	public void setPuestoId(BigDecimal puestoId) {
		this.puestoId = puestoId.intValue();
	}
	public String getDescripcionPuestoId() {
		return descripcionPuestoId;
	}
	public void setDescripcionPuestoId(String descripcionPuestoId) {
		this.descripcionPuestoId = descripcionPuestoId;
	}
	public int getSegmentoId() {
		return segmentoId;
	}
	public void setSegmentoId(int segmentoId) {
		this.segmentoId = segmentoId;
	}
	public void setSegmentoId(BigDecimal segmentoId) {
		this.segmentoId = segmentoId.intValue();
	}
	public String getDescripcionSegmentoId() {
		return descripcionSegmentoId;
	}
	public void setDescripcionSegmentoId(String descripcionSegmentoId) {
		this.descripcionSegmentoId = descripcionSegmentoId;
	}
	public String getFechaAlta() {
		return fechaAlta;
	}
	public void setFechaAlta(String fechaAlta) {
		this.fechaAlta = fechaAlta;
	}
	public String getDescripcionDepto() {
		return descripcionDepto;
	}
	public void setDescripcionDepto(String descripcionDepto) {
		this.descripcionDepto = descripcionDepto;
	}
	public int getEsVirtual() {
		return esVirtual;
	}
	public void setEsVirtual(int esVirtual) {
		this.esVirtual = esVirtual;
	}
}	
