/**
 * Familia.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.bancoazteca.srcu.spring.ws.administracion.empleados.axis;
@SuppressWarnings({ "unused", "rawtypes" })
public class Familia  implements java.io.Serializable {
    /**
	 * 
	 */
	private static final long serialVersionUID = 2289594306168735496L;

	private java.lang.String parentesco_Familia;

    private java.lang.String nombreInicial_Familia;

    private java.lang.String apellidoPaterno_Familia;

    private java.lang.String apellidoMaterno_Familia;

    private java.lang.String pais_Familia;

    private java.lang.String genero_Familia;

    private int fechaNacimiento_Familia;

    private java.lang.String lugarNacimiento_Familia;

    private java.lang.String consecutivo_Familia;

    public Familia() {
    }

    public Familia(
           java.lang.String parentesco_Familia,
           java.lang.String nombreInicial_Familia,
           java.lang.String apellidoPaterno_Familia,
           java.lang.String apellidoMaterno_Familia,
           java.lang.String pais_Familia,
           java.lang.String genero_Familia,
           int fechaNacimiento_Familia,
           java.lang.String lugarNacimiento_Familia,
           java.lang.String consecutivo_Familia) {
           this.parentesco_Familia = parentesco_Familia;
           this.nombreInicial_Familia = nombreInicial_Familia;
           this.apellidoPaterno_Familia = apellidoPaterno_Familia;
           this.apellidoMaterno_Familia = apellidoMaterno_Familia;
           this.pais_Familia = pais_Familia;
           this.genero_Familia = genero_Familia;
           this.fechaNacimiento_Familia = fechaNacimiento_Familia;
           this.lugarNacimiento_Familia = lugarNacimiento_Familia;
           this.consecutivo_Familia = consecutivo_Familia;
    }


    /**
     * Gets the parentesco_Familia value for this Familia.
     * 
     * @return parentesco_Familia
     */
    public java.lang.String getParentesco_Familia() {
        return parentesco_Familia;
    }


    /**
     * Sets the parentesco_Familia value for this Familia.
     * 
     * @param parentesco_Familia
     */
    public void setParentesco_Familia(java.lang.String parentesco_Familia) {
        this.parentesco_Familia = parentesco_Familia;
    }


    /**
     * Gets the nombreInicial_Familia value for this Familia.
     * 
     * @return nombreInicial_Familia
     */
    public java.lang.String getNombreInicial_Familia() {
        return nombreInicial_Familia;
    }


    /**
     * Sets the nombreInicial_Familia value for this Familia.
     * 
     * @param nombreInicial_Familia
     */
    public void setNombreInicial_Familia(java.lang.String nombreInicial_Familia) {
        this.nombreInicial_Familia = nombreInicial_Familia;
    }


    /**
     * Gets the apellidoPaterno_Familia value for this Familia.
     * 
     * @return apellidoPaterno_Familia
     */
    public java.lang.String getApellidoPaterno_Familia() {
        return apellidoPaterno_Familia;
    }


    /**
     * Sets the apellidoPaterno_Familia value for this Familia.
     * 
     * @param apellidoPaterno_Familia
     */
    public void setApellidoPaterno_Familia(java.lang.String apellidoPaterno_Familia) {
        this.apellidoPaterno_Familia = apellidoPaterno_Familia;
    }


    /**
     * Gets the apellidoMaterno_Familia value for this Familia.
     * 
     * @return apellidoMaterno_Familia
     */
    public java.lang.String getApellidoMaterno_Familia() {
        return apellidoMaterno_Familia;
    }


    /**
     * Sets the apellidoMaterno_Familia value for this Familia.
     * 
     * @param apellidoMaterno_Familia
     */
    public void setApellidoMaterno_Familia(java.lang.String apellidoMaterno_Familia) {
        this.apellidoMaterno_Familia = apellidoMaterno_Familia;
    }


    /**
     * Gets the pais_Familia value for this Familia.
     * 
     * @return pais_Familia
     */
    public java.lang.String getPais_Familia() {
        return pais_Familia;
    }


    /**
     * Sets the pais_Familia value for this Familia.
     * 
     * @param pais_Familia
     */
    public void setPais_Familia(java.lang.String pais_Familia) {
        this.pais_Familia = pais_Familia;
    }


    /**
     * Gets the genero_Familia value for this Familia.
     * 
     * @return genero_Familia
     */
    public java.lang.String getGenero_Familia() {
        return genero_Familia;
    }


    /**
     * Sets the genero_Familia value for this Familia.
     * 
     * @param genero_Familia
     */
    public void setGenero_Familia(java.lang.String genero_Familia) {
        this.genero_Familia = genero_Familia;
    }


    /**
     * Gets the fechaNacimiento_Familia value for this Familia.
     * 
     * @return fechaNacimiento_Familia
     */
    public int getFechaNacimiento_Familia() {
        return fechaNacimiento_Familia;
    }


    /**
     * Sets the fechaNacimiento_Familia value for this Familia.
     * 
     * @param fechaNacimiento_Familia
     */
    public void setFechaNacimiento_Familia(int fechaNacimiento_Familia) {
        this.fechaNacimiento_Familia = fechaNacimiento_Familia;
    }


    /**
     * Gets the lugarNacimiento_Familia value for this Familia.
     * 
     * @return lugarNacimiento_Familia
     */
    public java.lang.String getLugarNacimiento_Familia() {
        return lugarNacimiento_Familia;
    }


    /**
     * Sets the lugarNacimiento_Familia value for this Familia.
     * 
     * @param lugarNacimiento_Familia
     */
    public void setLugarNacimiento_Familia(java.lang.String lugarNacimiento_Familia) {
        this.lugarNacimiento_Familia = lugarNacimiento_Familia;
    }


    /**
     * Gets the consecutivo_Familia value for this Familia.
     * 
     * @return consecutivo_Familia
     */
    public java.lang.String getConsecutivo_Familia() {
        return consecutivo_Familia;
    }


    /**
     * Sets the consecutivo_Familia value for this Familia.
     * 
     * @param consecutivo_Familia
     */
    public void setConsecutivo_Familia(java.lang.String consecutivo_Familia) {
        this.consecutivo_Familia = consecutivo_Familia;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Familia)) return false;
        Familia other = (Familia) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.parentesco_Familia==null && other.getParentesco_Familia()==null) || 
             (this.parentesco_Familia!=null &&
              this.parentesco_Familia.equals(other.getParentesco_Familia()))) &&
            ((this.nombreInicial_Familia==null && other.getNombreInicial_Familia()==null) || 
             (this.nombreInicial_Familia!=null &&
              this.nombreInicial_Familia.equals(other.getNombreInicial_Familia()))) &&
            ((this.apellidoPaterno_Familia==null && other.getApellidoPaterno_Familia()==null) || 
             (this.apellidoPaterno_Familia!=null &&
              this.apellidoPaterno_Familia.equals(other.getApellidoPaterno_Familia()))) &&
            ((this.apellidoMaterno_Familia==null && other.getApellidoMaterno_Familia()==null) || 
             (this.apellidoMaterno_Familia!=null &&
              this.apellidoMaterno_Familia.equals(other.getApellidoMaterno_Familia()))) &&
            ((this.pais_Familia==null && other.getPais_Familia()==null) || 
             (this.pais_Familia!=null &&
              this.pais_Familia.equals(other.getPais_Familia()))) &&
            ((this.genero_Familia==null && other.getGenero_Familia()==null) || 
             (this.genero_Familia!=null &&
              this.genero_Familia.equals(other.getGenero_Familia()))) &&
            this.fechaNacimiento_Familia == other.getFechaNacimiento_Familia() &&
            ((this.lugarNacimiento_Familia==null && other.getLugarNacimiento_Familia()==null) || 
             (this.lugarNacimiento_Familia!=null &&
              this.lugarNacimiento_Familia.equals(other.getLugarNacimiento_Familia()))) &&
            ((this.consecutivo_Familia==null && other.getConsecutivo_Familia()==null) || 
             (this.consecutivo_Familia!=null &&
              this.consecutivo_Familia.equals(other.getConsecutivo_Familia())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getParentesco_Familia() != null) {
            _hashCode += getParentesco_Familia().hashCode();
        }
        if (getNombreInicial_Familia() != null) {
            _hashCode += getNombreInicial_Familia().hashCode();
        }
        if (getApellidoPaterno_Familia() != null) {
            _hashCode += getApellidoPaterno_Familia().hashCode();
        }
        if (getApellidoMaterno_Familia() != null) {
            _hashCode += getApellidoMaterno_Familia().hashCode();
        }
        if (getPais_Familia() != null) {
            _hashCode += getPais_Familia().hashCode();
        }
        if (getGenero_Familia() != null) {
            _hashCode += getGenero_Familia().hashCode();
        }
        _hashCode += getFechaNacimiento_Familia();
        if (getLugarNacimiento_Familia() != null) {
            _hashCode += getLugarNacimiento_Familia().hashCode();
        }
        if (getConsecutivo_Familia() != null) {
            _hashCode += getConsecutivo_Familia().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Familia.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Familia"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("parentesco_Familia");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Parentesco_Familia"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nombreInicial_Familia");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "NombreInicial_Familia"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("apellidoPaterno_Familia");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ApellidoPaterno_Familia"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("apellidoMaterno_Familia");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ApellidoMaterno_Familia"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("pais_Familia");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Pais_Familia"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("genero_Familia");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Genero_Familia"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("fechaNacimiento_Familia");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "FechaNacimiento_Familia"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lugarNacimiento_Familia");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "LugarNacimiento_Familia"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("consecutivo_Familia");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Consecutivo_Familia"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
