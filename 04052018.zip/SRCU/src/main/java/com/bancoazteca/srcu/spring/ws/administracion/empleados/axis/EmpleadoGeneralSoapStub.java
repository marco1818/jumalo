/**
 * EmpleadoGeneralSoapStub.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.bancoazteca.srcu.spring.ws.administracion.empleados.axis;
@SuppressWarnings({ "unused", "rawtypes","unchecked" })
public class EmpleadoGeneralSoapStub extends org.apache.axis.client.Stub implements EmpleadoGeneralSoap {
	private java.util.Vector cachedSerClasses = new java.util.Vector();
	private java.util.Vector cachedSerQNames = new java.util.Vector();
	private java.util.Vector cachedSerFactories = new java.util.Vector();
	private java.util.Vector cachedDeserFactories = new java.util.Vector();

    static org.apache.axis.description.OperationDesc [] _operations;

    static {
        _operations = new org.apache.axis.description.OperationDesc[53];
        _initOperationDesc1();
        _initOperationDesc2();
        _initOperationDesc3();
        _initOperationDesc4();
        _initOperationDesc5();
        _initOperationDesc6();
    }

    private static void _initOperationDesc1(){
        org.apache.axis.description.OperationDesc oper;
        org.apache.axis.description.ParameterDesc param;
        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getEmpleadoGeneral");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Usuario"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Contrase�a"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Empleado"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Empresa"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError"), org.apache.axis.description.ParameterDesc.INOUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"), boolean.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje"), org.apache.axis.description.ParameterDesc.INOUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Empleado"));
        oper.setReturnClass(Empleado.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "getEmpleadoGeneralResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[0] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getEmpleadoGeneralDineroExpress");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Usuario"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Contrase�a"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Empleado"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Empresa"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError"), org.apache.axis.description.ParameterDesc.INOUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"), boolean.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje"), org.apache.axis.description.ParameterDesc.INOUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "EmpleadoDExpress"));
        oper.setReturnClass(EmpleadoDExpress.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "getEmpleadoGeneralDineroExpressResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[1] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getTarjetaAmarillaEmpleado");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Usuario"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Contrase�a"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Empleado"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Empresa"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError"), org.apache.axis.description.ParameterDesc.INOUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"), boolean.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje"), org.apache.axis.description.ParameterDesc.INOUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "TarjetasAmarillas"));
        oper.setReturnClass(TarjetasAmarillas.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "getTarjetaAmarillaEmpleadoResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[2] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getTarjetaAmarillaCtaBanco");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Usuario"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Contrase�a"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "CuentaBanco"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Empresa"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError"), org.apache.axis.description.ParameterDesc.INOUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"), boolean.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje"), org.apache.axis.description.ParameterDesc.INOUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "TarjetasAmarillasCtaBanco"));
        oper.setReturnClass(TarjetasAmarillasCtaBanco.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "getTarjetaAmarillaCtaBancoResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[3] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getTarjetaAmarillaEmpleadoSIE");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Usuario"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Contrase�a"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Empleado"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Fecha"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError"), org.apache.axis.description.ParameterDesc.INOUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"), boolean.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje"), org.apache.axis.description.ParameterDesc.INOUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ArrayOfTarjetasAmarillasSIE"));
        oper.setReturnClass(TarjetasAmarillasSIE[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "getTarjetaAmarillaEmpleadoSIEResult"));
        param = oper.getReturnParamDesc();
        param.setItemQName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "TarjetasAmarillasSIE"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[4] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getTarjetaAmarillaEmpleadoSIE_Tabla");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Usuario"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Contrase�a"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Empleado"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Fecha"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError"), org.apache.axis.description.ParameterDesc.INOUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje"), org.apache.axis.description.ParameterDesc.INOUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        oper.setReturnClass(java.lang.String.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "getTarjetaAmarillaEmpleadoSIE_TablaResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[5] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getEmpleadoPorCentroCostos");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Usuario"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Contrase�a"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "CentroCostos"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Empresa"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError"), org.apache.axis.description.ParameterDesc.INOUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"), boolean.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje"), org.apache.axis.description.ParameterDesc.INOUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ArrayOfEmpleado"));
        oper.setReturnClass(Empleado[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "getEmpleadoPorCentroCostosResult"));
        param = oper.getReturnParamDesc();
        param.setItemQName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Empleado"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[6] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getEmpleadoPorSituacion");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Usuario"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Contrase�a"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Situacion"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Fecha"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Pais"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Empresa"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError"), org.apache.axis.description.ParameterDesc.INOUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"), boolean.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje"), org.apache.axis.description.ParameterDesc.INOUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ArrayOfEmpleado"));
        oper.setReturnClass(Empleado[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "getEmpleadoPorSituacionResult"));
        param = oper.getReturnParamDesc();
        param.setItemQName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Empleado"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[7] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getDatosCorreo");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Usuario"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Contrase�a"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Empleado"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Empresa"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError"), org.apache.axis.description.ParameterDesc.INOUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"), boolean.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje"), org.apache.axis.description.ParameterDesc.INOUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Estructura_DatosCorreo"));
        oper.setReturnClass(Estructura_DatosCorreo.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "getDatosCorreoResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[8] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getFuncionEmpleado");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Usuario"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Contrase�a"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Empleado"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Empresa"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError"), org.apache.axis.description.ParameterDesc.INOUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"), boolean.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje"), org.apache.axis.description.ParameterDesc.INOUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Funcion"));
        oper.setReturnClass(Funcion.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "getFuncionEmpleadoResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[9] = oper;

    }

    private static void _initOperationDesc2(){
        org.apache.axis.description.OperationDesc oper;
        org.apache.axis.description.ParameterDesc param;
        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getVacantes");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Usuario"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Contrase�a"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError"), org.apache.axis.description.ParameterDesc.INOUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"), boolean.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje"), org.apache.axis.description.ParameterDesc.INOUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ArrayOfVacante"));
        oper.setReturnClass(Vacante[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "getVacantesResult"));
        param = oper.getReturnParamDesc();
        param.setItemQName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Vacante"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[10] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getEmpleadoPorFuncion");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Usuario"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Contrase�a"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Funcion"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Pais"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Empresa"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError"), org.apache.axis.description.ParameterDesc.INOUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"), boolean.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje"), org.apache.axis.description.ParameterDesc.INOUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ArrayOfEmpleado"));
        oper.setReturnClass(Empleado[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "getEmpleadoPorFuncionResult"));
        param = oper.getReturnParamDesc();
        param.setItemQName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Empleado"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[11] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getEmpleadoPorMovimiento");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Usuario"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Contrase�a"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Fecha"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Empresa"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError"), org.apache.axis.description.ParameterDesc.INOUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"), boolean.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje"), org.apache.axis.description.ParameterDesc.INOUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ArrayOfEmpleado"));
        oper.setReturnClass(Empleado[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "getEmpleadoPorMovimientoResult"));
        param = oper.getReturnParamDesc();
        param.setItemQName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Empleado"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[12] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getEmpleadoIncapacidad");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Usuario"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Contrase�a"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Empresa"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "fechaActualiza"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError"), org.apache.axis.description.ParameterDesc.INOUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"), boolean.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje"), org.apache.axis.description.ParameterDesc.INOUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ArrayOfIncapacidad"));
        oper.setReturnClass(Incapacidad[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "getEmpleadoIncapacidadResult"));
        param = oper.getReturnParamDesc();
        param.setItemQName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Incapacidad"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[13] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getCorreo");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Usuario"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Contrase�a"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Valor"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Empresa"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Pais"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError"), org.apache.axis.description.ParameterDesc.INOUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"), boolean.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje"), org.apache.axis.description.ParameterDesc.INOUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        oper.setReturnClass(java.lang.String.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "getCorreoResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[14] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getRFC");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Nombre"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ApellidoPaterno"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ApellidoMaterno"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "FechaNacimiento"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        oper.setReturnClass(java.lang.String.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "getRFCResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[15] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getEsDirector");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Usuario"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Contrase�a"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Empleado"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Empresa"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "EsDirector"), org.apache.axis.description.ParameterDesc.INOUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"), boolean.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError"), org.apache.axis.description.ParameterDesc.INOUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"), boolean.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje"), org.apache.axis.description.ParameterDesc.INOUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(org.apache.axis.encoding.XMLType.AXIS_VOID);
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[16] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getCuentaClabe");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Usuario"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Contrase�a"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Empleado"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Empresa"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError"), org.apache.axis.description.ParameterDesc.INOUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"), boolean.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje"), org.apache.axis.description.ParameterDesc.INOUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        oper.setReturnClass(java.lang.String.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "getCuentaClabeResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[17] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getHuellaClienteUnico");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Usuario"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Contrase�a"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Empleado"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Empresa"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError"), org.apache.axis.description.ParameterDesc.INOUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"), boolean.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje"), org.apache.axis.description.ParameterDesc.INOUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", ">>getHuellaClienteUnicoResponse>getHuellaClienteUnicoResult"));
        oper.setReturnClass(GetHuellaClienteUnicoResponseGetHuellaClienteUnicoResult.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "getHuellaClienteUnicoResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[18] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getHuellaClienteUnicoLAM");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Usuario"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Contrase�a"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Empleado"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Empresa"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError"), org.apache.axis.description.ParameterDesc.INOUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"), boolean.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje"), org.apache.axis.description.ParameterDesc.INOUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", ">>getHuellaClienteUnicoLAMResponse>getHuellaClienteUnicoLAMResult"));
        oper.setReturnClass(GetHuellaClienteUnicoLAMResponseGetHuellaClienteUnicoLAMResult.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "getHuellaClienteUnicoLAMResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[19] = oper;

    }

    private static void _initOperationDesc3(){
        org.apache.axis.description.OperationDesc oper;
        org.apache.axis.description.ParameterDesc param;
        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getHuellaClienteUnicoQA");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Usuario"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Contrase�a"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Empleado"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Empresa"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError"), org.apache.axis.description.ParameterDesc.INOUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"), boolean.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje"), org.apache.axis.description.ParameterDesc.INOUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", ">>getHuellaClienteUnicoQAResponse>getHuellaClienteUnicoQAResult"));
        oper.setReturnClass(GetHuellaClienteUnicoQAResponseGetHuellaClienteUnicoQAResult.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "getHuellaClienteUnicoQAResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[20] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getFechaPago");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Usuario"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Contrase�a"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Empleado"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Empresa"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError"), org.apache.axis.description.ParameterDesc.INOUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"), boolean.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje"), org.apache.axis.description.ParameterDesc.INOUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        oper.setReturnClass(java.lang.String.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "getFechaPagoResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[21] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getCoincidencias");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Usuario"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Contrase�a"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Filtro"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Situacion"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError"), org.apache.axis.description.ParameterDesc.INOUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"), boolean.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje"), org.apache.axis.description.ParameterDesc.INOUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ArrayOfCoincidencia"));
        oper.setReturnClass(Coincidencia[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "getCoincidenciasResult"));
        param = oper.getReturnParamDesc();
        param.setItemQName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Coincidencia"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[22] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getLineaSuperior");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Usuario"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Contrase�a"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Empleado"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Empresa"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError"), org.apache.axis.description.ParameterDesc.INOUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"), boolean.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje"), org.apache.axis.description.ParameterDesc.INOUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ArrayOfSuperiores"));
        oper.setReturnClass(Superiores[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "getLineaSuperiorResult"));
        param = oper.getReturnParamDesc();
        param.setItemQName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Superiores"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[23] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getLineaInferior");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Usuario"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Contrase�a"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Empleado"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Empresa"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError"), org.apache.axis.description.ParameterDesc.INOUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"), boolean.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje"), org.apache.axis.description.ParameterDesc.INOUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ArrayOfSubordinado"));
        oper.setReturnClass(Subordinado[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "getLineaInferiorResult"));
        param = oper.getReturnParamDesc();
        param.setItemQName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Subordinado"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[24] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getLineaInferiorSAP");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Usuario"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Contrase�a"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Puesto"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Empresa"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Nivel"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Pais"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError"), org.apache.axis.description.ParameterDesc.INOUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"), boolean.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje"), org.apache.axis.description.ParameterDesc.INOUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ArrayOfSubordinado"));
        oper.setReturnClass(Subordinado[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "getLineaInferiorSAPResult"));
        param = oper.getReturnParamDesc();
        param.setItemQName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Subordinado"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[25] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getLineaInferiorPorEmpleadoRep");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Usuario"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Contrase�a"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Empleado"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Empresa"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError"), org.apache.axis.description.ParameterDesc.INOUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"), boolean.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje"), org.apache.axis.description.ParameterDesc.INOUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ArrayOfSubordinado"));
        oper.setReturnClass(Subordinado[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "getLineaInferiorPorEmpleadoRepResult"));
        param = oper.getReturnParamDesc();
        param.setItemQName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Subordinado"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[26] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("existeEmpleado");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Usuario"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Contrase�a"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Empleado"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Empresa"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError"), org.apache.axis.description.ParameterDesc.INOUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"), boolean.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje"), org.apache.axis.description.ParameterDesc.INOUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        oper.setReturnClass(int.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "existeEmpleadoResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[27] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getCentroCostosTVA");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Usuario"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Contrase�a"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Empleado"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError"), org.apache.axis.description.ParameterDesc.INOUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"), boolean.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje"), org.apache.axis.description.ParameterDesc.INOUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        oper.setReturnClass(long.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "getCentroCostosTVAResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[28] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getRankingMapaTalento");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Usuario"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Contrase�a"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Empleado"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Empresa"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "PerteneceRanking"), org.apache.axis.description.ParameterDesc.INOUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"), boolean.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError"), org.apache.axis.description.ParameterDesc.INOUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"), boolean.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje"), org.apache.axis.description.ParameterDesc.INOUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(org.apache.axis.encoding.XMLType.AXIS_VOID);
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[29] = oper;

    }

    private static void _initOperationDesc4(){
        org.apache.axis.description.OperationDesc oper;
        org.apache.axis.description.ParameterDesc param;
        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getCuentaBancoEmpleado");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Usuario"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Contrase�a"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Empleado"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Empresa"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "CuentaBanco"), org.apache.axis.description.ParameterDesc.INOUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError"), org.apache.axis.description.ParameterDesc.INOUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"), boolean.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje"), org.apache.axis.description.ParameterDesc.INOUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(org.apache.axis.encoding.XMLType.AXIS_VOID);
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[30] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getCuentaBanco");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Usuario"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Contrasenia"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Empleado"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Empresa"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "CuentaBanco"), org.apache.axis.description.ParameterDesc.INOUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError"), org.apache.axis.description.ParameterDesc.INOUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"), boolean.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje"), org.apache.axis.description.ParameterDesc.INOUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(org.apache.axis.encoding.XMLType.AXIS_VOID);
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[31] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getDatosEmpleadosBaja");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Usuario"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Contrase�a"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Empleado"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ArrayOfInt"), int[].class, false, false);
        param.setItemQName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "int"));
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Empresa"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError"), org.apache.axis.description.ParameterDesc.INOUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"), boolean.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje"), org.apache.axis.description.ParameterDesc.INOUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ArrayOfEmpleadoBaja"));
        oper.setReturnClass(EmpleadoBaja[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "getDatosEmpleadosBajaResult"));
        param = oper.getReturnParamDesc();
        param.setItemQName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "EmpleadoBaja"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[32] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("setSolicitudBajaPlantillaDinamica");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Usuario"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Contrase�a"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "EmpleadoBaja"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Empresa"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "FolioFBP"), org.apache.axis.description.ParameterDesc.INOUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError"), org.apache.axis.description.ParameterDesc.INOUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"), boolean.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje"), org.apache.axis.description.ParameterDesc.INOUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(org.apache.axis.encoding.XMLType.AXIS_VOID);
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[33] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("setSolicitudBajaTarjetasAmarillas");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Usuario"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Contrase�a"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "EmpleadoBaja"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Empresa"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "FolioFBP"), org.apache.axis.description.ParameterDesc.INOUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError"), org.apache.axis.description.ParameterDesc.INOUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"), boolean.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje"), org.apache.axis.description.ParameterDesc.INOUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(org.apache.axis.encoding.XMLType.AXIS_VOID);
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[34] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getSeguimientoBajaPlantillaDinamica");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Usuario"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Contrase�a"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "FolioFBP"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Empresa"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "EmpleadoGestionBaja"), org.apache.axis.description.ParameterDesc.INOUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Estatus"), org.apache.axis.description.ParameterDesc.INOUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "FechaActualizacion"), org.apache.axis.description.ParameterDesc.INOUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError"), org.apache.axis.description.ParameterDesc.INOUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"), boolean.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje"), org.apache.axis.description.ParameterDesc.INOUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(org.apache.axis.encoding.XMLType.AXIS_VOID);
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[35] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("setDigitalizacionDocumentosEmpleado");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Usuario"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Contrase�a"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Empleado"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Pais"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Documento"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Tipo"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Etapa"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError"), org.apache.axis.description.ParameterDesc.INOUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"), boolean.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje"), org.apache.axis.description.ParameterDesc.INOUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(org.apache.axis.encoding.XMLType.AXIS_VOID);
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[36] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getQ12Empleado");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Usuario"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Contrase�a"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Empleado"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Empresa"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Periodo"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ListaEmpleado"), org.apache.axis.description.ParameterDesc.INOUT, new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ArrayOfEmpleadoQ12"), EmpleadoQ12[].class, false, false);
        param.setItemQName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "EmpleadoQ12"));
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError"), org.apache.axis.description.ParameterDesc.INOUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"), boolean.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje"), org.apache.axis.description.ParameterDesc.INOUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(org.apache.axis.encoding.XMLType.AXIS_VOID);
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[37] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getRanking_Empleado");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Usuario"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Contrase�a"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Empresa"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Pais"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Fecha"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Funcion"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Nivel"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "CC"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Periodo"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError"), org.apache.axis.description.ParameterDesc.INOUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"), boolean.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje"), org.apache.axis.description.ParameterDesc.INOUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(org.apache.axis.encoding.XMLType.AXIS_VOID);
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[38] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getConsultaCargaVacacionesGeo");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Usuario"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Contrase�a"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError"), org.apache.axis.description.ParameterDesc.INOUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"), boolean.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje"), org.apache.axis.description.ParameterDesc.INOUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ArrayOfVacacionesGeo"));
        oper.setReturnClass(VacacionesGeo[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "getConsultaCargaVacacionesGeoResult"));
        param = oper.getReturnParamDesc();
        param.setItemQName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "VacacionesGeo"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[39] = oper;

    }

    private static void _initOperationDesc5(){
        org.apache.axis.description.OperationDesc oper;
        org.apache.axis.description.ParameterDesc param;
        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getTarjetaAmarilla_Periodo");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Usuario"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Contrase�a"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Fecha"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError"), org.apache.axis.description.ParameterDesc.INOUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"), boolean.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje"), org.apache.axis.description.ParameterDesc.INOUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ArrayOfTarjetaAmarilla_Periodo"));
        oper.setReturnClass(TarjetaAmarilla_Periodo[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "getTarjetaAmarilla_PeriodoResult"));
        param = oper.getReturnParamDesc();
        param.setItemQName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "TarjetaAmarilla_Periodo"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[40] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getDetalleBaja");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Usuario"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Contrase�a"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Empleado"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Empresa"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError"), org.apache.axis.description.ParameterDesc.INOUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"), boolean.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje"), org.apache.axis.description.ParameterDesc.INOUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ArrayOfDetalleBaja"));
        oper.setReturnClass(DetalleBaja[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "getDetalleBajaResult"));
        param = oper.getReturnParamDesc();
        param.setItemQName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "DetalleBaja"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[41] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getDescPlaza");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Usuario"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Contrase�a"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "CentroCostos"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Pais"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError"), org.apache.axis.description.ParameterDesc.INOUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"), boolean.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje"), org.apache.axis.description.ParameterDesc.INOUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ArrayOfPlaza"));
        oper.setReturnClass(Plaza[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "getDescPlazaResult"));
        param = oper.getReturnParamDesc();
        param.setItemQName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Plaza"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[42] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getBeneficiariosEmpleado");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Usuario"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Contrase�a"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Empleado"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Empresa"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "TipoBeneficiario"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Pais"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError"), org.apache.axis.description.ParameterDesc.INOUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"), boolean.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje"), org.apache.axis.description.ParameterDesc.INOUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Beneficiarios"));
        oper.setReturnClass(Beneficiarios.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "getBeneficiariosEmpleadoResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[43] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getEmpleadoCoincideNombreRFC");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Usuario"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Contrase�a"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Nombre"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ApPaterno"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ApMaterno"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Pais"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Empresa"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "RegCed"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError"), org.apache.axis.description.ParameterDesc.INOUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"), boolean.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje"), org.apache.axis.description.ParameterDesc.INOUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ArrayOfDatosCoincidencias"));
        oper.setReturnClass(DatosCoincidencias[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "getEmpleadoCoincideNombreRFCResult"));
        param = oper.getReturnParamDesc();
        param.setItemQName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "DatosCoincidencias"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[44] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getEmpleadoIncapacidadSAP");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Usuario"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Contrase�a"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Empleado"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Empresa"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Fecha"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Pais"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError"), org.apache.axis.description.ParameterDesc.INOUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"), boolean.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje"), org.apache.axis.description.ParameterDesc.INOUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ArrayOfAuscencia"));
        oper.setReturnClass(Auscencia[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "getEmpleadoIncapacidadSAPResult"));
        param = oper.getReturnParamDesc();
        param.setItemQName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Auscencia"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[45] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getEmpleadoAuscentismo");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Usuario"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Contrase�a"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Empleado"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Empresa"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Fecha"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Pais"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError"), org.apache.axis.description.ParameterDesc.INOUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"), boolean.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje"), org.apache.axis.description.ParameterDesc.INOUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ArrayOfAuscencia"));
        oper.setReturnClass(Auscencia[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "getEmpleadoAuscentismoResult"));
        param = oper.getReturnParamDesc();
        param.setItemQName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Auscencia"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[46] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getDatosEmpleadosMasivo");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Usuario"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Contrase�a"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Empleado"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ArrayOfEmpleadoEmp"), EmpleadoEmp[].class, false, false);
        param.setItemQName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "EmpleadoEmp"));
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Empresa"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError"), org.apache.axis.description.ParameterDesc.INOUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"), boolean.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje"), org.apache.axis.description.ParameterDesc.INOUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ArrayOfEmpleadoGral"));
        oper.setReturnClass(EmpleadoGral[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "getDatosEmpleadosResult"));
        param = oper.getReturnParamDesc();
        param.setItemQName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "EmpleadoGral"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[47] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getValidaCuentaNegocio");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Usuario"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Contrase�a"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "CuentaBanco"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Empresa"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ValNegocio"), org.apache.axis.description.ParameterDesc.INOUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError"), org.apache.axis.description.ParameterDesc.INOUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"), boolean.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje"), org.apache.axis.description.ParameterDesc.INOUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(org.apache.axis.encoding.XMLType.AXIS_VOID);
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[48] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getValidaCuentaEmpleado");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Usuario"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Contrase�a"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "CuentaBanco"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Empresa"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Empleado"), org.apache.axis.description.ParameterDesc.INOUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError"), org.apache.axis.description.ParameterDesc.INOUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"), boolean.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje"), org.apache.axis.description.ParameterDesc.INOUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(org.apache.axis.encoding.XMLType.AXIS_VOID);
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[49] = oper;

    }

    private static void _initOperationDesc6(){
        org.apache.axis.description.OperationDesc oper;
        org.apache.axis.description.ParameterDesc param;
        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getEmpleadoPromocion");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Usuario"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Contrase�a"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "NumeroEmpleado"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Empresa"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError"), org.apache.axis.description.ParameterDesc.INOUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"), boolean.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje"), org.apache.axis.description.ParameterDesc.INOUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ArrayOfEmpleadoPromocion"));
        oper.setReturnClass(EmpleadoPromocion[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "getEmpleadoPromocionResult"));
        param = oper.getReturnParamDesc();
        param.setItemQName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "EmpleadoPromocion"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[50] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getClienteUnicoEmpleado");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Usuario"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Contrase�a"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Empleado"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Empresa"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError"), org.apache.axis.description.ParameterDesc.INOUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"), boolean.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje"), org.apache.axis.description.ParameterDesc.INOUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        oper.setReturnClass(java.lang.String.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "getClienteUnicoEmpleadoResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[51] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getCuotaPatronal");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Usuario"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Contrasena"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Empresa"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Compania"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Anio"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Periodo"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError"), org.apache.axis.description.ParameterDesc.INOUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"), boolean.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje"), org.apache.axis.description.ParameterDesc.INOUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "CuotasPatronales"));
        oper.setReturnClass(CuotasPatronales.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "getCuotaPatronalResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[52] = oper;

    }

    public EmpleadoGeneralSoapStub() throws org.apache.axis.AxisFault {
         this(null);
    }

    public EmpleadoGeneralSoapStub(java.net.URL endpointURL, javax.xml.rpc.Service service) throws org.apache.axis.AxisFault {
         this(service);
         super.cachedEndpoint = endpointURL;
    }

	public EmpleadoGeneralSoapStub(javax.xml.rpc.Service service) throws org.apache.axis.AxisFault {
        if (service == null) {
            super.service = new org.apache.axis.client.Service();
        } else {
            super.service = service;
        }
        ((org.apache.axis.client.Service)super.service).setTypeMappingVersion("1.2");
            java.lang.Class cls;
            javax.xml.namespace.QName qName;
            javax.xml.namespace.QName qName2;
            java.lang.Class beansf = org.apache.axis.encoding.ser.BeanSerializerFactory.class;
            java.lang.Class beandf = org.apache.axis.encoding.ser.BeanDeserializerFactory.class;
            java.lang.Class enumsf = org.apache.axis.encoding.ser.EnumSerializerFactory.class;
            java.lang.Class enumdf = org.apache.axis.encoding.ser.EnumDeserializerFactory.class;
            java.lang.Class arraysf = org.apache.axis.encoding.ser.ArraySerializerFactory.class;
            java.lang.Class arraydf = org.apache.axis.encoding.ser.ArrayDeserializerFactory.class;
            java.lang.Class simplesf = org.apache.axis.encoding.ser.SimpleSerializerFactory.class;
            java.lang.Class simpledf = org.apache.axis.encoding.ser.SimpleDeserializerFactory.class;
            java.lang.Class simplelistsf = org.apache.axis.encoding.ser.SimpleListSerializerFactory.class;
            java.lang.Class simplelistdf = org.apache.axis.encoding.ser.SimpleListDeserializerFactory.class;
        addBindings0();
        addBindings1();
    }

	private void addBindings0() {
            java.lang.Class cls;
            javax.xml.namespace.QName qName;
            javax.xml.namespace.QName qName2;
            java.lang.Class beansf = org.apache.axis.encoding.ser.BeanSerializerFactory.class;
            java.lang.Class beandf = org.apache.axis.encoding.ser.BeanDeserializerFactory.class;
            java.lang.Class enumsf = org.apache.axis.encoding.ser.EnumSerializerFactory.class;
            java.lang.Class enumdf = org.apache.axis.encoding.ser.EnumDeserializerFactory.class;
            java.lang.Class arraysf = org.apache.axis.encoding.ser.ArraySerializerFactory.class;
            java.lang.Class arraydf = org.apache.axis.encoding.ser.ArrayDeserializerFactory.class;
            java.lang.Class simplesf = org.apache.axis.encoding.ser.SimpleSerializerFactory.class;
            java.lang.Class simpledf = org.apache.axis.encoding.ser.SimpleDeserializerFactory.class;
            java.lang.Class simplelistsf = org.apache.axis.encoding.ser.SimpleListSerializerFactory.class;
            java.lang.Class simplelistdf = org.apache.axis.encoding.ser.SimpleListDeserializerFactory.class;
            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", ">>getHuellaClienteUnicoLAMResponse>getHuellaClienteUnicoLAMResult");
            cachedSerQNames.add(qName);
            cls = GetHuellaClienteUnicoLAMResponseGetHuellaClienteUnicoLAMResult.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", ">>getHuellaClienteUnicoQAResponse>getHuellaClienteUnicoQAResult");
            cachedSerQNames.add(qName);
            cls = GetHuellaClienteUnicoQAResponseGetHuellaClienteUnicoQAResult.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", ">>getHuellaClienteUnicoResponse>getHuellaClienteUnicoResult");
            cachedSerQNames.add(qName);
            cls = GetHuellaClienteUnicoResponseGetHuellaClienteUnicoResult.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", ">existeEmpleado");
            cachedSerQNames.add(qName);
            cls = ExisteEmpleado.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", ">existeEmpleadoResponse");
            cachedSerQNames.add(qName);
            cls = ExisteEmpleadoResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", ">getBeneficiariosEmpleado");
            cachedSerQNames.add(qName);
            cls = GetBeneficiariosEmpleado.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", ">getBeneficiariosEmpleadoResponse");
            cachedSerQNames.add(qName);
            cls = GetBeneficiariosEmpleadoResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", ">getCentroCostosTVA");
            cachedSerQNames.add(qName);
            cls = GetCentroCostosTVA.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", ">getCentroCostosTVAResponse");
            cachedSerQNames.add(qName);
            cls = GetCentroCostosTVAResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", ">getClienteUnicoEmpleado");
            cachedSerQNames.add(qName);
            cls = GetClienteUnicoEmpleado.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", ">getClienteUnicoEmpleadoResponse");
            cachedSerQNames.add(qName);
            cls = GetClienteUnicoEmpleadoResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", ">getCoincidencias");
            cachedSerQNames.add(qName);
            cls = GetCoincidencias.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", ">getCoincidenciasResponse");
            cachedSerQNames.add(qName);
            cls = GetCoincidenciasResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", ">getConsultaCargaVacacionesGeo");
            cachedSerQNames.add(qName);
            cls = GetConsultaCargaVacacionesGeo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", ">getConsultaCargaVacacionesGeoResponse");
            cachedSerQNames.add(qName);
            cls = GetConsultaCargaVacacionesGeoResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", ">getCuentaBanco");
            cachedSerQNames.add(qName);
            cls = GetCuentaBanco.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", ">getCuentaBancoEmpleado");
            cachedSerQNames.add(qName);
            cls = GetCuentaBancoEmpleado.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", ">getCuentaBancoEmpleadoResponse");
            cachedSerQNames.add(qName);
            cls = GetCuentaBancoEmpleadoResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", ">getCuentaBancoResponse");
            cachedSerQNames.add(qName);
            cls = GetCuentaBancoResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", ">getCuotaPatronal");
            cachedSerQNames.add(qName);
            cls = GetCuotaPatronal.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", ">getCuotaPatronalResponse");
            cachedSerQNames.add(qName);
            cls = GetCuotaPatronalResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", ">getDatosEmpleados");
            cachedSerQNames.add(qName);
            cls = GetDatosEmpleados.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", ">getDatosEmpleadosBaja");
            cachedSerQNames.add(qName);
            cls = GetDatosEmpleadosBaja.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", ">getDatosEmpleadosBajaResponse");
            cachedSerQNames.add(qName);
            cls = GetDatosEmpleadosBajaResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", ">getDatosEmpleadosResponse");
            cachedSerQNames.add(qName);
            cls = GetDatosEmpleadosResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", ">getDescPlaza");
            cachedSerQNames.add(qName);
            cls = GetDescPlaza.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", ">getDescPlazaResponse");
            cachedSerQNames.add(qName);
            cls = GetDescPlazaResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", ">getDetalleBaja");
            cachedSerQNames.add(qName);
            cls = GetDetalleBaja.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", ">getDetalleBajaResponse");
            cachedSerQNames.add(qName);
            cls = GetDetalleBajaResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", ">getEmpleadoAuscentismo");
            cachedSerQNames.add(qName);
            cls = GetEmpleadoAuscentismo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", ">getEmpleadoAuscentismoResponse");
            cachedSerQNames.add(qName);
            cls = GetEmpleadoAuscentismoResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", ">getEmpleadoCoincideNombreRFC");
            cachedSerQNames.add(qName);
            cls = GetEmpleadoCoincideNombreRFC.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", ">getEmpleadoCoincideNombreRFCResponse");
            cachedSerQNames.add(qName);
            cls = GetEmpleadoCoincideNombreRFCResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", ">getEmpleadoIncapacidadSAP");
            cachedSerQNames.add(qName);
            cls = GetEmpleadoIncapacidadSAP.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", ">getEmpleadoIncapacidadSAPResponse");
            cachedSerQNames.add(qName);
            cls = GetEmpleadoIncapacidadSAPResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", ">getEmpleadoPromocion");
            cachedSerQNames.add(qName);
            cls = GetEmpleadoPromocion.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", ">getEmpleadoPromocionResponse");
            cachedSerQNames.add(qName);
            cls = GetEmpleadoPromocionResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", ">getFechaPago");
            cachedSerQNames.add(qName);
            cls = GetFechaPago.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", ">getFechaPagoResponse");
            cachedSerQNames.add(qName);
            cls = GetFechaPagoResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", ">getHuellaClienteUnicoLAM");
            cachedSerQNames.add(qName);
            cls = GetHuellaClienteUnicoLAM.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", ">getHuellaClienteUnicoLAMResponse");
            cachedSerQNames.add(qName);
            cls = GetHuellaClienteUnicoLAMResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", ">getHuellaClienteUnicoQA");
            cachedSerQNames.add(qName);
            cls = GetHuellaClienteUnicoQA.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", ">getHuellaClienteUnicoQAResponse");
            cachedSerQNames.add(qName);
            cls = GetHuellaClienteUnicoQAResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", ">getLineaInferior");
            cachedSerQNames.add(qName);
            cls = GetLineaInferior.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", ">getLineaInferiorPorEmpleadoRep");
            cachedSerQNames.add(qName);
            cls = GetLineaInferiorPorEmpleadoRep.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", ">getLineaInferiorPorEmpleadoRepResponse");
            cachedSerQNames.add(qName);
            cls = GetLineaInferiorPorEmpleadoRepResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", ">getLineaInferiorResponse");
            cachedSerQNames.add(qName);
            cls = GetLineaInferiorResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", ">getLineaInferiorSAP");
            cachedSerQNames.add(qName);
            cls = GetLineaInferiorSAP.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", ">getLineaInferiorSAPResponse");
            cachedSerQNames.add(qName);
            cls = GetLineaInferiorSAPResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", ">getLineaSuperior");
            cachedSerQNames.add(qName);
            cls = GetLineaSuperior.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", ">getLineaSuperiorResponse");
            cachedSerQNames.add(qName);
            cls = GetLineaSuperiorResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", ">getQ12Empleado");
            cachedSerQNames.add(qName);
            cls = GetQ12Empleado.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", ">getQ12EmpleadoResponse");
            cachedSerQNames.add(qName);
            cls = GetQ12EmpleadoResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", ">getRanking_Empleado");
            cachedSerQNames.add(qName);
            cls = GetRanking_Empleado.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", ">getRanking_EmpleadoResponse");
            cachedSerQNames.add(qName);
            cls = GetRanking_EmpleadoResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", ">getRankingMapaTalento");
            cachedSerQNames.add(qName);
            cls = GetRankingMapaTalento.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", ">getRankingMapaTalentoResponse");
            cachedSerQNames.add(qName);
            cls = GetRankingMapaTalentoResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", ">getSeguimientoBajaPlantillaDinamica");
            cachedSerQNames.add(qName);
            cls = GetSeguimientoBajaPlantillaDinamica.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", ">getSeguimientoBajaPlantillaDinamicaResponse");
            cachedSerQNames.add(qName);
            cls = GetSeguimientoBajaPlantillaDinamicaResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", ">getTarjetaAmarilla_Periodo");
            cachedSerQNames.add(qName);
            cls = GetTarjetaAmarilla_Periodo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", ">getTarjetaAmarilla_PeriodoResponse");
            cachedSerQNames.add(qName);
            cls = GetTarjetaAmarilla_PeriodoResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", ">getValidaCuentaEmpleado");
            cachedSerQNames.add(qName);
            cls = GetValidaCuentaEmpleado.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", ">getValidaCuentaEmpleadoResponse");
            cachedSerQNames.add(qName);
            cls = GetValidaCuentaEmpleadoResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", ">getValidaCuentaNegocio");
            cachedSerQNames.add(qName);
            cls = GetValidaCuentaNegocio.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", ">getValidaCuentaNegocioResponse");
            cachedSerQNames.add(qName);
            cls = GetValidaCuentaNegocioResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", ">setDigitalizacionDocumentosEmpleado");
            cachedSerQNames.add(qName);
            cls = SetDigitalizacionDocumentosEmpleado.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", ">setDigitalizacionDocumentosEmpleadoResponse");
            cachedSerQNames.add(qName);
            cls = SetDigitalizacionDocumentosEmpleadoResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", ">setSolicitudBajaPlantillaDinamica");
            cachedSerQNames.add(qName);
            cls = SetSolicitudBajaPlantillaDinamica.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", ">setSolicitudBajaPlantillaDinamicaResponse");
            cachedSerQNames.add(qName);
            cls = SetSolicitudBajaPlantillaDinamicaResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", ">setSolicitudBajaTarjetasAmarillas");
            cachedSerQNames.add(qName);
            cls = SetSolicitudBajaTarjetasAmarillas.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", ">setSolicitudBajaTarjetasAmarillasResponse");
            cachedSerQNames.add(qName);
            cls = SetSolicitudBajaTarjetasAmarillasResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Afiliacion");
            cachedSerQNames.add(qName);
            cls = Afiliacion.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ArrayOfAuscencia");
            cachedSerQNames.add(qName);
            cls = Auscencia[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Auscencia");
            qName2 = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Auscencia");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ArrayOfBeneficiariosEmpleado");
            cachedSerQNames.add(qName);
            cls = BeneficiariosEmpleado[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "BeneficiariosEmpleado");
            qName2 = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "BeneficiariosEmpleado");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ArrayOfCoincidencia");
            cachedSerQNames.add(qName);
            cls = Coincidencia[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Coincidencia");
            qName2 = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Coincidencia");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ArrayOfCuotaPatronal");
            cachedSerQNames.add(qName);
            cls = CuotaPatronal[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "CuotaPatronal");
            qName2 = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "CuotaPatronal");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ArrayOfDatosCoincidencias");
            cachedSerQNames.add(qName);
            cls = DatosCoincidencias[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "DatosCoincidencias");
            qName2 = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "DatosCoincidencias");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ArrayOfDetalleBaja");
            cachedSerQNames.add(qName);
            cls = DetalleBaja[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "DetalleBaja");
            qName2 = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "DetalleBaja");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ArrayOfEmpleado");
            cachedSerQNames.add(qName);
            cls = Empleado[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Empleado");
            qName2 = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Empleado");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ArrayOfEmpleadoBaja");
            cachedSerQNames.add(qName);
            cls = EmpleadoBaja[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "EmpleadoBaja");
            qName2 = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "EmpleadoBaja");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ArrayOfEmpleadoEmp");
            cachedSerQNames.add(qName);
            cls = EmpleadoEmp[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "EmpleadoEmp");
            qName2 = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "EmpleadoEmp");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ArrayOfEmpleadoGral");
            cachedSerQNames.add(qName);
            cls = EmpleadoGral[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "EmpleadoGral");
            qName2 = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "EmpleadoGral");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ArrayOfEmpleadoPromocion");
            cachedSerQNames.add(qName);
            cls = EmpleadoPromocion[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "EmpleadoPromocion");
            qName2 = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "EmpleadoPromocion");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ArrayOfEmpleadoQ12");
            cachedSerQNames.add(qName);
            cls = EmpleadoQ12[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "EmpleadoQ12");
            qName2 = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "EmpleadoQ12");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ArrayOfFamilia");
            cachedSerQNames.add(qName);
            cls = Familia[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Familia");
            qName2 = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Familia");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ArrayOfIncapacidad");
            cachedSerQNames.add(qName);
            cls = Incapacidad[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Incapacidad");
            qName2 = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Incapacidad");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ArrayOfInt");
            cachedSerQNames.add(qName);
            cls = int[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int");
            qName2 = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "int");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ArrayOfPlaza");
            cachedSerQNames.add(qName);
            cls = Plaza[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Plaza");
            qName2 = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Plaza");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ArrayOfSubordinado");
            cachedSerQNames.add(qName);
            cls = Subordinado[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Subordinado");
            qName2 = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Subordinado");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ArrayOfSuperiores");
            cachedSerQNames.add(qName);
            cls = Superiores[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Superiores");
            qName2 = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Superiores");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ArrayOfTarjetaAmarilla_Periodo");
            cachedSerQNames.add(qName);
            cls = TarjetaAmarilla_Periodo[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "TarjetaAmarilla_Periodo");
            qName2 = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "TarjetaAmarilla_Periodo");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ArrayOfTarjetasAmarillasSIE");
            cachedSerQNames.add(qName);
            cls = TarjetasAmarillasSIE[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "TarjetasAmarillasSIE");
            qName2 = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "TarjetasAmarillasSIE");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ArrayOfVacacionesGeo");
            cachedSerQNames.add(qName);
            cls = VacacionesGeo[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "VacacionesGeo");
            qName2 = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "VacacionesGeo");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ArrayOfVacante");
            cachedSerQNames.add(qName);
            cls = Vacante[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Vacante");
            qName2 = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Vacante");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Auscencia");
            cachedSerQNames.add(qName);
            cls = Auscencia.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Beneficiarios");
            cachedSerQNames.add(qName);
            cls = Beneficiarios.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "BeneficiariosEmpleado");
            cachedSerQNames.add(qName);
            cls = BeneficiariosEmpleado.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Coincidencia");
            cachedSerQNames.add(qName);
            cls = Coincidencia.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "CuotaPatronal");
            cachedSerQNames.add(qName);
            cls = CuotaPatronal.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "CuotasPatronales");
            cachedSerQNames.add(qName);
            cls = CuotasPatronales.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

    }
	private void addBindings1() {
            java.lang.Class cls;
            javax.xml.namespace.QName qName;
            javax.xml.namespace.QName qName2;
            java.lang.Class beansf = org.apache.axis.encoding.ser.BeanSerializerFactory.class;
            java.lang.Class beandf = org.apache.axis.encoding.ser.BeanDeserializerFactory.class;
            java.lang.Class enumsf = org.apache.axis.encoding.ser.EnumSerializerFactory.class;
            java.lang.Class enumdf = org.apache.axis.encoding.ser.EnumDeserializerFactory.class;
            java.lang.Class arraysf = org.apache.axis.encoding.ser.ArraySerializerFactory.class;
            java.lang.Class arraydf = org.apache.axis.encoding.ser.ArrayDeserializerFactory.class;
            java.lang.Class simplesf = org.apache.axis.encoding.ser.SimpleSerializerFactory.class;
            java.lang.Class simpledf = org.apache.axis.encoding.ser.SimpleDeserializerFactory.class;
            java.lang.Class simplelistsf = org.apache.axis.encoding.ser.SimpleListSerializerFactory.class;
            java.lang.Class simplelistdf = org.apache.axis.encoding.ser.SimpleListDeserializerFactory.class;
            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "DatosCoincidencias");
            cachedSerQNames.add(qName);
            cls = DatosCoincidencias.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "DetalleBaja");
            cachedSerQNames.add(qName);
            cls = DetalleBaja.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Direccion");
            cachedSerQNames.add(qName);
            cls = Direccion.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Empleado");
            cachedSerQNames.add(qName);
            cls = Empleado.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "EmpleadoBaja");
            cachedSerQNames.add(qName);
            cls = EmpleadoBaja.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "EmpleadoDExpress");
            cachedSerQNames.add(qName);
            cls = EmpleadoDExpress.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "EmpleadoEmp");
            cachedSerQNames.add(qName);
            cls = EmpleadoEmp.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "EmpleadoGral");
            cachedSerQNames.add(qName);
            cls = EmpleadoGral.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "EmpleadoPromocion");
            cachedSerQNames.add(qName);
            cls = EmpleadoPromocion.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "EmpleadoQ12");
            cachedSerQNames.add(qName);
            cls = EmpleadoQ12.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Estructura_DatosCorreo");
            cachedSerQNames.add(qName);
            cls = Estructura_DatosCorreo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Familia");
            cachedSerQNames.add(qName);
            cls = Familia.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Fecha");
            cachedSerQNames.add(qName);
            cls = Fecha.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Funcion");
            cachedSerQNames.add(qName);
            cls = Funcion.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Incapacidad");
            cachedSerQNames.add(qName);
            cls = Incapacidad.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Nomina");
            cachedSerQNames.add(qName);
            cls = Nomina.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Plaza");
            cachedSerQNames.add(qName);
            cls = Plaza.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ResumenCuotaPatronal");
            cachedSerQNames.add(qName);
            cls = ResumenCuotaPatronal.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Subordinado");
            cachedSerQNames.add(qName);
            cls = Subordinado.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Sueldo");
            cachedSerQNames.add(qName);
            cls = Sueldo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Superiores");
            cachedSerQNames.add(qName);
            cls = Superiores.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "TarjetaAmarilla_Periodo");
            cachedSerQNames.add(qName);
            cls = TarjetaAmarilla_Periodo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "TarjetasAmarillas");
            cachedSerQNames.add(qName);
            cls = TarjetasAmarillas.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "TarjetasAmarillasCtaBanco");
            cachedSerQNames.add(qName);
            cls = TarjetasAmarillasCtaBanco.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "TarjetasAmarillasSIE");
            cachedSerQNames.add(qName);
            cls = TarjetasAmarillasSIE.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "VacacionesGeo");
            cachedSerQNames.add(qName);
            cls = VacacionesGeo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Vacante");
            cachedSerQNames.add(qName);
            cls = Vacante.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

    }

	protected org.apache.axis.client.Call createCall() throws java.rmi.RemoteException {
        try {
            org.apache.axis.client.Call _call = super._createCall();
            if (super.maintainSessionSet) {
                _call.setMaintainSession(super.maintainSession);
            }
            if (super.cachedUsername != null) {
                _call.setUsername(super.cachedUsername);
            }
            if (super.cachedPassword != null) {
                _call.setPassword(super.cachedPassword);
            }
            if (super.cachedEndpoint != null) {
                _call.setTargetEndpointAddress(super.cachedEndpoint);
            }
            if (super.cachedTimeout != null) {
                _call.setTimeout(super.cachedTimeout);
            }
            if (super.cachedPortName != null) {
                _call.setPortName(super.cachedPortName);
            }
            java.util.Enumeration keys = super.cachedProperties.keys();
            while (keys.hasMoreElements()) {
                java.lang.String key = (java.lang.String) keys.nextElement();
                _call.setProperty(key, super.cachedProperties.get(key));
            }
            // All the type mapping information is registered
            // when the first call is made.
            // The type mapping information is actually registered in
            // the TypeMappingRegistry of the service, which
            // is the reason why registration is only needed for the first call.
            synchronized (this) {
                if (firstCall()) {
                    // must set encoding style before registering serializers
                    _call.setEncodingStyle(null);
                    for (int i = 0; i < cachedSerFactories.size(); ++i) {
                        java.lang.Class cls = (java.lang.Class) cachedSerClasses.get(i);
                        javax.xml.namespace.QName qName =
                                (javax.xml.namespace.QName) cachedSerQNames.get(i);
                        java.lang.Object x = cachedSerFactories.get(i);
                        if (x instanceof Class) {
                            java.lang.Class sf = (java.lang.Class)
                                 cachedSerFactories.get(i);
                            java.lang.Class df = (java.lang.Class)
                                 cachedDeserFactories.get(i);
                            _call.registerTypeMapping(cls, qName, sf, df, false);
                        }
                        else if (x instanceof javax.xml.rpc.encoding.SerializerFactory) {
                            org.apache.axis.encoding.SerializerFactory sf = (org.apache.axis.encoding.SerializerFactory)
                                 cachedSerFactories.get(i);
                            org.apache.axis.encoding.DeserializerFactory df = (org.apache.axis.encoding.DeserializerFactory)
                                 cachedDeserFactories.get(i);
                            _call.registerTypeMapping(cls, qName, sf, df, false);
                        }
                    }
                }
            }
            return _call;
        }
        catch (java.lang.Throwable _t) {
            throw new org.apache.axis.AxisFault("Failure trying to get the Call object", _t);
        }
    }

	public Empleado getEmpleadoGeneral(java.lang.String usuario, java.lang.String contrase�a, int empleado, java.lang.String empresa, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[0]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://SistemasRH.com/DatosGenerales/getEmpleadoGeneral");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "getEmpleadoGeneral"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {usuario, contrase�a, new java.lang.Integer(empleado), empresa, new java.lang.Boolean(existeError.value), mensaje.value});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            java.util.Map _output;
            _output = _call.getOutputParams();
            try {
                existeError.value = ((java.lang.Boolean) _output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError"))).booleanValue();
            } catch (java.lang.Exception _exception) {
                existeError.value = ((java.lang.Boolean) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError")), boolean.class)).booleanValue();
            }
            try {
                mensaje.value = (java.lang.String) _output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje"));
            } catch (java.lang.Exception _exception) {
                mensaje.value = (java.lang.String) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje")), java.lang.String.class);
            }
            try {
                return (Empleado) _resp;
            } catch (java.lang.Exception _exception) {
                return (Empleado) org.apache.axis.utils.JavaUtils.convert(_resp, Empleado.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

	public EmpleadoDExpress getEmpleadoGeneralDineroExpress(java.lang.String usuario, java.lang.String contrase�a, int empleado, java.lang.String empresa, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[1]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://SistemasRH.com/DatosGenerales/getEmpleadoGeneralDineroExpress");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "getEmpleadoGeneralDineroExpress"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {usuario, contrase�a, new java.lang.Integer(empleado), empresa, new java.lang.Boolean(existeError.value), mensaje.value});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            java.util.Map _output;
            _output = _call.getOutputParams();
            try {
                existeError.value = ((java.lang.Boolean) _output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError"))).booleanValue();
            } catch (java.lang.Exception _exception) {
                existeError.value = ((java.lang.Boolean) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError")), boolean.class)).booleanValue();
            }
            try {
                mensaje.value = (java.lang.String) _output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje"));
            } catch (java.lang.Exception _exception) {
                mensaje.value = (java.lang.String) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje")), java.lang.String.class);
            }
            try {
                return (EmpleadoDExpress) _resp;
            } catch (java.lang.Exception _exception) {
                return (EmpleadoDExpress) org.apache.axis.utils.JavaUtils.convert(_resp, EmpleadoDExpress.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

	public TarjetasAmarillas getTarjetaAmarillaEmpleado(java.lang.String usuario, java.lang.String contrase�a, int empleado, java.lang.String empresa, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[2]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://SistemasRH.com/DatosGenerales/getTarjetaAmarillaEmpleado");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "getTarjetaAmarillaEmpleado"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {usuario, contrase�a, new java.lang.Integer(empleado), empresa, new java.lang.Boolean(existeError.value), mensaje.value});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            java.util.Map _output;
            _output = _call.getOutputParams();
            try {
                existeError.value = ((java.lang.Boolean) _output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError"))).booleanValue();
            } catch (java.lang.Exception _exception) {
                existeError.value = ((java.lang.Boolean) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError")), boolean.class)).booleanValue();
            }
            try {
                mensaje.value = (java.lang.String) _output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje"));
            } catch (java.lang.Exception _exception) {
                mensaje.value = (java.lang.String) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje")), java.lang.String.class);
            }
            try {
                return (TarjetasAmarillas) _resp;
            } catch (java.lang.Exception _exception) {
                return (TarjetasAmarillas) org.apache.axis.utils.JavaUtils.convert(_resp, TarjetasAmarillas.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

	public TarjetasAmarillasCtaBanco getTarjetaAmarillaCtaBanco(java.lang.String usuario, java.lang.String contrase�a, java.lang.String cuentaBanco, java.lang.String empresa, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[3]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://SistemasRH.com/DatosGenerales/getTarjetaAmarillaCtaBanco");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "getTarjetaAmarillaCtaBanco"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {usuario, contrase�a, cuentaBanco, empresa, new java.lang.Boolean(existeError.value), mensaje.value});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            java.util.Map _output;
            _output = _call.getOutputParams();
            try {
                existeError.value = ((java.lang.Boolean) _output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError"))).booleanValue();
            } catch (java.lang.Exception _exception) {
                existeError.value = ((java.lang.Boolean) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError")), boolean.class)).booleanValue();
            }
            try {
                mensaje.value = (java.lang.String) _output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje"));
            } catch (java.lang.Exception _exception) {
                mensaje.value = (java.lang.String) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje")), java.lang.String.class);
            }
            try {
                return (TarjetasAmarillasCtaBanco) _resp;
            } catch (java.lang.Exception _exception) {
                return (TarjetasAmarillasCtaBanco) org.apache.axis.utils.JavaUtils.convert(_resp, TarjetasAmarillasCtaBanco.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

	public TarjetasAmarillasSIE[] getTarjetaAmarillaEmpleadoSIE(java.lang.String usuario, java.lang.String contrase�a, int empleado, int fecha, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[4]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://SistemasRH.com/DatosGenerales/getTarjetaAmarillaEmpleadoSIE");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "getTarjetaAmarillaEmpleadoSIE"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {usuario, contrase�a, new java.lang.Integer(empleado), new java.lang.Integer(fecha), new java.lang.Boolean(existeError.value), mensaje.value});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            java.util.Map _output;
            _output = _call.getOutputParams();
            try {
                existeError.value = ((java.lang.Boolean) _output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError"))).booleanValue();
            } catch (java.lang.Exception _exception) {
                existeError.value = ((java.lang.Boolean) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError")), boolean.class)).booleanValue();
            }
            try {
                mensaje.value = (java.lang.String) _output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje"));
            } catch (java.lang.Exception _exception) {
                mensaje.value = (java.lang.String) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje")), java.lang.String.class);
            }
            try {
                return (TarjetasAmarillasSIE[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (TarjetasAmarillasSIE[]) org.apache.axis.utils.JavaUtils.convert(_resp, TarjetasAmarillasSIE[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

	public java.lang.String getTarjetaAmarillaEmpleadoSIE_Tabla(java.lang.String usuario, java.lang.String contrase�a, java.lang.String empleado, java.lang.String fecha, javax.xml.rpc.holders.StringHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[5]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://SistemasRH.com/DatosGenerales/getTarjetaAmarillaEmpleadoSIE_Tabla");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "getTarjetaAmarillaEmpleadoSIE_Tabla"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {usuario, contrase�a, empleado, fecha, existeError.value, mensaje.value});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            java.util.Map _output;
            _output = _call.getOutputParams();
            try {
                existeError.value = (java.lang.String) _output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError"));
            } catch (java.lang.Exception _exception) {
                existeError.value = (java.lang.String) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError")), java.lang.String.class);
            }
            try {
                mensaje.value = (java.lang.String) _output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje"));
            } catch (java.lang.Exception _exception) {
                mensaje.value = (java.lang.String) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje")), java.lang.String.class);
            }
            try {
                return (java.lang.String) _resp;
            } catch (java.lang.Exception _exception) {
                return (java.lang.String) org.apache.axis.utils.JavaUtils.convert(_resp, java.lang.String.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public Empleado[] getEmpleadoPorCentroCostos(java.lang.String usuario, java.lang.String contrase�a, int centroCostos, java.lang.String empresa, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[6]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://SistemasRH.com/DatosGenerales/getEmpleadoPorCentroCostos");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "getEmpleadoPorCentroCostos"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {usuario, contrase�a, new java.lang.Integer(centroCostos), empresa, new java.lang.Boolean(existeError.value), mensaje.value});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            java.util.Map _output;
            _output = _call.getOutputParams();
            try {
                existeError.value = ((java.lang.Boolean) _output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError"))).booleanValue();
            } catch (java.lang.Exception _exception) {
                existeError.value = ((java.lang.Boolean) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError")), boolean.class)).booleanValue();
            }
            try {
                mensaje.value = (java.lang.String) _output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje"));
            } catch (java.lang.Exception _exception) {
                mensaje.value = (java.lang.String) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje")), java.lang.String.class);
            }
            try {
                return (Empleado[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (Empleado[]) org.apache.axis.utils.JavaUtils.convert(_resp, Empleado[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public Empleado[] getEmpleadoPorSituacion(java.lang.String usuario, java.lang.String contrase�a, java.lang.String situacion, int fecha, java.lang.String pais, java.lang.String empresa, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[7]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://SistemasRH.com/DatosGenerales/getEmpleadoPorSituacion");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "getEmpleadoPorSituacion"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {usuario, contrase�a, situacion, new java.lang.Integer(fecha), pais, empresa, new java.lang.Boolean(existeError.value), mensaje.value});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            java.util.Map _output;
            _output = _call.getOutputParams();
            try {
                existeError.value = ((java.lang.Boolean) _output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError"))).booleanValue();
            } catch (java.lang.Exception _exception) {
                existeError.value = ((java.lang.Boolean) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError")), boolean.class)).booleanValue();
            }
            try {
                mensaje.value = (java.lang.String) _output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje"));
            } catch (java.lang.Exception _exception) {
                mensaje.value = (java.lang.String) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje")), java.lang.String.class);
            }
            try {
                return (Empleado[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (Empleado[]) org.apache.axis.utils.JavaUtils.convert(_resp, Empleado[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public Estructura_DatosCorreo getDatosCorreo(java.lang.String usuario, java.lang.String contrase�a, int empleado, java.lang.String empresa, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[8]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://SistemasRH.com/DatosGenerales/getDatosCorreo");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "getDatosCorreo"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {usuario, contrase�a, new java.lang.Integer(empleado), empresa, new java.lang.Boolean(existeError.value), mensaje.value});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            java.util.Map _output;
            _output = _call.getOutputParams();
            try {
                existeError.value = ((java.lang.Boolean) _output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError"))).booleanValue();
            } catch (java.lang.Exception _exception) {
                existeError.value = ((java.lang.Boolean) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError")), boolean.class)).booleanValue();
            }
            try {
                mensaje.value = (java.lang.String) _output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje"));
            } catch (java.lang.Exception _exception) {
                mensaje.value = (java.lang.String) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje")), java.lang.String.class);
            }
            try {
                return (Estructura_DatosCorreo) _resp;
            } catch (java.lang.Exception _exception) {
                return (Estructura_DatosCorreo) org.apache.axis.utils.JavaUtils.convert(_resp, Estructura_DatosCorreo.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public Funcion getFuncionEmpleado(java.lang.String usuario, java.lang.String contrase�a, int empleado, java.lang.String empresa, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[9]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://SistemasRH.com/DatosGenerales/getFuncionEmpleado");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "getFuncionEmpleado"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {usuario, contrase�a, new java.lang.Integer(empleado), empresa, new java.lang.Boolean(existeError.value), mensaje.value});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            java.util.Map _output;
            _output = _call.getOutputParams();
            try {
                existeError.value = ((java.lang.Boolean) _output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError"))).booleanValue();
            } catch (java.lang.Exception _exception) {
                existeError.value = ((java.lang.Boolean) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError")), boolean.class)).booleanValue();
            }
            try {
                mensaje.value = (java.lang.String) _output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje"));
            } catch (java.lang.Exception _exception) {
                mensaje.value = (java.lang.String) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje")), java.lang.String.class);
            }
            try {
                return (Funcion) _resp;
            } catch (java.lang.Exception _exception) {
                return (Funcion) org.apache.axis.utils.JavaUtils.convert(_resp, Funcion.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public Vacante[] getVacantes(java.lang.String usuario, java.lang.String contrase�a, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[10]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://SistemasRH.com/DatosGenerales/getVacantes");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "getVacantes"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {usuario, contrase�a, new java.lang.Boolean(existeError.value), mensaje.value});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            java.util.Map _output;
            _output = _call.getOutputParams();
            try {
                existeError.value = ((java.lang.Boolean) _output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError"))).booleanValue();
            } catch (java.lang.Exception _exception) {
                existeError.value = ((java.lang.Boolean) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError")), boolean.class)).booleanValue();
            }
            try {
                mensaje.value = (java.lang.String) _output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje"));
            } catch (java.lang.Exception _exception) {
                mensaje.value = (java.lang.String) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje")), java.lang.String.class);
            }
            try {
                return (Vacante[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (Vacante[]) org.apache.axis.utils.JavaUtils.convert(_resp, Vacante[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public Empleado[] getEmpleadoPorFuncion(java.lang.String usuario, java.lang.String contrase�a, int funcion, java.lang.String pais, java.lang.String empresa, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[11]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://SistemasRH.com/DatosGenerales/getEmpleadoPorFuncion");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "getEmpleadoPorFuncion"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {usuario, contrase�a, new java.lang.Integer(funcion), pais, empresa, new java.lang.Boolean(existeError.value), mensaje.value});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            java.util.Map _output;
            _output = _call.getOutputParams();
            try {
                existeError.value = ((java.lang.Boolean) _output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError"))).booleanValue();
            } catch (java.lang.Exception _exception) {
                existeError.value = ((java.lang.Boolean) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError")), boolean.class)).booleanValue();
            }
            try {
                mensaje.value = (java.lang.String) _output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje"));
            } catch (java.lang.Exception _exception) {
                mensaje.value = (java.lang.String) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje")), java.lang.String.class);
            }
            try {
                return (Empleado[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (Empleado[]) org.apache.axis.utils.JavaUtils.convert(_resp, Empleado[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public Empleado[] getEmpleadoPorMovimiento(java.lang.String usuario, java.lang.String contrase�a, int fecha, java.lang.String empresa, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[12]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://SistemasRH.com/DatosGenerales/getEmpleadoPorMovimiento");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "getEmpleadoPorMovimiento"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {usuario, contrase�a, new java.lang.Integer(fecha), empresa, new java.lang.Boolean(existeError.value), mensaje.value});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            java.util.Map _output;
            _output = _call.getOutputParams();
            try {
                existeError.value = ((java.lang.Boolean) _output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError"))).booleanValue();
            } catch (java.lang.Exception _exception) {
                existeError.value = ((java.lang.Boolean) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError")), boolean.class)).booleanValue();
            }
            try {
                mensaje.value = (java.lang.String) _output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje"));
            } catch (java.lang.Exception _exception) {
                mensaje.value = (java.lang.String) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje")), java.lang.String.class);
            }
            try {
                return (Empleado[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (Empleado[]) org.apache.axis.utils.JavaUtils.convert(_resp, Empleado[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public Incapacidad[] getEmpleadoIncapacidad(java.lang.String usuario, java.lang.String contrase�a, java.lang.String empresa, int fechaActualiza, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[13]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://SistemasRH.com/DatosGenerales/getEmpleadoIncapacidad");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "getEmpleadoIncapacidad"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {usuario, contrase�a, empresa, new java.lang.Integer(fechaActualiza), new java.lang.Boolean(existeError.value), mensaje.value});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            java.util.Map _output;
            _output = _call.getOutputParams();
            try {
                existeError.value = ((java.lang.Boolean) _output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError"))).booleanValue();
            } catch (java.lang.Exception _exception) {
                existeError.value = ((java.lang.Boolean) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError")), boolean.class)).booleanValue();
            }
            try {
                mensaje.value = (java.lang.String) _output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje"));
            } catch (java.lang.Exception _exception) {
                mensaje.value = (java.lang.String) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje")), java.lang.String.class);
            }
            try {
                return (Incapacidad[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (Incapacidad[]) org.apache.axis.utils.JavaUtils.convert(_resp, Incapacidad[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public java.lang.String getCorreo(java.lang.String usuario, java.lang.String contrase�a, java.lang.String valor, java.lang.String empresa, java.lang.String pais, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[14]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://SistemasRH.com/DatosGenerales/getCorreo");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "getCorreo"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {usuario, contrase�a, valor, empresa, pais, new java.lang.Boolean(existeError.value), mensaje.value});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            java.util.Map _output;
            _output = _call.getOutputParams();
            try {
                existeError.value = ((java.lang.Boolean) _output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError"))).booleanValue();
            } catch (java.lang.Exception _exception) {
                existeError.value = ((java.lang.Boolean) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError")), boolean.class)).booleanValue();
            }
            try {
                mensaje.value = (java.lang.String) _output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje"));
            } catch (java.lang.Exception _exception) {
                mensaje.value = (java.lang.String) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje")), java.lang.String.class);
            }
            try {
                return (java.lang.String) _resp;
            } catch (java.lang.Exception _exception) {
                return (java.lang.String) org.apache.axis.utils.JavaUtils.convert(_resp, java.lang.String.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public java.lang.String getRFC(java.lang.String nombre, java.lang.String apellidoPaterno, java.lang.String apellidoMaterno, int fechaNacimiento) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[15]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://SistemasRH.com/DatosGenerales/getRFC");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "getRFC"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {nombre, apellidoPaterno, apellidoMaterno, new java.lang.Integer(fechaNacimiento)});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (java.lang.String) _resp;
            } catch (java.lang.Exception _exception) {
                return (java.lang.String) org.apache.axis.utils.JavaUtils.convert(_resp, java.lang.String.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public void getEsDirector(java.lang.String usuario, java.lang.String contrase�a, int empleado, java.lang.String empresa, javax.xml.rpc.holders.BooleanHolder esDirector, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[16]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://SistemasRH.com/DatosGenerales/getEsDirector");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "getEsDirector"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {usuario, contrase�a, new java.lang.Integer(empleado), empresa, new java.lang.Boolean(esDirector.value), new java.lang.Boolean(existeError.value), mensaje.value});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            java.util.Map _output;
            _output = _call.getOutputParams();
            try {
                esDirector.value = ((java.lang.Boolean) _output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "EsDirector"))).booleanValue();
            } catch (java.lang.Exception _exception) {
                esDirector.value = ((java.lang.Boolean) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "EsDirector")), boolean.class)).booleanValue();
            }
            try {
                existeError.value = ((java.lang.Boolean) _output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError"))).booleanValue();
            } catch (java.lang.Exception _exception) {
                existeError.value = ((java.lang.Boolean) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError")), boolean.class)).booleanValue();
            }
            try {
                mensaje.value = (java.lang.String) _output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje"));
            } catch (java.lang.Exception _exception) {
                mensaje.value = (java.lang.String) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje")), java.lang.String.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public java.lang.String getCuentaClabe(java.lang.String usuario, java.lang.String contrase�a, int empleado, java.lang.String empresa, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[17]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://SistemasRH.com/DatosGenerales/getCuentaClabe");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "getCuentaClabe"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {usuario, contrase�a, new java.lang.Integer(empleado), empresa, new java.lang.Boolean(existeError.value), mensaje.value});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            java.util.Map _output;
            _output = _call.getOutputParams();
            try {
                existeError.value = ((java.lang.Boolean) _output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError"))).booleanValue();
            } catch (java.lang.Exception _exception) {
                existeError.value = ((java.lang.Boolean) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError")), boolean.class)).booleanValue();
            }
            try {
                mensaje.value = (java.lang.String) _output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje"));
            } catch (java.lang.Exception _exception) {
                mensaje.value = (java.lang.String) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje")), java.lang.String.class);
            }
            try {
                return (java.lang.String) _resp;
            } catch (java.lang.Exception _exception) {
                return (java.lang.String) org.apache.axis.utils.JavaUtils.convert(_resp, java.lang.String.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

	public GetHuellaClienteUnicoResponseGetHuellaClienteUnicoResult getHuellaClienteUnico(java.lang.String usuario, java.lang.String contrase�a, int empleado, java.lang.String empresa, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[18]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://SistemasRH.com/DatosGenerales/getHuellaClienteUnico");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "getHuellaClienteUnico"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {usuario, contrase�a, new java.lang.Integer(empleado), empresa, new java.lang.Boolean(existeError.value), mensaje.value});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            java.util.Map _output;
            _output = _call.getOutputParams();
            try {
                existeError.value = ((java.lang.Boolean) _output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError"))).booleanValue();
            } catch (java.lang.Exception _exception) {
                existeError.value = ((java.lang.Boolean) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError")), boolean.class)).booleanValue();
            }
            try {
                mensaje.value = (java.lang.String) _output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje"));
            } catch (java.lang.Exception _exception) {
                mensaje.value = (java.lang.String) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje")), java.lang.String.class);
            }
            try {
                return (GetHuellaClienteUnicoResponseGetHuellaClienteUnicoResult) _resp;
            } catch (java.lang.Exception _exception) {
                return (GetHuellaClienteUnicoResponseGetHuellaClienteUnicoResult) org.apache.axis.utils.JavaUtils.convert(_resp, GetHuellaClienteUnicoResponseGetHuellaClienteUnicoResult.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public GetHuellaClienteUnicoLAMResponseGetHuellaClienteUnicoLAMResult getHuellaClienteUnicoLAM(java.lang.String usuario, java.lang.String contrase�a, int empleado, java.lang.String empresa, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[19]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://SistemasRH.com/DatosGenerales/getHuellaClienteUnicoLAM");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "getHuellaClienteUnicoLAM"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {usuario, contrase�a, new java.lang.Integer(empleado), empresa, new java.lang.Boolean(existeError.value), mensaje.value});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            java.util.Map _output;
            _output = _call.getOutputParams();
            try {
                existeError.value = ((java.lang.Boolean) _output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError"))).booleanValue();
            } catch (java.lang.Exception _exception) {
                existeError.value = ((java.lang.Boolean) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError")), boolean.class)).booleanValue();
            }
            try {
                mensaje.value = (java.lang.String) _output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje"));
            } catch (java.lang.Exception _exception) {
                mensaje.value = (java.lang.String) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje")), java.lang.String.class);
            }
            try {
                return (GetHuellaClienteUnicoLAMResponseGetHuellaClienteUnicoLAMResult) _resp;
            } catch (java.lang.Exception _exception) {
                return (GetHuellaClienteUnicoLAMResponseGetHuellaClienteUnicoLAMResult) org.apache.axis.utils.JavaUtils.convert(_resp, GetHuellaClienteUnicoLAMResponseGetHuellaClienteUnicoLAMResult.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public GetHuellaClienteUnicoQAResponseGetHuellaClienteUnicoQAResult getHuellaClienteUnicoQA(java.lang.String usuario, java.lang.String contrase�a, int empleado, java.lang.String empresa, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[20]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://SistemasRH.com/DatosGenerales/getHuellaClienteUnicoQA");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "getHuellaClienteUnicoQA"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {usuario, contrase�a, new java.lang.Integer(empleado), empresa, new java.lang.Boolean(existeError.value), mensaje.value});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            java.util.Map _output;
            _output = _call.getOutputParams();
            try {
                existeError.value = ((java.lang.Boolean) _output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError"))).booleanValue();
            } catch (java.lang.Exception _exception) {
                existeError.value = ((java.lang.Boolean) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError")), boolean.class)).booleanValue();
            }
            try {
                mensaje.value = (java.lang.String) _output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje"));
            } catch (java.lang.Exception _exception) {
                mensaje.value = (java.lang.String) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje")), java.lang.String.class);
            }
            try {
                return (GetHuellaClienteUnicoQAResponseGetHuellaClienteUnicoQAResult) _resp;
            } catch (java.lang.Exception _exception) {
                return (GetHuellaClienteUnicoQAResponseGetHuellaClienteUnicoQAResult) org.apache.axis.utils.JavaUtils.convert(_resp, GetHuellaClienteUnicoQAResponseGetHuellaClienteUnicoQAResult.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public java.lang.String getFechaPago(java.lang.String usuario, java.lang.String contrase�a, int empleado, java.lang.String empresa, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[21]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://SistemasRH.com/DatosGenerales/getFechaPago");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "getFechaPago"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {usuario, contrase�a, new java.lang.Integer(empleado), empresa, new java.lang.Boolean(existeError.value), mensaje.value});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            java.util.Map _output;
            _output = _call.getOutputParams();
            try {
                existeError.value = ((java.lang.Boolean) _output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError"))).booleanValue();
            } catch (java.lang.Exception _exception) {
                existeError.value = ((java.lang.Boolean) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError")), boolean.class)).booleanValue();
            }
            try {
                mensaje.value = (java.lang.String) _output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje"));
            } catch (java.lang.Exception _exception) {
                mensaje.value = (java.lang.String) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje")), java.lang.String.class);
            }
            try {
                return (java.lang.String) _resp;
            } catch (java.lang.Exception _exception) {
                return (java.lang.String) org.apache.axis.utils.JavaUtils.convert(_resp, java.lang.String.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public Coincidencia[] getCoincidencias(java.lang.String usuario, java.lang.String contrase�a, java.lang.String filtro, java.lang.String situacion, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[22]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://SistemasRH.com/DatosGenerales/getCoincidencias");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "getCoincidencias"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {usuario, contrase�a, filtro, situacion, new java.lang.Boolean(existeError.value), mensaje.value});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            java.util.Map _output;
            _output = _call.getOutputParams();
            try {
                existeError.value = ((java.lang.Boolean) _output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError"))).booleanValue();
            } catch (java.lang.Exception _exception) {
                existeError.value = ((java.lang.Boolean) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError")), boolean.class)).booleanValue();
            }
            try {
                mensaje.value = (java.lang.String) _output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje"));
            } catch (java.lang.Exception _exception) {
                mensaje.value = (java.lang.String) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje")), java.lang.String.class);
            }
            try {
                return (Coincidencia[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (Coincidencia[]) org.apache.axis.utils.JavaUtils.convert(_resp, Coincidencia[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public Superiores[] getLineaSuperior(java.lang.String usuario, java.lang.String contrase�a, int empleado, java.lang.String empresa, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[23]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://SistemasRH.com/DatosGenerales/getLineaSuperior");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "getLineaSuperior"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {usuario, contrase�a, new java.lang.Integer(empleado), empresa, new java.lang.Boolean(existeError.value), mensaje.value});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            java.util.Map _output;
            _output = _call.getOutputParams();
            try {
                existeError.value = ((java.lang.Boolean) _output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError"))).booleanValue();
            } catch (java.lang.Exception _exception) {
                existeError.value = ((java.lang.Boolean) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError")), boolean.class)).booleanValue();
            }
            try {
                mensaje.value = (java.lang.String) _output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje"));
            } catch (java.lang.Exception _exception) {
                mensaje.value = (java.lang.String) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje")), java.lang.String.class);
            }
            try {
                return (Superiores[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (Superiores[]) org.apache.axis.utils.JavaUtils.convert(_resp, Superiores[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public Subordinado[] getLineaInferior(java.lang.String usuario, java.lang.String contrase�a, int empleado, java.lang.String empresa, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[24]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://SistemasRH.com/DatosGenerales/getLineaInferior");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "getLineaInferior"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {usuario, contrase�a, new java.lang.Integer(empleado), empresa, new java.lang.Boolean(existeError.value), mensaje.value});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            java.util.Map _output;
            _output = _call.getOutputParams();
            try {
                existeError.value = ((java.lang.Boolean) _output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError"))).booleanValue();
            } catch (java.lang.Exception _exception) {
                existeError.value = ((java.lang.Boolean) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError")), boolean.class)).booleanValue();
            }
            try {
                mensaje.value = (java.lang.String) _output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje"));
            } catch (java.lang.Exception _exception) {
                mensaje.value = (java.lang.String) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje")), java.lang.String.class);
            }
            try {
                return (Subordinado[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (Subordinado[]) org.apache.axis.utils.JavaUtils.convert(_resp, Subordinado[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public Subordinado[] getLineaInferiorSAP(java.lang.String usuario, java.lang.String contrase�a, int puesto, java.lang.String empresa, int nivel, java.lang.String pais, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[25]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://SistemasRH.com/DatosGenerales/getLineaInferiorSAP");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "getLineaInferiorSAP"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {usuario, contrase�a, new java.lang.Integer(puesto), empresa, new java.lang.Integer(nivel), pais, new java.lang.Boolean(existeError.value), mensaje.value});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            java.util.Map _output;
            _output = _call.getOutputParams();
            try {
                existeError.value = ((java.lang.Boolean) _output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError"))).booleanValue();
            } catch (java.lang.Exception _exception) {
                existeError.value = ((java.lang.Boolean) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError")), boolean.class)).booleanValue();
            }
            try {
                mensaje.value = (java.lang.String) _output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje"));
            } catch (java.lang.Exception _exception) {
                mensaje.value = (java.lang.String) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje")), java.lang.String.class);
            }
            try {
                return (Subordinado[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (Subordinado[]) org.apache.axis.utils.JavaUtils.convert(_resp, Subordinado[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public Subordinado[] getLineaInferiorPorEmpleadoRep(java.lang.String usuario, java.lang.String contrase�a, int empleado, java.lang.String empresa, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[26]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://SistemasRH.com/DatosGenerales/getLineaInferiorPorEmpleadoRep");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "getLineaInferiorPorEmpleadoRep"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {usuario, contrase�a, new java.lang.Integer(empleado), empresa, new java.lang.Boolean(existeError.value), mensaje.value});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            java.util.Map _output;
            _output = _call.getOutputParams();
            try {
                existeError.value = ((java.lang.Boolean) _output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError"))).booleanValue();
            } catch (java.lang.Exception _exception) {
                existeError.value = ((java.lang.Boolean) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError")), boolean.class)).booleanValue();
            }
            try {
                mensaje.value = (java.lang.String) _output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje"));
            } catch (java.lang.Exception _exception) {
                mensaje.value = (java.lang.String) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje")), java.lang.String.class);
            }
            try {
                return (Subordinado[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (Subordinado[]) org.apache.axis.utils.JavaUtils.convert(_resp, Subordinado[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public int existeEmpleado(java.lang.String usuario, java.lang.String contrase�a, int empleado, java.lang.String empresa, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[27]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://SistemasRH.com/DatosGenerales/existeEmpleado");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "existeEmpleado"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {usuario, contrase�a, new java.lang.Integer(empleado), empresa, new java.lang.Boolean(existeError.value), mensaje.value});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            java.util.Map _output;
            _output = _call.getOutputParams();
            try {
                existeError.value = ((java.lang.Boolean) _output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError"))).booleanValue();
            } catch (java.lang.Exception _exception) {
                existeError.value = ((java.lang.Boolean) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError")), boolean.class)).booleanValue();
            }
            try {
                mensaje.value = (java.lang.String) _output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje"));
            } catch (java.lang.Exception _exception) {
                mensaje.value = (java.lang.String) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje")), java.lang.String.class);
            }
            try {
                return ((java.lang.Integer) _resp).intValue();
            } catch (java.lang.Exception _exception) {
                return ((java.lang.Integer) org.apache.axis.utils.JavaUtils.convert(_resp, int.class)).intValue();
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public long getCentroCostosTVA(java.lang.String usuario, java.lang.String contrase�a, int empleado, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[28]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://SistemasRH.com/DatosGenerales/getCentroCostosTVA");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "getCentroCostosTVA"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {usuario, contrase�a, new java.lang.Integer(empleado), new java.lang.Boolean(existeError.value), mensaje.value});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            java.util.Map _output;
            _output = _call.getOutputParams();
            try {
                existeError.value = ((java.lang.Boolean) _output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError"))).booleanValue();
            } catch (java.lang.Exception _exception) {
                existeError.value = ((java.lang.Boolean) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError")), boolean.class)).booleanValue();
            }
            try {
                mensaje.value = (java.lang.String) _output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje"));
            } catch (java.lang.Exception _exception) {
                mensaje.value = (java.lang.String) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje")), java.lang.String.class);
            }
            try {
                return ((java.lang.Long) _resp).longValue();
            } catch (java.lang.Exception _exception) {
                return ((java.lang.Long) org.apache.axis.utils.JavaUtils.convert(_resp, long.class)).longValue();
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public void getRankingMapaTalento(java.lang.String usuario, java.lang.String contrase�a, int empleado, java.lang.String empresa, javax.xml.rpc.holders.BooleanHolder perteneceRanking, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[29]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://SistemasRH.com/DatosGenerales/getRankingMapaTalento");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "getRankingMapaTalento"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {usuario, contrase�a, new java.lang.Integer(empleado), empresa, new java.lang.Boolean(perteneceRanking.value), new java.lang.Boolean(existeError.value), mensaje.value});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            java.util.Map _output;
            _output = _call.getOutputParams();
            try {
                perteneceRanking.value = ((java.lang.Boolean) _output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "PerteneceRanking"))).booleanValue();
            } catch (java.lang.Exception _exception) {
                perteneceRanking.value = ((java.lang.Boolean) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "PerteneceRanking")), boolean.class)).booleanValue();
            }
            try {
                existeError.value = ((java.lang.Boolean) _output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError"))).booleanValue();
            } catch (java.lang.Exception _exception) {
                existeError.value = ((java.lang.Boolean) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError")), boolean.class)).booleanValue();
            }
            try {
                mensaje.value = (java.lang.String) _output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje"));
            } catch (java.lang.Exception _exception) {
                mensaje.value = (java.lang.String) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje")), java.lang.String.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public void getCuentaBancoEmpleado(java.lang.String usuario, java.lang.String contrase�a, int empleado, java.lang.String empresa, javax.xml.rpc.holders.StringHolder cuentaBanco, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[30]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://SistemasRH.com/DatosGenerales/getCuentaBancoEmpleado");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "getCuentaBancoEmpleado"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {usuario, contrase�a, new java.lang.Integer(empleado), empresa, cuentaBanco.value, new java.lang.Boolean(existeError.value), mensaje.value});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            java.util.Map _output;
            _output = _call.getOutputParams();
            try {
                cuentaBanco.value = (java.lang.String) _output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "CuentaBanco"));
            } catch (java.lang.Exception _exception) {
                cuentaBanco.value = (java.lang.String) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "CuentaBanco")), java.lang.String.class);
            }
            try {
                existeError.value = ((java.lang.Boolean) _output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError"))).booleanValue();
            } catch (java.lang.Exception _exception) {
                existeError.value = ((java.lang.Boolean) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError")), boolean.class)).booleanValue();
            }
            try {
                mensaje.value = (java.lang.String) _output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje"));
            } catch (java.lang.Exception _exception) {
                mensaje.value = (java.lang.String) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje")), java.lang.String.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public void getCuentaBanco(java.lang.String usuario, java.lang.String contrasenia, int empleado, java.lang.String empresa, javax.xml.rpc.holders.StringHolder cuentaBanco, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[31]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://SistemasRH.com/DatosGenerales/getCuentaBanco");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "getCuentaBanco"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {usuario, contrasenia, new java.lang.Integer(empleado), empresa, cuentaBanco.value, new java.lang.Boolean(existeError.value), mensaje.value});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            java.util.Map _output;
            _output = _call.getOutputParams();
            try {
                cuentaBanco.value = (java.lang.String) _output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "CuentaBanco"));
            } catch (java.lang.Exception _exception) {
                cuentaBanco.value = (java.lang.String) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "CuentaBanco")), java.lang.String.class);
            }
            try {
                existeError.value = ((java.lang.Boolean) _output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError"))).booleanValue();
            } catch (java.lang.Exception _exception) {
                existeError.value = ((java.lang.Boolean) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError")), boolean.class)).booleanValue();
            }
            try {
                mensaje.value = (java.lang.String) _output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje"));
            } catch (java.lang.Exception _exception) {
                mensaje.value = (java.lang.String) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje")), java.lang.String.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public EmpleadoBaja[] getDatosEmpleadosBaja(java.lang.String usuario, java.lang.String contrase�a, int[] empleado, java.lang.String empresa, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[32]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://SistemasRH.com/DatosGenerales/getDatosEmpleadosBaja");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "getDatosEmpleadosBaja"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {usuario, contrase�a, empleado, empresa, new java.lang.Boolean(existeError.value), mensaje.value});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            java.util.Map _output;
            _output = _call.getOutputParams();
            try {
                existeError.value = ((java.lang.Boolean) _output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError"))).booleanValue();
            } catch (java.lang.Exception _exception) {
                existeError.value = ((java.lang.Boolean) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError")), boolean.class)).booleanValue();
            }
            try {
                mensaje.value = (java.lang.String) _output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje"));
            } catch (java.lang.Exception _exception) {
                mensaje.value = (java.lang.String) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje")), java.lang.String.class);
            }
            try {
                return (EmpleadoBaja[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (EmpleadoBaja[]) org.apache.axis.utils.JavaUtils.convert(_resp, EmpleadoBaja[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public void setSolicitudBajaPlantillaDinamica(java.lang.String usuario, java.lang.String contrase�a, int empleadoBaja, java.lang.String empresa, javax.xml.rpc.holders.IntHolder folioFBP, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[33]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://SistemasRH.com/DatosGenerales/setSolicitudBajaPlantillaDinamica");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "setSolicitudBajaPlantillaDinamica"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {usuario, contrase�a, new java.lang.Integer(empleadoBaja), empresa, new java.lang.Integer(folioFBP.value), new java.lang.Boolean(existeError.value), mensaje.value});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            java.util.Map _output;
            _output = _call.getOutputParams();
            try {
                folioFBP.value = ((java.lang.Integer) _output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "FolioFBP"))).intValue();
            } catch (java.lang.Exception _exception) {
                folioFBP.value = ((java.lang.Integer) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "FolioFBP")), int.class)).intValue();
            }
            try {
                existeError.value = ((java.lang.Boolean) _output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError"))).booleanValue();
            } catch (java.lang.Exception _exception) {
                existeError.value = ((java.lang.Boolean) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError")), boolean.class)).booleanValue();
            }
            try {
                mensaje.value = (java.lang.String) _output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje"));
            } catch (java.lang.Exception _exception) {
                mensaje.value = (java.lang.String) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje")), java.lang.String.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public void setSolicitudBajaTarjetasAmarillas(java.lang.String usuario, java.lang.String contrase�a, int empleadoBaja, java.lang.String empresa, javax.xml.rpc.holders.IntHolder folioFBP, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[34]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://SistemasRH.com/DatosGenerales/setSolicitudBajaTarjetasAmarillas");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "setSolicitudBajaTarjetasAmarillas"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {usuario, contrase�a, new java.lang.Integer(empleadoBaja), empresa, new java.lang.Integer(folioFBP.value), new java.lang.Boolean(existeError.value), mensaje.value});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            java.util.Map _output;
            _output = _call.getOutputParams();
            try {
                folioFBP.value = ((java.lang.Integer) _output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "FolioFBP"))).intValue();
            } catch (java.lang.Exception _exception) {
                folioFBP.value = ((java.lang.Integer) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "FolioFBP")), int.class)).intValue();
            }
            try {
                existeError.value = ((java.lang.Boolean) _output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError"))).booleanValue();
            } catch (java.lang.Exception _exception) {
                existeError.value = ((java.lang.Boolean) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError")), boolean.class)).booleanValue();
            }
            try {
                mensaje.value = (java.lang.String) _output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje"));
            } catch (java.lang.Exception _exception) {
                mensaje.value = (java.lang.String) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje")), java.lang.String.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public void getSeguimientoBajaPlantillaDinamica(java.lang.String usuario, java.lang.String contrase�a, int folioFBP, java.lang.String empresa, javax.xml.rpc.holders.IntHolder empleadoGestionBaja, javax.xml.rpc.holders.IntHolder estatus, javax.xml.rpc.holders.StringHolder fechaActualizacion, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[35]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://SistemasRH.com/DatosGenerales/getSeguimientoBajaPlantillaDinamica");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "getSeguimientoBajaPlantillaDinamica"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {usuario, contrase�a, new java.lang.Integer(folioFBP), empresa, new java.lang.Integer(empleadoGestionBaja.value), new java.lang.Integer(estatus.value), fechaActualizacion.value, new java.lang.Boolean(existeError.value), mensaje.value});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            java.util.Map _output;
            _output = _call.getOutputParams();
            try {
                empleadoGestionBaja.value = ((java.lang.Integer) _output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "EmpleadoGestionBaja"))).intValue();
            } catch (java.lang.Exception _exception) {
                empleadoGestionBaja.value = ((java.lang.Integer) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "EmpleadoGestionBaja")), int.class)).intValue();
            }
            try {
                estatus.value = ((java.lang.Integer) _output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Estatus"))).intValue();
            } catch (java.lang.Exception _exception) {
                estatus.value = ((java.lang.Integer) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Estatus")), int.class)).intValue();
            }
            try {
                fechaActualizacion.value = (java.lang.String) _output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "FechaActualizacion"));
            } catch (java.lang.Exception _exception) {
                fechaActualizacion.value = (java.lang.String) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "FechaActualizacion")), java.lang.String.class);
            }
            try {
                existeError.value = ((java.lang.Boolean) _output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError"))).booleanValue();
            } catch (java.lang.Exception _exception) {
                existeError.value = ((java.lang.Boolean) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError")), boolean.class)).booleanValue();
            }
            try {
                mensaje.value = (java.lang.String) _output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje"));
            } catch (java.lang.Exception _exception) {
                mensaje.value = (java.lang.String) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje")), java.lang.String.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public void setDigitalizacionDocumentosEmpleado(java.lang.String usuario, java.lang.String contrase�a, int empleado, int pais, java.lang.String documento, int tipo, int etapa, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[36]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://SistemasRH.com/DatosGenerales/setDigitalizacionDocumentosEmpleado");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "setDigitalizacionDocumentosEmpleado"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {usuario, contrase�a, new java.lang.Integer(empleado), new java.lang.Integer(pais), documento, new java.lang.Integer(tipo), new java.lang.Integer(etapa), new java.lang.Boolean(existeError.value), mensaje.value});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            java.util.Map _output;
            _output = _call.getOutputParams();
            try {
                existeError.value = ((java.lang.Boolean) _output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError"))).booleanValue();
            } catch (java.lang.Exception _exception) {
                existeError.value = ((java.lang.Boolean) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError")), boolean.class)).booleanValue();
            }
            try {
                mensaje.value = (java.lang.String) _output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje"));
            } catch (java.lang.Exception _exception) {
                mensaje.value = (java.lang.String) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje")), java.lang.String.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public void getQ12Empleado(java.lang.String usuario, java.lang.String contrase�a, int empleado, java.lang.String empresa, int periodo, ArrayOfEmpleadoQ12Holder listaEmpleado, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[37]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://SistemasRH.com/DatosGenerales/getQ12Empleado");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "getQ12Empleado"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {usuario, contrase�a, new java.lang.Integer(empleado), empresa, new java.lang.Integer(periodo), listaEmpleado.value, new java.lang.Boolean(existeError.value), mensaje.value});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            java.util.Map _output;
            _output = _call.getOutputParams();
            try {
                listaEmpleado.value = (EmpleadoQ12[]) _output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ListaEmpleado"));
            } catch (java.lang.Exception _exception) {
                listaEmpleado.value = (EmpleadoQ12[]) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ListaEmpleado")), EmpleadoQ12[].class);
            }
            try {
                existeError.value = ((java.lang.Boolean) _output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError"))).booleanValue();
            } catch (java.lang.Exception _exception) {
                existeError.value = ((java.lang.Boolean) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError")), boolean.class)).booleanValue();
            }
            try {
                mensaje.value = (java.lang.String) _output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje"));
            } catch (java.lang.Exception _exception) {
                mensaje.value = (java.lang.String) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje")), java.lang.String.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public void getRanking_Empleado(java.lang.String usuario, java.lang.String contrase�a, java.lang.String empresa, java.lang.String pais, java.lang.String fecha, java.lang.String funcion, java.lang.String nivel, java.lang.String CC, java.lang.String periodo, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[38]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://SistemasRH.com/DatosGenerales/getRanking_Empleado");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "getRanking_Empleado"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {usuario, contrase�a, empresa, pais, fecha, funcion, nivel, CC, periodo, new java.lang.Boolean(existeError.value), mensaje.value});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            java.util.Map _output;
            _output = _call.getOutputParams();
            try {
                existeError.value = ((java.lang.Boolean) _output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError"))).booleanValue();
            } catch (java.lang.Exception _exception) {
                existeError.value = ((java.lang.Boolean) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError")), boolean.class)).booleanValue();
            }
            try {
                mensaje.value = (java.lang.String) _output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje"));
            } catch (java.lang.Exception _exception) {
                mensaje.value = (java.lang.String) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje")), java.lang.String.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public VacacionesGeo[] getConsultaCargaVacacionesGeo(java.lang.String usuario, java.lang.String contrase�a, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[39]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://SistemasRH.com/DatosGenerales/getConsultaCargaVacacionesGeo");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "getConsultaCargaVacacionesGeo"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {usuario, contrase�a, new java.lang.Boolean(existeError.value), mensaje.value});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            java.util.Map _output;
            _output = _call.getOutputParams();
            try {
                existeError.value = ((java.lang.Boolean) _output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError"))).booleanValue();
            } catch (java.lang.Exception _exception) {
                existeError.value = ((java.lang.Boolean) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError")), boolean.class)).booleanValue();
            }
            try {
                mensaje.value = (java.lang.String) _output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje"));
            } catch (java.lang.Exception _exception) {
                mensaje.value = (java.lang.String) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje")), java.lang.String.class);
            }
            try {
                return (VacacionesGeo[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (VacacionesGeo[]) org.apache.axis.utils.JavaUtils.convert(_resp, VacacionesGeo[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public TarjetaAmarilla_Periodo[] getTarjetaAmarilla_Periodo(java.lang.String usuario, java.lang.String contrase�a, int fecha, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[40]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://SistemasRH.com/DatosGenerales/getTarjetaAmarilla_Periodo");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "getTarjetaAmarilla_Periodo"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {usuario, contrase�a, new java.lang.Integer(fecha), new java.lang.Boolean(existeError.value), mensaje.value});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            java.util.Map _output;
            _output = _call.getOutputParams();
            try {
                existeError.value = ((java.lang.Boolean) _output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError"))).booleanValue();
            } catch (java.lang.Exception _exception) {
                existeError.value = ((java.lang.Boolean) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError")), boolean.class)).booleanValue();
            }
            try {
                mensaje.value = (java.lang.String) _output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje"));
            } catch (java.lang.Exception _exception) {
                mensaje.value = (java.lang.String) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje")), java.lang.String.class);
            }
            try {
                return (TarjetaAmarilla_Periodo[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (TarjetaAmarilla_Periodo[]) org.apache.axis.utils.JavaUtils.convert(_resp, TarjetaAmarilla_Periodo[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public DetalleBaja[] getDetalleBaja(java.lang.String usuario, java.lang.String contrase�a, int empleado, java.lang.String empresa, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[41]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://SistemasRH.com/DatosGenerales/getDetalleBaja");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "getDetalleBaja"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {usuario, contrase�a, new java.lang.Integer(empleado), empresa, new java.lang.Boolean(existeError.value), mensaje.value});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            java.util.Map _output;
            _output = _call.getOutputParams();
            try {
                existeError.value = ((java.lang.Boolean) _output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError"))).booleanValue();
            } catch (java.lang.Exception _exception) {
                existeError.value = ((java.lang.Boolean) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError")), boolean.class)).booleanValue();
            }
            try {
                mensaje.value = (java.lang.String) _output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje"));
            } catch (java.lang.Exception _exception) {
                mensaje.value = (java.lang.String) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje")), java.lang.String.class);
            }
            try {
                return (DetalleBaja[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (DetalleBaja[]) org.apache.axis.utils.JavaUtils.convert(_resp, DetalleBaja[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public Plaza[] getDescPlaza(java.lang.String usuario, java.lang.String contrase�a, int centroCostos, java.lang.String pais, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[42]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://SistemasRH.com/DatosGenerales/getDescPlaza");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "getDescPlaza"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {usuario, contrase�a, new java.lang.Integer(centroCostos), pais, new java.lang.Boolean(existeError.value), mensaje.value});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            java.util.Map _output;
            _output = _call.getOutputParams();
            try {
                existeError.value = ((java.lang.Boolean) _output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError"))).booleanValue();
            } catch (java.lang.Exception _exception) {
                existeError.value = ((java.lang.Boolean) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError")), boolean.class)).booleanValue();
            }
            try {
                mensaje.value = (java.lang.String) _output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje"));
            } catch (java.lang.Exception _exception) {
                mensaje.value = (java.lang.String) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje")), java.lang.String.class);
            }
            try {
                return (Plaza[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (Plaza[]) org.apache.axis.utils.JavaUtils.convert(_resp, Plaza[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public Beneficiarios getBeneficiariosEmpleado(java.lang.String usuario, java.lang.String contrase�a, int empleado, java.lang.String empresa, int tipoBeneficiario, java.lang.String pais, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[43]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://SistemasRH.com/DatosGenerales/getBeneficiariosEmpleado");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "getBeneficiariosEmpleado"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {usuario, contrase�a, new java.lang.Integer(empleado), empresa, new java.lang.Integer(tipoBeneficiario), pais, new java.lang.Boolean(existeError.value), mensaje.value});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            java.util.Map _output;
            _output = _call.getOutputParams();
            try {
                existeError.value = ((java.lang.Boolean) _output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError"))).booleanValue();
            } catch (java.lang.Exception _exception) {
                existeError.value = ((java.lang.Boolean) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError")), boolean.class)).booleanValue();
            }
            try {
                mensaje.value = (java.lang.String) _output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje"));
            } catch (java.lang.Exception _exception) {
                mensaje.value = (java.lang.String) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje")), java.lang.String.class);
            }
            try {
                return (Beneficiarios) _resp;
            } catch (java.lang.Exception _exception) {
                return (Beneficiarios) org.apache.axis.utils.JavaUtils.convert(_resp, Beneficiarios.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public DatosCoincidencias[] getEmpleadoCoincideNombreRFC(java.lang.String usuario, java.lang.String contrase�a, java.lang.String nombre, java.lang.String apPaterno, java.lang.String apMaterno, java.lang.String pais, java.lang.String empresa, java.lang.String regCed, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[44]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://SistemasRH.com/DatosGenerales/getEmpleadoCoincideNombreRFC");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "getEmpleadoCoincideNombreRFC"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {usuario, contrase�a, nombre, apPaterno, apMaterno, pais, empresa, regCed, new java.lang.Boolean(existeError.value), mensaje.value});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            java.util.Map _output;
            _output = _call.getOutputParams();
            try {
                existeError.value = ((java.lang.Boolean) _output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError"))).booleanValue();
            } catch (java.lang.Exception _exception) {
                existeError.value = ((java.lang.Boolean) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError")), boolean.class)).booleanValue();
            }
            try {
                mensaje.value = (java.lang.String) _output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje"));
            } catch (java.lang.Exception _exception) {
                mensaje.value = (java.lang.String) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje")), java.lang.String.class);
            }
            try {
                return (DatosCoincidencias[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (DatosCoincidencias[]) org.apache.axis.utils.JavaUtils.convert(_resp, DatosCoincidencias[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public Auscencia[] getEmpleadoIncapacidadSAP(java.lang.String usuario, java.lang.String contrase�a, int empleado, java.lang.String empresa, int fecha, java.lang.String pais, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[45]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://SistemasRH.com/DatosGenerales/getEmpleadoIncapacidadSAP");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "getEmpleadoIncapacidadSAP"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {usuario, contrase�a, new java.lang.Integer(empleado), empresa, new java.lang.Integer(fecha), pais, new java.lang.Boolean(existeError.value), mensaje.value});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            java.util.Map _output;
            _output = _call.getOutputParams();
            try {
                existeError.value = ((java.lang.Boolean) _output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError"))).booleanValue();
            } catch (java.lang.Exception _exception) {
                existeError.value = ((java.lang.Boolean) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError")), boolean.class)).booleanValue();
            }
            try {
                mensaje.value = (java.lang.String) _output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje"));
            } catch (java.lang.Exception _exception) {
                mensaje.value = (java.lang.String) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje")), java.lang.String.class);
            }
            try {
                return (Auscencia[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (Auscencia[]) org.apache.axis.utils.JavaUtils.convert(_resp, Auscencia[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public Auscencia[] getEmpleadoAuscentismo(java.lang.String usuario, java.lang.String contrase�a, int empleado, java.lang.String empresa, int fecha, java.lang.String pais, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[46]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://SistemasRH.com/DatosGenerales/getEmpleadoAuscentismo");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "getEmpleadoAuscentismo"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {usuario, contrase�a, new java.lang.Integer(empleado), empresa, new java.lang.Integer(fecha), pais, new java.lang.Boolean(existeError.value), mensaje.value});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            java.util.Map _output;
            _output = _call.getOutputParams();
            try {
                existeError.value = ((java.lang.Boolean) _output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError"))).booleanValue();
            } catch (java.lang.Exception _exception) {
                existeError.value = ((java.lang.Boolean) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError")), boolean.class)).booleanValue();
            }
            try {
                mensaje.value = (java.lang.String) _output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje"));
            } catch (java.lang.Exception _exception) {
                mensaje.value = (java.lang.String) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje")), java.lang.String.class);
            }
            try {
                return (Auscencia[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (Auscencia[]) org.apache.axis.utils.JavaUtils.convert(_resp, Auscencia[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public EmpleadoGral[] getDatosEmpleadosMasivo(java.lang.String usuario, java.lang.String contrase�a, EmpleadoEmp[] empleado, java.lang.String empresa, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[47]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://SistemasRH.com/DatosGenerales/getDatosEmpleados");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "getDatosEmpleados"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {usuario, contrase�a, empleado, empresa, new java.lang.Boolean(existeError.value), mensaje.value});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            java.util.Map _output;
            _output = _call.getOutputParams();
            try {
                existeError.value = ((java.lang.Boolean) _output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError"))).booleanValue();
            } catch (java.lang.Exception _exception) {
                existeError.value = ((java.lang.Boolean) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError")), boolean.class)).booleanValue();
            }
            try {
                mensaje.value = (java.lang.String) _output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje"));
            } catch (java.lang.Exception _exception) {
                mensaje.value = (java.lang.String) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje")), java.lang.String.class);
            }
            try {
                return (EmpleadoGral[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (EmpleadoGral[]) org.apache.axis.utils.JavaUtils.convert(_resp, EmpleadoGral[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public void getValidaCuentaNegocio(java.lang.String usuario, java.lang.String contrase�a, java.lang.String cuentaBanco, java.lang.String empresa, javax.xml.rpc.holders.IntHolder valNegocio, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[48]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://SistemasRH.com/DatosGenerales/getValidaCuentaNegocio");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "getValidaCuentaNegocio"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {usuario, contrase�a, cuentaBanco, empresa, new java.lang.Integer(valNegocio.value), new java.lang.Boolean(existeError.value), mensaje.value});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            java.util.Map _output;
            _output = _call.getOutputParams();
            try {
                valNegocio.value = ((java.lang.Integer) _output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ValNegocio"))).intValue();
            } catch (java.lang.Exception _exception) {
                valNegocio.value = ((java.lang.Integer) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ValNegocio")), int.class)).intValue();
            }
            try {
                existeError.value = ((java.lang.Boolean) _output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError"))).booleanValue();
            } catch (java.lang.Exception _exception) {
                existeError.value = ((java.lang.Boolean) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError")), boolean.class)).booleanValue();
            }
            try {
                mensaje.value = (java.lang.String) _output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje"));
            } catch (java.lang.Exception _exception) {
                mensaje.value = (java.lang.String) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje")), java.lang.String.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public void getValidaCuentaEmpleado(java.lang.String usuario, java.lang.String contrase�a, java.lang.String cuentaBanco, java.lang.String empresa, javax.xml.rpc.holders.IntHolder empleado, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[49]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://SistemasRH.com/DatosGenerales/getValidaCuentaEmpleado");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "getValidaCuentaEmpleado"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {usuario, contrase�a, cuentaBanco, empresa, new java.lang.Integer(empleado.value), new java.lang.Boolean(existeError.value), mensaje.value});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            java.util.Map _output;
            _output = _call.getOutputParams();
            try {
                empleado.value = ((java.lang.Integer) _output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Empleado"))).intValue();
            } catch (java.lang.Exception _exception) {
                empleado.value = ((java.lang.Integer) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Empleado")), int.class)).intValue();
            }
            try {
                existeError.value = ((java.lang.Boolean) _output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError"))).booleanValue();
            } catch (java.lang.Exception _exception) {
                existeError.value = ((java.lang.Boolean) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError")), boolean.class)).booleanValue();
            }
            try {
                mensaje.value = (java.lang.String) _output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje"));
            } catch (java.lang.Exception _exception) {
                mensaje.value = (java.lang.String) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje")), java.lang.String.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public EmpleadoPromocion[] getEmpleadoPromocion(java.lang.String usuario, java.lang.String contrase�a, int numeroEmpleado, java.lang.String empresa, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[50]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://SistemasRH.com/DatosGenerales/getEmpleadoPromocion");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "getEmpleadoPromocion"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {usuario, contrase�a, new java.lang.Integer(numeroEmpleado), empresa, new java.lang.Boolean(existeError.value), mensaje.value});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            java.util.Map _output;
            _output = _call.getOutputParams();
            try {
                existeError.value = ((java.lang.Boolean) _output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError"))).booleanValue();
            } catch (java.lang.Exception _exception) {
                existeError.value = ((java.lang.Boolean) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError")), boolean.class)).booleanValue();
            }
            try {
                mensaje.value = (java.lang.String) _output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje"));
            } catch (java.lang.Exception _exception) {
                mensaje.value = (java.lang.String) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje")), java.lang.String.class);
            }
            try {
                return (EmpleadoPromocion[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (EmpleadoPromocion[]) org.apache.axis.utils.JavaUtils.convert(_resp, EmpleadoPromocion[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public java.lang.String getClienteUnicoEmpleado(java.lang.String usuario, java.lang.String contrase�a, int empleado, java.lang.String empresa, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[51]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://SistemasRH.com/DatosGenerales/getClienteUnicoEmpleado");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "getClienteUnicoEmpleado"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {usuario, contrase�a, new java.lang.Integer(empleado), empresa, new java.lang.Boolean(existeError.value), mensaje.value});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            java.util.Map _output;
            _output = _call.getOutputParams();
            try {
                existeError.value = ((java.lang.Boolean) _output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError"))).booleanValue();
            } catch (java.lang.Exception _exception) {
                existeError.value = ((java.lang.Boolean) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError")), boolean.class)).booleanValue();
            }
            try {
                mensaje.value = (java.lang.String) _output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje"));
            } catch (java.lang.Exception _exception) {
                mensaje.value = (java.lang.String) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje")), java.lang.String.class);
            }
            try {
                return (java.lang.String) _resp;
            } catch (java.lang.Exception _exception) {
                return (java.lang.String) org.apache.axis.utils.JavaUtils.convert(_resp, java.lang.String.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public CuotasPatronales getCuotaPatronal(java.lang.String usuario, java.lang.String contrasena, java.lang.String empresa, java.lang.String compania, int anio, int periodo, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[52]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://SistemasRH.com/DatosGenerales/getCuotaPatronal");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "getCuotaPatronal"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {usuario, contrasena, empresa, compania, new java.lang.Integer(anio), new java.lang.Integer(periodo), new java.lang.Boolean(existeError.value), mensaje.value});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            java.util.Map _output;
            _output = _call.getOutputParams();
            try {
                existeError.value = ((java.lang.Boolean) _output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError"))).booleanValue();
            } catch (java.lang.Exception _exception) {
                existeError.value = ((java.lang.Boolean) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError")), boolean.class)).booleanValue();
            }
            try {
                mensaje.value = (java.lang.String) _output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje"));
            } catch (java.lang.Exception _exception) {
                mensaje.value = (java.lang.String) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje")), java.lang.String.class);
            }
            try {
                return (CuotasPatronales) _resp;
            } catch (java.lang.Exception _exception) {
                return (CuotasPatronales) org.apache.axis.utils.JavaUtils.convert(_resp, CuotasPatronales.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

}
