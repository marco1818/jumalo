package com.bancoazteca.srcu.spring.ws.administracion.empleados;

import com.bancoazteca.srcu.spring.ws.administracion.empleados.axis.Empleado;

public interface DatosEmpleado {
	public Empleado consultaEmpleadoSap(String numeroEmpleado);
}
