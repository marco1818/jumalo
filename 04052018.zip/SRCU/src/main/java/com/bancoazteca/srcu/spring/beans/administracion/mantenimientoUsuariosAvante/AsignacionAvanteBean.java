package com.bancoazteca.srcu.spring.beans.administracion.mantenimientoUsuariosAvante;

import java.util.List;

import com.bancoazteca.srcu.spring.beans.utilerias.BaseBean;

public class AsignacionAvanteBean extends BaseBean{
	private	String	empleadoOpera;
	private	List<DepartamentosAvanteBean> zonas;
	private	List<EmpleadosAvanteBean> coordinadores;
	private	List<AsignacionDepartamentosAvanteBean> regiones;
	private	List<AsignacionDepartamentosAvanteBean> gerencias;
	private	List<JefesCobranzaBean> jefesCobranza;
	private	List<EmpleadosAvanteBean> especialistasRegion;
	private	String coordinadorOperar;
	private String regionOperar;
	private int gerenciaOperar;
//	private List<String> especialistas;
	private	List<String> espeacialistaAsignado;
	private int zonaOperar;
	private List<String> jcsAsignar;
	private List<Integer> especialistaAsignar;
	
	public AsignacionAvanteBean() {
		
	}

	public String getEmpleadoOpera() {
		return empleadoOpera;
	}

	public void setEmpleadoOpera(String empleadoOpera) {
		this.empleadoOpera = empleadoOpera;
	}

	public List<DepartamentosAvanteBean> getZonas() {
		return zonas;
	}

	public void setZonas(List<DepartamentosAvanteBean> zonas) {
		this.zonas = zonas;
	}

	
	public List<EmpleadosAvanteBean> getCoordinadores() {
		return coordinadores;
	}

	public void setCoordinadores(List<EmpleadosAvanteBean> coordinadores) {
		this.coordinadores = coordinadores;
	}

	public List<AsignacionDepartamentosAvanteBean> getRegiones() {
		return regiones;
	}

	public void setRegiones(List<AsignacionDepartamentosAvanteBean> regiones) {
		this.regiones = regiones;
	}

	public List<AsignacionDepartamentosAvanteBean> getGerencias() {
		return gerencias;
	}

	public void setGerencias(List<AsignacionDepartamentosAvanteBean> gerencias) {
		this.gerencias = gerencias;
	}

	public List<JefesCobranzaBean> getJefesCobranza() {
		return jefesCobranza;
	}

	public void setJefesCobranza(List<JefesCobranzaBean> jefesCobranza) {
		this.jefesCobranza = jefesCobranza;
	}

	public List<EmpleadosAvanteBean> getEspecialistasRegion() {
		return especialistasRegion;
	}

	public void setEspecialistasRegion(List<EmpleadosAvanteBean> especialistasRegion) {
		this.especialistasRegion = especialistasRegion;
	}

	public String getCoordinadorOperar() {
		return coordinadorOperar;
	}

	public void setCoordinadorOperar(String coordinadorOperar) {
		this.coordinadorOperar = coordinadorOperar;
	}

	public int getGerenciaOperar() {
		return gerenciaOperar;
	}

	public void setGerenciaOperar(int gerenciaOperar) {
		this.gerenciaOperar = gerenciaOperar;
	}

	public String getRegionOperar() {
		return regionOperar;
	}

	public void setRegionOperar(String regionOperar) {
		this.regionOperar = regionOperar;
	}

	public int getZonaOperar() {
		return zonaOperar;
	}

	public void setZonaOperar(int zonaOperar) {
		this.zonaOperar = zonaOperar;
	}
		
	public List<String> getEspeacialistaAsignado() {
		return espeacialistaAsignado;
	}

	public void setEspeacialistaAsignado(List<String> espeacialistaAsignado) {
		this.espeacialistaAsignado = espeacialistaAsignado;
	}

	public List<String> getJcsAsignar() {
		return jcsAsignar;
	}

	public void setJcsAsignar(List<String> jcsAsignar) {
		this.jcsAsignar = jcsAsignar;
	}

	public List<Integer> getEspecialistaAsignar() {
		return especialistaAsignar;
	}

	public void setEspecialistaAsignar(List<Integer> especialistaAsignar) {
		this.especialistaAsignar = especialistaAsignar;
	}
	
	
}

