package com.bancoazteca.srcu.spring.servicios.administracion.personalActivo;

import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.bancoazteca.srcu.spring.beans.administracion.personalActivo.ComparacionSapBean;
import com.bancoazteca.srcu.spring.beans.administracion.personalActivo.PersonalActivoBean;
import com.bancoazteca.srcu.spring.beans.administracion.personalActivo.VacantesSrcuBean;
import com.bancoazteca.srcu.spring.beans.utilerias.SimpleBean;
import com.bancoazteca.srcu.spring.daos.administracion.mantenimientoUsuariosSap.MantenimientoUsuariosSapDAO;
import com.bancoazteca.srcu.spring.daos.administracion.personalActivo.PersonalActivoDAO;
import com.bancoazteca.srcu.spring.ws.administracion.posicionesSap.PosicionesSapBean;
import com.bancoazteca.srcu.spring.ws.administracion.posicionesSap.ServiciosSAP;
import com.bancoazteca.srcu.spring.ws.administracion.posicionesSap.ServiciosSAPImpl.Enum_ServiciosSAP_Consulta;

@Service
public class PersonalActivoServicioImpl implements PersonalActivoServicio{

	public interface Enum_Consultas_PersonalActivo{
		int	consultaPersonalActivo		=	1;
	}
	
	public interface Enum_Funciones_SAP{
		int	segmento_1A		=	215;
		int	segmento_1B		=	8342;
		int	segmento_2A		=	276;
		int	jv				=	377;
		int	jvc				=	8312;
		int segmento_2A_CT	=	9474;
		int segmento_2B_CT	=	9475;
	}
	
	public interface Enum_Segmentos_Srcu{
		int	segmento_1A	=	1;
		int	segmento_1B	=	2;
		int	segmento_2A	=	4;
		int	segmento_2B	=	44;
		int	jvc			=	50;
		int	jv			=	119;
	}
	
	public interface Enum_Segmentos_Desc{
		String	JC_1A	=	"SEGMENTO 1A";
		String	JC_1B	=	"SEGMENTO 1B";
		String	JC_2A	=	"SEGMENTO 2A";
		String	JC_2B	=	"SEGMENTO 2B";
		String	JCV		=	"JCV (BANCA)";
		String	JVC		=	"JVC";
	}
	
	@Autowired
	private PersonalActivoDAO personalActivoDAO;
	@Autowired
	private MantenimientoUsuariosSapDAO mantenimientoUsuariosSapDAO;
	@Autowired
	private ServiciosSAP serviciosSAP;	

	@Override
	public List<PersonalActivoBean> consulta(int gerenciaId, int opcion) {
		List<PersonalActivoBean> personalActivo = new ArrayList<PersonalActivoBean>();
		
		switch (opcion) {
		case Enum_Consultas_PersonalActivo.consultaPersonalActivo:
				personalActivo = personalActivoDAO.consultaPersonalActivo(gerenciaId);
			break;
		default:
			break;
		}
		
		return personalActivo;
	}
	
	@Override
	public List<ComparacionSapBean> comparacionSap(int deptoId) {
		List<ComparacionSapBean> comparacionSap = null;
		
		List<PosicionesSapBean> posicionesSap = new ArrayList<PosicionesSapBean>(); 
		SimpleBean centroCostos = mantenimientoUsuariosSapDAO.consultaCeco(deptoId);
		posicionesSap = serviciosSAP.consultaPosicionesSAP(Enum_ServiciosSAP_Consulta.posiciones_vacantes_x_ceco, String.valueOf(centroCostos.getCodigo()), 0);
		List<VacantesSrcuBean> vacantesSrcu = mantenimientoUsuariosSapDAO.consultaVacantesSrcu(deptoId, 1);
		
		if(posicionesSap != null) {
			comparacionSap = new ArrayList<ComparacionSapBean>();
			
			int segmento1A	=	0;
			int segmento1B	=	0;
			int segmento2A	=	0;
			int segmento2B	=	0;
			int	jv			=	0;
			int	jvc			=	0;
			
			for(PosicionesSapBean posicionesSapBean: posicionesSap) {
				switch (posicionesSapBean.getFuncionSAP()) {
				case Enum_Funciones_SAP.segmento_1A:
					segmento1A++;
					break;
				case Enum_Funciones_SAP.segmento_1B:
					segmento1B++;
					break;
				case Enum_Funciones_SAP.segmento_2A:
					segmento2A++;
					break;
				case Enum_Funciones_SAP.segmento_2A_CT:
					segmento2A++;
					break;
				case Enum_Funciones_SAP.segmento_2B_CT:
					segmento2B++;
					break;
				case Enum_Funciones_SAP.jv:
					jv++;
					break;
				case Enum_Funciones_SAP.jvc:
					jvc++;
					break;

				default:
					break;
				}
			}
			
			for(VacantesSrcuBean vacantesSrcuBean: vacantesSrcu) {
				ComparacionSapBean comparacionBean = null;
				switch (vacantesSrcuBean.getSegmento()) {
				case Enum_Segmentos_Srcu.segmento_1A:
					comparacionBean	= new ComparacionSapBean(vacantesSrcuBean.getDeptoId(),Enum_Funciones_SAP.segmento_1A,vacantesSrcuBean.getTotalVirtuales(),segmento1A,vacantesSrcuBean.getSegmento(),(segmento1A-vacantesSrcuBean.getTotalVirtuales()));
					comparacionBean.setSegmentoDesc(Enum_Segmentos_Desc.JC_1A);
					comparacionSap.add(comparacionBean);
					break;
				case Enum_Segmentos_Srcu.segmento_1B:
					comparacionBean	= new ComparacionSapBean(vacantesSrcuBean.getDeptoId(),Enum_Funciones_SAP.segmento_1B,vacantesSrcuBean.getTotalVirtuales(),segmento1B,vacantesSrcuBean.getSegmento(),(segmento1B-vacantesSrcuBean.getTotalVirtuales()));
					comparacionBean.setSegmentoDesc(Enum_Segmentos_Desc.JC_1B);
					comparacionSap.add(comparacionBean);
					break;
				case Enum_Segmentos_Srcu.segmento_2A:
					comparacionBean	= new ComparacionSapBean(vacantesSrcuBean.getDeptoId(),Enum_Funciones_SAP.segmento_2A,vacantesSrcuBean.getTotalVirtuales(),segmento2A,vacantesSrcuBean.getSegmento(),(segmento2A-vacantesSrcuBean.getTotalVirtuales()));
					comparacionBean.setSegmentoDesc(Enum_Segmentos_Desc.JC_2A);
					comparacionSap.add(comparacionBean);
					break;
				case Enum_Segmentos_Srcu.segmento_2B:
					comparacionBean	= new ComparacionSapBean(vacantesSrcuBean.getDeptoId(),Enum_Funciones_SAP.segmento_2B_CT,vacantesSrcuBean.getTotalVirtuales(),segmento2B,vacantesSrcuBean.getSegmento(),(segmento2B-vacantesSrcuBean.getTotalVirtuales()));
					comparacionBean.setSegmentoDesc(Enum_Segmentos_Desc.JC_2B);
					comparacionSap.add(comparacionBean);
					break;
				case Enum_Segmentos_Srcu.jv:
					comparacionBean	= new ComparacionSapBean(vacantesSrcuBean.getDeptoId(),Enum_Funciones_SAP.jv,vacantesSrcuBean.getTotalVirtuales(),jv,vacantesSrcuBean.getSegmento(),(jv-vacantesSrcuBean.getTotalVirtuales()));
					comparacionBean.setSegmentoDesc(Enum_Segmentos_Desc.JCV);
					comparacionSap.add(comparacionBean);
					break;
				case Enum_Segmentos_Srcu.jvc:
					comparacionBean	= new ComparacionSapBean(vacantesSrcuBean.getDeptoId(),Enum_Funciones_SAP.jvc,vacantesSrcuBean.getTotalVirtuales(),jvc,vacantesSrcuBean.getSegmento(),(jvc-vacantesSrcuBean.getTotalVirtuales()));
					comparacionBean.setSegmentoDesc(Enum_Segmentos_Desc.JVC);
					comparacionSap.add(comparacionBean);
					break;
				default:
					break;
				}
			}
		}
		
		return comparacionSap;
	}
	
	public void setPersonalActivoDAO(PersonalActivoDAO personalActivoDAO) {
		this.personalActivoDAO = personalActivoDAO;
	}
	
	public void setServiciosSAP(ServiciosSAP serviciosSAP) {
		this.serviciosSAP = serviciosSAP;
	}
	
	public void setMantenimientoUsuariosSapDAO(MantenimientoUsuariosSapDAO mantenimientoUsuariosSapDAO) {
		this.mantenimientoUsuariosSapDAO = mantenimientoUsuariosSapDAO;
	}

}
