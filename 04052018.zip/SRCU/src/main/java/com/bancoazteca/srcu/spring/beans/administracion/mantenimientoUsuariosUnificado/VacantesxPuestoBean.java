package com.bancoazteca.srcu.spring.beans.administracion.mantenimientoUsuariosUnificado;

import java.math.BigDecimal;

public class VacantesxPuestoBean {
	private	int	segmentoId;
	private	String	segmentoDesc;
	
	public VacantesxPuestoBean() {
		
	}

	public int getSegmentoId() {
		return segmentoId;
	}

	public void setSegmentoId(int segmentoId) {
		this.segmentoId = segmentoId;
	}

	public void setSegmentoId(BigDecimal segmentoId) {
		this.segmentoId = segmentoId.intValue();
	}
	
	public String getSegmentoDesc() {
		return segmentoDesc;
	}

	public void setSegmentoDesc(String segmentoDesc) {
		this.segmentoDesc = segmentoDesc;
	}
	
}