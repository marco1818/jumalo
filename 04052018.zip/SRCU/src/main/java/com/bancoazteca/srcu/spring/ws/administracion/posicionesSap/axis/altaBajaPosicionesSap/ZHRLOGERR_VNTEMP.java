/**
 * ZHRLOGERR_VNTEMP.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.bancoazteca.srcu.spring.ws.administracion.posicionesSap.axis.altaBajaPosicionesSap;

public class ZHRLOGERR_VNTEMP  extends SAPStructure  implements java.io.Serializable {

	private static final long serialVersionUID = 5878495362840162598L;

	private java.lang.String MANDT;

    private java.lang.String PERNR;

    private java.lang.String AEDTM;

    private java.lang.String CONSECUTIVO;

    private java.lang.String UNAME;

    private java.lang.String FOLIO;

    private java.lang.String REFERENCIA;

    private java.lang.String TEXT;

    private java.lang.String TCODE;

    private java.lang.String DYNAME;

    private java.lang.String DYNUMB;

    private java.lang.String MSGTYP;

    private java.lang.String MSGSPRA;

    private java.lang.String MSGID;

    private java.lang.String MSGNR;

    private java.lang.String MSGV1;

    private java.lang.String MSGV2;

    private java.lang.String MSGV3;

    private java.lang.String MSGV4;

    private java.lang.String ENV;

    private java.lang.String FLDNAME;

    public ZHRLOGERR_VNTEMP() {
    }

    public ZHRLOGERR_VNTEMP(
           java.lang.String MANDT,
           java.lang.String PERNR,
           java.lang.String AEDTM,
           java.lang.String CONSECUTIVO,
           java.lang.String UNAME,
           java.lang.String FOLIO,
           java.lang.String REFERENCIA,
           java.lang.String TEXT,
           java.lang.String TCODE,
           java.lang.String DYNAME,
           java.lang.String DYNUMB,
           java.lang.String MSGTYP,
           java.lang.String MSGSPRA,
           java.lang.String MSGID,
           java.lang.String MSGNR,
           java.lang.String MSGV1,
           java.lang.String MSGV2,
           java.lang.String MSGV3,
           java.lang.String MSGV4,
           java.lang.String ENV,
           java.lang.String FLDNAME) {
        this.MANDT = MANDT;
        this.PERNR = PERNR;
        this.AEDTM = AEDTM;
        this.CONSECUTIVO = CONSECUTIVO;
        this.UNAME = UNAME;
        this.FOLIO = FOLIO;
        this.REFERENCIA = REFERENCIA;
        this.TEXT = TEXT;
        this.TCODE = TCODE;
        this.DYNAME = DYNAME;
        this.DYNUMB = DYNUMB;
        this.MSGTYP = MSGTYP;
        this.MSGSPRA = MSGSPRA;
        this.MSGID = MSGID;
        this.MSGNR = MSGNR;
        this.MSGV1 = MSGV1;
        this.MSGV2 = MSGV2;
        this.MSGV3 = MSGV3;
        this.MSGV4 = MSGV4;
        this.ENV = ENV;
        this.FLDNAME = FLDNAME;
    }


    /**
     * Gets the MANDT value for this ZHRLOGERR_VNTEMP.
     * 
     * @return MANDT
     */
    public java.lang.String getMANDT() {
        return MANDT;
    }


    /**
     * Sets the MANDT value for this ZHRLOGERR_VNTEMP.
     * 
     * @param MANDT
     */
    public void setMANDT(java.lang.String MANDT) {
        this.MANDT = MANDT;
    }


    /**
     * Gets the PERNR value for this ZHRLOGERR_VNTEMP.
     * 
     * @return PERNR
     */
    public java.lang.String getPERNR() {
        return PERNR;
    }


    /**
     * Sets the PERNR value for this ZHRLOGERR_VNTEMP.
     * 
     * @param PERNR
     */
    public void setPERNR(java.lang.String PERNR) {
        this.PERNR = PERNR;
    }


    /**
     * Gets the AEDTM value for this ZHRLOGERR_VNTEMP.
     * 
     * @return AEDTM
     */
    public java.lang.String getAEDTM() {
        return AEDTM;
    }


    /**
     * Sets the AEDTM value for this ZHRLOGERR_VNTEMP.
     * 
     * @param AEDTM
     */
    public void setAEDTM(java.lang.String AEDTM) {
        this.AEDTM = AEDTM;
    }


    /**
     * Gets the CONSECUTIVO value for this ZHRLOGERR_VNTEMP.
     * 
     * @return CONSECUTIVO
     */
    public java.lang.String getCONSECUTIVO() {
        return CONSECUTIVO;
    }


    /**
     * Sets the CONSECUTIVO value for this ZHRLOGERR_VNTEMP.
     * 
     * @param CONSECUTIVO
     */
    public void setCONSECUTIVO(java.lang.String CONSECUTIVO) {
        this.CONSECUTIVO = CONSECUTIVO;
    }


    /**
     * Gets the UNAME value for this ZHRLOGERR_VNTEMP.
     * 
     * @return UNAME
     */
    public java.lang.String getUNAME() {
        return UNAME;
    }


    /**
     * Sets the UNAME value for this ZHRLOGERR_VNTEMP.
     * 
     * @param UNAME
     */
    public void setUNAME(java.lang.String UNAME) {
        this.UNAME = UNAME;
    }


    /**
     * Gets the FOLIO value for this ZHRLOGERR_VNTEMP.
     * 
     * @return FOLIO
     */
    public java.lang.String getFOLIO() {
        return FOLIO;
    }


    /**
     * Sets the FOLIO value for this ZHRLOGERR_VNTEMP.
     * 
     * @param FOLIO
     */
    public void setFOLIO(java.lang.String FOLIO) {
        this.FOLIO = FOLIO;
    }


    /**
     * Gets the REFERENCIA value for this ZHRLOGERR_VNTEMP.
     * 
     * @return REFERENCIA
     */
    public java.lang.String getREFERENCIA() {
        return REFERENCIA;
    }


    /**
     * Sets the REFERENCIA value for this ZHRLOGERR_VNTEMP.
     * 
     * @param REFERENCIA
     */
    public void setREFERENCIA(java.lang.String REFERENCIA) {
        this.REFERENCIA = REFERENCIA;
    }


    /**
     * Gets the TEXT value for this ZHRLOGERR_VNTEMP.
     * 
     * @return TEXT
     */
    public java.lang.String getTEXT() {
        return TEXT;
    }


    /**
     * Sets the TEXT value for this ZHRLOGERR_VNTEMP.
     * 
     * @param TEXT
     */
    public void setTEXT(java.lang.String TEXT) {
        this.TEXT = TEXT;
    }


    /**
     * Gets the TCODE value for this ZHRLOGERR_VNTEMP.
     * 
     * @return TCODE
     */
    public java.lang.String getTCODE() {
        return TCODE;
    }


    /**
     * Sets the TCODE value for this ZHRLOGERR_VNTEMP.
     * 
     * @param TCODE
     */
    public void setTCODE(java.lang.String TCODE) {
        this.TCODE = TCODE;
    }


    /**
     * Gets the DYNAME value for this ZHRLOGERR_VNTEMP.
     * 
     * @return DYNAME
     */
    public java.lang.String getDYNAME() {
        return DYNAME;
    }


    /**
     * Sets the DYNAME value for this ZHRLOGERR_VNTEMP.
     * 
     * @param DYNAME
     */
    public void setDYNAME(java.lang.String DYNAME) {
        this.DYNAME = DYNAME;
    }


    /**
     * Gets the DYNUMB value for this ZHRLOGERR_VNTEMP.
     * 
     * @return DYNUMB
     */
    public java.lang.String getDYNUMB() {
        return DYNUMB;
    }


    /**
     * Sets the DYNUMB value for this ZHRLOGERR_VNTEMP.
     * 
     * @param DYNUMB
     */
    public void setDYNUMB(java.lang.String DYNUMB) {
        this.DYNUMB = DYNUMB;
    }


    /**
     * Gets the MSGTYP value for this ZHRLOGERR_VNTEMP.
     * 
     * @return MSGTYP
     */
    public java.lang.String getMSGTYP() {
        return MSGTYP;
    }


    /**
     * Sets the MSGTYP value for this ZHRLOGERR_VNTEMP.
     * 
     * @param MSGTYP
     */
    public void setMSGTYP(java.lang.String MSGTYP) {
        this.MSGTYP = MSGTYP;
    }


    /**
     * Gets the MSGSPRA value for this ZHRLOGERR_VNTEMP.
     * 
     * @return MSGSPRA
     */
    public java.lang.String getMSGSPRA() {
        return MSGSPRA;
    }


    /**
     * Sets the MSGSPRA value for this ZHRLOGERR_VNTEMP.
     * 
     * @param MSGSPRA
     */
    public void setMSGSPRA(java.lang.String MSGSPRA) {
        this.MSGSPRA = MSGSPRA;
    }


    /**
     * Gets the MSGID value for this ZHRLOGERR_VNTEMP.
     * 
     * @return MSGID
     */
    public java.lang.String getMSGID() {
        return MSGID;
    }


    /**
     * Sets the MSGID value for this ZHRLOGERR_VNTEMP.
     * 
     * @param MSGID
     */
    public void setMSGID(java.lang.String MSGID) {
        this.MSGID = MSGID;
    }


    /**
     * Gets the MSGNR value for this ZHRLOGERR_VNTEMP.
     * 
     * @return MSGNR
     */
    public java.lang.String getMSGNR() {
        return MSGNR;
    }


    /**
     * Sets the MSGNR value for this ZHRLOGERR_VNTEMP.
     * 
     * @param MSGNR
     */
    public void setMSGNR(java.lang.String MSGNR) {
        this.MSGNR = MSGNR;
    }


    /**
     * Gets the MSGV1 value for this ZHRLOGERR_VNTEMP.
     * 
     * @return MSGV1
     */
    public java.lang.String getMSGV1() {
        return MSGV1;
    }


    /**
     * Sets the MSGV1 value for this ZHRLOGERR_VNTEMP.
     * 
     * @param MSGV1
     */
    public void setMSGV1(java.lang.String MSGV1) {
        this.MSGV1 = MSGV1;
    }


    /**
     * Gets the MSGV2 value for this ZHRLOGERR_VNTEMP.
     * 
     * @return MSGV2
     */
    public java.lang.String getMSGV2() {
        return MSGV2;
    }


    /**
     * Sets the MSGV2 value for this ZHRLOGERR_VNTEMP.
     * 
     * @param MSGV2
     */
    public void setMSGV2(java.lang.String MSGV2) {
        this.MSGV2 = MSGV2;
    }


    /**
     * Gets the MSGV3 value for this ZHRLOGERR_VNTEMP.
     * 
     * @return MSGV3
     */
    public java.lang.String getMSGV3() {
        return MSGV3;
    }


    /**
     * Sets the MSGV3 value for this ZHRLOGERR_VNTEMP.
     * 
     * @param MSGV3
     */
    public void setMSGV3(java.lang.String MSGV3) {
        this.MSGV3 = MSGV3;
    }


    /**
     * Gets the MSGV4 value for this ZHRLOGERR_VNTEMP.
     * 
     * @return MSGV4
     */
    public java.lang.String getMSGV4() {
        return MSGV4;
    }


    /**
     * Sets the MSGV4 value for this ZHRLOGERR_VNTEMP.
     * 
     * @param MSGV4
     */
    public void setMSGV4(java.lang.String MSGV4) {
        this.MSGV4 = MSGV4;
    }


    /**
     * Gets the ENV value for this ZHRLOGERR_VNTEMP.
     * 
     * @return ENV
     */
    public java.lang.String getENV() {
        return ENV;
    }


    /**
     * Sets the ENV value for this ZHRLOGERR_VNTEMP.
     * 
     * @param ENV
     */
    public void setENV(java.lang.String ENV) {
        this.ENV = ENV;
    }


    /**
     * Gets the FLDNAME value for this ZHRLOGERR_VNTEMP.
     * 
     * @return FLDNAME
     */
    public java.lang.String getFLDNAME() {
        return FLDNAME;
    }


    /**
     * Sets the FLDNAME value for this ZHRLOGERR_VNTEMP.
     * 
     * @param FLDNAME
     */
    public void setFLDNAME(java.lang.String FLDNAME) {
        this.FLDNAME = FLDNAME;
    }

    private java.lang.Object __equalsCalc = null;
    @SuppressWarnings("unused")
	public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ZHRLOGERR_VNTEMP)) return false;
        ZHRLOGERR_VNTEMP other = (ZHRLOGERR_VNTEMP) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.MANDT==null && other.getMANDT()==null) || 
             (this.MANDT!=null &&
              this.MANDT.equals(other.getMANDT()))) &&
            ((this.PERNR==null && other.getPERNR()==null) || 
             (this.PERNR!=null &&
              this.PERNR.equals(other.getPERNR()))) &&
            ((this.AEDTM==null && other.getAEDTM()==null) || 
             (this.AEDTM!=null &&
              this.AEDTM.equals(other.getAEDTM()))) &&
            ((this.CONSECUTIVO==null && other.getCONSECUTIVO()==null) || 
             (this.CONSECUTIVO!=null &&
              this.CONSECUTIVO.equals(other.getCONSECUTIVO()))) &&
            ((this.UNAME==null && other.getUNAME()==null) || 
             (this.UNAME!=null &&
              this.UNAME.equals(other.getUNAME()))) &&
            ((this.FOLIO==null && other.getFOLIO()==null) || 
             (this.FOLIO!=null &&
              this.FOLIO.equals(other.getFOLIO()))) &&
            ((this.REFERENCIA==null && other.getREFERENCIA()==null) || 
             (this.REFERENCIA!=null &&
              this.REFERENCIA.equals(other.getREFERENCIA()))) &&
            ((this.TEXT==null && other.getTEXT()==null) || 
             (this.TEXT!=null &&
              this.TEXT.equals(other.getTEXT()))) &&
            ((this.TCODE==null && other.getTCODE()==null) || 
             (this.TCODE!=null &&
              this.TCODE.equals(other.getTCODE()))) &&
            ((this.DYNAME==null && other.getDYNAME()==null) || 
             (this.DYNAME!=null &&
              this.DYNAME.equals(other.getDYNAME()))) &&
            ((this.DYNUMB==null && other.getDYNUMB()==null) || 
             (this.DYNUMB!=null &&
              this.DYNUMB.equals(other.getDYNUMB()))) &&
            ((this.MSGTYP==null && other.getMSGTYP()==null) || 
             (this.MSGTYP!=null &&
              this.MSGTYP.equals(other.getMSGTYP()))) &&
            ((this.MSGSPRA==null && other.getMSGSPRA()==null) || 
             (this.MSGSPRA!=null &&
              this.MSGSPRA.equals(other.getMSGSPRA()))) &&
            ((this.MSGID==null && other.getMSGID()==null) || 
             (this.MSGID!=null &&
              this.MSGID.equals(other.getMSGID()))) &&
            ((this.MSGNR==null && other.getMSGNR()==null) || 
             (this.MSGNR!=null &&
              this.MSGNR.equals(other.getMSGNR()))) &&
            ((this.MSGV1==null && other.getMSGV1()==null) || 
             (this.MSGV1!=null &&
              this.MSGV1.equals(other.getMSGV1()))) &&
            ((this.MSGV2==null && other.getMSGV2()==null) || 
             (this.MSGV2!=null &&
              this.MSGV2.equals(other.getMSGV2()))) &&
            ((this.MSGV3==null && other.getMSGV3()==null) || 
             (this.MSGV3!=null &&
              this.MSGV3.equals(other.getMSGV3()))) &&
            ((this.MSGV4==null && other.getMSGV4()==null) || 
             (this.MSGV4!=null &&
              this.MSGV4.equals(other.getMSGV4()))) &&
            ((this.ENV==null && other.getENV()==null) || 
             (this.ENV!=null &&
              this.ENV.equals(other.getENV()))) &&
            ((this.FLDNAME==null && other.getFLDNAME()==null) || 
             (this.FLDNAME!=null &&
              this.FLDNAME.equals(other.getFLDNAME())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getMANDT() != null) {
            _hashCode += getMANDT().hashCode();
        }
        if (getPERNR() != null) {
            _hashCode += getPERNR().hashCode();
        }
        if (getAEDTM() != null) {
            _hashCode += getAEDTM().hashCode();
        }
        if (getCONSECUTIVO() != null) {
            _hashCode += getCONSECUTIVO().hashCode();
        }
        if (getUNAME() != null) {
            _hashCode += getUNAME().hashCode();
        }
        if (getFOLIO() != null) {
            _hashCode += getFOLIO().hashCode();
        }
        if (getREFERENCIA() != null) {
            _hashCode += getREFERENCIA().hashCode();
        }
        if (getTEXT() != null) {
            _hashCode += getTEXT().hashCode();
        }
        if (getTCODE() != null) {
            _hashCode += getTCODE().hashCode();
        }
        if (getDYNAME() != null) {
            _hashCode += getDYNAME().hashCode();
        }
        if (getDYNUMB() != null) {
            _hashCode += getDYNUMB().hashCode();
        }
        if (getMSGTYP() != null) {
            _hashCode += getMSGTYP().hashCode();
        }
        if (getMSGSPRA() != null) {
            _hashCode += getMSGSPRA().hashCode();
        }
        if (getMSGID() != null) {
            _hashCode += getMSGID().hashCode();
        }
        if (getMSGNR() != null) {
            _hashCode += getMSGNR().hashCode();
        }
        if (getMSGV1() != null) {
            _hashCode += getMSGV1().hashCode();
        }
        if (getMSGV2() != null) {
            _hashCode += getMSGV2().hashCode();
        }
        if (getMSGV3() != null) {
            _hashCode += getMSGV3().hashCode();
        }
        if (getMSGV4() != null) {
            _hashCode += getMSGV4().hashCode();
        }
        if (getENV() != null) {
            _hashCode += getENV().hashCode();
        }
        if (getFLDNAME() != null) {
            _hashCode += getFLDNAME().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ZHRLOGERR_VNTEMP.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://tempuri.org/", "ZHRLOGERR_VNTEMP"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("MANDT");
        elemField.setXmlName(new javax.xml.namespace.QName("", "MANDT"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("PERNR");
        elemField.setXmlName(new javax.xml.namespace.QName("", "PERNR"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AEDTM");
        elemField.setXmlName(new javax.xml.namespace.QName("", "AEDTM"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CONSECUTIVO");
        elemField.setXmlName(new javax.xml.namespace.QName("", "CONSECUTIVO"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("UNAME");
        elemField.setXmlName(new javax.xml.namespace.QName("", "UNAME"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("FOLIO");
        elemField.setXmlName(new javax.xml.namespace.QName("", "FOLIO"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("REFERENCIA");
        elemField.setXmlName(new javax.xml.namespace.QName("", "REFERENCIA"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("TEXT");
        elemField.setXmlName(new javax.xml.namespace.QName("", "TEXT"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("TCODE");
        elemField.setXmlName(new javax.xml.namespace.QName("", "TCODE"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("DYNAME");
        elemField.setXmlName(new javax.xml.namespace.QName("", "DYNAME"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("DYNUMB");
        elemField.setXmlName(new javax.xml.namespace.QName("", "DYNUMB"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("MSGTYP");
        elemField.setXmlName(new javax.xml.namespace.QName("", "MSGTYP"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("MSGSPRA");
        elemField.setXmlName(new javax.xml.namespace.QName("", "MSGSPRA"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("MSGID");
        elemField.setXmlName(new javax.xml.namespace.QName("", "MSGID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("MSGNR");
        elemField.setXmlName(new javax.xml.namespace.QName("", "MSGNR"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("MSGV1");
        elemField.setXmlName(new javax.xml.namespace.QName("", "MSGV1"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("MSGV2");
        elemField.setXmlName(new javax.xml.namespace.QName("", "MSGV2"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("MSGV3");
        elemField.setXmlName(new javax.xml.namespace.QName("", "MSGV3"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("MSGV4");
        elemField.setXmlName(new javax.xml.namespace.QName("", "MSGV4"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ENV");
        elemField.setXmlName(new javax.xml.namespace.QName("", "ENV"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("FLDNAME");
        elemField.setXmlName(new javax.xml.namespace.QName("", "FLDNAME"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    @SuppressWarnings("rawtypes")
	public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    @SuppressWarnings("rawtypes")
	public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
