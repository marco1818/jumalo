/**
 * EmpleadoBaja.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.bancoazteca.srcu.spring.ws.administracion.empleados.axis;

public class EmpleadoBaja  implements java.io.Serializable {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1777696589730093373L;

	private int numeroEmpleado;

    private java.lang.String situacion;

    private java.lang.String enProcesoBaja;

    private java.lang.String fechaBaja;

    private java.lang.String tieneFiniquito;

    private java.lang.String tipoPago;

    private java.math.BigDecimal montoFiniquito;

    public EmpleadoBaja() {
    }

    public EmpleadoBaja(
           int numeroEmpleado,
           java.lang.String situacion,
           java.lang.String enProcesoBaja,
           java.lang.String fechaBaja,
           java.lang.String tieneFiniquito,
           java.lang.String tipoPago,
           java.math.BigDecimal montoFiniquito) {
           this.numeroEmpleado = numeroEmpleado;
           this.situacion = situacion;
           this.enProcesoBaja = enProcesoBaja;
           this.fechaBaja = fechaBaja;
           this.tieneFiniquito = tieneFiniquito;
           this.tipoPago = tipoPago;
           this.montoFiniquito = montoFiniquito;
    }


    /**
     * Gets the numeroEmpleado value for this EmpleadoBaja.
     * 
     * @return numeroEmpleado
     */
    public int getNumeroEmpleado() {
        return numeroEmpleado;
    }


    /**
     * Sets the numeroEmpleado value for this EmpleadoBaja.
     * 
     * @param numeroEmpleado
     */
    public void setNumeroEmpleado(int numeroEmpleado) {
        this.numeroEmpleado = numeroEmpleado;
    }


    /**
     * Gets the situacion value for this EmpleadoBaja.
     * 
     * @return situacion
     */
    public java.lang.String getSituacion() {
        return situacion;
    }


    /**
     * Sets the situacion value for this EmpleadoBaja.
     * 
     * @param situacion
     */
    public void setSituacion(java.lang.String situacion) {
        this.situacion = situacion;
    }


    /**
     * Gets the enProcesoBaja value for this EmpleadoBaja.
     * 
     * @return enProcesoBaja
     */
    public java.lang.String getEnProcesoBaja() {
        return enProcesoBaja;
    }


    /**
     * Sets the enProcesoBaja value for this EmpleadoBaja.
     * 
     * @param enProcesoBaja
     */
    public void setEnProcesoBaja(java.lang.String enProcesoBaja) {
        this.enProcesoBaja = enProcesoBaja;
    }


    /**
     * Gets the fechaBaja value for this EmpleadoBaja.
     * 
     * @return fechaBaja
     */
    public java.lang.String getFechaBaja() {
        return fechaBaja;
    }


    /**
     * Sets the fechaBaja value for this EmpleadoBaja.
     * 
     * @param fechaBaja
     */
    public void setFechaBaja(java.lang.String fechaBaja) {
        this.fechaBaja = fechaBaja;
    }


    /**
     * Gets the tieneFiniquito value for this EmpleadoBaja.
     * 
     * @return tieneFiniquito
     */
    public java.lang.String getTieneFiniquito() {
        return tieneFiniquito;
    }


    /**
     * Sets the tieneFiniquito value for this EmpleadoBaja.
     * 
     * @param tieneFiniquito
     */
    public void setTieneFiniquito(java.lang.String tieneFiniquito) {
        this.tieneFiniquito = tieneFiniquito;
    }


    /**
     * Gets the tipoPago value for this EmpleadoBaja.
     * 
     * @return tipoPago
     */
    public java.lang.String getTipoPago() {
        return tipoPago;
    }


    /**
     * Sets the tipoPago value for this EmpleadoBaja.
     * 
     * @param tipoPago
     */
    public void setTipoPago(java.lang.String tipoPago) {
        this.tipoPago = tipoPago;
    }


    /**
     * Gets the montoFiniquito value for this EmpleadoBaja.
     * 
     * @return montoFiniquito
     */
    public java.math.BigDecimal getMontoFiniquito() {
        return montoFiniquito;
    }


    /**
     * Sets the montoFiniquito value for this EmpleadoBaja.
     * 
     * @param montoFiniquito
     */
    public void setMontoFiniquito(java.math.BigDecimal montoFiniquito) {
        this.montoFiniquito = montoFiniquito;
    }

    private java.lang.Object __equalsCalc = null;
    @SuppressWarnings("unused")
	public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof EmpleadoBaja)) return false;
        EmpleadoBaja other = (EmpleadoBaja) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this.numeroEmpleado == other.getNumeroEmpleado() &&
            ((this.situacion==null && other.getSituacion()==null) || 
             (this.situacion!=null &&
              this.situacion.equals(other.getSituacion()))) &&
            ((this.enProcesoBaja==null && other.getEnProcesoBaja()==null) || 
             (this.enProcesoBaja!=null &&
              this.enProcesoBaja.equals(other.getEnProcesoBaja()))) &&
            ((this.fechaBaja==null && other.getFechaBaja()==null) || 
             (this.fechaBaja!=null &&
              this.fechaBaja.equals(other.getFechaBaja()))) &&
            ((this.tieneFiniquito==null && other.getTieneFiniquito()==null) || 
             (this.tieneFiniquito!=null &&
              this.tieneFiniquito.equals(other.getTieneFiniquito()))) &&
            ((this.tipoPago==null && other.getTipoPago()==null) || 
             (this.tipoPago!=null &&
              this.tipoPago.equals(other.getTipoPago()))) &&
            ((this.montoFiniquito==null && other.getMontoFiniquito()==null) || 
             (this.montoFiniquito!=null &&
              this.montoFiniquito.equals(other.getMontoFiniquito())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += getNumeroEmpleado();
        if (getSituacion() != null) {
            _hashCode += getSituacion().hashCode();
        }
        if (getEnProcesoBaja() != null) {
            _hashCode += getEnProcesoBaja().hashCode();
        }
        if (getFechaBaja() != null) {
            _hashCode += getFechaBaja().hashCode();
        }
        if (getTieneFiniquito() != null) {
            _hashCode += getTieneFiniquito().hashCode();
        }
        if (getTipoPago() != null) {
            _hashCode += getTipoPago().hashCode();
        }
        if (getMontoFiniquito() != null) {
            _hashCode += getMontoFiniquito().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(EmpleadoBaja.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "EmpleadoBaja"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroEmpleado");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "NumeroEmpleado"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("situacion");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Situacion"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("enProcesoBaja");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "EnProcesoBaja"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("fechaBaja");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "FechaBaja"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("tieneFiniquito");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "TieneFiniquito"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("tipoPago");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "TipoPago"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("montoFiniquito");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "MontoFiniquito"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    @SuppressWarnings("rawtypes")
	public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    @SuppressWarnings("rawtypes")
	public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
