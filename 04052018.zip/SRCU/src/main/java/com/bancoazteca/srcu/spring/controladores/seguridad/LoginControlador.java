package com.bancoazteca.srcu.spring.controladores.seguridad;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class LoginControlador {

	@InitBinder
	public void InitBinder(WebDataBinder webDataBinder, WebRequest webRequest) {
		webDataBinder.setDisallowedFields("");
	}

	@RequestMapping(value = { "/", "/login.htm" }, method = RequestMethod.GET)
	public ModelAndView login() {
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("seguridad/login");
		return modelAndView;
	}

}
