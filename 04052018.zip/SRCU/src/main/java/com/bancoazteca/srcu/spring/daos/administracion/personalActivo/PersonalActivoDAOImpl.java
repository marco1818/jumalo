package com.bancoazteca.srcu.spring.daos.administracion.personalActivo;

import java.util.ArrayList;
import java.util.List;
import org.springframework.stereotype.Repository;

import com.bancoazteca.srcu.spring.beans.administracion.personalActivo.PersonalActivoBean;
import com.bancoazteca.srcu.spring.daos.utilerias.BaseDAO;

@Repository
public class PersonalActivoDAOImpl extends BaseDAO implements PersonalActivoDAO{
	
	public interface Enum_Funciones_PersonalActivo{
		String	consultaPersonalActivo	=	"CONSULTA_PERSONAL_ACTIVO";
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<PersonalActivoBean> consultaPersonalActivo(int gerenciaId) {
		List<PersonalActivoBean> personalActivoBean = new ArrayList<PersonalActivoBean>();
		ArrayList<Object> parametros = new ArrayList<Object>();
		parametros.add(gerenciaId);
		parametros.add("ES");
		
		
		personalActivoBean =  (List<PersonalActivoBean>) ejecutaFuncionAll(Enum_Funciones_PersonalActivo.consultaPersonalActivo, parametros, new PersonalActivoBean().getClass());
		
		for(int posicion = 0;posicion < personalActivoBean.size();posicion++) {
			if(personalActivoBean.get(posicion).getIdPuesEmp() == 469) {
				personalActivoBean.remove(posicion);
			}
		}
		
		return personalActivoBean;
	}

}
