/**
 * Subordinado.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.bancoazteca.srcu.spring.ws.administracion.empleados.axis;
@SuppressWarnings({ "unused", "rawtypes", "serial" })
public class Subordinado  implements java.io.Serializable {
    private int numeroEmpleado_Subordinado;

    private java.lang.String nombreInicial_Subordinado;

    private java.lang.String apellidoPaterno_Subordinado;

    private java.lang.String apellidoMaterno_Subordinado;

    private int idPuesto_Subordinado;

    private java.lang.String desPuesto_Subordinado;

    private int idFuncion_Subordinado;

    private java.lang.String desFuncion_Subordinado;

    private int idCentroCostos_Subordinado;

    private java.lang.String desCentroCostos_Subordinado;

    private java.lang.String idCompa�ia_Subordinado;

    private java.lang.String desCompa�ia_Subordinado;

    private int numeroEmpleadoSuperior_Subordinado;

    private java.lang.String nombreEmpleadoSuperior_Subordinado;

    private int idPuestoSuperior_Subordinado;

    private java.lang.String genero_Subordinado;

    private java.lang.String estadoCivil_Subordinado;

    private boolean activo_Subordinado;

    private java.lang.String idHorario_Subordinado;

    private java.lang.String desHorario_Subordinado;

    private java.lang.String periodoPago_Subordinado;

    private java.lang.String idPais_Subordinado;

    private Nomina datosNomina_Subordinado;

    private Fecha fechasEmpleado_Subordinado;

    public Subordinado() {
    }

    public Subordinado(
           int numeroEmpleado_Subordinado,
           java.lang.String nombreInicial_Subordinado,
           java.lang.String apellidoPaterno_Subordinado,
           java.lang.String apellidoMaterno_Subordinado,
           int idPuesto_Subordinado,
           java.lang.String desPuesto_Subordinado,
           int idFuncion_Subordinado,
           java.lang.String desFuncion_Subordinado,
           int idCentroCostos_Subordinado,
           java.lang.String desCentroCostos_Subordinado,
           java.lang.String idCompa�ia_Subordinado,
           java.lang.String desCompa�ia_Subordinado,
           int numeroEmpleadoSuperior_Subordinado,
           java.lang.String nombreEmpleadoSuperior_Subordinado,
           int idPuestoSuperior_Subordinado,
           java.lang.String genero_Subordinado,
           java.lang.String estadoCivil_Subordinado,
           boolean activo_Subordinado,
           java.lang.String idHorario_Subordinado,
           java.lang.String desHorario_Subordinado,
           java.lang.String periodoPago_Subordinado,
           java.lang.String idPais_Subordinado,
           Nomina datosNomina_Subordinado,
           Fecha fechasEmpleado_Subordinado) {
           this.numeroEmpleado_Subordinado = numeroEmpleado_Subordinado;
           this.nombreInicial_Subordinado = nombreInicial_Subordinado;
           this.apellidoPaterno_Subordinado = apellidoPaterno_Subordinado;
           this.apellidoMaterno_Subordinado = apellidoMaterno_Subordinado;
           this.idPuesto_Subordinado = idPuesto_Subordinado;
           this.desPuesto_Subordinado = desPuesto_Subordinado;
           this.idFuncion_Subordinado = idFuncion_Subordinado;
           this.desFuncion_Subordinado = desFuncion_Subordinado;
           this.idCentroCostos_Subordinado = idCentroCostos_Subordinado;
           this.desCentroCostos_Subordinado = desCentroCostos_Subordinado;
           this.idCompa�ia_Subordinado = idCompa�ia_Subordinado;
           this.desCompa�ia_Subordinado = desCompa�ia_Subordinado;
           this.numeroEmpleadoSuperior_Subordinado = numeroEmpleadoSuperior_Subordinado;
           this.nombreEmpleadoSuperior_Subordinado = nombreEmpleadoSuperior_Subordinado;
           this.idPuestoSuperior_Subordinado = idPuestoSuperior_Subordinado;
           this.genero_Subordinado = genero_Subordinado;
           this.estadoCivil_Subordinado = estadoCivil_Subordinado;
           this.activo_Subordinado = activo_Subordinado;
           this.idHorario_Subordinado = idHorario_Subordinado;
           this.desHorario_Subordinado = desHorario_Subordinado;
           this.periodoPago_Subordinado = periodoPago_Subordinado;
           this.idPais_Subordinado = idPais_Subordinado;
           this.datosNomina_Subordinado = datosNomina_Subordinado;
           this.fechasEmpleado_Subordinado = fechasEmpleado_Subordinado;
    }


    /**
     * Gets the numeroEmpleado_Subordinado value for this Subordinado.
     * 
     * @return numeroEmpleado_Subordinado
     */
    public int getNumeroEmpleado_Subordinado() {
        return numeroEmpleado_Subordinado;
    }


    /**
     * Sets the numeroEmpleado_Subordinado value for this Subordinado.
     * 
     * @param numeroEmpleado_Subordinado
     */
    public void setNumeroEmpleado_Subordinado(int numeroEmpleado_Subordinado) {
        this.numeroEmpleado_Subordinado = numeroEmpleado_Subordinado;
    }


    /**
     * Gets the nombreInicial_Subordinado value for this Subordinado.
     * 
     * @return nombreInicial_Subordinado
     */
    public java.lang.String getNombreInicial_Subordinado() {
        return nombreInicial_Subordinado;
    }


    /**
     * Sets the nombreInicial_Subordinado value for this Subordinado.
     * 
     * @param nombreInicial_Subordinado
     */
    public void setNombreInicial_Subordinado(java.lang.String nombreInicial_Subordinado) {
        this.nombreInicial_Subordinado = nombreInicial_Subordinado;
    }


    /**
     * Gets the apellidoPaterno_Subordinado value for this Subordinado.
     * 
     * @return apellidoPaterno_Subordinado
     */
    public java.lang.String getApellidoPaterno_Subordinado() {
        return apellidoPaterno_Subordinado;
    }


    /**
     * Sets the apellidoPaterno_Subordinado value for this Subordinado.
     * 
     * @param apellidoPaterno_Subordinado
     */
    public void setApellidoPaterno_Subordinado(java.lang.String apellidoPaterno_Subordinado) {
        this.apellidoPaterno_Subordinado = apellidoPaterno_Subordinado;
    }


    /**
     * Gets the apellidoMaterno_Subordinado value for this Subordinado.
     * 
     * @return apellidoMaterno_Subordinado
     */
    public java.lang.String getApellidoMaterno_Subordinado() {
        return apellidoMaterno_Subordinado;
    }


    /**
     * Sets the apellidoMaterno_Subordinado value for this Subordinado.
     * 
     * @param apellidoMaterno_Subordinado
     */
    public void setApellidoMaterno_Subordinado(java.lang.String apellidoMaterno_Subordinado) {
        this.apellidoMaterno_Subordinado = apellidoMaterno_Subordinado;
    }


    /**
     * Gets the idPuesto_Subordinado value for this Subordinado.
     * 
     * @return idPuesto_Subordinado
     */
    public int getIdPuesto_Subordinado() {
        return idPuesto_Subordinado;
    }


    /**
     * Sets the idPuesto_Subordinado value for this Subordinado.
     * 
     * @param idPuesto_Subordinado
     */
    public void setIdPuesto_Subordinado(int idPuesto_Subordinado) {
        this.idPuesto_Subordinado = idPuesto_Subordinado;
    }


    /**
     * Gets the desPuesto_Subordinado value for this Subordinado.
     * 
     * @return desPuesto_Subordinado
     */
    public java.lang.String getDesPuesto_Subordinado() {
        return desPuesto_Subordinado;
    }


    /**
     * Sets the desPuesto_Subordinado value for this Subordinado.
     * 
     * @param desPuesto_Subordinado
     */
    public void setDesPuesto_Subordinado(java.lang.String desPuesto_Subordinado) {
        this.desPuesto_Subordinado = desPuesto_Subordinado;
    }


    /**
     * Gets the idFuncion_Subordinado value for this Subordinado.
     * 
     * @return idFuncion_Subordinado
     */
    public int getIdFuncion_Subordinado() {
        return idFuncion_Subordinado;
    }


    /**
     * Sets the idFuncion_Subordinado value for this Subordinado.
     * 
     * @param idFuncion_Subordinado
     */
    public void setIdFuncion_Subordinado(int idFuncion_Subordinado) {
        this.idFuncion_Subordinado = idFuncion_Subordinado;
    }


    /**
     * Gets the desFuncion_Subordinado value for this Subordinado.
     * 
     * @return desFuncion_Subordinado
     */
    public java.lang.String getDesFuncion_Subordinado() {
        return desFuncion_Subordinado;
    }


    /**
     * Sets the desFuncion_Subordinado value for this Subordinado.
     * 
     * @param desFuncion_Subordinado
     */
    public void setDesFuncion_Subordinado(java.lang.String desFuncion_Subordinado) {
        this.desFuncion_Subordinado = desFuncion_Subordinado;
    }


    /**
     * Gets the idCentroCostos_Subordinado value for this Subordinado.
     * 
     * @return idCentroCostos_Subordinado
     */
    public int getIdCentroCostos_Subordinado() {
        return idCentroCostos_Subordinado;
    }


    /**
     * Sets the idCentroCostos_Subordinado value for this Subordinado.
     * 
     * @param idCentroCostos_Subordinado
     */
    public void setIdCentroCostos_Subordinado(int idCentroCostos_Subordinado) {
        this.idCentroCostos_Subordinado = idCentroCostos_Subordinado;
    }


    /**
     * Gets the desCentroCostos_Subordinado value for this Subordinado.
     * 
     * @return desCentroCostos_Subordinado
     */
    public java.lang.String getDesCentroCostos_Subordinado() {
        return desCentroCostos_Subordinado;
    }


    /**
     * Sets the desCentroCostos_Subordinado value for this Subordinado.
     * 
     * @param desCentroCostos_Subordinado
     */
    public void setDesCentroCostos_Subordinado(java.lang.String desCentroCostos_Subordinado) {
        this.desCentroCostos_Subordinado = desCentroCostos_Subordinado;
    }


    /**
     * Gets the idCompa�ia_Subordinado value for this Subordinado.
     * 
     * @return idCompa�ia_Subordinado
     */
    public java.lang.String getIdCompa�ia_Subordinado() {
        return idCompa�ia_Subordinado;
    }


    /**
     * Sets the idCompa�ia_Subordinado value for this Subordinado.
     * 
     * @param idCompa�ia_Subordinado
     */
    public void setIdCompa�ia_Subordinado(java.lang.String idCompa�ia_Subordinado) {
        this.idCompa�ia_Subordinado = idCompa�ia_Subordinado;
    }


    /**
     * Gets the desCompa�ia_Subordinado value for this Subordinado.
     * 
     * @return desCompa�ia_Subordinado
     */
    public java.lang.String getDesCompa�ia_Subordinado() {
        return desCompa�ia_Subordinado;
    }


    /**
     * Sets the desCompa�ia_Subordinado value for this Subordinado.
     * 
     * @param desCompa�ia_Subordinado
     */
    public void setDesCompa�ia_Subordinado(java.lang.String desCompa�ia_Subordinado) {
        this.desCompa�ia_Subordinado = desCompa�ia_Subordinado;
    }


    /**
     * Gets the numeroEmpleadoSuperior_Subordinado value for this Subordinado.
     * 
     * @return numeroEmpleadoSuperior_Subordinado
     */
    public int getNumeroEmpleadoSuperior_Subordinado() {
        return numeroEmpleadoSuperior_Subordinado;
    }


    /**
     * Sets the numeroEmpleadoSuperior_Subordinado value for this Subordinado.
     * 
     * @param numeroEmpleadoSuperior_Subordinado
     */
    public void setNumeroEmpleadoSuperior_Subordinado(int numeroEmpleadoSuperior_Subordinado) {
        this.numeroEmpleadoSuperior_Subordinado = numeroEmpleadoSuperior_Subordinado;
    }


    /**
     * Gets the nombreEmpleadoSuperior_Subordinado value for this Subordinado.
     * 
     * @return nombreEmpleadoSuperior_Subordinado
     */
    public java.lang.String getNombreEmpleadoSuperior_Subordinado() {
        return nombreEmpleadoSuperior_Subordinado;
    }


    /**
     * Sets the nombreEmpleadoSuperior_Subordinado value for this Subordinado.
     * 
     * @param nombreEmpleadoSuperior_Subordinado
     */
    public void setNombreEmpleadoSuperior_Subordinado(java.lang.String nombreEmpleadoSuperior_Subordinado) {
        this.nombreEmpleadoSuperior_Subordinado = nombreEmpleadoSuperior_Subordinado;
    }


    /**
     * Gets the idPuestoSuperior_Subordinado value for this Subordinado.
     * 
     * @return idPuestoSuperior_Subordinado
     */
    public int getIdPuestoSuperior_Subordinado() {
        return idPuestoSuperior_Subordinado;
    }


    /**
     * Sets the idPuestoSuperior_Subordinado value for this Subordinado.
     * 
     * @param idPuestoSuperior_Subordinado
     */
    public void setIdPuestoSuperior_Subordinado(int idPuestoSuperior_Subordinado) {
        this.idPuestoSuperior_Subordinado = idPuestoSuperior_Subordinado;
    }


    /**
     * Gets the genero_Subordinado value for this Subordinado.
     * 
     * @return genero_Subordinado
     */
    public java.lang.String getGenero_Subordinado() {
        return genero_Subordinado;
    }


    /**
     * Sets the genero_Subordinado value for this Subordinado.
     * 
     * @param genero_Subordinado
     */
    public void setGenero_Subordinado(java.lang.String genero_Subordinado) {
        this.genero_Subordinado = genero_Subordinado;
    }


    /**
     * Gets the estadoCivil_Subordinado value for this Subordinado.
     * 
     * @return estadoCivil_Subordinado
     */
    public java.lang.String getEstadoCivil_Subordinado() {
        return estadoCivil_Subordinado;
    }


    /**
     * Sets the estadoCivil_Subordinado value for this Subordinado.
     * 
     * @param estadoCivil_Subordinado
     */
    public void setEstadoCivil_Subordinado(java.lang.String estadoCivil_Subordinado) {
        this.estadoCivil_Subordinado = estadoCivil_Subordinado;
    }


    /**
     * Gets the activo_Subordinado value for this Subordinado.
     * 
     * @return activo_Subordinado
     */
    public boolean isActivo_Subordinado() {
        return activo_Subordinado;
    }


    /**
     * Sets the activo_Subordinado value for this Subordinado.
     * 
     * @param activo_Subordinado
     */
    public void setActivo_Subordinado(boolean activo_Subordinado) {
        this.activo_Subordinado = activo_Subordinado;
    }


    /**
     * Gets the idHorario_Subordinado value for this Subordinado.
     * 
     * @return idHorario_Subordinado
     */
    public java.lang.String getIdHorario_Subordinado() {
        return idHorario_Subordinado;
    }


    /**
     * Sets the idHorario_Subordinado value for this Subordinado.
     * 
     * @param idHorario_Subordinado
     */
    public void setIdHorario_Subordinado(java.lang.String idHorario_Subordinado) {
        this.idHorario_Subordinado = idHorario_Subordinado;
    }


    /**
     * Gets the desHorario_Subordinado value for this Subordinado.
     * 
     * @return desHorario_Subordinado
     */
    public java.lang.String getDesHorario_Subordinado() {
        return desHorario_Subordinado;
    }


    /**
     * Sets the desHorario_Subordinado value for this Subordinado.
     * 
     * @param desHorario_Subordinado
     */
    public void setDesHorario_Subordinado(java.lang.String desHorario_Subordinado) {
        this.desHorario_Subordinado = desHorario_Subordinado;
    }


    /**
     * Gets the periodoPago_Subordinado value for this Subordinado.
     * 
     * @return periodoPago_Subordinado
     */
    public java.lang.String getPeriodoPago_Subordinado() {
        return periodoPago_Subordinado;
    }


    /**
     * Sets the periodoPago_Subordinado value for this Subordinado.
     * 
     * @param periodoPago_Subordinado
     */
    public void setPeriodoPago_Subordinado(java.lang.String periodoPago_Subordinado) {
        this.periodoPago_Subordinado = periodoPago_Subordinado;
    }


    /**
     * Gets the idPais_Subordinado value for this Subordinado.
     * 
     * @return idPais_Subordinado
     */
    public java.lang.String getIdPais_Subordinado() {
        return idPais_Subordinado;
    }


    /**
     * Sets the idPais_Subordinado value for this Subordinado.
     * 
     * @param idPais_Subordinado
     */
    public void setIdPais_Subordinado(java.lang.String idPais_Subordinado) {
        this.idPais_Subordinado = idPais_Subordinado;
    }


    /**
     * Gets the datosNomina_Subordinado value for this Subordinado.
     * 
     * @return datosNomina_Subordinado
     */
    public Nomina getDatosNomina_Subordinado() {
        return datosNomina_Subordinado;
    }


    /**
     * Sets the datosNomina_Subordinado value for this Subordinado.
     * 
     * @param datosNomina_Subordinado
     */
    public void setDatosNomina_Subordinado(Nomina datosNomina_Subordinado) {
        this.datosNomina_Subordinado = datosNomina_Subordinado;
    }


    /**
     * Gets the fechasEmpleado_Subordinado value for this Subordinado.
     * 
     * @return fechasEmpleado_Subordinado
     */
    public Fecha getFechasEmpleado_Subordinado() {
        return fechasEmpleado_Subordinado;
    }


    /**
     * Sets the fechasEmpleado_Subordinado value for this Subordinado.
     * 
     * @param fechasEmpleado_Subordinado
     */
    public void setFechasEmpleado_Subordinado(Fecha fechasEmpleado_Subordinado) {
        this.fechasEmpleado_Subordinado = fechasEmpleado_Subordinado;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Subordinado)) return false;
        Subordinado other = (Subordinado) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this.numeroEmpleado_Subordinado == other.getNumeroEmpleado_Subordinado() &&
            ((this.nombreInicial_Subordinado==null && other.getNombreInicial_Subordinado()==null) || 
             (this.nombreInicial_Subordinado!=null &&
              this.nombreInicial_Subordinado.equals(other.getNombreInicial_Subordinado()))) &&
            ((this.apellidoPaterno_Subordinado==null && other.getApellidoPaterno_Subordinado()==null) || 
             (this.apellidoPaterno_Subordinado!=null &&
              this.apellidoPaterno_Subordinado.equals(other.getApellidoPaterno_Subordinado()))) &&
            ((this.apellidoMaterno_Subordinado==null && other.getApellidoMaterno_Subordinado()==null) || 
             (this.apellidoMaterno_Subordinado!=null &&
              this.apellidoMaterno_Subordinado.equals(other.getApellidoMaterno_Subordinado()))) &&
            this.idPuesto_Subordinado == other.getIdPuesto_Subordinado() &&
            ((this.desPuesto_Subordinado==null && other.getDesPuesto_Subordinado()==null) || 
             (this.desPuesto_Subordinado!=null &&
              this.desPuesto_Subordinado.equals(other.getDesPuesto_Subordinado()))) &&
            this.idFuncion_Subordinado == other.getIdFuncion_Subordinado() &&
            ((this.desFuncion_Subordinado==null && other.getDesFuncion_Subordinado()==null) || 
             (this.desFuncion_Subordinado!=null &&
              this.desFuncion_Subordinado.equals(other.getDesFuncion_Subordinado()))) &&
            this.idCentroCostos_Subordinado == other.getIdCentroCostos_Subordinado() &&
            ((this.desCentroCostos_Subordinado==null && other.getDesCentroCostos_Subordinado()==null) || 
             (this.desCentroCostos_Subordinado!=null &&
              this.desCentroCostos_Subordinado.equals(other.getDesCentroCostos_Subordinado()))) &&
            ((this.idCompa�ia_Subordinado==null && other.getIdCompa�ia_Subordinado()==null) || 
             (this.idCompa�ia_Subordinado!=null &&
              this.idCompa�ia_Subordinado.equals(other.getIdCompa�ia_Subordinado()))) &&
            ((this.desCompa�ia_Subordinado==null && other.getDesCompa�ia_Subordinado()==null) || 
             (this.desCompa�ia_Subordinado!=null &&
              this.desCompa�ia_Subordinado.equals(other.getDesCompa�ia_Subordinado()))) &&
            this.numeroEmpleadoSuperior_Subordinado == other.getNumeroEmpleadoSuperior_Subordinado() &&
            ((this.nombreEmpleadoSuperior_Subordinado==null && other.getNombreEmpleadoSuperior_Subordinado()==null) || 
             (this.nombreEmpleadoSuperior_Subordinado!=null &&
              this.nombreEmpleadoSuperior_Subordinado.equals(other.getNombreEmpleadoSuperior_Subordinado()))) &&
            this.idPuestoSuperior_Subordinado == other.getIdPuestoSuperior_Subordinado() &&
            ((this.genero_Subordinado==null && other.getGenero_Subordinado()==null) || 
             (this.genero_Subordinado!=null &&
              this.genero_Subordinado.equals(other.getGenero_Subordinado()))) &&
            ((this.estadoCivil_Subordinado==null && other.getEstadoCivil_Subordinado()==null) || 
             (this.estadoCivil_Subordinado!=null &&
              this.estadoCivil_Subordinado.equals(other.getEstadoCivil_Subordinado()))) &&
            this.activo_Subordinado == other.isActivo_Subordinado() &&
            ((this.idHorario_Subordinado==null && other.getIdHorario_Subordinado()==null) || 
             (this.idHorario_Subordinado!=null &&
              this.idHorario_Subordinado.equals(other.getIdHorario_Subordinado()))) &&
            ((this.desHorario_Subordinado==null && other.getDesHorario_Subordinado()==null) || 
             (this.desHorario_Subordinado!=null &&
              this.desHorario_Subordinado.equals(other.getDesHorario_Subordinado()))) &&
            ((this.periodoPago_Subordinado==null && other.getPeriodoPago_Subordinado()==null) || 
             (this.periodoPago_Subordinado!=null &&
              this.periodoPago_Subordinado.equals(other.getPeriodoPago_Subordinado()))) &&
            ((this.idPais_Subordinado==null && other.getIdPais_Subordinado()==null) || 
             (this.idPais_Subordinado!=null &&
              this.idPais_Subordinado.equals(other.getIdPais_Subordinado()))) &&
            ((this.datosNomina_Subordinado==null && other.getDatosNomina_Subordinado()==null) || 
             (this.datosNomina_Subordinado!=null &&
              this.datosNomina_Subordinado.equals(other.getDatosNomina_Subordinado()))) &&
            ((this.fechasEmpleado_Subordinado==null && other.getFechasEmpleado_Subordinado()==null) || 
             (this.fechasEmpleado_Subordinado!=null &&
              this.fechasEmpleado_Subordinado.equals(other.getFechasEmpleado_Subordinado())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += getNumeroEmpleado_Subordinado();
        if (getNombreInicial_Subordinado() != null) {
            _hashCode += getNombreInicial_Subordinado().hashCode();
        }
        if (getApellidoPaterno_Subordinado() != null) {
            _hashCode += getApellidoPaterno_Subordinado().hashCode();
        }
        if (getApellidoMaterno_Subordinado() != null) {
            _hashCode += getApellidoMaterno_Subordinado().hashCode();
        }
        _hashCode += getIdPuesto_Subordinado();
        if (getDesPuesto_Subordinado() != null) {
            _hashCode += getDesPuesto_Subordinado().hashCode();
        }
        _hashCode += getIdFuncion_Subordinado();
        if (getDesFuncion_Subordinado() != null) {
            _hashCode += getDesFuncion_Subordinado().hashCode();
        }
        _hashCode += getIdCentroCostos_Subordinado();
        if (getDesCentroCostos_Subordinado() != null) {
            _hashCode += getDesCentroCostos_Subordinado().hashCode();
        }
        if (getIdCompa�ia_Subordinado() != null) {
            _hashCode += getIdCompa�ia_Subordinado().hashCode();
        }
        if (getDesCompa�ia_Subordinado() != null) {
            _hashCode += getDesCompa�ia_Subordinado().hashCode();
        }
        _hashCode += getNumeroEmpleadoSuperior_Subordinado();
        if (getNombreEmpleadoSuperior_Subordinado() != null) {
            _hashCode += getNombreEmpleadoSuperior_Subordinado().hashCode();
        }
        _hashCode += getIdPuestoSuperior_Subordinado();
        if (getGenero_Subordinado() != null) {
            _hashCode += getGenero_Subordinado().hashCode();
        }
        if (getEstadoCivil_Subordinado() != null) {
            _hashCode += getEstadoCivil_Subordinado().hashCode();
        }
        _hashCode += (isActivo_Subordinado() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        if (getIdHorario_Subordinado() != null) {
            _hashCode += getIdHorario_Subordinado().hashCode();
        }
        if (getDesHorario_Subordinado() != null) {
            _hashCode += getDesHorario_Subordinado().hashCode();
        }
        if (getPeriodoPago_Subordinado() != null) {
            _hashCode += getPeriodoPago_Subordinado().hashCode();
        }
        if (getIdPais_Subordinado() != null) {
            _hashCode += getIdPais_Subordinado().hashCode();
        }
        if (getDatosNomina_Subordinado() != null) {
            _hashCode += getDatosNomina_Subordinado().hashCode();
        }
        if (getFechasEmpleado_Subordinado() != null) {
            _hashCode += getFechasEmpleado_Subordinado().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Subordinado.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Subordinado"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroEmpleado_Subordinado");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "NumeroEmpleado_Subordinado"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nombreInicial_Subordinado");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "NombreInicial_Subordinado"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("apellidoPaterno_Subordinado");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ApellidoPaterno_Subordinado"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("apellidoMaterno_Subordinado");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ApellidoMaterno_Subordinado"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("idPuesto_Subordinado");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "idPuesto_Subordinado"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("desPuesto_Subordinado");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "DesPuesto_Subordinado"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("idFuncion_Subordinado");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "idFuncion_Subordinado"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("desFuncion_Subordinado");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "DesFuncion_Subordinado"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("idCentroCostos_Subordinado");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "idCentroCostos_Subordinado"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("desCentroCostos_Subordinado");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "DesCentroCostos_Subordinado"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("idCompa�ia_Subordinado");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "idCompa�ia_Subordinado"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("desCompa�ia_Subordinado");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "DesCompa�ia_Subordinado"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroEmpleadoSuperior_Subordinado");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "NumeroEmpleadoSuperior_Subordinado"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nombreEmpleadoSuperior_Subordinado");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "NombreEmpleadoSuperior_Subordinado"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("idPuestoSuperior_Subordinado");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "idPuestoSuperior_Subordinado"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("genero_Subordinado");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Genero_Subordinado"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("estadoCivil_Subordinado");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "EstadoCivil_Subordinado"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("activo_Subordinado");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Activo_Subordinado"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("idHorario_Subordinado");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "idHorario_Subordinado"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("desHorario_Subordinado");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "DesHorario_Subordinado"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("periodoPago_Subordinado");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "PeriodoPago_Subordinado"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("idPais_Subordinado");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "idPais_Subordinado"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("datosNomina_Subordinado");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "DatosNomina_Subordinado"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Nomina"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("fechasEmpleado_Subordinado");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "FechasEmpleado_Subordinado"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Fecha"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
