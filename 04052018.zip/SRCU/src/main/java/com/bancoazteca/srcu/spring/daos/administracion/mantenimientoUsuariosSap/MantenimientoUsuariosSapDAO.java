package com.bancoazteca.srcu.spring.daos.administracion.mantenimientoUsuariosSap;

import java.util.List;

import com.bancoazteca.srcu.spring.beans.administracion.mantenimientoTelefonos.DatosEmpleadoBean;
import com.bancoazteca.srcu.spring.beans.administracion.mantenimientoUsuariosSap.DepartamentosBean;
import com.bancoazteca.srcu.spring.beans.administracion.mantenimientoUsuariosSap.EmpleadosBean;
import com.bancoazteca.srcu.spring.beans.administracion.mantenimientoUsuariosSap.VacantesBean;
import com.bancoazteca.srcu.spring.beans.administracion.personalActivo.VacantesSrcuBean;
import com.bancoazteca.srcu.spring.beans.sistema.MensajeTransaccionBean;
import com.bancoazteca.srcu.spring.beans.utilerias.CatalogoBean;
import com.bancoazteca.srcu.spring.beans.utilerias.SimpleBean;
import com.bancoazteca.srcu.spring.ws.administracion.posicionesSap.ParametrosWSBean;

public interface MantenimientoUsuariosSapDAO {
	public	SimpleBean consultaCeco(int depto);
	public	List<VacantesSrcuBean> consultaVacantesSrcu(int deptoId, int tipoConsulta);
	public	List<CatalogoBean> consultaPuestosAdministrativos();
	public	List<CatalogoBean> consultaPuestosGeografia(int puestoOperador);
	public	List<DepartamentosBean> consultaDepartamentos(int puestoMovimiento, int pais, int puestoDelegado, String empleadoDelegado);
	public	DatosEmpleadoBean consultaDatosEmpleado(String numeroEmpleado);
	public	List<EmpleadosBean> consultaEmpleados(int gerenciaId, int puestoId);
	public	SimpleBean validaCreacionxClientes(int gerenciaId, int segmento);
	public	SimpleBean validaCreacionxEliminacion(int gerenciaId, int segmento, String empleadoOpera);
	public	ParametrosWSBean consultaParametrosWS(int ceco, int funcionSAP);
	public	VacantesBean consultaVirtualDisponible(int gerenciaId, int puestoAlta);
	public	SimpleBean	registraMovimientoVacantes(String numeroPosicion, String empleadoVirtual, int estatus, String numeroEmpleado, String respuestaWS, String descripcionWS, String empleadoOpera, int tipoOperacion);
	public	MensajeTransaccionBean	altaEmpleado(String numeroEmpleado, int departamentoId, int puestoId, int plazaId, String nombreEmpleado, String empleadoOpera, int segmentoId);
}
