/**
 * ZRH_REG_CRED.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.bancoazteca.srcu.spring.ws.administracion.posicionesSap.axis.altaBajaPosicionesSap;

public class ZRH_REG_CRED  extends SAPStructure  implements java.io.Serializable {

	private static final long serialVersionUID = -586974224216663063L;

	private java.lang.String PERNR;

    private java.lang.String INFTY;

    private java.lang.String SUBTY;

    private java.lang.String OBJPS;

    private java.lang.String SPRPS;

    private java.lang.String ENDDA;

    private java.lang.String BEGDA;

    private java.lang.String SEQNR;

    private java.lang.String AEDTM;

    private java.lang.String UNAME;

    private java.lang.String HISTO;

    private java.lang.String ITXEX;

    private java.lang.String REFEX;

    private java.lang.String ORDEX;

    private java.lang.String ITBLD;

    private java.lang.String PREAS;

    private java.lang.String FLAG1;

    private java.lang.String FLAG2;

    private java.lang.String FLAG3;

    private java.lang.String FLAG4;

    private java.lang.String RESE1;

    private java.lang.String RESE2;

    private java.lang.String GRPVL;

    private java.lang.String BUKRS;

    private java.lang.String WERKS;

    private java.lang.String PERSG;

    private java.lang.String PERSK;

    private java.lang.String VDSK1;

    private java.lang.String GSBER;

    private java.lang.String BTRTL;

    private java.lang.String JUPER;

    private java.lang.String ABKRS;

    private java.lang.String ANSVH;

    private java.lang.String KOSTL;

    private java.lang.String ORGEH;

    private java.lang.String PLANS;

    private java.lang.String STELL;

    private java.lang.String MSTBR;

    private java.lang.String SACHA;

    private java.lang.String SACHP;

    private java.lang.String SACHZ;

    private java.lang.String SNAME;

    private java.lang.String ENAME;

    private java.lang.String OTYPE;

    private java.lang.String SBMOD;

    private java.lang.String KOKRS;

    private java.lang.String FISTL;

    private java.lang.String GEBER;

    private java.lang.String FKBER;

    private java.lang.String GRANT_NBR;

    private java.lang.String SGMNT;

    private java.lang.String BUDGET_PD;

    private java.lang.String ZZSOCSC;

    private java.lang.String ZZTEXTO;

    private java.math.BigDecimal SABR;

    private java.math.BigDecimal SCBR;

    private java.math.BigDecimal SCNE;

    private java.lang.String POSINF;

    private java.lang.String BUILD;

    private java.math.BigDecimal SABR_EMP;

    private java.math.BigDecimal SCNETO_EMP;

    private java.math.BigDecimal SABR_POS;

    private java.math.BigDecimal SCNETO_POS;

    public ZRH_REG_CRED() {
    }

    public ZRH_REG_CRED(
           java.lang.String PERNR,
           java.lang.String INFTY,
           java.lang.String SUBTY,
           java.lang.String OBJPS,
           java.lang.String SPRPS,
           java.lang.String ENDDA,
           java.lang.String BEGDA,
           java.lang.String SEQNR,
           java.lang.String AEDTM,
           java.lang.String UNAME,
           java.lang.String HISTO,
           java.lang.String ITXEX,
           java.lang.String REFEX,
           java.lang.String ORDEX,
           java.lang.String ITBLD,
           java.lang.String PREAS,
           java.lang.String FLAG1,
           java.lang.String FLAG2,
           java.lang.String FLAG3,
           java.lang.String FLAG4,
           java.lang.String RESE1,
           java.lang.String RESE2,
           java.lang.String GRPVL,
           java.lang.String BUKRS,
           java.lang.String WERKS,
           java.lang.String PERSG,
           java.lang.String PERSK,
           java.lang.String VDSK1,
           java.lang.String GSBER,
           java.lang.String BTRTL,
           java.lang.String JUPER,
           java.lang.String ABKRS,
           java.lang.String ANSVH,
           java.lang.String KOSTL,
           java.lang.String ORGEH,
           java.lang.String PLANS,
           java.lang.String STELL,
           java.lang.String MSTBR,
           java.lang.String SACHA,
           java.lang.String SACHP,
           java.lang.String SACHZ,
           java.lang.String SNAME,
           java.lang.String ENAME,
           java.lang.String OTYPE,
           java.lang.String SBMOD,
           java.lang.String KOKRS,
           java.lang.String FISTL,
           java.lang.String GEBER,
           java.lang.String FKBER,
           java.lang.String GRANT_NBR,
           java.lang.String SGMNT,
           java.lang.String BUDGET_PD,
           java.lang.String ZZSOCSC,
           java.lang.String ZZTEXTO,
           java.math.BigDecimal SABR,
           java.math.BigDecimal SCBR,
           java.math.BigDecimal SCNE,
           java.lang.String POSINF,
           java.lang.String BUILD,
           java.math.BigDecimal SABR_EMP,
           java.math.BigDecimal SCNETO_EMP,
           java.math.BigDecimal SABR_POS,
           java.math.BigDecimal SCNETO_POS) {
        this.PERNR = PERNR;
        this.INFTY = INFTY;
        this.SUBTY = SUBTY;
        this.OBJPS = OBJPS;
        this.SPRPS = SPRPS;
        this.ENDDA = ENDDA;
        this.BEGDA = BEGDA;
        this.SEQNR = SEQNR;
        this.AEDTM = AEDTM;
        this.UNAME = UNAME;
        this.HISTO = HISTO;
        this.ITXEX = ITXEX;
        this.REFEX = REFEX;
        this.ORDEX = ORDEX;
        this.ITBLD = ITBLD;
        this.PREAS = PREAS;
        this.FLAG1 = FLAG1;
        this.FLAG2 = FLAG2;
        this.FLAG3 = FLAG3;
        this.FLAG4 = FLAG4;
        this.RESE1 = RESE1;
        this.RESE2 = RESE2;
        this.GRPVL = GRPVL;
        this.BUKRS = BUKRS;
        this.WERKS = WERKS;
        this.PERSG = PERSG;
        this.PERSK = PERSK;
        this.VDSK1 = VDSK1;
        this.GSBER = GSBER;
        this.BTRTL = BTRTL;
        this.JUPER = JUPER;
        this.ABKRS = ABKRS;
        this.ANSVH = ANSVH;
        this.KOSTL = KOSTL;
        this.ORGEH = ORGEH;
        this.PLANS = PLANS;
        this.STELL = STELL;
        this.MSTBR = MSTBR;
        this.SACHA = SACHA;
        this.SACHP = SACHP;
        this.SACHZ = SACHZ;
        this.SNAME = SNAME;
        this.ENAME = ENAME;
        this.OTYPE = OTYPE;
        this.SBMOD = SBMOD;
        this.KOKRS = KOKRS;
        this.FISTL = FISTL;
        this.GEBER = GEBER;
        this.FKBER = FKBER;
        this.GRANT_NBR = GRANT_NBR;
        this.SGMNT = SGMNT;
        this.BUDGET_PD = BUDGET_PD;
        this.ZZSOCSC = ZZSOCSC;
        this.ZZTEXTO = ZZTEXTO;
        this.SABR = SABR;
        this.SCBR = SCBR;
        this.SCNE = SCNE;
        this.POSINF = POSINF;
        this.BUILD = BUILD;
        this.SABR_EMP = SABR_EMP;
        this.SCNETO_EMP = SCNETO_EMP;
        this.SABR_POS = SABR_POS;
        this.SCNETO_POS = SCNETO_POS;
    }


    /**
     * Gets the PERNR value for this ZRH_REG_CRED.
     * 
     * @return PERNR
     */
    public java.lang.String getPERNR() {
        return PERNR;
    }


    /**
     * Sets the PERNR value for this ZRH_REG_CRED.
     * 
     * @param PERNR
     */
    public void setPERNR(java.lang.String PERNR) {
        this.PERNR = PERNR;
    }


    /**
     * Gets the INFTY value for this ZRH_REG_CRED.
     * 
     * @return INFTY
     */
    public java.lang.String getINFTY() {
        return INFTY;
    }


    /**
     * Sets the INFTY value for this ZRH_REG_CRED.
     * 
     * @param INFTY
     */
    public void setINFTY(java.lang.String INFTY) {
        this.INFTY = INFTY;
    }


    /**
     * Gets the SUBTY value for this ZRH_REG_CRED.
     * 
     * @return SUBTY
     */
    public java.lang.String getSUBTY() {
        return SUBTY;
    }


    /**
     * Sets the SUBTY value for this ZRH_REG_CRED.
     * 
     * @param SUBTY
     */
    public void setSUBTY(java.lang.String SUBTY) {
        this.SUBTY = SUBTY;
    }


    /**
     * Gets the OBJPS value for this ZRH_REG_CRED.
     * 
     * @return OBJPS
     */
    public java.lang.String getOBJPS() {
        return OBJPS;
    }


    /**
     * Sets the OBJPS value for this ZRH_REG_CRED.
     * 
     * @param OBJPS
     */
    public void setOBJPS(java.lang.String OBJPS) {
        this.OBJPS = OBJPS;
    }


    /**
     * Gets the SPRPS value for this ZRH_REG_CRED.
     * 
     * @return SPRPS
     */
    public java.lang.String getSPRPS() {
        return SPRPS;
    }


    /**
     * Sets the SPRPS value for this ZRH_REG_CRED.
     * 
     * @param SPRPS
     */
    public void setSPRPS(java.lang.String SPRPS) {
        this.SPRPS = SPRPS;
    }


    /**
     * Gets the ENDDA value for this ZRH_REG_CRED.
     * 
     * @return ENDDA
     */
    public java.lang.String getENDDA() {
        return ENDDA;
    }


    /**
     * Sets the ENDDA value for this ZRH_REG_CRED.
     * 
     * @param ENDDA
     */
    public void setENDDA(java.lang.String ENDDA) {
        this.ENDDA = ENDDA;
    }


    /**
     * Gets the BEGDA value for this ZRH_REG_CRED.
     * 
     * @return BEGDA
     */
    public java.lang.String getBEGDA() {
        return BEGDA;
    }


    /**
     * Sets the BEGDA value for this ZRH_REG_CRED.
     * 
     * @param BEGDA
     */
    public void setBEGDA(java.lang.String BEGDA) {
        this.BEGDA = BEGDA;
    }


    /**
     * Gets the SEQNR value for this ZRH_REG_CRED.
     * 
     * @return SEQNR
     */
    public java.lang.String getSEQNR() {
        return SEQNR;
    }


    /**
     * Sets the SEQNR value for this ZRH_REG_CRED.
     * 
     * @param SEQNR
     */
    public void setSEQNR(java.lang.String SEQNR) {
        this.SEQNR = SEQNR;
    }


    /**
     * Gets the AEDTM value for this ZRH_REG_CRED.
     * 
     * @return AEDTM
     */
    public java.lang.String getAEDTM() {
        return AEDTM;
    }


    /**
     * Sets the AEDTM value for this ZRH_REG_CRED.
     * 
     * @param AEDTM
     */
    public void setAEDTM(java.lang.String AEDTM) {
        this.AEDTM = AEDTM;
    }


    /**
     * Gets the UNAME value for this ZRH_REG_CRED.
     * 
     * @return UNAME
     */
    public java.lang.String getUNAME() {
        return UNAME;
    }


    /**
     * Sets the UNAME value for this ZRH_REG_CRED.
     * 
     * @param UNAME
     */
    public void setUNAME(java.lang.String UNAME) {
        this.UNAME = UNAME;
    }


    /**
     * Gets the HISTO value for this ZRH_REG_CRED.
     * 
     * @return HISTO
     */
    public java.lang.String getHISTO() {
        return HISTO;
    }


    /**
     * Sets the HISTO value for this ZRH_REG_CRED.
     * 
     * @param HISTO
     */
    public void setHISTO(java.lang.String HISTO) {
        this.HISTO = HISTO;
    }


    /**
     * Gets the ITXEX value for this ZRH_REG_CRED.
     * 
     * @return ITXEX
     */
    public java.lang.String getITXEX() {
        return ITXEX;
    }


    /**
     * Sets the ITXEX value for this ZRH_REG_CRED.
     * 
     * @param ITXEX
     */
    public void setITXEX(java.lang.String ITXEX) {
        this.ITXEX = ITXEX;
    }


    /**
     * Gets the REFEX value for this ZRH_REG_CRED.
     * 
     * @return REFEX
     */
    public java.lang.String getREFEX() {
        return REFEX;
    }


    /**
     * Sets the REFEX value for this ZRH_REG_CRED.
     * 
     * @param REFEX
     */
    public void setREFEX(java.lang.String REFEX) {
        this.REFEX = REFEX;
    }


    /**
     * Gets the ORDEX value for this ZRH_REG_CRED.
     * 
     * @return ORDEX
     */
    public java.lang.String getORDEX() {
        return ORDEX;
    }


    /**
     * Sets the ORDEX value for this ZRH_REG_CRED.
     * 
     * @param ORDEX
     */
    public void setORDEX(java.lang.String ORDEX) {
        this.ORDEX = ORDEX;
    }


    /**
     * Gets the ITBLD value for this ZRH_REG_CRED.
     * 
     * @return ITBLD
     */
    public java.lang.String getITBLD() {
        return ITBLD;
    }


    /**
     * Sets the ITBLD value for this ZRH_REG_CRED.
     * 
     * @param ITBLD
     */
    public void setITBLD(java.lang.String ITBLD) {
        this.ITBLD = ITBLD;
    }


    /**
     * Gets the PREAS value for this ZRH_REG_CRED.
     * 
     * @return PREAS
     */
    public java.lang.String getPREAS() {
        return PREAS;
    }


    /**
     * Sets the PREAS value for this ZRH_REG_CRED.
     * 
     * @param PREAS
     */
    public void setPREAS(java.lang.String PREAS) {
        this.PREAS = PREAS;
    }


    /**
     * Gets the FLAG1 value for this ZRH_REG_CRED.
     * 
     * @return FLAG1
     */
    public java.lang.String getFLAG1() {
        return FLAG1;
    }


    /**
     * Sets the FLAG1 value for this ZRH_REG_CRED.
     * 
     * @param FLAG1
     */
    public void setFLAG1(java.lang.String FLAG1) {
        this.FLAG1 = FLAG1;
    }


    /**
     * Gets the FLAG2 value for this ZRH_REG_CRED.
     * 
     * @return FLAG2
     */
    public java.lang.String getFLAG2() {
        return FLAG2;
    }


    /**
     * Sets the FLAG2 value for this ZRH_REG_CRED.
     * 
     * @param FLAG2
     */
    public void setFLAG2(java.lang.String FLAG2) {
        this.FLAG2 = FLAG2;
    }


    /**
     * Gets the FLAG3 value for this ZRH_REG_CRED.
     * 
     * @return FLAG3
     */
    public java.lang.String getFLAG3() {
        return FLAG3;
    }


    /**
     * Sets the FLAG3 value for this ZRH_REG_CRED.
     * 
     * @param FLAG3
     */
    public void setFLAG3(java.lang.String FLAG3) {
        this.FLAG3 = FLAG3;
    }


    /**
     * Gets the FLAG4 value for this ZRH_REG_CRED.
     * 
     * @return FLAG4
     */
    public java.lang.String getFLAG4() {
        return FLAG4;
    }


    /**
     * Sets the FLAG4 value for this ZRH_REG_CRED.
     * 
     * @param FLAG4
     */
    public void setFLAG4(java.lang.String FLAG4) {
        this.FLAG4 = FLAG4;
    }


    /**
     * Gets the RESE1 value for this ZRH_REG_CRED.
     * 
     * @return RESE1
     */
    public java.lang.String getRESE1() {
        return RESE1;
    }


    /**
     * Sets the RESE1 value for this ZRH_REG_CRED.
     * 
     * @param RESE1
     */
    public void setRESE1(java.lang.String RESE1) {
        this.RESE1 = RESE1;
    }


    /**
     * Gets the RESE2 value for this ZRH_REG_CRED.
     * 
     * @return RESE2
     */
    public java.lang.String getRESE2() {
        return RESE2;
    }


    /**
     * Sets the RESE2 value for this ZRH_REG_CRED.
     * 
     * @param RESE2
     */
    public void setRESE2(java.lang.String RESE2) {
        this.RESE2 = RESE2;
    }


    /**
     * Gets the GRPVL value for this ZRH_REG_CRED.
     * 
     * @return GRPVL
     */
    public java.lang.String getGRPVL() {
        return GRPVL;
    }


    /**
     * Sets the GRPVL value for this ZRH_REG_CRED.
     * 
     * @param GRPVL
     */
    public void setGRPVL(java.lang.String GRPVL) {
        this.GRPVL = GRPVL;
    }


    /**
     * Gets the BUKRS value for this ZRH_REG_CRED.
     * 
     * @return BUKRS
     */
    public java.lang.String getBUKRS() {
        return BUKRS;
    }


    /**
     * Sets the BUKRS value for this ZRH_REG_CRED.
     * 
     * @param BUKRS
     */
    public void setBUKRS(java.lang.String BUKRS) {
        this.BUKRS = BUKRS;
    }


    /**
     * Gets the WERKS value for this ZRH_REG_CRED.
     * 
     * @return WERKS
     */
    public java.lang.String getWERKS() {
        return WERKS;
    }


    /**
     * Sets the WERKS value for this ZRH_REG_CRED.
     * 
     * @param WERKS
     */
    public void setWERKS(java.lang.String WERKS) {
        this.WERKS = WERKS;
    }


    /**
     * Gets the PERSG value for this ZRH_REG_CRED.
     * 
     * @return PERSG
     */
    public java.lang.String getPERSG() {
        return PERSG;
    }


    /**
     * Sets the PERSG value for this ZRH_REG_CRED.
     * 
     * @param PERSG
     */
    public void setPERSG(java.lang.String PERSG) {
        this.PERSG = PERSG;
    }


    /**
     * Gets the PERSK value for this ZRH_REG_CRED.
     * 
     * @return PERSK
     */
    public java.lang.String getPERSK() {
        return PERSK;
    }


    /**
     * Sets the PERSK value for this ZRH_REG_CRED.
     * 
     * @param PERSK
     */
    public void setPERSK(java.lang.String PERSK) {
        this.PERSK = PERSK;
    }


    /**
     * Gets the VDSK1 value for this ZRH_REG_CRED.
     * 
     * @return VDSK1
     */
    public java.lang.String getVDSK1() {
        return VDSK1;
    }


    /**
     * Sets the VDSK1 value for this ZRH_REG_CRED.
     * 
     * @param VDSK1
     */
    public void setVDSK1(java.lang.String VDSK1) {
        this.VDSK1 = VDSK1;
    }


    /**
     * Gets the GSBER value for this ZRH_REG_CRED.
     * 
     * @return GSBER
     */
    public java.lang.String getGSBER() {
        return GSBER;
    }


    /**
     * Sets the GSBER value for this ZRH_REG_CRED.
     * 
     * @param GSBER
     */
    public void setGSBER(java.lang.String GSBER) {
        this.GSBER = GSBER;
    }


    /**
     * Gets the BTRTL value for this ZRH_REG_CRED.
     * 
     * @return BTRTL
     */
    public java.lang.String getBTRTL() {
        return BTRTL;
    }


    /**
     * Sets the BTRTL value for this ZRH_REG_CRED.
     * 
     * @param BTRTL
     */
    public void setBTRTL(java.lang.String BTRTL) {
        this.BTRTL = BTRTL;
    }


    /**
     * Gets the JUPER value for this ZRH_REG_CRED.
     * 
     * @return JUPER
     */
    public java.lang.String getJUPER() {
        return JUPER;
    }


    /**
     * Sets the JUPER value for this ZRH_REG_CRED.
     * 
     * @param JUPER
     */
    public void setJUPER(java.lang.String JUPER) {
        this.JUPER = JUPER;
    }


    /**
     * Gets the ABKRS value for this ZRH_REG_CRED.
     * 
     * @return ABKRS
     */
    public java.lang.String getABKRS() {
        return ABKRS;
    }


    /**
     * Sets the ABKRS value for this ZRH_REG_CRED.
     * 
     * @param ABKRS
     */
    public void setABKRS(java.lang.String ABKRS) {
        this.ABKRS = ABKRS;
    }


    /**
     * Gets the ANSVH value for this ZRH_REG_CRED.
     * 
     * @return ANSVH
     */
    public java.lang.String getANSVH() {
        return ANSVH;
    }


    /**
     * Sets the ANSVH value for this ZRH_REG_CRED.
     * 
     * @param ANSVH
     */
    public void setANSVH(java.lang.String ANSVH) {
        this.ANSVH = ANSVH;
    }


    /**
     * Gets the KOSTL value for this ZRH_REG_CRED.
     * 
     * @return KOSTL
     */
    public java.lang.String getKOSTL() {
        return KOSTL;
    }


    /**
     * Sets the KOSTL value for this ZRH_REG_CRED.
     * 
     * @param KOSTL
     */
    public void setKOSTL(java.lang.String KOSTL) {
        this.KOSTL = KOSTL;
    }


    /**
     * Gets the ORGEH value for this ZRH_REG_CRED.
     * 
     * @return ORGEH
     */
    public java.lang.String getORGEH() {
        return ORGEH;
    }


    /**
     * Sets the ORGEH value for this ZRH_REG_CRED.
     * 
     * @param ORGEH
     */
    public void setORGEH(java.lang.String ORGEH) {
        this.ORGEH = ORGEH;
    }


    /**
     * Gets the PLANS value for this ZRH_REG_CRED.
     * 
     * @return PLANS
     */
    public java.lang.String getPLANS() {
        return PLANS;
    }


    /**
     * Sets the PLANS value for this ZRH_REG_CRED.
     * 
     * @param PLANS
     */
    public void setPLANS(java.lang.String PLANS) {
        this.PLANS = PLANS;
    }


    /**
     * Gets the STELL value for this ZRH_REG_CRED.
     * 
     * @return STELL
     */
    public java.lang.String getSTELL() {
        return STELL;
    }


    /**
     * Sets the STELL value for this ZRH_REG_CRED.
     * 
     * @param STELL
     */
    public void setSTELL(java.lang.String STELL) {
        this.STELL = STELL;
    }


    /**
     * Gets the MSTBR value for this ZRH_REG_CRED.
     * 
     * @return MSTBR
     */
    public java.lang.String getMSTBR() {
        return MSTBR;
    }


    /**
     * Sets the MSTBR value for this ZRH_REG_CRED.
     * 
     * @param MSTBR
     */
    public void setMSTBR(java.lang.String MSTBR) {
        this.MSTBR = MSTBR;
    }


    /**
     * Gets the SACHA value for this ZRH_REG_CRED.
     * 
     * @return SACHA
     */
    public java.lang.String getSACHA() {
        return SACHA;
    }


    /**
     * Sets the SACHA value for this ZRH_REG_CRED.
     * 
     * @param SACHA
     */
    public void setSACHA(java.lang.String SACHA) {
        this.SACHA = SACHA;
    }


    /**
     * Gets the SACHP value for this ZRH_REG_CRED.
     * 
     * @return SACHP
     */
    public java.lang.String getSACHP() {
        return SACHP;
    }


    /**
     * Sets the SACHP value for this ZRH_REG_CRED.
     * 
     * @param SACHP
     */
    public void setSACHP(java.lang.String SACHP) {
        this.SACHP = SACHP;
    }


    /**
     * Gets the SACHZ value for this ZRH_REG_CRED.
     * 
     * @return SACHZ
     */
    public java.lang.String getSACHZ() {
        return SACHZ;
    }


    /**
     * Sets the SACHZ value for this ZRH_REG_CRED.
     * 
     * @param SACHZ
     */
    public void setSACHZ(java.lang.String SACHZ) {
        this.SACHZ = SACHZ;
    }


    /**
     * Gets the SNAME value for this ZRH_REG_CRED.
     * 
     * @return SNAME
     */
    public java.lang.String getSNAME() {
        return SNAME;
    }


    /**
     * Sets the SNAME value for this ZRH_REG_CRED.
     * 
     * @param SNAME
     */
    public void setSNAME(java.lang.String SNAME) {
        this.SNAME = SNAME;
    }


    /**
     * Gets the ENAME value for this ZRH_REG_CRED.
     * 
     * @return ENAME
     */
    public java.lang.String getENAME() {
        return ENAME;
    }


    /**
     * Sets the ENAME value for this ZRH_REG_CRED.
     * 
     * @param ENAME
     */
    public void setENAME(java.lang.String ENAME) {
        this.ENAME = ENAME;
    }


    /**
     * Gets the OTYPE value for this ZRH_REG_CRED.
     * 
     * @return OTYPE
     */
    public java.lang.String getOTYPE() {
        return OTYPE;
    }


    /**
     * Sets the OTYPE value for this ZRH_REG_CRED.
     * 
     * @param OTYPE
     */
    public void setOTYPE(java.lang.String OTYPE) {
        this.OTYPE = OTYPE;
    }


    /**
     * Gets the SBMOD value for this ZRH_REG_CRED.
     * 
     * @return SBMOD
     */
    public java.lang.String getSBMOD() {
        return SBMOD;
    }


    /**
     * Sets the SBMOD value for this ZRH_REG_CRED.
     * 
     * @param SBMOD
     */
    public void setSBMOD(java.lang.String SBMOD) {
        this.SBMOD = SBMOD;
    }


    /**
     * Gets the KOKRS value for this ZRH_REG_CRED.
     * 
     * @return KOKRS
     */
    public java.lang.String getKOKRS() {
        return KOKRS;
    }


    /**
     * Sets the KOKRS value for this ZRH_REG_CRED.
     * 
     * @param KOKRS
     */
    public void setKOKRS(java.lang.String KOKRS) {
        this.KOKRS = KOKRS;
    }


    /**
     * Gets the FISTL value for this ZRH_REG_CRED.
     * 
     * @return FISTL
     */
    public java.lang.String getFISTL() {
        return FISTL;
    }


    /**
     * Sets the FISTL value for this ZRH_REG_CRED.
     * 
     * @param FISTL
     */
    public void setFISTL(java.lang.String FISTL) {
        this.FISTL = FISTL;
    }


    /**
     * Gets the GEBER value for this ZRH_REG_CRED.
     * 
     * @return GEBER
     */
    public java.lang.String getGEBER() {
        return GEBER;
    }


    /**
     * Sets the GEBER value for this ZRH_REG_CRED.
     * 
     * @param GEBER
     */
    public void setGEBER(java.lang.String GEBER) {
        this.GEBER = GEBER;
    }


    /**
     * Gets the FKBER value for this ZRH_REG_CRED.
     * 
     * @return FKBER
     */
    public java.lang.String getFKBER() {
        return FKBER;
    }


    /**
     * Sets the FKBER value for this ZRH_REG_CRED.
     * 
     * @param FKBER
     */
    public void setFKBER(java.lang.String FKBER) {
        this.FKBER = FKBER;
    }


    /**
     * Gets the GRANT_NBR value for this ZRH_REG_CRED.
     * 
     * @return GRANT_NBR
     */
    public java.lang.String getGRANT_NBR() {
        return GRANT_NBR;
    }


    /**
     * Sets the GRANT_NBR value for this ZRH_REG_CRED.
     * 
     * @param GRANT_NBR
     */
    public void setGRANT_NBR(java.lang.String GRANT_NBR) {
        this.GRANT_NBR = GRANT_NBR;
    }


    /**
     * Gets the SGMNT value for this ZRH_REG_CRED.
     * 
     * @return SGMNT
     */
    public java.lang.String getSGMNT() {
        return SGMNT;
    }


    /**
     * Sets the SGMNT value for this ZRH_REG_CRED.
     * 
     * @param SGMNT
     */
    public void setSGMNT(java.lang.String SGMNT) {
        this.SGMNT = SGMNT;
    }


    /**
     * Gets the BUDGET_PD value for this ZRH_REG_CRED.
     * 
     * @return BUDGET_PD
     */
    public java.lang.String getBUDGET_PD() {
        return BUDGET_PD;
    }


    /**
     * Sets the BUDGET_PD value for this ZRH_REG_CRED.
     * 
     * @param BUDGET_PD
     */
    public void setBUDGET_PD(java.lang.String BUDGET_PD) {
        this.BUDGET_PD = BUDGET_PD;
    }


    /**
     * Gets the ZZSOCSC value for this ZRH_REG_CRED.
     * 
     * @return ZZSOCSC
     */
    public java.lang.String getZZSOCSC() {
        return ZZSOCSC;
    }


    /**
     * Sets the ZZSOCSC value for this ZRH_REG_CRED.
     * 
     * @param ZZSOCSC
     */
    public void setZZSOCSC(java.lang.String ZZSOCSC) {
        this.ZZSOCSC = ZZSOCSC;
    }


    /**
     * Gets the ZZTEXTO value for this ZRH_REG_CRED.
     * 
     * @return ZZTEXTO
     */
    public java.lang.String getZZTEXTO() {
        return ZZTEXTO;
    }


    /**
     * Sets the ZZTEXTO value for this ZRH_REG_CRED.
     * 
     * @param ZZTEXTO
     */
    public void setZZTEXTO(java.lang.String ZZTEXTO) {
        this.ZZTEXTO = ZZTEXTO;
    }


    /**
     * Gets the SABR value for this ZRH_REG_CRED.
     * 
     * @return SABR
     */
    public java.math.BigDecimal getSABR() {
        return SABR;
    }


    /**
     * Sets the SABR value for this ZRH_REG_CRED.
     * 
     * @param SABR
     */
    public void setSABR(java.math.BigDecimal SABR) {
        this.SABR = SABR;
    }


    /**
     * Gets the SCBR value for this ZRH_REG_CRED.
     * 
     * @return SCBR
     */
    public java.math.BigDecimal getSCBR() {
        return SCBR;
    }


    /**
     * Sets the SCBR value for this ZRH_REG_CRED.
     * 
     * @param SCBR
     */
    public void setSCBR(java.math.BigDecimal SCBR) {
        this.SCBR = SCBR;
    }


    /**
     * Gets the SCNE value for this ZRH_REG_CRED.
     * 
     * @return SCNE
     */
    public java.math.BigDecimal getSCNE() {
        return SCNE;
    }


    /**
     * Sets the SCNE value for this ZRH_REG_CRED.
     * 
     * @param SCNE
     */
    public void setSCNE(java.math.BigDecimal SCNE) {
        this.SCNE = SCNE;
    }


    /**
     * Gets the POSINF value for this ZRH_REG_CRED.
     * 
     * @return POSINF
     */
    public java.lang.String getPOSINF() {
        return POSINF;
    }


    /**
     * Sets the POSINF value for this ZRH_REG_CRED.
     * 
     * @param POSINF
     */
    public void setPOSINF(java.lang.String POSINF) {
        this.POSINF = POSINF;
    }


    /**
     * Gets the BUILD value for this ZRH_REG_CRED.
     * 
     * @return BUILD
     */
    public java.lang.String getBUILD() {
        return BUILD;
    }


    /**
     * Sets the BUILD value for this ZRH_REG_CRED.
     * 
     * @param BUILD
     */
    public void setBUILD(java.lang.String BUILD) {
        this.BUILD = BUILD;
    }


    /**
     * Gets the SABR_EMP value for this ZRH_REG_CRED.
     * 
     * @return SABR_EMP
     */
    public java.math.BigDecimal getSABR_EMP() {
        return SABR_EMP;
    }


    /**
     * Sets the SABR_EMP value for this ZRH_REG_CRED.
     * 
     * @param SABR_EMP
     */
    public void setSABR_EMP(java.math.BigDecimal SABR_EMP) {
        this.SABR_EMP = SABR_EMP;
    }


    /**
     * Gets the SCNETO_EMP value for this ZRH_REG_CRED.
     * 
     * @return SCNETO_EMP
     */
    public java.math.BigDecimal getSCNETO_EMP() {
        return SCNETO_EMP;
    }


    /**
     * Sets the SCNETO_EMP value for this ZRH_REG_CRED.
     * 
     * @param SCNETO_EMP
     */
    public void setSCNETO_EMP(java.math.BigDecimal SCNETO_EMP) {
        this.SCNETO_EMP = SCNETO_EMP;
    }


    /**
     * Gets the SABR_POS value for this ZRH_REG_CRED.
     * 
     * @return SABR_POS
     */
    public java.math.BigDecimal getSABR_POS() {
        return SABR_POS;
    }


    /**
     * Sets the SABR_POS value for this ZRH_REG_CRED.
     * 
     * @param SABR_POS
     */
    public void setSABR_POS(java.math.BigDecimal SABR_POS) {
        this.SABR_POS = SABR_POS;
    }


    /**
     * Gets the SCNETO_POS value for this ZRH_REG_CRED.
     * 
     * @return SCNETO_POS
     */
    public java.math.BigDecimal getSCNETO_POS() {
        return SCNETO_POS;
    }


    /**
     * Sets the SCNETO_POS value for this ZRH_REG_CRED.
     * 
     * @param SCNETO_POS
     */
    public void setSCNETO_POS(java.math.BigDecimal SCNETO_POS) {
        this.SCNETO_POS = SCNETO_POS;
    }

    private java.lang.Object __equalsCalc = null;
    @SuppressWarnings("unused")
	public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ZRH_REG_CRED)) return false;
        ZRH_REG_CRED other = (ZRH_REG_CRED) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.PERNR==null && other.getPERNR()==null) || 
             (this.PERNR!=null &&
              this.PERNR.equals(other.getPERNR()))) &&
            ((this.INFTY==null && other.getINFTY()==null) || 
             (this.INFTY!=null &&
              this.INFTY.equals(other.getINFTY()))) &&
            ((this.SUBTY==null && other.getSUBTY()==null) || 
             (this.SUBTY!=null &&
              this.SUBTY.equals(other.getSUBTY()))) &&
            ((this.OBJPS==null && other.getOBJPS()==null) || 
             (this.OBJPS!=null &&
              this.OBJPS.equals(other.getOBJPS()))) &&
            ((this.SPRPS==null && other.getSPRPS()==null) || 
             (this.SPRPS!=null &&
              this.SPRPS.equals(other.getSPRPS()))) &&
            ((this.ENDDA==null && other.getENDDA()==null) || 
             (this.ENDDA!=null &&
              this.ENDDA.equals(other.getENDDA()))) &&
            ((this.BEGDA==null && other.getBEGDA()==null) || 
             (this.BEGDA!=null &&
              this.BEGDA.equals(other.getBEGDA()))) &&
            ((this.SEQNR==null && other.getSEQNR()==null) || 
             (this.SEQNR!=null &&
              this.SEQNR.equals(other.getSEQNR()))) &&
            ((this.AEDTM==null && other.getAEDTM()==null) || 
             (this.AEDTM!=null &&
              this.AEDTM.equals(other.getAEDTM()))) &&
            ((this.UNAME==null && other.getUNAME()==null) || 
             (this.UNAME!=null &&
              this.UNAME.equals(other.getUNAME()))) &&
            ((this.HISTO==null && other.getHISTO()==null) || 
             (this.HISTO!=null &&
              this.HISTO.equals(other.getHISTO()))) &&
            ((this.ITXEX==null && other.getITXEX()==null) || 
             (this.ITXEX!=null &&
              this.ITXEX.equals(other.getITXEX()))) &&
            ((this.REFEX==null && other.getREFEX()==null) || 
             (this.REFEX!=null &&
              this.REFEX.equals(other.getREFEX()))) &&
            ((this.ORDEX==null && other.getORDEX()==null) || 
             (this.ORDEX!=null &&
              this.ORDEX.equals(other.getORDEX()))) &&
            ((this.ITBLD==null && other.getITBLD()==null) || 
             (this.ITBLD!=null &&
              this.ITBLD.equals(other.getITBLD()))) &&
            ((this.PREAS==null && other.getPREAS()==null) || 
             (this.PREAS!=null &&
              this.PREAS.equals(other.getPREAS()))) &&
            ((this.FLAG1==null && other.getFLAG1()==null) || 
             (this.FLAG1!=null &&
              this.FLAG1.equals(other.getFLAG1()))) &&
            ((this.FLAG2==null && other.getFLAG2()==null) || 
             (this.FLAG2!=null &&
              this.FLAG2.equals(other.getFLAG2()))) &&
            ((this.FLAG3==null && other.getFLAG3()==null) || 
             (this.FLAG3!=null &&
              this.FLAG3.equals(other.getFLAG3()))) &&
            ((this.FLAG4==null && other.getFLAG4()==null) || 
             (this.FLAG4!=null &&
              this.FLAG4.equals(other.getFLAG4()))) &&
            ((this.RESE1==null && other.getRESE1()==null) || 
             (this.RESE1!=null &&
              this.RESE1.equals(other.getRESE1()))) &&
            ((this.RESE2==null && other.getRESE2()==null) || 
             (this.RESE2!=null &&
              this.RESE2.equals(other.getRESE2()))) &&
            ((this.GRPVL==null && other.getGRPVL()==null) || 
             (this.GRPVL!=null &&
              this.GRPVL.equals(other.getGRPVL()))) &&
            ((this.BUKRS==null && other.getBUKRS()==null) || 
             (this.BUKRS!=null &&
              this.BUKRS.equals(other.getBUKRS()))) &&
            ((this.WERKS==null && other.getWERKS()==null) || 
             (this.WERKS!=null &&
              this.WERKS.equals(other.getWERKS()))) &&
            ((this.PERSG==null && other.getPERSG()==null) || 
             (this.PERSG!=null &&
              this.PERSG.equals(other.getPERSG()))) &&
            ((this.PERSK==null && other.getPERSK()==null) || 
             (this.PERSK!=null &&
              this.PERSK.equals(other.getPERSK()))) &&
            ((this.VDSK1==null && other.getVDSK1()==null) || 
             (this.VDSK1!=null &&
              this.VDSK1.equals(other.getVDSK1()))) &&
            ((this.GSBER==null && other.getGSBER()==null) || 
             (this.GSBER!=null &&
              this.GSBER.equals(other.getGSBER()))) &&
            ((this.BTRTL==null && other.getBTRTL()==null) || 
             (this.BTRTL!=null &&
              this.BTRTL.equals(other.getBTRTL()))) &&
            ((this.JUPER==null && other.getJUPER()==null) || 
             (this.JUPER!=null &&
              this.JUPER.equals(other.getJUPER()))) &&
            ((this.ABKRS==null && other.getABKRS()==null) || 
             (this.ABKRS!=null &&
              this.ABKRS.equals(other.getABKRS()))) &&
            ((this.ANSVH==null && other.getANSVH()==null) || 
             (this.ANSVH!=null &&
              this.ANSVH.equals(other.getANSVH()))) &&
            ((this.KOSTL==null && other.getKOSTL()==null) || 
             (this.KOSTL!=null &&
              this.KOSTL.equals(other.getKOSTL()))) &&
            ((this.ORGEH==null && other.getORGEH()==null) || 
             (this.ORGEH!=null &&
              this.ORGEH.equals(other.getORGEH()))) &&
            ((this.PLANS==null && other.getPLANS()==null) || 
             (this.PLANS!=null &&
              this.PLANS.equals(other.getPLANS()))) &&
            ((this.STELL==null && other.getSTELL()==null) || 
             (this.STELL!=null &&
              this.STELL.equals(other.getSTELL()))) &&
            ((this.MSTBR==null && other.getMSTBR()==null) || 
             (this.MSTBR!=null &&
              this.MSTBR.equals(other.getMSTBR()))) &&
            ((this.SACHA==null && other.getSACHA()==null) || 
             (this.SACHA!=null &&
              this.SACHA.equals(other.getSACHA()))) &&
            ((this.SACHP==null && other.getSACHP()==null) || 
             (this.SACHP!=null &&
              this.SACHP.equals(other.getSACHP()))) &&
            ((this.SACHZ==null && other.getSACHZ()==null) || 
             (this.SACHZ!=null &&
              this.SACHZ.equals(other.getSACHZ()))) &&
            ((this.SNAME==null && other.getSNAME()==null) || 
             (this.SNAME!=null &&
              this.SNAME.equals(other.getSNAME()))) &&
            ((this.ENAME==null && other.getENAME()==null) || 
             (this.ENAME!=null &&
              this.ENAME.equals(other.getENAME()))) &&
            ((this.OTYPE==null && other.getOTYPE()==null) || 
             (this.OTYPE!=null &&
              this.OTYPE.equals(other.getOTYPE()))) &&
            ((this.SBMOD==null && other.getSBMOD()==null) || 
             (this.SBMOD!=null &&
              this.SBMOD.equals(other.getSBMOD()))) &&
            ((this.KOKRS==null && other.getKOKRS()==null) || 
             (this.KOKRS!=null &&
              this.KOKRS.equals(other.getKOKRS()))) &&
            ((this.FISTL==null && other.getFISTL()==null) || 
             (this.FISTL!=null &&
              this.FISTL.equals(other.getFISTL()))) &&
            ((this.GEBER==null && other.getGEBER()==null) || 
             (this.GEBER!=null &&
              this.GEBER.equals(other.getGEBER()))) &&
            ((this.FKBER==null && other.getFKBER()==null) || 
             (this.FKBER!=null &&
              this.FKBER.equals(other.getFKBER()))) &&
            ((this.GRANT_NBR==null && other.getGRANT_NBR()==null) || 
             (this.GRANT_NBR!=null &&
              this.GRANT_NBR.equals(other.getGRANT_NBR()))) &&
            ((this.SGMNT==null && other.getSGMNT()==null) || 
             (this.SGMNT!=null &&
              this.SGMNT.equals(other.getSGMNT()))) &&
            ((this.BUDGET_PD==null && other.getBUDGET_PD()==null) || 
             (this.BUDGET_PD!=null &&
              this.BUDGET_PD.equals(other.getBUDGET_PD()))) &&
            ((this.ZZSOCSC==null && other.getZZSOCSC()==null) || 
             (this.ZZSOCSC!=null &&
              this.ZZSOCSC.equals(other.getZZSOCSC()))) &&
            ((this.ZZTEXTO==null && other.getZZTEXTO()==null) || 
             (this.ZZTEXTO!=null &&
              this.ZZTEXTO.equals(other.getZZTEXTO()))) &&
            ((this.SABR==null && other.getSABR()==null) || 
             (this.SABR!=null &&
              this.SABR.equals(other.getSABR()))) &&
            ((this.SCBR==null && other.getSCBR()==null) || 
             (this.SCBR!=null &&
              this.SCBR.equals(other.getSCBR()))) &&
            ((this.SCNE==null && other.getSCNE()==null) || 
             (this.SCNE!=null &&
              this.SCNE.equals(other.getSCNE()))) &&
            ((this.POSINF==null && other.getPOSINF()==null) || 
             (this.POSINF!=null &&
              this.POSINF.equals(other.getPOSINF()))) &&
            ((this.BUILD==null && other.getBUILD()==null) || 
             (this.BUILD!=null &&
              this.BUILD.equals(other.getBUILD()))) &&
            ((this.SABR_EMP==null && other.getSABR_EMP()==null) || 
             (this.SABR_EMP!=null &&
              this.SABR_EMP.equals(other.getSABR_EMP()))) &&
            ((this.SCNETO_EMP==null && other.getSCNETO_EMP()==null) || 
             (this.SCNETO_EMP!=null &&
              this.SCNETO_EMP.equals(other.getSCNETO_EMP()))) &&
            ((this.SABR_POS==null && other.getSABR_POS()==null) || 
             (this.SABR_POS!=null &&
              this.SABR_POS.equals(other.getSABR_POS()))) &&
            ((this.SCNETO_POS==null && other.getSCNETO_POS()==null) || 
             (this.SCNETO_POS!=null &&
              this.SCNETO_POS.equals(other.getSCNETO_POS())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getPERNR() != null) {
            _hashCode += getPERNR().hashCode();
        }
        if (getINFTY() != null) {
            _hashCode += getINFTY().hashCode();
        }
        if (getSUBTY() != null) {
            _hashCode += getSUBTY().hashCode();
        }
        if (getOBJPS() != null) {
            _hashCode += getOBJPS().hashCode();
        }
        if (getSPRPS() != null) {
            _hashCode += getSPRPS().hashCode();
        }
        if (getENDDA() != null) {
            _hashCode += getENDDA().hashCode();
        }
        if (getBEGDA() != null) {
            _hashCode += getBEGDA().hashCode();
        }
        if (getSEQNR() != null) {
            _hashCode += getSEQNR().hashCode();
        }
        if (getAEDTM() != null) {
            _hashCode += getAEDTM().hashCode();
        }
        if (getUNAME() != null) {
            _hashCode += getUNAME().hashCode();
        }
        if (getHISTO() != null) {
            _hashCode += getHISTO().hashCode();
        }
        if (getITXEX() != null) {
            _hashCode += getITXEX().hashCode();
        }
        if (getREFEX() != null) {
            _hashCode += getREFEX().hashCode();
        }
        if (getORDEX() != null) {
            _hashCode += getORDEX().hashCode();
        }
        if (getITBLD() != null) {
            _hashCode += getITBLD().hashCode();
        }
        if (getPREAS() != null) {
            _hashCode += getPREAS().hashCode();
        }
        if (getFLAG1() != null) {
            _hashCode += getFLAG1().hashCode();
        }
        if (getFLAG2() != null) {
            _hashCode += getFLAG2().hashCode();
        }
        if (getFLAG3() != null) {
            _hashCode += getFLAG3().hashCode();
        }
        if (getFLAG4() != null) {
            _hashCode += getFLAG4().hashCode();
        }
        if (getRESE1() != null) {
            _hashCode += getRESE1().hashCode();
        }
        if (getRESE2() != null) {
            _hashCode += getRESE2().hashCode();
        }
        if (getGRPVL() != null) {
            _hashCode += getGRPVL().hashCode();
        }
        if (getBUKRS() != null) {
            _hashCode += getBUKRS().hashCode();
        }
        if (getWERKS() != null) {
            _hashCode += getWERKS().hashCode();
        }
        if (getPERSG() != null) {
            _hashCode += getPERSG().hashCode();
        }
        if (getPERSK() != null) {
            _hashCode += getPERSK().hashCode();
        }
        if (getVDSK1() != null) {
            _hashCode += getVDSK1().hashCode();
        }
        if (getGSBER() != null) {
            _hashCode += getGSBER().hashCode();
        }
        if (getBTRTL() != null) {
            _hashCode += getBTRTL().hashCode();
        }
        if (getJUPER() != null) {
            _hashCode += getJUPER().hashCode();
        }
        if (getABKRS() != null) {
            _hashCode += getABKRS().hashCode();
        }
        if (getANSVH() != null) {
            _hashCode += getANSVH().hashCode();
        }
        if (getKOSTL() != null) {
            _hashCode += getKOSTL().hashCode();
        }
        if (getORGEH() != null) {
            _hashCode += getORGEH().hashCode();
        }
        if (getPLANS() != null) {
            _hashCode += getPLANS().hashCode();
        }
        if (getSTELL() != null) {
            _hashCode += getSTELL().hashCode();
        }
        if (getMSTBR() != null) {
            _hashCode += getMSTBR().hashCode();
        }
        if (getSACHA() != null) {
            _hashCode += getSACHA().hashCode();
        }
        if (getSACHP() != null) {
            _hashCode += getSACHP().hashCode();
        }
        if (getSACHZ() != null) {
            _hashCode += getSACHZ().hashCode();
        }
        if (getSNAME() != null) {
            _hashCode += getSNAME().hashCode();
        }
        if (getENAME() != null) {
            _hashCode += getENAME().hashCode();
        }
        if (getOTYPE() != null) {
            _hashCode += getOTYPE().hashCode();
        }
        if (getSBMOD() != null) {
            _hashCode += getSBMOD().hashCode();
        }
        if (getKOKRS() != null) {
            _hashCode += getKOKRS().hashCode();
        }
        if (getFISTL() != null) {
            _hashCode += getFISTL().hashCode();
        }
        if (getGEBER() != null) {
            _hashCode += getGEBER().hashCode();
        }
        if (getFKBER() != null) {
            _hashCode += getFKBER().hashCode();
        }
        if (getGRANT_NBR() != null) {
            _hashCode += getGRANT_NBR().hashCode();
        }
        if (getSGMNT() != null) {
            _hashCode += getSGMNT().hashCode();
        }
        if (getBUDGET_PD() != null) {
            _hashCode += getBUDGET_PD().hashCode();
        }
        if (getZZSOCSC() != null) {
            _hashCode += getZZSOCSC().hashCode();
        }
        if (getZZTEXTO() != null) {
            _hashCode += getZZTEXTO().hashCode();
        }
        if (getSABR() != null) {
            _hashCode += getSABR().hashCode();
        }
        if (getSCBR() != null) {
            _hashCode += getSCBR().hashCode();
        }
        if (getSCNE() != null) {
            _hashCode += getSCNE().hashCode();
        }
        if (getPOSINF() != null) {
            _hashCode += getPOSINF().hashCode();
        }
        if (getBUILD() != null) {
            _hashCode += getBUILD().hashCode();
        }
        if (getSABR_EMP() != null) {
            _hashCode += getSABR_EMP().hashCode();
        }
        if (getSCNETO_EMP() != null) {
            _hashCode += getSCNETO_EMP().hashCode();
        }
        if (getSABR_POS() != null) {
            _hashCode += getSABR_POS().hashCode();
        }
        if (getSCNETO_POS() != null) {
            _hashCode += getSCNETO_POS().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ZRH_REG_CRED.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://tempuri.org/", "ZRH_REG_CRED"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("PERNR");
        elemField.setXmlName(new javax.xml.namespace.QName("", "PERNR"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("INFTY");
        elemField.setXmlName(new javax.xml.namespace.QName("", "INFTY"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SUBTY");
        elemField.setXmlName(new javax.xml.namespace.QName("", "SUBTY"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("OBJPS");
        elemField.setXmlName(new javax.xml.namespace.QName("", "OBJPS"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SPRPS");
        elemField.setXmlName(new javax.xml.namespace.QName("", "SPRPS"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ENDDA");
        elemField.setXmlName(new javax.xml.namespace.QName("", "ENDDA"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("BEGDA");
        elemField.setXmlName(new javax.xml.namespace.QName("", "BEGDA"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SEQNR");
        elemField.setXmlName(new javax.xml.namespace.QName("", "SEQNR"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AEDTM");
        elemField.setXmlName(new javax.xml.namespace.QName("", "AEDTM"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("UNAME");
        elemField.setXmlName(new javax.xml.namespace.QName("", "UNAME"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("HISTO");
        elemField.setXmlName(new javax.xml.namespace.QName("", "HISTO"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ITXEX");
        elemField.setXmlName(new javax.xml.namespace.QName("", "ITXEX"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("REFEX");
        elemField.setXmlName(new javax.xml.namespace.QName("", "REFEX"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ORDEX");
        elemField.setXmlName(new javax.xml.namespace.QName("", "ORDEX"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ITBLD");
        elemField.setXmlName(new javax.xml.namespace.QName("", "ITBLD"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("PREAS");
        elemField.setXmlName(new javax.xml.namespace.QName("", "PREAS"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("FLAG1");
        elemField.setXmlName(new javax.xml.namespace.QName("", "FLAG1"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("FLAG2");
        elemField.setXmlName(new javax.xml.namespace.QName("", "FLAG2"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("FLAG3");
        elemField.setXmlName(new javax.xml.namespace.QName("", "FLAG3"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("FLAG4");
        elemField.setXmlName(new javax.xml.namespace.QName("", "FLAG4"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("RESE1");
        elemField.setXmlName(new javax.xml.namespace.QName("", "RESE1"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("RESE2");
        elemField.setXmlName(new javax.xml.namespace.QName("", "RESE2"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("GRPVL");
        elemField.setXmlName(new javax.xml.namespace.QName("", "GRPVL"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("BUKRS");
        elemField.setXmlName(new javax.xml.namespace.QName("", "BUKRS"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("WERKS");
        elemField.setXmlName(new javax.xml.namespace.QName("", "WERKS"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("PERSG");
        elemField.setXmlName(new javax.xml.namespace.QName("", "PERSG"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("PERSK");
        elemField.setXmlName(new javax.xml.namespace.QName("", "PERSK"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("VDSK1");
        elemField.setXmlName(new javax.xml.namespace.QName("", "VDSK1"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("GSBER");
        elemField.setXmlName(new javax.xml.namespace.QName("", "GSBER"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("BTRTL");
        elemField.setXmlName(new javax.xml.namespace.QName("", "BTRTL"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("JUPER");
        elemField.setXmlName(new javax.xml.namespace.QName("", "JUPER"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ABKRS");
        elemField.setXmlName(new javax.xml.namespace.QName("", "ABKRS"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ANSVH");
        elemField.setXmlName(new javax.xml.namespace.QName("", "ANSVH"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KOSTL");
        elemField.setXmlName(new javax.xml.namespace.QName("", "KOSTL"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ORGEH");
        elemField.setXmlName(new javax.xml.namespace.QName("", "ORGEH"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("PLANS");
        elemField.setXmlName(new javax.xml.namespace.QName("", "PLANS"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("STELL");
        elemField.setXmlName(new javax.xml.namespace.QName("", "STELL"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("MSTBR");
        elemField.setXmlName(new javax.xml.namespace.QName("", "MSTBR"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SACHA");
        elemField.setXmlName(new javax.xml.namespace.QName("", "SACHA"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SACHP");
        elemField.setXmlName(new javax.xml.namespace.QName("", "SACHP"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SACHZ");
        elemField.setXmlName(new javax.xml.namespace.QName("", "SACHZ"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SNAME");
        elemField.setXmlName(new javax.xml.namespace.QName("", "SNAME"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ENAME");
        elemField.setXmlName(new javax.xml.namespace.QName("", "ENAME"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("OTYPE");
        elemField.setXmlName(new javax.xml.namespace.QName("", "OTYPE"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SBMOD");
        elemField.setXmlName(new javax.xml.namespace.QName("", "SBMOD"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KOKRS");
        elemField.setXmlName(new javax.xml.namespace.QName("", "KOKRS"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("FISTL");
        elemField.setXmlName(new javax.xml.namespace.QName("", "FISTL"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("GEBER");
        elemField.setXmlName(new javax.xml.namespace.QName("", "GEBER"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("FKBER");
        elemField.setXmlName(new javax.xml.namespace.QName("", "FKBER"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("GRANT_NBR");
        elemField.setXmlName(new javax.xml.namespace.QName("", "GRANT_NBR"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SGMNT");
        elemField.setXmlName(new javax.xml.namespace.QName("", "SGMNT"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("BUDGET_PD");
        elemField.setXmlName(new javax.xml.namespace.QName("", "BUDGET_PD"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ZZSOCSC");
        elemField.setXmlName(new javax.xml.namespace.QName("", "ZZSOCSC"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ZZTEXTO");
        elemField.setXmlName(new javax.xml.namespace.QName("", "ZZTEXTO"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SABR");
        elemField.setXmlName(new javax.xml.namespace.QName("", "SABR"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SCBR");
        elemField.setXmlName(new javax.xml.namespace.QName("", "SCBR"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SCNE");
        elemField.setXmlName(new javax.xml.namespace.QName("", "SCNE"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("POSINF");
        elemField.setXmlName(new javax.xml.namespace.QName("", "POSINF"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("BUILD");
        elemField.setXmlName(new javax.xml.namespace.QName("", "BUILD"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SABR_EMP");
        elemField.setXmlName(new javax.xml.namespace.QName("", "SABR_EMP"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SCNETO_EMP");
        elemField.setXmlName(new javax.xml.namespace.QName("", "SCNETO_EMP"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SABR_POS");
        elemField.setXmlName(new javax.xml.namespace.QName("", "SABR_POS"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SCNETO_POS");
        elemField.setXmlName(new javax.xml.namespace.QName("", "SCNETO_POS"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    @SuppressWarnings("rawtypes")
	public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    @SuppressWarnings("rawtypes")
	public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
