package com.bancoazteca.srcu.spring.ws.administracion.posicionesSap;

import java.math.BigDecimal;

public class ParametrosWSBean {
	private String fcsidNeg;
	private String fcsMedia;
	private String fcsShort;
	private String fcssText;
	private String fcsFuncion;
	private String fcsTipoPos;
	private String fcsSociedad;
	private String fcsDivision;
	private String fcsSubDivision;
	private String fcsAreaPersonal;
	private String fcsEdificio;
	private String fcsClaseConv;
	private String fcsAreaConv;
	private String fcsAgrupConv;
	private String fcsGrupoProf;
	private String fcssDosAbruto;
	private String fcsDoscBruto;
	private String fcsDoscNeto;
	private BigDecimal fisUnidadOrg;
	
	public  ParametrosWSBean() {
		
	}

	public String getFcsidNeg() {
		return fcsidNeg;
	}

	public void setFcsidNeg(String fcsidNeg) {
		this.fcsidNeg = fcsidNeg;
	}

	public String getFcsMedia() {
		return fcsMedia;
	}

	public void setFcsMedia(String fcsMedia) {
		this.fcsMedia = fcsMedia;
	}

	public String getFcsShort() {
		return fcsShort;
	}

	public void setFcsShort(String fcsShort) {
		this.fcsShort = fcsShort;
	}

	public String getFcssText() {
		return fcssText;
	}

	public void setFcssText(String fcssText) {
		this.fcssText = fcssText;
	}

	public String getFcsFuncion() {
		return fcsFuncion;
	}

	public void setFcsFuncion(String fcsFuncion) {
		this.fcsFuncion = fcsFuncion;
	}

	public String getFcsTipoPos() {
		return fcsTipoPos;
	}

	public void setFcsTipoPos(String fcsTipoPos) {
		this.fcsTipoPos = fcsTipoPos;
	}

	public String getFcsSociedad() {
		return fcsSociedad;
	}

	public void setFcsSociedad(String fcsSociedad) {
		this.fcsSociedad = fcsSociedad;
	}

	public String getFcsDivision() {
		return fcsDivision;
	}

	public void setFcsDivision(String fcsDivision) {
		this.fcsDivision = fcsDivision;
	}

	public String getFcsSubDivision() {
		return fcsSubDivision;
	}

	public void setFcsSubDivision(String fcsSubDivision) {
		this.fcsSubDivision = fcsSubDivision;
	}

	public String getFcsAreaPersonal() {
		return fcsAreaPersonal;
	}

	public void setFcsAreaPersonal(String fcsAreaPersonal) {
		this.fcsAreaPersonal = fcsAreaPersonal;
	}

	public String getFcsEdificio() {
		return fcsEdificio;
	}

	public void setFcsEdificio(String fcsEdificio) {
		this.fcsEdificio = fcsEdificio;
	}

	public String getFcsClaseConv() {
		return fcsClaseConv;
	}

	public void setFcsClaseConv(String fcsClaseConv) {
		this.fcsClaseConv = fcsClaseConv;
	}

	public String getFcsAreaConv() {
		return fcsAreaConv;
	}

	public void setFcsAreaConv(String fcsAreaConv) {
		this.fcsAreaConv = fcsAreaConv;
	}

	public String getFcsAgrupConv() {
		return fcsAgrupConv;
	}

	public void setFcsAgrupConv(String fcsAgrupConv) {
		this.fcsAgrupConv = fcsAgrupConv;
	}

	public String getFcsGrupoProf() {
		return fcsGrupoProf;
	}

	public void setFcsGrupoProf(String fcsGrupoProf) {
		this.fcsGrupoProf = fcsGrupoProf;
	}

	public String getFcssDosAbruto() {
		return fcssDosAbruto;
	}

	public void setFcssDosAbruto(String fcssDosAbruto) {
		this.fcssDosAbruto = fcssDosAbruto;
	}

	public String getFcsDoscBruto() {
		return fcsDoscBruto;
	}

	public void setFcsDoscBruto(String fcsDoscBruto) {
		this.fcsDoscBruto = fcsDoscBruto;
	}

	public String getFcsDoscNeto() {
		return fcsDoscNeto;
	}

	public void setFcsDoscNeto(String fcsDoscNeto) {
		this.fcsDoscNeto = fcsDoscNeto;
	}

	public BigDecimal getFisUnidadOrg() {
		return fisUnidadOrg;
	}

	public void setFisUnidadOrg(BigDecimal fisUnidadOrg) {
		this.fisUnidadOrg = fisUnidadOrg;
	}
	
}
