/**
 * Sueldo.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.bancoazteca.srcu.spring.ws.administracion.empleados.axis;
@SuppressWarnings({ "unused", "rawtypes", "serial" })
public class Sueldo  implements java.io.Serializable {
    private java.math.BigDecimal sueldoSA;

    private java.math.BigDecimal sueldoSC;

    private java.math.BigDecimal sueldoSAPromedio;

    private java.math.BigDecimal sueldoSCPromedio;

    private java.math.BigDecimal sueldoVentaEmpleados;

    private java.math.BigDecimal sueldoBruto;

    public Sueldo() {
    }

    public Sueldo(
           java.math.BigDecimal sueldoSA,
           java.math.BigDecimal sueldoSC,
           java.math.BigDecimal sueldoSAPromedio,
           java.math.BigDecimal sueldoSCPromedio,
           java.math.BigDecimal sueldoVentaEmpleados,
           java.math.BigDecimal sueldoBruto) {
           this.sueldoSA = sueldoSA;
           this.sueldoSC = sueldoSC;
           this.sueldoSAPromedio = sueldoSAPromedio;
           this.sueldoSCPromedio = sueldoSCPromedio;
           this.sueldoVentaEmpleados = sueldoVentaEmpleados;
           this.sueldoBruto = sueldoBruto;
    }


    /**
     * Gets the sueldoSA value for this Sueldo.
     * 
     * @return sueldoSA
     */
    public java.math.BigDecimal getSueldoSA() {
        return sueldoSA;
    }


    /**
     * Sets the sueldoSA value for this Sueldo.
     * 
     * @param sueldoSA
     */
    public void setSueldoSA(java.math.BigDecimal sueldoSA) {
        this.sueldoSA = sueldoSA;
    }


    /**
     * Gets the sueldoSC value for this Sueldo.
     * 
     * @return sueldoSC
     */
    public java.math.BigDecimal getSueldoSC() {
        return sueldoSC;
    }


    /**
     * Sets the sueldoSC value for this Sueldo.
     * 
     * @param sueldoSC
     */
    public void setSueldoSC(java.math.BigDecimal sueldoSC) {
        this.sueldoSC = sueldoSC;
    }


    /**
     * Gets the sueldoSAPromedio value for this Sueldo.
     * 
     * @return sueldoSAPromedio
     */
    public java.math.BigDecimal getSueldoSAPromedio() {
        return sueldoSAPromedio;
    }


    /**
     * Sets the sueldoSAPromedio value for this Sueldo.
     * 
     * @param sueldoSAPromedio
     */
    public void setSueldoSAPromedio(java.math.BigDecimal sueldoSAPromedio) {
        this.sueldoSAPromedio = sueldoSAPromedio;
    }


    /**
     * Gets the sueldoSCPromedio value for this Sueldo.
     * 
     * @return sueldoSCPromedio
     */
    public java.math.BigDecimal getSueldoSCPromedio() {
        return sueldoSCPromedio;
    }


    /**
     * Sets the sueldoSCPromedio value for this Sueldo.
     * 
     * @param sueldoSCPromedio
     */
    public void setSueldoSCPromedio(java.math.BigDecimal sueldoSCPromedio) {
        this.sueldoSCPromedio = sueldoSCPromedio;
    }


    /**
     * Gets the sueldoVentaEmpleados value for this Sueldo.
     * 
     * @return sueldoVentaEmpleados
     */
    public java.math.BigDecimal getSueldoVentaEmpleados() {
        return sueldoVentaEmpleados;
    }


    /**
     * Sets the sueldoVentaEmpleados value for this Sueldo.
     * 
     * @param sueldoVentaEmpleados
     */
    public void setSueldoVentaEmpleados(java.math.BigDecimal sueldoVentaEmpleados) {
        this.sueldoVentaEmpleados = sueldoVentaEmpleados;
    }


    /**
     * Gets the sueldoBruto value for this Sueldo.
     * 
     * @return sueldoBruto
     */
    public java.math.BigDecimal getSueldoBruto() {
        return sueldoBruto;
    }


    /**
     * Sets the sueldoBruto value for this Sueldo.
     * 
     * @param sueldoBruto
     */
    public void setSueldoBruto(java.math.BigDecimal sueldoBruto) {
        this.sueldoBruto = sueldoBruto;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Sueldo)) return false;
        Sueldo other = (Sueldo) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.sueldoSA==null && other.getSueldoSA()==null) || 
             (this.sueldoSA!=null &&
              this.sueldoSA.equals(other.getSueldoSA()))) &&
            ((this.sueldoSC==null && other.getSueldoSC()==null) || 
             (this.sueldoSC!=null &&
              this.sueldoSC.equals(other.getSueldoSC()))) &&
            ((this.sueldoSAPromedio==null && other.getSueldoSAPromedio()==null) || 
             (this.sueldoSAPromedio!=null &&
              this.sueldoSAPromedio.equals(other.getSueldoSAPromedio()))) &&
            ((this.sueldoSCPromedio==null && other.getSueldoSCPromedio()==null) || 
             (this.sueldoSCPromedio!=null &&
              this.sueldoSCPromedio.equals(other.getSueldoSCPromedio()))) &&
            ((this.sueldoVentaEmpleados==null && other.getSueldoVentaEmpleados()==null) || 
             (this.sueldoVentaEmpleados!=null &&
              this.sueldoVentaEmpleados.equals(other.getSueldoVentaEmpleados()))) &&
            ((this.sueldoBruto==null && other.getSueldoBruto()==null) || 
             (this.sueldoBruto!=null &&
              this.sueldoBruto.equals(other.getSueldoBruto())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getSueldoSA() != null) {
            _hashCode += getSueldoSA().hashCode();
        }
        if (getSueldoSC() != null) {
            _hashCode += getSueldoSC().hashCode();
        }
        if (getSueldoSAPromedio() != null) {
            _hashCode += getSueldoSAPromedio().hashCode();
        }
        if (getSueldoSCPromedio() != null) {
            _hashCode += getSueldoSCPromedio().hashCode();
        }
        if (getSueldoVentaEmpleados() != null) {
            _hashCode += getSueldoVentaEmpleados().hashCode();
        }
        if (getSueldoBruto() != null) {
            _hashCode += getSueldoBruto().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Sueldo.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Sueldo"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("sueldoSA");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "SueldoSA"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("sueldoSC");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "SueldoSC"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("sueldoSAPromedio");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "SueldoSAPromedio"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("sueldoSCPromedio");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "SueldoSCPromedio"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("sueldoVentaEmpleados");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "SueldoVentaEmpleados"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("sueldoBruto");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "SueldoBruto"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
