package com.bancoazteca.srcu.spring.ws.administracion.posicionesSap;

public class RespuestaLimitaPosicionBean {
	private int codigo;
	private String fechaLimita;
	private String mensaje;
	private String descripcion;
	private String mensajeError;
	private String numPosicionLimita;
	
	public RespuestaLimitaPosicionBean() {
		
	}

	public int getCodigo() {
		return codigo;
	}

	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}

	public String getFechaLimita() {
		return fechaLimita;
	}

	public void setFechaLimita(String fechaLimita) {
		this.fechaLimita = fechaLimita;
	}

	public String getMensaje() {
		return mensaje;
	}

	public void setMensaje(String mensaje) {
		this.mensaje = mensaje;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public String getMensajeError() {
		return mensajeError;
	}

	public void setMensajeError(String mensajeError) {
		this.mensajeError = mensajeError;
	}

	public String getNumPosicionLimita() {
		return numPosicionLimita;
	}

	public void setNumPosicionLimita(String numPosicionLimita) {
		this.numPosicionLimita = numPosicionLimita;
	}
	
}
