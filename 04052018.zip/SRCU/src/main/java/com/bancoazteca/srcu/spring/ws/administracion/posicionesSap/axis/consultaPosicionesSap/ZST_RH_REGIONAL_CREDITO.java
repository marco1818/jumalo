/**
 * ZST_RH_REGIONAL_CREDITO.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.bancoazteca.srcu.spring.ws.administracion.posicionesSap.axis.consultaPosicionesSap;

@SuppressWarnings("serial")
public class ZST_RH_REGIONAL_CREDITO  implements java.io.Serializable {
    private java.lang.String CECO;

    private java.lang.String FNSAP;

    private java.lang.String IDPOS;

    private java.lang.String PERNR;

    public ZST_RH_REGIONAL_CREDITO() {
    }

    public ZST_RH_REGIONAL_CREDITO(
           java.lang.String CECO,
           java.lang.String FNSAP,
           java.lang.String IDPOS,
           java.lang.String PERNR) {
           this.CECO = CECO;
           this.FNSAP = FNSAP;
           this.IDPOS = IDPOS;
           this.PERNR = PERNR;
    }


    /**
     * Gets the CECO value for this ZST_RH_REGIONAL_CREDITO.
     * 
     * @return CECO
     */
    public java.lang.String getCECO() {
        return CECO;
    }


    /**
     * Sets the CECO value for this ZST_RH_REGIONAL_CREDITO.
     * 
     * @param CECO
     */
    public void setCECO(java.lang.String CECO) {
        this.CECO = CECO;
    }


    /**
     * Gets the FNSAP value for this ZST_RH_REGIONAL_CREDITO.
     * 
     * @return FNSAP
     */
    public java.lang.String getFNSAP() {
        return FNSAP;
    }


    /**
     * Sets the FNSAP value for this ZST_RH_REGIONAL_CREDITO.
     * 
     * @param FNSAP
     */
    public void setFNSAP(java.lang.String FNSAP) {
        this.FNSAP = FNSAP;
    }


    /**
     * Gets the IDPOS value for this ZST_RH_REGIONAL_CREDITO.
     * 
     * @return IDPOS
     */
    public java.lang.String getIDPOS() {
        return IDPOS;
    }


    /**
     * Sets the IDPOS value for this ZST_RH_REGIONAL_CREDITO.
     * 
     * @param IDPOS
     */
    public void setIDPOS(java.lang.String IDPOS) {
        this.IDPOS = IDPOS;
    }


    /**
     * Gets the PERNR value for this ZST_RH_REGIONAL_CREDITO.
     * 
     * @return PERNR
     */
    public java.lang.String getPERNR() {
        return PERNR;
    }


    /**
     * Sets the PERNR value for this ZST_RH_REGIONAL_CREDITO.
     * 
     * @param PERNR
     */
    public void setPERNR(java.lang.String PERNR) {
        this.PERNR = PERNR;
    }

    private java.lang.Object __equalsCalc = null;
    @SuppressWarnings("unused")
	public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ZST_RH_REGIONAL_CREDITO)) return false;
        ZST_RH_REGIONAL_CREDITO other = (ZST_RH_REGIONAL_CREDITO) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.CECO==null && other.getCECO()==null) || 
             (this.CECO!=null &&
              this.CECO.equals(other.getCECO()))) &&
            ((this.FNSAP==null && other.getFNSAP()==null) || 
             (this.FNSAP!=null &&
              this.FNSAP.equals(other.getFNSAP()))) &&
            ((this.IDPOS==null && other.getIDPOS()==null) || 
             (this.IDPOS!=null &&
              this.IDPOS.equals(other.getIDPOS()))) &&
            ((this.PERNR==null && other.getPERNR()==null) || 
             (this.PERNR!=null &&
              this.PERNR.equals(other.getPERNR())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getCECO() != null) {
            _hashCode += getCECO().hashCode();
        }
        if (getFNSAP() != null) {
            _hashCode += getFNSAP().hashCode();
        }
        if (getIDPOS() != null) {
            _hashCode += getIDPOS().hashCode();
        }
        if (getPERNR() != null) {
            _hashCode += getPERNR().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ZST_RH_REGIONAL_CREDITO.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn:sap-com:document:sap:rfc:functions", "ZST_RH_REGIONAL_CREDITO"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CECO");
        elemField.setXmlName(new javax.xml.namespace.QName("", "CECO"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("FNSAP");
        elemField.setXmlName(new javax.xml.namespace.QName("", "FNSAP"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("IDPOS");
        elemField.setXmlName(new javax.xml.namespace.QName("", "IDPOS"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("PERNR");
        elemField.setXmlName(new javax.xml.namespace.QName("", "PERNR"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    @SuppressWarnings({ "rawtypes" })
	public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    @SuppressWarnings("rawtypes")
	public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
