package com.bancoazteca.srcu.spring.beans.administracion.mantenimientoUsuariosSap;

public class VacantesBean {
	private String numeroVacante;
	private String mensaje;
		
	public VacantesBean() {
		
	}

	public String getNumeroVacante() {
		return numeroVacante;
	}

	public void setNumeroVacante(String numeroVacante) {
		this.numeroVacante = numeroVacante;
	}

	public String getMensaje() {
		return mensaje;
	}

	public void setMensaje(String mensaje) {
		this.mensaje = mensaje;
	}
	
}
