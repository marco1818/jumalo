package com.bancoazteca.srcu.spring.ws.administracion.posicionesSap.axis.altaBajaPosicionesSap;

import javax.xml.rpc.holders.StringHolder;

public class Srv_PosicionSoapProxy implements Srv_PosicionSoap {
  private String _endpoint = null;
  private Srv_PosicionSoap srv_PosicionSoap = null;
  
  public Srv_PosicionSoapProxy() {
    _initSrv_PosicionSoapProxy();
  }
  
  public Srv_PosicionSoapProxy(String endpoint) {
    _endpoint = endpoint;
    _initSrv_PosicionSoapProxy();
  }
  
  private void _initSrv_PosicionSoapProxy() {
    try {
      srv_PosicionSoap = (new Srv_PosicionLocator()).getSrv_PosicionSoap();
      if (srv_PosicionSoap != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)srv_PosicionSoap)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)srv_PosicionSoap)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (srv_PosicionSoap != null)
      ((javax.xml.rpc.Stub)srv_PosicionSoap)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public Srv_PosicionSoap getSrv_PosicionSoap() {
    if (srv_PosicionSoap == null)
      _initSrv_PosicionSoapProxy();
    return srv_PosicionSoap;
  }
  
  public void cambia_DenPos(java.lang.String sIdNeg, java.lang.String sUsr, java.lang.String sPwd, java.lang.String sPos, java.lang.String sShort, java.lang.String sText, java.lang.String sBegda, ArrayOfZHRLOGERR_VNTEMPHolder it_Err) throws java.rmi.RemoteException{
    if (srv_PosicionSoap == null)
      _initSrv_PosicionSoapProxy();
    srv_PosicionSoap.cambia_DenPos(sIdNeg, sUsr, sPwd, sPos, sShort, sText, sBegda, it_Err);
  }
  
  public void cambia_Ccostos(java.lang.String sIdNeg, java.lang.String sUsr, java.lang.String sPwd, java.lang.String sPos, java.lang.String sPosRep, java.lang.String sUOrg, java.lang.String sCCostos, java.lang.String sBegda, ArrayOfZHRLOGERR_VNTEMPHolder it_Err) throws java.rmi.RemoteException{
    if (srv_PosicionSoap == null)
      _initSrv_PosicionSoapProxy();
    srv_PosicionSoap.cambia_Ccostos(sIdNeg, sUsr, sPwd, sPos, sPosRep, sUOrg, sCCostos, sBegda, it_Err);
  }
  
  public void cat_Ubicacion(java.lang.String sIdNeg, java.lang.String sUsr, java.lang.String sPwd, ArrayOfZRH_CATALOGOSHolder catalogo, ArrayOfZHRLOGERR_VNTEMPHolder it_Err) throws java.rmi.RemoteException{
    if (srv_PosicionSoap == null)
      _initSrv_PosicionSoapProxy();
    srv_PosicionSoap.cat_Ubicacion(sIdNeg, sUsr, sPwd, catalogo, it_Err);
  }
  
  public void cambia_Ubicacion(java.lang.String sIdNeg, java.lang.String sUsr, java.lang.String sPwd, java.lang.String sPos, java.lang.String sUbi, ArrayOfZHRLOGERR_VNTEMPHolder it_Err) throws java.rmi.RemoteException{
    if (srv_PosicionSoap == null)
      _initSrv_PosicionSoapProxy();
    srv_PosicionSoap.cambia_Ubicacion(sIdNeg, sUsr, sPwd, sPos, sUbi, it_Err);
  }
  
  public void crea_Enlace_LinRep(java.lang.String sIdNeg, java.lang.String sUsr, java.lang.String sPwd, java.lang.String sPosSup, java.lang.String sPosEmp, java.lang.String sBegda, ArrayOfZHRLOGERR_VNTEMPHolder it_Err) throws java.rmi.RemoteException{
    if (srv_PosicionSoap == null)
      _initSrv_PosicionSoapProxy();
    srv_PosicionSoap.crea_Enlace_LinRep(sIdNeg, sUsr, sPwd, sPosSup, sPosEmp, sBegda, it_Err);
  }
  
  public void crea_Enlace_LinRep_Brasil(java.lang.String sIdNeg, java.lang.String sUsr, java.lang.String sPwd, java.lang.String sPosSup, java.lang.String sPosEmp, java.lang.String sBegda, ArrayOfZHRLOGERR_VNTEMPHolder it_Err) throws java.rmi.RemoteException{
    if (srv_PosicionSoap == null)
      _initSrv_PosicionSoapProxy();
    srv_PosicionSoap.crea_Enlace_LinRep_Brasil(sIdNeg, sUsr, sPwd, sPosSup, sPosEmp, sBegda, it_Err);
  }
  
  public void crea_Enlace_AdmPos(java.lang.String sIdNeg, java.lang.String sUsr, java.lang.String sPwd, java.lang.String sPosAdm, java.lang.String sPosEmp, java.lang.String sBegda, ArrayOfZHRLOGERR_VNTEMPHolder it_Err) throws java.rmi.RemoteException{
    if (srv_PosicionSoap == null)
      _initSrv_PosicionSoapProxy();
    srv_PosicionSoap.crea_Enlace_AdmPos(sIdNeg, sUsr, sPwd, sPosAdm, sPosEmp, sBegda, it_Err);
  }
  
  public void crea_Enlace_Funcion(java.lang.String sIdNeg, java.lang.String sUsr, java.lang.String sPwd, java.lang.String sPos, java.lang.String sFunc, java.lang.String sBegda, ArrayOfZHRLOGERR_VNTEMPHolder it_Err) throws java.rmi.RemoteException{
    if (srv_PosicionSoap == null)
      _initSrv_PosicionSoapProxy();
    srv_PosicionSoap.crea_Enlace_Funcion(sIdNeg, sUsr, sPwd, sPos, sFunc, sBegda, it_Err);
  }
  
  public void crea_PlanCost(java.lang.String sIdNeg, java.lang.String sUsr, java.lang.String sPwd, java.lang.String sPos, java.math.BigDecimal dSa_Bruto, java.math.BigDecimal dSc_Bruto, java.math.BigDecimal dSc_Neto, java.lang.String sBegda, ArrayOfZHRLOGERR_VNTEMPHolder it_Err) throws java.rmi.RemoteException{
    if (srv_PosicionSoap == null)
      _initSrv_PosicionSoapProxy();
    srv_PosicionSoap.crea_PlanCost(sIdNeg, sUsr, sPwd, sPos, dSa_Bruto, dSc_Bruto, dSc_Neto, sBegda, it_Err);
  }
  
  public void crea_Solo_PlanCost(java.lang.String sIdNeg, java.lang.String sUsr, java.lang.String sPwd, java.lang.String sPos, java.math.BigDecimal dSa_Bruto, java.math.BigDecimal dSc_Bruto, java.math.BigDecimal dSc_Neto, java.lang.String sBegda, ArrayOfZHRLOGERR_VNTEMPHolder it_Err) throws java.rmi.RemoteException{
    if (srv_PosicionSoap == null)
      _initSrv_PosicionSoapProxy();
    srv_PosicionSoap.crea_Solo_PlanCost(sIdNeg, sUsr, sPwd, sPos, dSa_Bruto, dSc_Bruto, dSc_Neto, sBegda, it_Err);
  }
  
  public void crea_Posicion(java.lang.String sIdNeg, java.lang.String sUsr, java.lang.String sPwd, java.lang.String sMedida, java.lang.String sShort, java.lang.String sStext, java.lang.String sPosinforma, java.lang.String sCcostos, java.lang.String sFuncion, java.lang.String sTipopos, java.lang.String sSociedad, java.lang.String sDivision, java.lang.String sSubdivision, java.lang.String sAreapersonal, java.lang.String sEdificio, java.lang.String sUnidadorg, java.lang.String sClaseconv, java.lang.String sAreaconv, java.lang.String sAgrupconv, java.lang.String sGrupoprof, java.math.BigDecimal dSdosabruto, java.math.BigDecimal dSdoscbruto, java.math.BigDecimal dSdoscneto, java.lang.String sRespde, ArrayOfZHRLOGERR_VNTEMPHolder it_Err) throws java.rmi.RemoteException{
    if (srv_PosicionSoap == null)
      _initSrv_PosicionSoapProxy();
    srv_PosicionSoap.crea_Posicion(sIdNeg, sUsr, sPwd, sMedida, sShort, sStext, sPosinforma, sCcostos, sFuncion, sTipopos, sSociedad, sDivision, sSubdivision, sAreapersonal, sEdificio, sUnidadorg, sClaseconv, sAreaconv, sAgrupconv, sGrupoprof, dSdosabruto, dSdoscbruto, dSdoscneto, sRespde, it_Err);
  }
  
  public void crea_RemTeo(java.lang.String sIdNeg, java.lang.String sUsr, java.lang.String sPwd, java.lang.String sPos, java.lang.String sCveconv, java.lang.String sAreaconv, java.lang.String sAgrpconv, java.lang.String sGrpprof, java.lang.String sRelab, java.lang.String sAdmnom, java.lang.String sBegda, ArrayOfZHRLOGERR_VNTEMPHolder it_Err) throws java.rmi.RemoteException{
    if (srv_PosicionSoap == null)
      _initSrv_PosicionSoapProxy();
    srv_PosicionSoap.crea_RemTeo(sIdNeg, sUsr, sPwd, sPos, sCveconv, sAreaconv, sAgrpconv, sGrpprof, sRelab, sAdmnom, sBegda, it_Err);
  }
  
  public void limita_Posicion(java.lang.String sIdNeg, java.lang.String sUsr, java.lang.String sPwd, java.lang.String sPos, java.lang.String sBegda, ArrayOfZHRLOGERR_VNTEMPHolder it_Err) throws java.rmi.RemoteException{
    if (srv_PosicionSoap == null)
      _initSrv_PosicionSoapProxy();
    srv_PosicionSoap.limita_Posicion(sIdNeg, sUsr, sPwd, sPos, sBegda, it_Err);
  }
  
  public void reactiva_Pos(java.lang.String sIdNeg, java.lang.String sUsr, java.lang.String sPwd, java.lang.String sPos, ArrayOfZHRLOGERR_VNTEMPHolder it_Err) throws java.rmi.RemoteException{
    if (srv_PosicionSoap == null)
      _initSrv_PosicionSoapProxy();
    srv_PosicionSoap.reactiva_Pos(sIdNeg, sUsr, sPwd, sPos, it_Err);
  }
  
  public void mov_Pos_Vac(java.lang.String sIdNeg, java.lang.String sUsr, java.lang.String sPwd, java.lang.String sPos, java.lang.String sCcostos, java.lang.String sClaseconv, java.lang.String sAreaconv, java.lang.String sAgrupconv, java.lang.String sGrupoprof, java.lang.String sSociedad, java.lang.String sDivision, java.lang.String sSubdivision, java.lang.String sAreapersonal, ArrayOfZHRLOGERR_VNTEMPHolder it_Err) throws java.rmi.RemoteException{
    if (srv_PosicionSoap == null)
      _initSrv_PosicionSoapProxy();
    srv_PosicionSoap.mov_Pos_Vac(sIdNeg, sUsr, sPwd, sPos, sCcostos, sClaseconv, sAreaconv, sAgrupconv, sGrupoprof, sSociedad, sDivision, sSubdivision, sAreapersonal, it_Err);
  }
  
  public void consulta(java.lang.String sIdNeg, java.lang.String sUsr, java.lang.String sPwd, java.lang.String sEmp, java.lang.String sPos, ArrayOfZRH_REG_CREDHolder it_Dat, ArrayOfZRH_CATALOGOSHolder it_CatPos, ArrayOfZRH_CATALOGOSHolder it_CatFun, ArrayOfZRH_CATALOGOSHolder it_CatUO, ArrayOfBAPIRETURN1Holder it_Err) throws java.rmi.RemoteException{
    if (srv_PosicionSoap == null)
      _initSrv_PosicionSoapProxy();
    srv_PosicionSoap.consulta(sIdNeg, sUsr, sPwd, sEmp, sPos, it_Dat, it_CatPos, it_CatFun, it_CatUO, it_Err);
  }
  
  public void consulta_Brasil(java.lang.String sIdNeg, java.lang.String sUsr, java.lang.String sPwd, java.lang.String sEmp, java.lang.String sPos, ArrayOfZRH_REG_CREDHolder it_Dat, ArrayOfZRH_CATALOGOSHolder it_CatPos, ArrayOfZRH_CATALOGOSHolder it_CatFun, ArrayOfZRH_CATALOGOSHolder it_CatUO, ArrayOfBAPIRETURN1Holder it_Err) throws java.rmi.RemoteException{
    if (srv_PosicionSoap == null)
      _initSrv_PosicionSoapProxy();
    srv_PosicionSoap.consulta_Brasil(sIdNeg, sUsr, sPwd, sEmp, sPos, it_Dat, it_CatPos, it_CatFun, it_CatUO, it_Err);
  }
  
  public void consulta_UO(java.lang.String sIdNeg, java.lang.String sUsr, java.lang.String sPwd, java.lang.String sUO, ArrayOfZRH_REG_CRED_UOHolder it_Dat, ArrayOfZRH_CATALOGOSHolder it_CatPos, ArrayOfZRH_CATALOGOSHolder it_CatFun, ArrayOfZRH_CATALOGOSHolder it_CatUO, ArrayOfBAPIRETURN1Holder it_Err) throws java.rmi.RemoteException{
    if (srv_PosicionSoap == null)
      _initSrv_PosicionSoapProxy();
    srv_PosicionSoap.consulta_UO(sIdNeg, sUsr, sPwd, sUO, it_Dat, it_CatPos, it_CatFun, it_CatUO, it_Err);
  }
  
  public void crea_Posicion_Brasil(java.lang.String sIdNeg, java.lang.String sUsr, java.lang.String sPwd, java.lang.String sMedida, java.lang.String sShort, java.lang.String sStext, java.lang.String sPosinforma, java.lang.String sCcostos, java.lang.String sFuncion, java.lang.String sSociedad, java.lang.String sDivision, java.lang.String sSubdivision, java.lang.String sAreapersonal, java.lang.String sEdificio, java.lang.String sUnidadorg, java.lang.String sClaseconv, java.lang.String sAreaconv, java.lang.String sAgrupconv, java.lang.String sGrupoprof, java.math.BigDecimal dSdobruto, java.lang.String sRespde, java.lang.String sTipopos, StringHolder sPlans, ArrayOfBAPIRETURN1Holder it_Err) throws java.rmi.RemoteException{
    if (srv_PosicionSoap == null)
      _initSrv_PosicionSoapProxy();
    srv_PosicionSoap.crea_Posicion_Brasil(sIdNeg, sUsr, sPwd, sMedida, sShort, sStext, sPosinforma, sCcostos, sFuncion, sSociedad, sDivision, sSubdivision, sAreapersonal, sEdificio, sUnidadorg, sClaseconv, sAreaconv, sAgrupconv, sGrupoprof, dSdobruto, sRespde, sTipopos, sPlans, it_Err);
  }
  
  public void crea_Dirige_Pos(java.lang.String sIdNeg, java.lang.String sUsr, java.lang.String sPwd, java.lang.String sPos, java.lang.String sOu, ArrayOfBAPIRETURN1Holder it_Err) throws java.rmi.RemoteException{
    if (srv_PosicionSoap == null)
      _initSrv_PosicionSoapProxy();
    srv_PosicionSoap.crea_Dirige_Pos(sIdNeg, sUsr, sPwd, sPos, sOu, it_Err);
  }
  
  public void borra_Dirige_Pos(java.lang.String sIdNeg, java.lang.String sUsr, java.lang.String sPwd, java.lang.String sPos, java.lang.String sOu, ArrayOfBAPIRETURN1Holder it_Err) throws java.rmi.RemoteException{
    if (srv_PosicionSoap == null)
      _initSrv_PosicionSoapProxy();
    srv_PosicionSoap.borra_Dirige_Pos(sIdNeg, sUsr, sPwd, sPos, sOu, it_Err);
  }
  
  public void crea_Enlace_Z10(java.lang.String sIdNeg, java.lang.String sUsr, java.lang.String sPwd, java.lang.String sPosOrg, java.lang.String sPosRep, ArrayOfBAPIRETURN1Holder it_Err) throws java.rmi.RemoteException{
    if (srv_PosicionSoap == null)
      _initSrv_PosicionSoapProxy();
    srv_PosicionSoap.crea_Enlace_Z10(sIdNeg, sUsr, sPwd, sPosOrg, sPosRep, it_Err);
  }
  
  public void borra_Enlace_Z10(java.lang.String sIdNeg, java.lang.String sUsr, java.lang.String sPwd, java.lang.String sPosOrg, ArrayOfBAPIRETURN1Holder it_Err) throws java.rmi.RemoteException{
    if (srv_PosicionSoap == null)
      _initSrv_PosicionSoapProxy();
    srv_PosicionSoap.borra_Enlace_Z10(sIdNeg, sUsr, sPwd, sPosOrg, it_Err);
  }
  
  public void crea_Inf_Vac(java.lang.String sIdNeg, java.lang.String sUsr, java.lang.String sPwd, java.lang.String sPosOrg, ArrayOfBAPIRETURN1Holder it_Err) throws java.rmi.RemoteException{
    if (srv_PosicionSoap == null)
      _initSrv_PosicionSoapProxy();
    srv_PosicionSoap.crea_Inf_Vac(sIdNeg, sUsr, sPwd, sPosOrg, it_Err);
  }
  
  public void mod_Sdo(java.lang.String sIdNeg, java.lang.String sUsr, java.lang.String sPwd, java.lang.String sPos, java.lang.String sCveConv, java.lang.String sAreaConv, java.lang.String sGrpProf, java.lang.String sSdoSA, java.lang.String sSdoSC, java.lang.String sBegDa, ArrayOfBAPIRETURN1Holder it_Err) throws java.rmi.RemoteException{
    if (srv_PosicionSoap == null)
      _initSrv_PosicionSoapProxy();
    srv_PosicionSoap.mod_Sdo(sIdNeg, sUsr, sPwd, sPos, sCveConv, sAreaConv, sGrpProf, sSdoSA, sSdoSC, sBegDa, it_Err);
  }
  
  public void mod_Sdo_Brasil(java.lang.String sIdNeg, java.lang.String sUsr, java.lang.String sPwd, java.lang.String sPos, java.lang.String sCveConv, java.lang.String sAreaConv, java.lang.String sGrpProf, java.lang.String sSdoSA, java.lang.String sSdoSC, java.lang.String sBegDa, ArrayOfBAPIRETURN1Holder it_Err) throws java.rmi.RemoteException{
    if (srv_PosicionSoap == null)
      _initSrv_PosicionSoapProxy();
    srv_PosicionSoap.mod_Sdo_Brasil(sIdNeg, sUsr, sPwd, sPos, sCveConv, sAreaConv, sGrpProf, sSdoSA, sSdoSC, sBegDa, it_Err);
  }
  
  public void lee_Pos_LinRep(java.lang.String sIdNeg, java.lang.String sUsr, java.lang.String sPwd, java.lang.String sPosSup, Lee_Pos_LinRepIt_Linrep it_Linrep, Lee_Pos_LinRepIt_Err it_Err, Lee_Pos_LinRepResponseIt_LinrepHolder it_Linrep2, Lee_Pos_LinRepResponseIt_ErrHolder it_Err2) throws java.rmi.RemoteException{
    if (srv_PosicionSoap == null)
      _initSrv_PosicionSoapProxy();
    srv_PosicionSoap.lee_Pos_LinRep(sIdNeg, sUsr, sPwd, sPosSup, it_Linrep, it_Err, it_Linrep2, it_Err2);
  }
  
  public void mod_Sdo_Bof(java.lang.String sIdNeg, java.lang.String sUsr, java.lang.String sPwd, java.lang.String sPos, java.lang.String sCveConv, java.lang.String sAreaConv, java.lang.String sGrpProf, java.lang.String sSdoSA, java.lang.String sSdoSC, java.lang.String sBegDa, ArrayOfBAPIRETURN1Holder it_Err) throws java.rmi.RemoteException{
    if (srv_PosicionSoap == null)
      _initSrv_PosicionSoapProxy();
    srv_PosicionSoap.mod_Sdo_Bof(sIdNeg, sUsr, sPwd, sPos, sCveConv, sAreaConv, sGrpProf, sSdoSA, sSdoSC, sBegDa, it_Err);
  }
}