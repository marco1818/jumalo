package com.bancoazteca.srcu.spring.beans.administracion.personalActivo;

import java.math.BigDecimal;

public class PersonalActivoBean {
	private String numJefe;
	private String nomJefe;
	private String puestoEmp;
	private String numEmp;
	private String nomEmp;
	private int idPuesEmp;
	private int idPuesJefe;
	private int nivel;
	private int idCanal;
	private String desCanal;
	private int idSucursal;
	private String descSucursal;
	private String fcDiaDescanso;
	private String ceco;
	private String fdFechaAlta;
	private String esForaneo;
	private String estatus;
	private String fechaModificacion;
	private String empleadoModifica;
	private int	totalClientes;
	
	public PersonalActivoBean() {
		
	}

	public String getNumJefe() {
		return numJefe;
	}

	public void setNumJefe(String numJefe) {
		this.numJefe = numJefe;
	}

	public String getNomJefe() {
		return nomJefe;
	}

	public void setNomJefe(String nomJefe) {
		this.nomJefe = nomJefe;
	}

	public String getPuestoEmp() {
		return puestoEmp;
	}

	public void setPuestoEmp(String puestoEmp) {
		this.puestoEmp = puestoEmp;
	}

	public String getNumEmp() {
		return numEmp;
	}

	public void setNumEmp(String numEmp) {
		this.numEmp = numEmp;
	}

	public String getNomEmp() {
		return nomEmp;
	}

	public void setNomEmp(String nomEmp) {
		this.nomEmp = nomEmp;
	}

	public int getIdPuesEmp() {
		return idPuesEmp;
	}

	public void setIdPuesEmp(int idPuesEmp) {
		this.idPuesEmp = idPuesEmp;
	}

	public void setIdPuesEmp(BigDecimal idPuesEmp) {
		this.idPuesEmp = idPuesEmp.intValue();
	}
	
	public int getIdPuesJefe() {
		return idPuesJefe;
	}

	public void setIdPuesJefe(int idPuesJefe) {
		this.idPuesJefe = idPuesJefe;
	}

	public void setIdPuesJefe(BigDecimal idPuesJefe) {
		this.idPuesJefe = idPuesJefe.intValue();
	}
	
	public int getNivel() {
		return nivel;
	}

	public void setNivel(int nivel) {
		this.nivel = nivel;
	}

	public void setNivel(BigDecimal nivel) {
		this.nivel = nivel.intValue();
	}
	
	public int getIdCanal() {
		return idCanal;
	}

	public void setIdCanal(int idCanal) {
		this.idCanal = idCanal;
	}

	public void setIdCanal(BigDecimal idCanal) {
		this.idCanal = idCanal.intValue();
	}
	
	public String getDesCanal() {
		return desCanal;
	}

	public void setDesCanal(String desCanal) {
		this.desCanal = desCanal;
	}

	public int getIdSucursal() {
		return idSucursal;
	}

	public void setIdSucursal(int idSucursal) {
		this.idSucursal = idSucursal;
	}

	public void setIdSucursal(BigDecimal idSucursal) {
		this.idSucursal = idSucursal.intValue();
	}
	
	public String getDescSucursal() {
		return descSucursal;
	}

	public void setDescSucursal(String descSucursal) {
		this.descSucursal = descSucursal;
	}

	public String getFcDiaDescanso() {
		return fcDiaDescanso;
	}

	public void setFcDiaDescanso(String fcDiaDescanso) {
		this.fcDiaDescanso = fcDiaDescanso;
	}

	public String getCeco() {
		return ceco;
	}

	public void setCeco(String ceco) {
		this.ceco = ceco;
	}

	public String getFdFechaAlta() {
		return fdFechaAlta;
	}

	public void setFdFechaAlta(String fdFechaAlta) {
		this.fdFechaAlta = fdFechaAlta;
	}

	public String getEsForaneo() {
		return esForaneo;
	}

	public void setEsForaneo(String esForaneo) {
		this.esForaneo = esForaneo;
	}

	public String getEstatus() {
		return estatus;
	}

	public void setEstatus(String estatus) {
		this.estatus = estatus;
	}

	public String getFechaModificacion() {
		return fechaModificacion;
	}

	public void setFechaModificacion(String fechaModificacion) {
		this.fechaModificacion = fechaModificacion;
	}

	public String getEmpleadoModifica() {
		return empleadoModifica;
	}

	public void setEmpleadoModifica(String empleadoModifica) {
		this.empleadoModifica = empleadoModifica;
	}

	public int getTotalClientes() {
		return totalClientes;
	}

	public void setTotalClientes(int totalClientes) {
		this.totalClientes = totalClientes;
	}
	public void setTotalClientes(BigDecimal totalClientes) {
		this.totalClientes = totalClientes.intValue();
	}
}
