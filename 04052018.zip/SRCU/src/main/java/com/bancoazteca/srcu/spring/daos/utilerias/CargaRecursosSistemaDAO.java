package com.bancoazteca.srcu.spring.daos.utilerias;

import java.util.logging.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class CargaRecursosSistemaDAO {
	
	private final static Logger logger = Logger.getLogger("CargaRecursosSistemaDAO");
	
	@SuppressWarnings("unused")
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	public CargaRecursosSistemaDAO(JdbcTemplate jdbcTemplate) {
		super();
		this.jdbcTemplate	=	jdbcTemplate;
		inizializarSistema();
	}
	
	private void inizializarSistema() {
		logger.info("Inizializando Recursos del Sistema.....");
		FuncionesSistema.getInstance();
	}
}
