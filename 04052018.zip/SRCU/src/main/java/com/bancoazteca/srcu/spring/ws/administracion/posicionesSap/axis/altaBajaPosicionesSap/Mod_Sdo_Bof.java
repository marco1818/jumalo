/**
 * Mod_Sdo_Bof.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.bancoazteca.srcu.spring.ws.administracion.posicionesSap.axis.altaBajaPosicionesSap;

public class Mod_Sdo_Bof  implements java.io.Serializable {
	private static final long serialVersionUID = -1855461447277564153L;

	private java.lang.String sIdNeg;

    private java.lang.String sUsr;

    private java.lang.String sPwd;

    private java.lang.String sPos;

    private java.lang.String sCveConv;

    private java.lang.String sAreaConv;

    private java.lang.String sGrpProf;

    private java.lang.String sSdoSA;

    private java.lang.String sSdoSC;

    private java.lang.String sBegDa;

    private BAPIRETURN1[] it_Err;

    public Mod_Sdo_Bof() {
    }

    public Mod_Sdo_Bof(
           java.lang.String sIdNeg,
           java.lang.String sUsr,
           java.lang.String sPwd,
           java.lang.String sPos,
           java.lang.String sCveConv,
           java.lang.String sAreaConv,
           java.lang.String sGrpProf,
           java.lang.String sSdoSA,
           java.lang.String sSdoSC,
           java.lang.String sBegDa,
           BAPIRETURN1[] it_Err) {
           this.sIdNeg = sIdNeg;
           this.sUsr = sUsr;
           this.sPwd = sPwd;
           this.sPos = sPos;
           this.sCveConv = sCveConv;
           this.sAreaConv = sAreaConv;
           this.sGrpProf = sGrpProf;
           this.sSdoSA = sSdoSA;
           this.sSdoSC = sSdoSC;
           this.sBegDa = sBegDa;
           this.it_Err = it_Err;
    }


    /**
     * Gets the sIdNeg value for this Mod_Sdo_Bof.
     * 
     * @return sIdNeg
     */
    public java.lang.String getSIdNeg() {
        return sIdNeg;
    }


    /**
     * Sets the sIdNeg value for this Mod_Sdo_Bof.
     * 
     * @param sIdNeg
     */
    public void setSIdNeg(java.lang.String sIdNeg) {
        this.sIdNeg = sIdNeg;
    }


    /**
     * Gets the sUsr value for this Mod_Sdo_Bof.
     * 
     * @return sUsr
     */
    public java.lang.String getSUsr() {
        return sUsr;
    }


    /**
     * Sets the sUsr value for this Mod_Sdo_Bof.
     * 
     * @param sUsr
     */
    public void setSUsr(java.lang.String sUsr) {
        this.sUsr = sUsr;
    }


    /**
     * Gets the sPwd value for this Mod_Sdo_Bof.
     * 
     * @return sPwd
     */
    public java.lang.String getSPwd() {
        return sPwd;
    }


    /**
     * Sets the sPwd value for this Mod_Sdo_Bof.
     * 
     * @param sPwd
     */
    public void setSPwd(java.lang.String sPwd) {
        this.sPwd = sPwd;
    }


    /**
     * Gets the sPos value for this Mod_Sdo_Bof.
     * 
     * @return sPos
     */
    public java.lang.String getSPos() {
        return sPos;
    }


    /**
     * Sets the sPos value for this Mod_Sdo_Bof.
     * 
     * @param sPos
     */
    public void setSPos(java.lang.String sPos) {
        this.sPos = sPos;
    }


    /**
     * Gets the sCveConv value for this Mod_Sdo_Bof.
     * 
     * @return sCveConv
     */
    public java.lang.String getSCveConv() {
        return sCveConv;
    }


    /**
     * Sets the sCveConv value for this Mod_Sdo_Bof.
     * 
     * @param sCveConv
     */
    public void setSCveConv(java.lang.String sCveConv) {
        this.sCveConv = sCveConv;
    }


    /**
     * Gets the sAreaConv value for this Mod_Sdo_Bof.
     * 
     * @return sAreaConv
     */
    public java.lang.String getSAreaConv() {
        return sAreaConv;
    }


    /**
     * Sets the sAreaConv value for this Mod_Sdo_Bof.
     * 
     * @param sAreaConv
     */
    public void setSAreaConv(java.lang.String sAreaConv) {
        this.sAreaConv = sAreaConv;
    }


    /**
     * Gets the sGrpProf value for this Mod_Sdo_Bof.
     * 
     * @return sGrpProf
     */
    public java.lang.String getSGrpProf() {
        return sGrpProf;
    }


    /**
     * Sets the sGrpProf value for this Mod_Sdo_Bof.
     * 
     * @param sGrpProf
     */
    public void setSGrpProf(java.lang.String sGrpProf) {
        this.sGrpProf = sGrpProf;
    }


    /**
     * Gets the sSdoSA value for this Mod_Sdo_Bof.
     * 
     * @return sSdoSA
     */
    public java.lang.String getSSdoSA() {
        return sSdoSA;
    }


    /**
     * Sets the sSdoSA value for this Mod_Sdo_Bof.
     * 
     * @param sSdoSA
     */
    public void setSSdoSA(java.lang.String sSdoSA) {
        this.sSdoSA = sSdoSA;
    }


    /**
     * Gets the sSdoSC value for this Mod_Sdo_Bof.
     * 
     * @return sSdoSC
     */
    public java.lang.String getSSdoSC() {
        return sSdoSC;
    }


    /**
     * Sets the sSdoSC value for this Mod_Sdo_Bof.
     * 
     * @param sSdoSC
     */
    public void setSSdoSC(java.lang.String sSdoSC) {
        this.sSdoSC = sSdoSC;
    }


    /**
     * Gets the sBegDa value for this Mod_Sdo_Bof.
     * 
     * @return sBegDa
     */
    public java.lang.String getSBegDa() {
        return sBegDa;
    }


    /**
     * Sets the sBegDa value for this Mod_Sdo_Bof.
     * 
     * @param sBegDa
     */
    public void setSBegDa(java.lang.String sBegDa) {
        this.sBegDa = sBegDa;
    }


    /**
     * Gets the it_Err value for this Mod_Sdo_Bof.
     * 
     * @return it_Err
     */
    public BAPIRETURN1[] getIt_Err() {
        return it_Err;
    }


    /**
     * Sets the it_Err value for this Mod_Sdo_Bof.
     * 
     * @param it_Err
     */
    public void setIt_Err(BAPIRETURN1[] it_Err) {
        this.it_Err = it_Err;
    }

    private java.lang.Object __equalsCalc = null;
    @SuppressWarnings("unused")
	public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Mod_Sdo_Bof)) return false;
        Mod_Sdo_Bof other = (Mod_Sdo_Bof) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.sIdNeg==null && other.getSIdNeg()==null) || 
             (this.sIdNeg!=null &&
              this.sIdNeg.equals(other.getSIdNeg()))) &&
            ((this.sUsr==null && other.getSUsr()==null) || 
             (this.sUsr!=null &&
              this.sUsr.equals(other.getSUsr()))) &&
            ((this.sPwd==null && other.getSPwd()==null) || 
             (this.sPwd!=null &&
              this.sPwd.equals(other.getSPwd()))) &&
            ((this.sPos==null && other.getSPos()==null) || 
             (this.sPos!=null &&
              this.sPos.equals(other.getSPos()))) &&
            ((this.sCveConv==null && other.getSCveConv()==null) || 
             (this.sCveConv!=null &&
              this.sCveConv.equals(other.getSCveConv()))) &&
            ((this.sAreaConv==null && other.getSAreaConv()==null) || 
             (this.sAreaConv!=null &&
              this.sAreaConv.equals(other.getSAreaConv()))) &&
            ((this.sGrpProf==null && other.getSGrpProf()==null) || 
             (this.sGrpProf!=null &&
              this.sGrpProf.equals(other.getSGrpProf()))) &&
            ((this.sSdoSA==null && other.getSSdoSA()==null) || 
             (this.sSdoSA!=null &&
              this.sSdoSA.equals(other.getSSdoSA()))) &&
            ((this.sSdoSC==null && other.getSSdoSC()==null) || 
             (this.sSdoSC!=null &&
              this.sSdoSC.equals(other.getSSdoSC()))) &&
            ((this.sBegDa==null && other.getSBegDa()==null) || 
             (this.sBegDa!=null &&
              this.sBegDa.equals(other.getSBegDa()))) &&
            ((this.it_Err==null && other.getIt_Err()==null) || 
             (this.it_Err!=null &&
              java.util.Arrays.equals(this.it_Err, other.getIt_Err())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getSIdNeg() != null) {
            _hashCode += getSIdNeg().hashCode();
        }
        if (getSUsr() != null) {
            _hashCode += getSUsr().hashCode();
        }
        if (getSPwd() != null) {
            _hashCode += getSPwd().hashCode();
        }
        if (getSPos() != null) {
            _hashCode += getSPos().hashCode();
        }
        if (getSCveConv() != null) {
            _hashCode += getSCveConv().hashCode();
        }
        if (getSAreaConv() != null) {
            _hashCode += getSAreaConv().hashCode();
        }
        if (getSGrpProf() != null) {
            _hashCode += getSGrpProf().hashCode();
        }
        if (getSSdoSA() != null) {
            _hashCode += getSSdoSA().hashCode();
        }
        if (getSSdoSC() != null) {
            _hashCode += getSSdoSC().hashCode();
        }
        if (getSBegDa() != null) {
            _hashCode += getSBegDa().hashCode();
        }
        if (getIt_Err() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getIt_Err());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getIt_Err(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Mod_Sdo_Bof.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://tempuri.org/", ">Mod_Sdo_Bof"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SIdNeg");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "sIdNeg"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SUsr");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "sUsr"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SPwd");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "sPwd"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SPos");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "sPos"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SCveConv");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "sCveConv"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SAreaConv");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "sAreaConv"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SGrpProf");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "sGrpProf"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SSdoSA");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "sSdoSA"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SSdoSC");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "sSdoSC"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SBegDa");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "sBegDa"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("it_Err");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "It_Err"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://tempuri.org/", "BAPIRETURN1"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("http://tempuri.org/", "BAPIRETURN1"));
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    @SuppressWarnings("rawtypes")
	public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    @SuppressWarnings("rawtypes")
	public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
