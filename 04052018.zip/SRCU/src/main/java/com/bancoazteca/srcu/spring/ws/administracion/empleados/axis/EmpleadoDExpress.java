/**
 * EmpleadoDExpress.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.bancoazteca.srcu.spring.ws.administracion.empleados.axis;

public class EmpleadoDExpress  implements java.io.Serializable {
    /**
	 * 
	 */
	private static final long serialVersionUID = 6296578192448575393L;

	private java.lang.String empresa;

    private int numeroEmpleado;

    private java.lang.String nombreInicial;

    private java.lang.String apellidoPaterno;

    private java.lang.String apellidoMaterno;

    private java.lang.String genero;

    private java.lang.String idPais;

    private java.lang.String estadoCivil;

    private java.lang.String calle;

    private java.lang.String numeroExterior;

    private java.lang.String numeroInterior;

    private java.lang.String colonia;

    private java.lang.String codigoPostal;

    private java.lang.String ciudad;

    private java.lang.String estado;

    private java.lang.String telefono;

    private java.lang.String idCompa�ia;

    private int idCentroCostos;

    private java.lang.String desCentroCostos;

    private java.lang.String desPuesto;

    private int fechaAltaTecnica;

    private int fechaAntiguedad;

    private java.lang.String periodoPago;

    private int fechaNacimiento;

    private java.lang.String RFC;

    private java.lang.String cuentaBanco;

    private java.lang.String sueldoVentaEmpleados;

    private int idDependencia;

    private java.lang.String IMSS;

    private int idNumeroEmpleadoJefe;

    private int idPuestoJefe;

    private boolean statusEmpleado;

    private java.lang.String fechaIngreso;

    private java.lang.String mensaje;

    private int status;

    private boolean activo;

    private java.lang.String antiguedad;

    public EmpleadoDExpress() {
    }

    public EmpleadoDExpress(
           java.lang.String empresa,
           int numeroEmpleado,
           java.lang.String nombreInicial,
           java.lang.String apellidoPaterno,
           java.lang.String apellidoMaterno,
           java.lang.String genero,
           java.lang.String idPais,
           java.lang.String estadoCivil,
           java.lang.String calle,
           java.lang.String numeroExterior,
           java.lang.String numeroInterior,
           java.lang.String colonia,
           java.lang.String codigoPostal,
           java.lang.String ciudad,
           java.lang.String estado,
           java.lang.String telefono,
           java.lang.String idCompa�ia,
           int idCentroCostos,
           java.lang.String desCentroCostos,
           java.lang.String desPuesto,
           int fechaAltaTecnica,
           int fechaAntiguedad,
           java.lang.String periodoPago,
           int fechaNacimiento,
           java.lang.String RFC,
           java.lang.String cuentaBanco,
           java.lang.String sueldoVentaEmpleados,
           int idDependencia,
           java.lang.String IMSS,
           int idNumeroEmpleadoJefe,
           int idPuestoJefe,
           boolean statusEmpleado,
           java.lang.String fechaIngreso,
           java.lang.String mensaje,
           int status,
           boolean activo,
           java.lang.String antiguedad) {
           this.empresa = empresa;
           this.numeroEmpleado = numeroEmpleado;
           this.nombreInicial = nombreInicial;
           this.apellidoPaterno = apellidoPaterno;
           this.apellidoMaterno = apellidoMaterno;
           this.genero = genero;
           this.idPais = idPais;
           this.estadoCivil = estadoCivil;
           this.calle = calle;
           this.numeroExterior = numeroExterior;
           this.numeroInterior = numeroInterior;
           this.colonia = colonia;
           this.codigoPostal = codigoPostal;
           this.ciudad = ciudad;
           this.estado = estado;
           this.telefono = telefono;
           this.idCompa�ia = idCompa�ia;
           this.idCentroCostos = idCentroCostos;
           this.desCentroCostos = desCentroCostos;
           this.desPuesto = desPuesto;
           this.fechaAltaTecnica = fechaAltaTecnica;
           this.fechaAntiguedad = fechaAntiguedad;
           this.periodoPago = periodoPago;
           this.fechaNacimiento = fechaNacimiento;
           this.RFC = RFC;
           this.cuentaBanco = cuentaBanco;
           this.sueldoVentaEmpleados = sueldoVentaEmpleados;
           this.idDependencia = idDependencia;
           this.IMSS = IMSS;
           this.idNumeroEmpleadoJefe = idNumeroEmpleadoJefe;
           this.idPuestoJefe = idPuestoJefe;
           this.statusEmpleado = statusEmpleado;
           this.fechaIngreso = fechaIngreso;
           this.mensaje = mensaje;
           this.status = status;
           this.activo = activo;
           this.antiguedad = antiguedad;
    }


    /**
     * Gets the empresa value for this EmpleadoDExpress.
     * 
     * @return empresa
     */
    public java.lang.String getEmpresa() {
        return empresa;
    }


    /**
     * Sets the empresa value for this EmpleadoDExpress.
     * 
     * @param empresa
     */
    public void setEmpresa(java.lang.String empresa) {
        this.empresa = empresa;
    }


    /**
     * Gets the numeroEmpleado value for this EmpleadoDExpress.
     * 
     * @return numeroEmpleado
     */
    public int getNumeroEmpleado() {
        return numeroEmpleado;
    }


    /**
     * Sets the numeroEmpleado value for this EmpleadoDExpress.
     * 
     * @param numeroEmpleado
     */
    public void setNumeroEmpleado(int numeroEmpleado) {
        this.numeroEmpleado = numeroEmpleado;
    }


    /**
     * Gets the nombreInicial value for this EmpleadoDExpress.
     * 
     * @return nombreInicial
     */
    public java.lang.String getNombreInicial() {
        return nombreInicial;
    }


    /**
     * Sets the nombreInicial value for this EmpleadoDExpress.
     * 
     * @param nombreInicial
     */
    public void setNombreInicial(java.lang.String nombreInicial) {
        this.nombreInicial = nombreInicial;
    }


    /**
     * Gets the apellidoPaterno value for this EmpleadoDExpress.
     * 
     * @return apellidoPaterno
     */
    public java.lang.String getApellidoPaterno() {
        return apellidoPaterno;
    }


    /**
     * Sets the apellidoPaterno value for this EmpleadoDExpress.
     * 
     * @param apellidoPaterno
     */
    public void setApellidoPaterno(java.lang.String apellidoPaterno) {
        this.apellidoPaterno = apellidoPaterno;
    }


    /**
     * Gets the apellidoMaterno value for this EmpleadoDExpress.
     * 
     * @return apellidoMaterno
     */
    public java.lang.String getApellidoMaterno() {
        return apellidoMaterno;
    }


    /**
     * Sets the apellidoMaterno value for this EmpleadoDExpress.
     * 
     * @param apellidoMaterno
     */
    public void setApellidoMaterno(java.lang.String apellidoMaterno) {
        this.apellidoMaterno = apellidoMaterno;
    }


    /**
     * Gets the genero value for this EmpleadoDExpress.
     * 
     * @return genero
     */
    public java.lang.String getGenero() {
        return genero;
    }


    /**
     * Sets the genero value for this EmpleadoDExpress.
     * 
     * @param genero
     */
    public void setGenero(java.lang.String genero) {
        this.genero = genero;
    }


    /**
     * Gets the idPais value for this EmpleadoDExpress.
     * 
     * @return idPais
     */
    public java.lang.String getIdPais() {
        return idPais;
    }


    /**
     * Sets the idPais value for this EmpleadoDExpress.
     * 
     * @param idPais
     */
    public void setIdPais(java.lang.String idPais) {
        this.idPais = idPais;
    }


    /**
     * Gets the estadoCivil value for this EmpleadoDExpress.
     * 
     * @return estadoCivil
     */
    public java.lang.String getEstadoCivil() {
        return estadoCivil;
    }


    /**
     * Sets the estadoCivil value for this EmpleadoDExpress.
     * 
     * @param estadoCivil
     */
    public void setEstadoCivil(java.lang.String estadoCivil) {
        this.estadoCivil = estadoCivil;
    }


    /**
     * Gets the calle value for this EmpleadoDExpress.
     * 
     * @return calle
     */
    public java.lang.String getCalle() {
        return calle;
    }


    /**
     * Sets the calle value for this EmpleadoDExpress.
     * 
     * @param calle
     */
    public void setCalle(java.lang.String calle) {
        this.calle = calle;
    }


    /**
     * Gets the numeroExterior value for this EmpleadoDExpress.
     * 
     * @return numeroExterior
     */
    public java.lang.String getNumeroExterior() {
        return numeroExterior;
    }


    /**
     * Sets the numeroExterior value for this EmpleadoDExpress.
     * 
     * @param numeroExterior
     */
    public void setNumeroExterior(java.lang.String numeroExterior) {
        this.numeroExterior = numeroExterior;
    }


    /**
     * Gets the numeroInterior value for this EmpleadoDExpress.
     * 
     * @return numeroInterior
     */
    public java.lang.String getNumeroInterior() {
        return numeroInterior;
    }


    /**
     * Sets the numeroInterior value for this EmpleadoDExpress.
     * 
     * @param numeroInterior
     */
    public void setNumeroInterior(java.lang.String numeroInterior) {
        this.numeroInterior = numeroInterior;
    }


    /**
     * Gets the colonia value for this EmpleadoDExpress.
     * 
     * @return colonia
     */
    public java.lang.String getColonia() {
        return colonia;
    }


    /**
     * Sets the colonia value for this EmpleadoDExpress.
     * 
     * @param colonia
     */
    public void setColonia(java.lang.String colonia) {
        this.colonia = colonia;
    }


    /**
     * Gets the codigoPostal value for this EmpleadoDExpress.
     * 
     * @return codigoPostal
     */
    public java.lang.String getCodigoPostal() {
        return codigoPostal;
    }


    /**
     * Sets the codigoPostal value for this EmpleadoDExpress.
     * 
     * @param codigoPostal
     */
    public void setCodigoPostal(java.lang.String codigoPostal) {
        this.codigoPostal = codigoPostal;
    }


    /**
     * Gets the ciudad value for this EmpleadoDExpress.
     * 
     * @return ciudad
     */
    public java.lang.String getCiudad() {
        return ciudad;
    }


    /**
     * Sets the ciudad value for this EmpleadoDExpress.
     * 
     * @param ciudad
     */
    public void setCiudad(java.lang.String ciudad) {
        this.ciudad = ciudad;
    }


    /**
     * Gets the estado value for this EmpleadoDExpress.
     * 
     * @return estado
     */
    public java.lang.String getEstado() {
        return estado;
    }


    /**
     * Sets the estado value for this EmpleadoDExpress.
     * 
     * @param estado
     */
    public void setEstado(java.lang.String estado) {
        this.estado = estado;
    }


    /**
     * Gets the telefono value for this EmpleadoDExpress.
     * 
     * @return telefono
     */
    public java.lang.String getTelefono() {
        return telefono;
    }


    /**
     * Sets the telefono value for this EmpleadoDExpress.
     * 
     * @param telefono
     */
    public void setTelefono(java.lang.String telefono) {
        this.telefono = telefono;
    }


    /**
     * Gets the idCompa�ia value for this EmpleadoDExpress.
     * 
     * @return idCompa�ia
     */
    public java.lang.String getIdCompa�ia() {
        return idCompa�ia;
    }


    /**
     * Sets the idCompa�ia value for this EmpleadoDExpress.
     * 
     * @param idCompa�ia
     */
    public void setIdCompa�ia(java.lang.String idCompa�ia) {
        this.idCompa�ia = idCompa�ia;
    }


    /**
     * Gets the idCentroCostos value for this EmpleadoDExpress.
     * 
     * @return idCentroCostos
     */
    public int getIdCentroCostos() {
        return idCentroCostos;
    }


    /**
     * Sets the idCentroCostos value for this EmpleadoDExpress.
     * 
     * @param idCentroCostos
     */
    public void setIdCentroCostos(int idCentroCostos) {
        this.idCentroCostos = idCentroCostos;
    }


    /**
     * Gets the desCentroCostos value for this EmpleadoDExpress.
     * 
     * @return desCentroCostos
     */
    public java.lang.String getDesCentroCostos() {
        return desCentroCostos;
    }


    /**
     * Sets the desCentroCostos value for this EmpleadoDExpress.
     * 
     * @param desCentroCostos
     */
    public void setDesCentroCostos(java.lang.String desCentroCostos) {
        this.desCentroCostos = desCentroCostos;
    }


    /**
     * Gets the desPuesto value for this EmpleadoDExpress.
     * 
     * @return desPuesto
     */
    public java.lang.String getDesPuesto() {
        return desPuesto;
    }


    /**
     * Sets the desPuesto value for this EmpleadoDExpress.
     * 
     * @param desPuesto
     */
    public void setDesPuesto(java.lang.String desPuesto) {
        this.desPuesto = desPuesto;
    }


    /**
     * Gets the fechaAltaTecnica value for this EmpleadoDExpress.
     * 
     * @return fechaAltaTecnica
     */
    public int getFechaAltaTecnica() {
        return fechaAltaTecnica;
    }


    /**
     * Sets the fechaAltaTecnica value for this EmpleadoDExpress.
     * 
     * @param fechaAltaTecnica
     */
    public void setFechaAltaTecnica(int fechaAltaTecnica) {
        this.fechaAltaTecnica = fechaAltaTecnica;
    }


    /**
     * Gets the fechaAntiguedad value for this EmpleadoDExpress.
     * 
     * @return fechaAntiguedad
     */
    public int getFechaAntiguedad() {
        return fechaAntiguedad;
    }


    /**
     * Sets the fechaAntiguedad value for this EmpleadoDExpress.
     * 
     * @param fechaAntiguedad
     */
    public void setFechaAntiguedad(int fechaAntiguedad) {
        this.fechaAntiguedad = fechaAntiguedad;
    }


    /**
     * Gets the periodoPago value for this EmpleadoDExpress.
     * 
     * @return periodoPago
     */
    public java.lang.String getPeriodoPago() {
        return periodoPago;
    }


    /**
     * Sets the periodoPago value for this EmpleadoDExpress.
     * 
     * @param periodoPago
     */
    public void setPeriodoPago(java.lang.String periodoPago) {
        this.periodoPago = periodoPago;
    }


    /**
     * Gets the fechaNacimiento value for this EmpleadoDExpress.
     * 
     * @return fechaNacimiento
     */
    public int getFechaNacimiento() {
        return fechaNacimiento;
    }


    /**
     * Sets the fechaNacimiento value for this EmpleadoDExpress.
     * 
     * @param fechaNacimiento
     */
    public void setFechaNacimiento(int fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }


    /**
     * Gets the RFC value for this EmpleadoDExpress.
     * 
     * @return RFC
     */
    public java.lang.String getRFC() {
        return RFC;
    }


    /**
     * Sets the RFC value for this EmpleadoDExpress.
     * 
     * @param RFC
     */
    public void setRFC(java.lang.String RFC) {
        this.RFC = RFC;
    }


    /**
     * Gets the cuentaBanco value for this EmpleadoDExpress.
     * 
     * @return cuentaBanco
     */
    public java.lang.String getCuentaBanco() {
        return cuentaBanco;
    }


    /**
     * Sets the cuentaBanco value for this EmpleadoDExpress.
     * 
     * @param cuentaBanco
     */
    public void setCuentaBanco(java.lang.String cuentaBanco) {
        this.cuentaBanco = cuentaBanco;
    }


    /**
     * Gets the sueldoVentaEmpleados value for this EmpleadoDExpress.
     * 
     * @return sueldoVentaEmpleados
     */
    public java.lang.String getSueldoVentaEmpleados() {
        return sueldoVentaEmpleados;
    }


    /**
     * Sets the sueldoVentaEmpleados value for this EmpleadoDExpress.
     * 
     * @param sueldoVentaEmpleados
     */
    public void setSueldoVentaEmpleados(java.lang.String sueldoVentaEmpleados) {
        this.sueldoVentaEmpleados = sueldoVentaEmpleados;
    }


    /**
     * Gets the idDependencia value for this EmpleadoDExpress.
     * 
     * @return idDependencia
     */
    public int getIdDependencia() {
        return idDependencia;
    }


    /**
     * Sets the idDependencia value for this EmpleadoDExpress.
     * 
     * @param idDependencia
     */
    public void setIdDependencia(int idDependencia) {
        this.idDependencia = idDependencia;
    }


    /**
     * Gets the IMSS value for this EmpleadoDExpress.
     * 
     * @return IMSS
     */
    public java.lang.String getIMSS() {
        return IMSS;
    }


    /**
     * Sets the IMSS value for this EmpleadoDExpress.
     * 
     * @param IMSS
     */
    public void setIMSS(java.lang.String IMSS) {
        this.IMSS = IMSS;
    }


    /**
     * Gets the idNumeroEmpleadoJefe value for this EmpleadoDExpress.
     * 
     * @return idNumeroEmpleadoJefe
     */
    public int getIdNumeroEmpleadoJefe() {
        return idNumeroEmpleadoJefe;
    }


    /**
     * Sets the idNumeroEmpleadoJefe value for this EmpleadoDExpress.
     * 
     * @param idNumeroEmpleadoJefe
     */
    public void setIdNumeroEmpleadoJefe(int idNumeroEmpleadoJefe) {
        this.idNumeroEmpleadoJefe = idNumeroEmpleadoJefe;
    }


    /**
     * Gets the idPuestoJefe value for this EmpleadoDExpress.
     * 
     * @return idPuestoJefe
     */
    public int getIdPuestoJefe() {
        return idPuestoJefe;
    }


    /**
     * Sets the idPuestoJefe value for this EmpleadoDExpress.
     * 
     * @param idPuestoJefe
     */
    public void setIdPuestoJefe(int idPuestoJefe) {
        this.idPuestoJefe = idPuestoJefe;
    }


    /**
     * Gets the statusEmpleado value for this EmpleadoDExpress.
     * 
     * @return statusEmpleado
     */
    public boolean isStatusEmpleado() {
        return statusEmpleado;
    }


    /**
     * Sets the statusEmpleado value for this EmpleadoDExpress.
     * 
     * @param statusEmpleado
     */
    public void setStatusEmpleado(boolean statusEmpleado) {
        this.statusEmpleado = statusEmpleado;
    }


    /**
     * Gets the fechaIngreso value for this EmpleadoDExpress.
     * 
     * @return fechaIngreso
     */
    public java.lang.String getFechaIngreso() {
        return fechaIngreso;
    }


    /**
     * Sets the fechaIngreso value for this EmpleadoDExpress.
     * 
     * @param fechaIngreso
     */
    public void setFechaIngreso(java.lang.String fechaIngreso) {
        this.fechaIngreso = fechaIngreso;
    }


    /**
     * Gets the mensaje value for this EmpleadoDExpress.
     * 
     * @return mensaje
     */
    public java.lang.String getMensaje() {
        return mensaje;
    }


    /**
     * Sets the mensaje value for this EmpleadoDExpress.
     * 
     * @param mensaje
     */
    public void setMensaje(java.lang.String mensaje) {
        this.mensaje = mensaje;
    }


    /**
     * Gets the status value for this EmpleadoDExpress.
     * 
     * @return status
     */
    public int getStatus() {
        return status;
    }


    /**
     * Sets the status value for this EmpleadoDExpress.
     * 
     * @param status
     */
    public void setStatus(int status) {
        this.status = status;
    }


    /**
     * Gets the activo value for this EmpleadoDExpress.
     * 
     * @return activo
     */
    public boolean isActivo() {
        return activo;
    }


    /**
     * Sets the activo value for this EmpleadoDExpress.
     * 
     * @param activo
     */
    public void setActivo(boolean activo) {
        this.activo = activo;
    }


    /**
     * Gets the antiguedad value for this EmpleadoDExpress.
     * 
     * @return antiguedad
     */
    public java.lang.String getAntiguedad() {
        return antiguedad;
    }


    /**
     * Sets the antiguedad value for this EmpleadoDExpress.
     * 
     * @param antiguedad
     */
    public void setAntiguedad(java.lang.String antiguedad) {
        this.antiguedad = antiguedad;
    }

    private java.lang.Object __equalsCalc = null;
    @SuppressWarnings("unused")
	public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof EmpleadoDExpress)) return false;
        EmpleadoDExpress other = (EmpleadoDExpress) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.empresa==null && other.getEmpresa()==null) || 
             (this.empresa!=null &&
              this.empresa.equals(other.getEmpresa()))) &&
            this.numeroEmpleado == other.getNumeroEmpleado() &&
            ((this.nombreInicial==null && other.getNombreInicial()==null) || 
             (this.nombreInicial!=null &&
              this.nombreInicial.equals(other.getNombreInicial()))) &&
            ((this.apellidoPaterno==null && other.getApellidoPaterno()==null) || 
             (this.apellidoPaterno!=null &&
              this.apellidoPaterno.equals(other.getApellidoPaterno()))) &&
            ((this.apellidoMaterno==null && other.getApellidoMaterno()==null) || 
             (this.apellidoMaterno!=null &&
              this.apellidoMaterno.equals(other.getApellidoMaterno()))) &&
            ((this.genero==null && other.getGenero()==null) || 
             (this.genero!=null &&
              this.genero.equals(other.getGenero()))) &&
            ((this.idPais==null && other.getIdPais()==null) || 
             (this.idPais!=null &&
              this.idPais.equals(other.getIdPais()))) &&
            ((this.estadoCivil==null && other.getEstadoCivil()==null) || 
             (this.estadoCivil!=null &&
              this.estadoCivil.equals(other.getEstadoCivil()))) &&
            ((this.calle==null && other.getCalle()==null) || 
             (this.calle!=null &&
              this.calle.equals(other.getCalle()))) &&
            ((this.numeroExterior==null && other.getNumeroExterior()==null) || 
             (this.numeroExterior!=null &&
              this.numeroExterior.equals(other.getNumeroExterior()))) &&
            ((this.numeroInterior==null && other.getNumeroInterior()==null) || 
             (this.numeroInterior!=null &&
              this.numeroInterior.equals(other.getNumeroInterior()))) &&
            ((this.colonia==null && other.getColonia()==null) || 
             (this.colonia!=null &&
              this.colonia.equals(other.getColonia()))) &&
            ((this.codigoPostal==null && other.getCodigoPostal()==null) || 
             (this.codigoPostal!=null &&
              this.codigoPostal.equals(other.getCodigoPostal()))) &&
            ((this.ciudad==null && other.getCiudad()==null) || 
             (this.ciudad!=null &&
              this.ciudad.equals(other.getCiudad()))) &&
            ((this.estado==null && other.getEstado()==null) || 
             (this.estado!=null &&
              this.estado.equals(other.getEstado()))) &&
            ((this.telefono==null && other.getTelefono()==null) || 
             (this.telefono!=null &&
              this.telefono.equals(other.getTelefono()))) &&
            ((this.idCompa�ia==null && other.getIdCompa�ia()==null) || 
             (this.idCompa�ia!=null &&
              this.idCompa�ia.equals(other.getIdCompa�ia()))) &&
            this.idCentroCostos == other.getIdCentroCostos() &&
            ((this.desCentroCostos==null && other.getDesCentroCostos()==null) || 
             (this.desCentroCostos!=null &&
              this.desCentroCostos.equals(other.getDesCentroCostos()))) &&
            ((this.desPuesto==null && other.getDesPuesto()==null) || 
             (this.desPuesto!=null &&
              this.desPuesto.equals(other.getDesPuesto()))) &&
            this.fechaAltaTecnica == other.getFechaAltaTecnica() &&
            this.fechaAntiguedad == other.getFechaAntiguedad() &&
            ((this.periodoPago==null && other.getPeriodoPago()==null) || 
             (this.periodoPago!=null &&
              this.periodoPago.equals(other.getPeriodoPago()))) &&
            this.fechaNacimiento == other.getFechaNacimiento() &&
            ((this.RFC==null && other.getRFC()==null) || 
             (this.RFC!=null &&
              this.RFC.equals(other.getRFC()))) &&
            ((this.cuentaBanco==null && other.getCuentaBanco()==null) || 
             (this.cuentaBanco!=null &&
              this.cuentaBanco.equals(other.getCuentaBanco()))) &&
            ((this.sueldoVentaEmpleados==null && other.getSueldoVentaEmpleados()==null) || 
             (this.sueldoVentaEmpleados!=null &&
              this.sueldoVentaEmpleados.equals(other.getSueldoVentaEmpleados()))) &&
            this.idDependencia == other.getIdDependencia() &&
            ((this.IMSS==null && other.getIMSS()==null) || 
             (this.IMSS!=null &&
              this.IMSS.equals(other.getIMSS()))) &&
            this.idNumeroEmpleadoJefe == other.getIdNumeroEmpleadoJefe() &&
            this.idPuestoJefe == other.getIdPuestoJefe() &&
            this.statusEmpleado == other.isStatusEmpleado() &&
            ((this.fechaIngreso==null && other.getFechaIngreso()==null) || 
             (this.fechaIngreso!=null &&
              this.fechaIngreso.equals(other.getFechaIngreso()))) &&
            ((this.mensaje==null && other.getMensaje()==null) || 
             (this.mensaje!=null &&
              this.mensaje.equals(other.getMensaje()))) &&
            this.status == other.getStatus() &&
            this.activo == other.isActivo() &&
            ((this.antiguedad==null && other.getAntiguedad()==null) || 
             (this.antiguedad!=null &&
              this.antiguedad.equals(other.getAntiguedad())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getEmpresa() != null) {
            _hashCode += getEmpresa().hashCode();
        }
        _hashCode += getNumeroEmpleado();
        if (getNombreInicial() != null) {
            _hashCode += getNombreInicial().hashCode();
        }
        if (getApellidoPaterno() != null) {
            _hashCode += getApellidoPaterno().hashCode();
        }
        if (getApellidoMaterno() != null) {
            _hashCode += getApellidoMaterno().hashCode();
        }
        if (getGenero() != null) {
            _hashCode += getGenero().hashCode();
        }
        if (getIdPais() != null) {
            _hashCode += getIdPais().hashCode();
        }
        if (getEstadoCivil() != null) {
            _hashCode += getEstadoCivil().hashCode();
        }
        if (getCalle() != null) {
            _hashCode += getCalle().hashCode();
        }
        if (getNumeroExterior() != null) {
            _hashCode += getNumeroExterior().hashCode();
        }
        if (getNumeroInterior() != null) {
            _hashCode += getNumeroInterior().hashCode();
        }
        if (getColonia() != null) {
            _hashCode += getColonia().hashCode();
        }
        if (getCodigoPostal() != null) {
            _hashCode += getCodigoPostal().hashCode();
        }
        if (getCiudad() != null) {
            _hashCode += getCiudad().hashCode();
        }
        if (getEstado() != null) {
            _hashCode += getEstado().hashCode();
        }
        if (getTelefono() != null) {
            _hashCode += getTelefono().hashCode();
        }
        if (getIdCompa�ia() != null) {
            _hashCode += getIdCompa�ia().hashCode();
        }
        _hashCode += getIdCentroCostos();
        if (getDesCentroCostos() != null) {
            _hashCode += getDesCentroCostos().hashCode();
        }
        if (getDesPuesto() != null) {
            _hashCode += getDesPuesto().hashCode();
        }
        _hashCode += getFechaAltaTecnica();
        _hashCode += getFechaAntiguedad();
        if (getPeriodoPago() != null) {
            _hashCode += getPeriodoPago().hashCode();
        }
        _hashCode += getFechaNacimiento();
        if (getRFC() != null) {
            _hashCode += getRFC().hashCode();
        }
        if (getCuentaBanco() != null) {
            _hashCode += getCuentaBanco().hashCode();
        }
        if (getSueldoVentaEmpleados() != null) {
            _hashCode += getSueldoVentaEmpleados().hashCode();
        }
        _hashCode += getIdDependencia();
        if (getIMSS() != null) {
            _hashCode += getIMSS().hashCode();
        }
        _hashCode += getIdNumeroEmpleadoJefe();
        _hashCode += getIdPuestoJefe();
        _hashCode += (isStatusEmpleado() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        if (getFechaIngreso() != null) {
            _hashCode += getFechaIngreso().hashCode();
        }
        if (getMensaje() != null) {
            _hashCode += getMensaje().hashCode();
        }
        _hashCode += getStatus();
        _hashCode += (isActivo() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        if (getAntiguedad() != null) {
            _hashCode += getAntiguedad().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(EmpleadoDExpress.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "EmpleadoDExpress"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("empresa");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Empresa"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroEmpleado");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "NumeroEmpleado"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nombreInicial");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "NombreInicial"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("apellidoPaterno");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ApellidoPaterno"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("apellidoMaterno");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ApellidoMaterno"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("genero");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Genero"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("idPais");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "idPais"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("estadoCivil");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "EstadoCivil"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("calle");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Calle"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroExterior");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "NumeroExterior"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroInterior");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "NumeroInterior"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("colonia");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Colonia"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoPostal");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "CodigoPostal"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ciudad");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Ciudad"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("estado");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Estado"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("telefono");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Telefono"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("idCompa�ia");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "idCompa�ia"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("idCentroCostos");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "idCentroCostos"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("desCentroCostos");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "DesCentroCostos"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("desPuesto");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "DesPuesto"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("fechaAltaTecnica");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "FechaAltaTecnica"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("fechaAntiguedad");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "FechaAntiguedad"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("periodoPago");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "PeriodoPago"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("fechaNacimiento");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "FechaNacimiento"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("RFC");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "RFC"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("cuentaBanco");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "CuentaBanco"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("sueldoVentaEmpleados");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "SueldoVentaEmpleados"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("idDependencia");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "idDependencia"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("IMSS");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "IMSS"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("idNumeroEmpleadoJefe");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "idNumeroEmpleadoJefe"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("idPuestoJefe");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "idPuestoJefe"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("statusEmpleado");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "StatusEmpleado"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("fechaIngreso");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "FechaIngreso"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("mensaje");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("status");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Status"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("activo");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Activo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("antiguedad");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Antiguedad"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    @SuppressWarnings("rawtypes")
	public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    @SuppressWarnings("rawtypes")
	public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
