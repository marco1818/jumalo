package com.bancoazteca.srcu.spring.configuracion;

//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
//import org.springframework.security.config.annotation.web.builders.HttpSecurity;
//import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
//import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
//
//import com.bancoazteca.srcu.spring.servicios.seguridad.AutenticacionServicio;

//@Configuration 
//@EnableWebSecurity 
public class SecurityConfig /*extends WebSecurityConfigurerAdapter*/{ 
        

      /*  @Autowired
        AutenticacionServicio autenticacionServicio;
        
        @Autowired 
        public void configureGlobal(AuthenticationManagerBuilder authenticationManagerBuilder) throws Exception{ 
        	authenticationManagerBuilder.authenticationProvider(autenticacionServicio);

        } 

        @Override 
        protected void configure(HttpSecurity httpSecurity) throws Exception { 
        	httpSecurity.csrf().disable();
        	
        	httpSecurity.authorizeRequests().antMatchers("/dwr/*").permitAll();
        	httpSecurity.authorizeRequests().antMatchers("/dwr/test/*").permitAll();
        	httpSecurity.authorizeRequests().antMatchers("/dwr/interface/*").permitAll();
        	httpSecurity.authorizeRequests().antMatchers("/dwr/call/plaincall/*").permitAll();
        	httpSecurity.authorizeRequests().antMatchers("/dwr/call/plaincall/__System.generateId.dwr").permitAll();
        	httpSecurity.authorizeRequests().antMatchers("/js/*").permitAll();
        	httpSecurity.authorizeRequests().antMatchers("/js/login/*").permitAll();
        	httpSecurity.authorizeRequests().antMatchers("/css/**").permitAll();
        	httpSecurity.authorizeRequests().antMatchers("/imagenes/**").permitAll();
        	httpSecurity.authorizeRequests().antMatchers("/login.htm").permitAll();
            httpSecurity.authorizeRequests().antMatchers("/*").permitAll();
        	httpSecurity.authorizeRequests().and().formLogin() 
            .loginProcessingUrl("/j_spring_security_check") 
            .loginPage("/login.htm")
            .failureUrl("/login.htm")
            .defaultSuccessUrl("/home.htm") 
            .usernameParameter("clave") 
            .passwordParameter("contrasenia") ;
            
            httpSecurity.logout().logoutUrl("/j_spring_security_logout").logoutSuccessUrl("/login.htm").invalidateHttpSession(true).deleteCookies("JSESSIONID");
            
        	

        }

		public AutenticacionServicio getAutenticacionServicio() {
			return autenticacionServicio;
		}

		public void setAutenticacionServicio(AutenticacionServicio autenticacionServicio) {
			this.autenticacionServicio = autenticacionServicio;
		} 
*/
        
} 
