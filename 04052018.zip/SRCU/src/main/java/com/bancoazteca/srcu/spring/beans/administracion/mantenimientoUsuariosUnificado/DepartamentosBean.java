package com.bancoazteca.srcu.spring.beans.administracion.mantenimientoUsuariosUnificado;

import java.math.BigDecimal;

public class DepartamentosBean {
	private	int	departamentoId;
	private	String deptoDesc;
	private String jefe;
	private	String descripcion;
	
	public DepartamentosBean() {
		
	}

	public int getDepartamentoId() {
		return departamentoId;
	}

	public void setDepartamentoId(int departamentoId) {
		this.departamentoId = departamentoId;
	}

	public void setDepartamentoId(BigDecimal departamentoId) {
		this.departamentoId = departamentoId.intValue();
	}
	
	public String getDeptoDesc() {
		return deptoDesc;
	}

	public void setDeptoDesc(String deptoDesc) {
		this.deptoDesc = deptoDesc;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public String getJefe() {
		return jefe;
	}

	public void setJefe(String jefe) {
		this.jefe = jefe;
	}
	
}
