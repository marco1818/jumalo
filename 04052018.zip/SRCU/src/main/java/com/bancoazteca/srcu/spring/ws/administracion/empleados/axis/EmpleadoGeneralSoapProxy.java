package com.bancoazteca.srcu.spring.ws.administracion.empleados.axis;

public class EmpleadoGeneralSoapProxy implements EmpleadoGeneralSoap {
  private String _endpoint = null;
  private EmpleadoGeneralSoap empleadoGeneralSoap = null;
  private int _timeout;
  
  public EmpleadoGeneralSoapProxy() {
    _initEmpleadoGeneralSoapProxy();
  }
  
  public EmpleadoGeneralSoapProxy(String endpoint) {
    _endpoint = endpoint;
    _initEmpleadoGeneralSoapProxy();
  }

  public EmpleadoGeneralSoapProxy(String endpoint, int timeout) {
	    _endpoint = endpoint;
	    _timeout = timeout;
	    _initEmpleadoGeneralSoapProxy();
	  }
  
  private void _initEmpleadoGeneralSoapProxy() {
    try {
      empleadoGeneralSoap = (new EmpleadoGeneralLocator()).getEmpleadoGeneralSoap();
      if (empleadoGeneralSoap != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)empleadoGeneralSoap)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)empleadoGeneralSoap)._getProperty("javax.xml.rpc.service.endpoint.address");
        
        if(_timeout > 0) {
        	((javax.xml.rpc.Stub)empleadoGeneralSoap)._setProperty("axis.connection.timeout",_timeout);
        }
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (empleadoGeneralSoap != null)
      ((javax.xml.rpc.Stub)empleadoGeneralSoap)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public EmpleadoGeneralSoap getEmpleadoGeneralSoap() {
    if (empleadoGeneralSoap == null)
      _initEmpleadoGeneralSoapProxy();
    return empleadoGeneralSoap;
  }
  
  public Empleado getEmpleadoGeneral(java.lang.String usuario, java.lang.String contrase�a, int empleado, java.lang.String empresa, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException{
    if (empleadoGeneralSoap == null)
      _initEmpleadoGeneralSoapProxy();
    return empleadoGeneralSoap.getEmpleadoGeneral(usuario, contrase�a, empleado, empresa, existeError, mensaje);
  }
  
  public EmpleadoDExpress getEmpleadoGeneralDineroExpress(java.lang.String usuario, java.lang.String contrase�a, int empleado, java.lang.String empresa, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException{
    if (empleadoGeneralSoap == null)
      _initEmpleadoGeneralSoapProxy();
    return empleadoGeneralSoap.getEmpleadoGeneralDineroExpress(usuario, contrase�a, empleado, empresa, existeError, mensaje);
  }
  
  public TarjetasAmarillas getTarjetaAmarillaEmpleado(java.lang.String usuario, java.lang.String contrase�a, int empleado, java.lang.String empresa, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException{
    if (empleadoGeneralSoap == null)
      _initEmpleadoGeneralSoapProxy();
    return empleadoGeneralSoap.getTarjetaAmarillaEmpleado(usuario, contrase�a, empleado, empresa, existeError, mensaje);
  }
  
  public TarjetasAmarillasCtaBanco getTarjetaAmarillaCtaBanco(java.lang.String usuario, java.lang.String contrase�a, java.lang.String cuentaBanco, java.lang.String empresa, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException{
    if (empleadoGeneralSoap == null)
      _initEmpleadoGeneralSoapProxy();
    return empleadoGeneralSoap.getTarjetaAmarillaCtaBanco(usuario, contrase�a, cuentaBanco, empresa, existeError, mensaje);
  }
  
  public TarjetasAmarillasSIE[] getTarjetaAmarillaEmpleadoSIE(java.lang.String usuario, java.lang.String contrase�a, int empleado, int fecha, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException{
    if (empleadoGeneralSoap == null)
      _initEmpleadoGeneralSoapProxy();
    return empleadoGeneralSoap.getTarjetaAmarillaEmpleadoSIE(usuario, contrase�a, empleado, fecha, existeError, mensaje);
  }
  
  public java.lang.String getTarjetaAmarillaEmpleadoSIE_Tabla(java.lang.String usuario, java.lang.String contrase�a, java.lang.String empleado, java.lang.String fecha, javax.xml.rpc.holders.StringHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException{
    if (empleadoGeneralSoap == null)
      _initEmpleadoGeneralSoapProxy();
    return empleadoGeneralSoap.getTarjetaAmarillaEmpleadoSIE_Tabla(usuario, contrase�a, empleado, fecha, existeError, mensaje);
  }
  
  public Empleado[] getEmpleadoPorCentroCostos(java.lang.String usuario, java.lang.String contrase�a, int centroCostos, java.lang.String empresa, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException{
    if (empleadoGeneralSoap == null)
      _initEmpleadoGeneralSoapProxy();
    return empleadoGeneralSoap.getEmpleadoPorCentroCostos(usuario, contrase�a, centroCostos, empresa, existeError, mensaje);
  }
  
  public Empleado[] getEmpleadoPorSituacion(java.lang.String usuario, java.lang.String contrase�a, java.lang.String situacion, int fecha, java.lang.String pais, java.lang.String empresa, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException{
    if (empleadoGeneralSoap == null)
      _initEmpleadoGeneralSoapProxy();
    return empleadoGeneralSoap.getEmpleadoPorSituacion(usuario, contrase�a, situacion, fecha, pais, empresa, existeError, mensaje);
  }
  
  public Estructura_DatosCorreo getDatosCorreo(java.lang.String usuario, java.lang.String contrase�a, int empleado, java.lang.String empresa, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException{
    if (empleadoGeneralSoap == null)
      _initEmpleadoGeneralSoapProxy();
    return empleadoGeneralSoap.getDatosCorreo(usuario, contrase�a, empleado, empresa, existeError, mensaje);
  }
  
  public Funcion getFuncionEmpleado(java.lang.String usuario, java.lang.String contrase�a, int empleado, java.lang.String empresa, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException{
    if (empleadoGeneralSoap == null)
      _initEmpleadoGeneralSoapProxy();
    return empleadoGeneralSoap.getFuncionEmpleado(usuario, contrase�a, empleado, empresa, existeError, mensaje);
  }
  
  public Vacante[] getVacantes(java.lang.String usuario, java.lang.String contrase�a, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException{
    if (empleadoGeneralSoap == null)
      _initEmpleadoGeneralSoapProxy();
    return empleadoGeneralSoap.getVacantes(usuario, contrase�a, existeError, mensaje);
  }
  
  public Empleado[] getEmpleadoPorFuncion(java.lang.String usuario, java.lang.String contrase�a, int funcion, java.lang.String pais, java.lang.String empresa, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException{
    if (empleadoGeneralSoap == null)
      _initEmpleadoGeneralSoapProxy();
    return empleadoGeneralSoap.getEmpleadoPorFuncion(usuario, contrase�a, funcion, pais, empresa, existeError, mensaje);
  }
  
  public Empleado[] getEmpleadoPorMovimiento(java.lang.String usuario, java.lang.String contrase�a, int fecha, java.lang.String empresa, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException{
    if (empleadoGeneralSoap == null)
      _initEmpleadoGeneralSoapProxy();
    return empleadoGeneralSoap.getEmpleadoPorMovimiento(usuario, contrase�a, fecha, empresa, existeError, mensaje);
  }
  
  public Incapacidad[] getEmpleadoIncapacidad(java.lang.String usuario, java.lang.String contrase�a, java.lang.String empresa, int fechaActualiza, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException{
    if (empleadoGeneralSoap == null)
      _initEmpleadoGeneralSoapProxy();
    return empleadoGeneralSoap.getEmpleadoIncapacidad(usuario, contrase�a, empresa, fechaActualiza, existeError, mensaje);
  }
  
  public java.lang.String getCorreo(java.lang.String usuario, java.lang.String contrase�a, java.lang.String valor, java.lang.String empresa, java.lang.String pais, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException{
    if (empleadoGeneralSoap == null)
      _initEmpleadoGeneralSoapProxy();
    return empleadoGeneralSoap.getCorreo(usuario, contrase�a, valor, empresa, pais, existeError, mensaje);
  }
  
  public java.lang.String getRFC(java.lang.String nombre, java.lang.String apellidoPaterno, java.lang.String apellidoMaterno, int fechaNacimiento) throws java.rmi.RemoteException{
    if (empleadoGeneralSoap == null)
      _initEmpleadoGeneralSoapProxy();
    return empleadoGeneralSoap.getRFC(nombre, apellidoPaterno, apellidoMaterno, fechaNacimiento);
  }
  
  public void getEsDirector(java.lang.String usuario, java.lang.String contrase�a, int empleado, java.lang.String empresa, javax.xml.rpc.holders.BooleanHolder esDirector, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException{
    if (empleadoGeneralSoap == null)
      _initEmpleadoGeneralSoapProxy();
    empleadoGeneralSoap.getEsDirector(usuario, contrase�a, empleado, empresa, esDirector, existeError, mensaje);
  }
  
  public java.lang.String getCuentaClabe(java.lang.String usuario, java.lang.String contrase�a, int empleado, java.lang.String empresa, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException{
    if (empleadoGeneralSoap == null)
      _initEmpleadoGeneralSoapProxy();
    return empleadoGeneralSoap.getCuentaClabe(usuario, contrase�a, empleado, empresa, existeError, mensaje);
  }
  
  public GetHuellaClienteUnicoResponseGetHuellaClienteUnicoResult getHuellaClienteUnico(java.lang.String usuario, java.lang.String contrase�a, int empleado, java.lang.String empresa, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException{
    if (empleadoGeneralSoap == null)
      _initEmpleadoGeneralSoapProxy();
    return empleadoGeneralSoap.getHuellaClienteUnico(usuario, contrase�a, empleado, empresa, existeError, mensaje);
  }
  
  public GetHuellaClienteUnicoLAMResponseGetHuellaClienteUnicoLAMResult getHuellaClienteUnicoLAM(java.lang.String usuario, java.lang.String contrase�a, int empleado, java.lang.String empresa, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException{
    if (empleadoGeneralSoap == null)
      _initEmpleadoGeneralSoapProxy();
    return empleadoGeneralSoap.getHuellaClienteUnicoLAM(usuario, contrase�a, empleado, empresa, existeError, mensaje);
  }
  
  public GetHuellaClienteUnicoQAResponseGetHuellaClienteUnicoQAResult getHuellaClienteUnicoQA(java.lang.String usuario, java.lang.String contrase�a, int empleado, java.lang.String empresa, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException{
    if (empleadoGeneralSoap == null)
      _initEmpleadoGeneralSoapProxy();
    return empleadoGeneralSoap.getHuellaClienteUnicoQA(usuario, contrase�a, empleado, empresa, existeError, mensaje);
  }
  
  public java.lang.String getFechaPago(java.lang.String usuario, java.lang.String contrase�a, int empleado, java.lang.String empresa, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException{
    if (empleadoGeneralSoap == null)
      _initEmpleadoGeneralSoapProxy();
    return empleadoGeneralSoap.getFechaPago(usuario, contrase�a, empleado, empresa, existeError, mensaje);
  }
  
  public Coincidencia[] getCoincidencias(java.lang.String usuario, java.lang.String contrase�a, java.lang.String filtro, java.lang.String situacion, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException{
    if (empleadoGeneralSoap == null)
      _initEmpleadoGeneralSoapProxy();
    return empleadoGeneralSoap.getCoincidencias(usuario, contrase�a, filtro, situacion, existeError, mensaje);
  }
  
  public Superiores[] getLineaSuperior(java.lang.String usuario, java.lang.String contrase�a, int empleado, java.lang.String empresa, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException{
    if (empleadoGeneralSoap == null)
      _initEmpleadoGeneralSoapProxy();
    return empleadoGeneralSoap.getLineaSuperior(usuario, contrase�a, empleado, empresa, existeError, mensaje);
  }
  
  public Subordinado[] getLineaInferior(java.lang.String usuario, java.lang.String contrase�a, int empleado, java.lang.String empresa, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException{
    if (empleadoGeneralSoap == null)
      _initEmpleadoGeneralSoapProxy();
    return empleadoGeneralSoap.getLineaInferior(usuario, contrase�a, empleado, empresa, existeError, mensaje);
  }
  
  public Subordinado[] getLineaInferiorSAP(java.lang.String usuario, java.lang.String contrase�a, int puesto, java.lang.String empresa, int nivel, java.lang.String pais, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException{
    if (empleadoGeneralSoap == null)
      _initEmpleadoGeneralSoapProxy();
    return empleadoGeneralSoap.getLineaInferiorSAP(usuario, contrase�a, puesto, empresa, nivel, pais, existeError, mensaje);
  }
  
  public Subordinado[] getLineaInferiorPorEmpleadoRep(java.lang.String usuario, java.lang.String contrase�a, int empleado, java.lang.String empresa, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException{
    if (empleadoGeneralSoap == null)
      _initEmpleadoGeneralSoapProxy();
    return empleadoGeneralSoap.getLineaInferiorPorEmpleadoRep(usuario, contrase�a, empleado, empresa, existeError, mensaje);
  }
  
  public int existeEmpleado(java.lang.String usuario, java.lang.String contrase�a, int empleado, java.lang.String empresa, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException{
    if (empleadoGeneralSoap == null)
      _initEmpleadoGeneralSoapProxy();
    return empleadoGeneralSoap.existeEmpleado(usuario, contrase�a, empleado, empresa, existeError, mensaje);
  }
  
  public long getCentroCostosTVA(java.lang.String usuario, java.lang.String contrase�a, int empleado, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException{
    if (empleadoGeneralSoap == null)
      _initEmpleadoGeneralSoapProxy();
    return empleadoGeneralSoap.getCentroCostosTVA(usuario, contrase�a, empleado, existeError, mensaje);
  }
  
  public void getRankingMapaTalento(java.lang.String usuario, java.lang.String contrase�a, int empleado, java.lang.String empresa, javax.xml.rpc.holders.BooleanHolder perteneceRanking, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException{
    if (empleadoGeneralSoap == null)
      _initEmpleadoGeneralSoapProxy();
    empleadoGeneralSoap.getRankingMapaTalento(usuario, contrase�a, empleado, empresa, perteneceRanking, existeError, mensaje);
  }
  
  public void getCuentaBancoEmpleado(java.lang.String usuario, java.lang.String contrase�a, int empleado, java.lang.String empresa, javax.xml.rpc.holders.StringHolder cuentaBanco, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException{
    if (empleadoGeneralSoap == null)
      _initEmpleadoGeneralSoapProxy();
    empleadoGeneralSoap.getCuentaBancoEmpleado(usuario, contrase�a, empleado, empresa, cuentaBanco, existeError, mensaje);
  }
  
  public void getCuentaBanco(java.lang.String usuario, java.lang.String contrasenia, int empleado, java.lang.String empresa, javax.xml.rpc.holders.StringHolder cuentaBanco, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException{
    if (empleadoGeneralSoap == null)
      _initEmpleadoGeneralSoapProxy();
    empleadoGeneralSoap.getCuentaBanco(usuario, contrasenia, empleado, empresa, cuentaBanco, existeError, mensaje);
  }
  
  public EmpleadoBaja[] getDatosEmpleadosBaja(java.lang.String usuario, java.lang.String contrase�a, int[] empleado, java.lang.String empresa, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException{
    if (empleadoGeneralSoap == null)
      _initEmpleadoGeneralSoapProxy();
    return empleadoGeneralSoap.getDatosEmpleadosBaja(usuario, contrase�a, empleado, empresa, existeError, mensaje);
  }
  
  public void setSolicitudBajaPlantillaDinamica(java.lang.String usuario, java.lang.String contrase�a, int empleadoBaja, java.lang.String empresa, javax.xml.rpc.holders.IntHolder folioFBP, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException{
    if (empleadoGeneralSoap == null)
      _initEmpleadoGeneralSoapProxy();
    empleadoGeneralSoap.setSolicitudBajaPlantillaDinamica(usuario, contrase�a, empleadoBaja, empresa, folioFBP, existeError, mensaje);
  }
  
  public void setSolicitudBajaTarjetasAmarillas(java.lang.String usuario, java.lang.String contrase�a, int empleadoBaja, java.lang.String empresa, javax.xml.rpc.holders.IntHolder folioFBP, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException{
    if (empleadoGeneralSoap == null)
      _initEmpleadoGeneralSoapProxy();
    empleadoGeneralSoap.setSolicitudBajaTarjetasAmarillas(usuario, contrase�a, empleadoBaja, empresa, folioFBP, existeError, mensaje);
  }
  
  public void getSeguimientoBajaPlantillaDinamica(java.lang.String usuario, java.lang.String contrase�a, int folioFBP, java.lang.String empresa, javax.xml.rpc.holders.IntHolder empleadoGestionBaja, javax.xml.rpc.holders.IntHolder estatus, javax.xml.rpc.holders.StringHolder fechaActualizacion, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException{
    if (empleadoGeneralSoap == null)
      _initEmpleadoGeneralSoapProxy();
    empleadoGeneralSoap.getSeguimientoBajaPlantillaDinamica(usuario, contrase�a, folioFBP, empresa, empleadoGestionBaja, estatus, fechaActualizacion, existeError, mensaje);
  }
  
  public void setDigitalizacionDocumentosEmpleado(java.lang.String usuario, java.lang.String contrase�a, int empleado, int pais, java.lang.String documento, int tipo, int etapa, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException{
    if (empleadoGeneralSoap == null)
      _initEmpleadoGeneralSoapProxy();
    empleadoGeneralSoap.setDigitalizacionDocumentosEmpleado(usuario, contrase�a, empleado, pais, documento, tipo, etapa, existeError, mensaje);
  }
  
  public void getQ12Empleado(java.lang.String usuario, java.lang.String contrase�a, int empleado, java.lang.String empresa, int periodo, ArrayOfEmpleadoQ12Holder listaEmpleado, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException{
    if (empleadoGeneralSoap == null)
      _initEmpleadoGeneralSoapProxy();
    empleadoGeneralSoap.getQ12Empleado(usuario, contrase�a, empleado, empresa, periodo, listaEmpleado, existeError, mensaje);
  }
  
  public void getRanking_Empleado(java.lang.String usuario, java.lang.String contrase�a, java.lang.String empresa, java.lang.String pais, java.lang.String fecha, java.lang.String funcion, java.lang.String nivel, java.lang.String CC, java.lang.String periodo, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException{
    if (empleadoGeneralSoap == null)
      _initEmpleadoGeneralSoapProxy();
    empleadoGeneralSoap.getRanking_Empleado(usuario, contrase�a, empresa, pais, fecha, funcion, nivel, CC, periodo, existeError, mensaje);
  }
  
  public VacacionesGeo[] getConsultaCargaVacacionesGeo(java.lang.String usuario, java.lang.String contrase�a, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException{
    if (empleadoGeneralSoap == null)
      _initEmpleadoGeneralSoapProxy();
    return empleadoGeneralSoap.getConsultaCargaVacacionesGeo(usuario, contrase�a, existeError, mensaje);
  }
  
  public TarjetaAmarilla_Periodo[] getTarjetaAmarilla_Periodo(java.lang.String usuario, java.lang.String contrase�a, int fecha, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException{
    if (empleadoGeneralSoap == null)
      _initEmpleadoGeneralSoapProxy();
    return empleadoGeneralSoap.getTarjetaAmarilla_Periodo(usuario, contrase�a, fecha, existeError, mensaje);
  }
  
  public DetalleBaja[] getDetalleBaja(java.lang.String usuario, java.lang.String contrase�a, int empleado, java.lang.String empresa, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException{
    if (empleadoGeneralSoap == null)
      _initEmpleadoGeneralSoapProxy();
    return empleadoGeneralSoap.getDetalleBaja(usuario, contrase�a, empleado, empresa, existeError, mensaje);
  }
  
  public Plaza[] getDescPlaza(java.lang.String usuario, java.lang.String contrase�a, int centroCostos, java.lang.String pais, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException{
    if (empleadoGeneralSoap == null)
      _initEmpleadoGeneralSoapProxy();
    return empleadoGeneralSoap.getDescPlaza(usuario, contrase�a, centroCostos, pais, existeError, mensaje);
  }
  
  public Beneficiarios getBeneficiariosEmpleado(java.lang.String usuario, java.lang.String contrase�a, int empleado, java.lang.String empresa, int tipoBeneficiario, java.lang.String pais, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException{
    if (empleadoGeneralSoap == null)
      _initEmpleadoGeneralSoapProxy();
    return empleadoGeneralSoap.getBeneficiariosEmpleado(usuario, contrase�a, empleado, empresa, tipoBeneficiario, pais, existeError, mensaje);
  }
  
  public DatosCoincidencias[] getEmpleadoCoincideNombreRFC(java.lang.String usuario, java.lang.String contrase�a, java.lang.String nombre, java.lang.String apPaterno, java.lang.String apMaterno, java.lang.String pais, java.lang.String empresa, java.lang.String regCed, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException{
    if (empleadoGeneralSoap == null)
      _initEmpleadoGeneralSoapProxy();
    return empleadoGeneralSoap.getEmpleadoCoincideNombreRFC(usuario, contrase�a, nombre, apPaterno, apMaterno, pais, empresa, regCed, existeError, mensaje);
  }
  
  public Auscencia[] getEmpleadoIncapacidadSAP(java.lang.String usuario, java.lang.String contrase�a, int empleado, java.lang.String empresa, int fecha, java.lang.String pais, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException{
    if (empleadoGeneralSoap == null)
      _initEmpleadoGeneralSoapProxy();
    return empleadoGeneralSoap.getEmpleadoIncapacidadSAP(usuario, contrase�a, empleado, empresa, fecha, pais, existeError, mensaje);
  }
  
  public Auscencia[] getEmpleadoAuscentismo(java.lang.String usuario, java.lang.String contrase�a, int empleado, java.lang.String empresa, int fecha, java.lang.String pais, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException{
    if (empleadoGeneralSoap == null)
      _initEmpleadoGeneralSoapProxy();
    return empleadoGeneralSoap.getEmpleadoAuscentismo(usuario, contrase�a, empleado, empresa, fecha, pais, existeError, mensaje);
  }
  
  public EmpleadoGral[] getDatosEmpleadosMasivo(java.lang.String usuario, java.lang.String contrase�a, EmpleadoEmp[] empleado, java.lang.String empresa, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException{
    if (empleadoGeneralSoap == null)
      _initEmpleadoGeneralSoapProxy();
    return empleadoGeneralSoap.getDatosEmpleadosMasivo(usuario, contrase�a, empleado, empresa, existeError, mensaje);
  }
  
  public void getValidaCuentaNegocio(java.lang.String usuario, java.lang.String contrase�a, java.lang.String cuentaBanco, java.lang.String empresa, javax.xml.rpc.holders.IntHolder valNegocio, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException{
    if (empleadoGeneralSoap == null)
      _initEmpleadoGeneralSoapProxy();
    empleadoGeneralSoap.getValidaCuentaNegocio(usuario, contrase�a, cuentaBanco, empresa, valNegocio, existeError, mensaje);
  }
  
  public void getValidaCuentaEmpleado(java.lang.String usuario, java.lang.String contrase�a, java.lang.String cuentaBanco, java.lang.String empresa, javax.xml.rpc.holders.IntHolder empleado, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException{
    if (empleadoGeneralSoap == null)
      _initEmpleadoGeneralSoapProxy();
    empleadoGeneralSoap.getValidaCuentaEmpleado(usuario, contrase�a, cuentaBanco, empresa, empleado, existeError, mensaje);
  }
  
  public EmpleadoPromocion[] getEmpleadoPromocion(java.lang.String usuario, java.lang.String contrase�a, int numeroEmpleado, java.lang.String empresa, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException{
    if (empleadoGeneralSoap == null)
      _initEmpleadoGeneralSoapProxy();
    return empleadoGeneralSoap.getEmpleadoPromocion(usuario, contrase�a, numeroEmpleado, empresa, existeError, mensaje);
  }
  
  public java.lang.String getClienteUnicoEmpleado(java.lang.String usuario, java.lang.String contrase�a, int empleado, java.lang.String empresa, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException{
    if (empleadoGeneralSoap == null)
      _initEmpleadoGeneralSoapProxy();
    return empleadoGeneralSoap.getClienteUnicoEmpleado(usuario, contrase�a, empleado, empresa, existeError, mensaje);
  }
  
  public CuotasPatronales getCuotaPatronal(java.lang.String usuario, java.lang.String contrasena, java.lang.String empresa, java.lang.String compania, int anio, int periodo, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException{
    if (empleadoGeneralSoap == null)
      _initEmpleadoGeneralSoapProxy();
    return empleadoGeneralSoap.getCuotaPatronal(usuario, contrasena, empresa, compania, anio, periodo, existeError, mensaje);
  }
  
  
}