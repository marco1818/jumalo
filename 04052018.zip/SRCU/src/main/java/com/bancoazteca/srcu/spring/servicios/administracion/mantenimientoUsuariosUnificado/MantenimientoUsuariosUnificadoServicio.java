package com.bancoazteca.srcu.spring.servicios.administracion.mantenimientoUsuariosUnificado;

import com.bancoazteca.srcu.spring.beans.administracion.mantenimientoUsuariosUnificado.MantenimientoUsuariosUnificadoBean;
import com.bancoazteca.srcu.spring.beans.sistema.MensajeTransaccionBean;

public interface MantenimientoUsuariosUnificadoServicio{
	public	MantenimientoUsuariosUnificadoBean consulta(MantenimientoUsuariosUnificadoBean mantenimientoUsuariosUnificado, int tipoConsulta);
	public	MensajeTransaccionBean grabaTransaccion(MantenimientoUsuariosUnificadoBean mantenimientoUsuariosUnificadoBean, int tipoOperacion);
}
