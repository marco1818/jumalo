package com.bancoazteca.srcu.spring.servicios.administracion.mantenimientoUsuariosSap;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bancoazteca.srcu.spring.beans.administracion.mantenimientoTelefonos.DatosEmpleadoBean;
import com.bancoazteca.srcu.spring.beans.administracion.mantenimientoUsuariosSap.MantenimientoUsuariosSapBean;
import com.bancoazteca.srcu.spring.beans.administracion.mantenimientoUsuariosSap.VacantesBean;
import com.bancoazteca.srcu.spring.beans.administracion.personalActivo.VacantesSrcuBean;
import com.bancoazteca.srcu.spring.beans.sistema.MensajeTransaccionBean;
import com.bancoazteca.srcu.spring.beans.utilerias.CatalogoBean;
import com.bancoazteca.srcu.spring.beans.utilerias.SimpleBean;
import com.bancoazteca.srcu.spring.daos.administracion.mantenimientoUsuariosSap.MantenimientoUsuariosSapDAO;
import com.bancoazteca.srcu.spring.servicios.utilerias.BaseServicio;
import com.bancoazteca.srcu.spring.ws.administracion.posicionesSap.RespuestaAltaPosicionBean;
import com.bancoazteca.srcu.spring.ws.administracion.posicionesSap.RespuestaLimitaPosicionBean;
import com.bancoazteca.srcu.spring.ws.administracion.posicionesSap.ServiciosSAP;
@Service
public class MantenimientoUsuariosSapServicioImpl extends BaseServicio implements MantenimientoUsuariosSapServicio{
	
	public interface Enum_Operaciones_MantenimientoUsuariosSap{
		int	altaVacante			=	1;
		int resgitraVacante		=	1;
		int limitaVacante		=	3;
	}
	
	public interface Enum_Consultas_MantenimientoUsuariosSap{
		int datosEmpleado	=	1;
		int	puestos			=	2;
		int departamentos	=	3;
		int empleados		=	4;
	}
	
	public interface Enum_Constantes_MantenimientoUsuariosSap{
		int	sistemas			=	900;
		int	direccionCyc		=	817;
		int	adminZonificacion	=	970;
		int asistenteJefePlaza	=	1131;
		int adminSrcu			=	1201;
		int	adminRdfLam			=	1203;
		int	jefeGeografia		=	1204;
		String cadenaVacia		=	"";
		int estatusActivo		=	1;
		String catalogoActivo	=	"1";
		int errorDesconocido	=	999;
		int exito				=	0;
		String empleadoVirtual	=	"EMPLEADO VIRTUAL";
		int enteroCero			=	0;
	}
	
	public interface Enum_Catalogos_MantenimientoUsuariosSap{
		int replicaSap	=	351;
	}
	
	public interface Enum_SubItems_MantenimientoUsuariosSap{
		int replicaSap	=	1;
	}
	
	@Autowired
	MantenimientoUsuariosSapDAO mantenimientoUsuariosSapDAO;
	
	@Autowired
	ServiciosSAP serviciosSAP;
	
	@Override
	public MensajeTransaccionBean grabaTrasaccion(MantenimientoUsuariosSapBean mantenimientoUsuariosSapBean,
			int tipoOperacion) {
		MensajeTransaccionBean mensajeTransaccionBean = new MensajeTransaccionBean();
		
		switch (tipoOperacion) {
		case Enum_Operaciones_MantenimientoUsuariosSap.altaVacante:
			mensajeTransaccionBean = altaVacante(mantenimientoUsuariosSapBean);
			break;

		default:
			break;
		}
		
		
		return mensajeTransaccionBean;
	}
	
	@Override
	public SimpleBean consultaCentroCostos(int deptoId) {
		SimpleBean centroCostos = new SimpleBean();
		centroCostos = mantenimientoUsuariosSapDAO.consultaCeco(deptoId);
		return centroCostos;
	}
	
	@Override
	public List<VacantesSrcuBean> consultaVacantesSrcu(int deptoId, int tipoConsulta) {
		List<VacantesSrcuBean> vacantes = new ArrayList<VacantesSrcuBean>();
		vacantes = mantenimientoUsuariosSapDAO.consultaVacantesSrcu(deptoId, tipoConsulta);
		
		return vacantes;
	}

	@Override
	public MantenimientoUsuariosSapBean consulta(MantenimientoUsuariosSapBean mantenimientoUsuariosSap, int tipoOperacion) {
		MantenimientoUsuariosSapBean mantenimientoUsuariosSapBean = new MantenimientoUsuariosSapBean();
		switch (tipoOperacion) {
		case Enum_Consultas_MantenimientoUsuariosSap.datosEmpleado:
			DatosEmpleadoBean datosEmpleadoBean = new DatosEmpleadoBean();
			datosEmpleadoBean = mantenimientoUsuariosSapDAO.consultaDatosEmpleado(mantenimientoUsuariosSap.getEmpleadoOpera());
			mantenimientoUsuariosSapBean.setEmpleadoOpera(mantenimientoUsuariosSap.getEmpleadoOpera());
			mantenimientoUsuariosSapBean.setEmpleadoDelegado(mantenimientoUsuariosSap.getEmpleadoDelegado());
			mantenimientoUsuariosSapBean.setPuestoIdEmpleadoOpera(datosEmpleadoBean.getPuestoId());
			mantenimientoUsuariosSapBean.setDeptoIdEmpleadoOpera(datosEmpleadoBean.getDeptoId());
			mantenimientoUsuariosSapBean.setPuestoDelegado(mantenimientoUsuariosSap.getPuestoDelegado());
			break;
		case Enum_Consultas_MantenimientoUsuariosSap.puestos:
			mantenimientoUsuariosSapBean.setPuestosBeans(consultaPuestos(mantenimientoUsuariosSap.getPuestoIdEmpleadoOpera()));
			break;
		case Enum_Consultas_MantenimientoUsuariosSap.departamentos:
			mantenimientoUsuariosSapBean.setDepartamentos(mantenimientoUsuariosSapDAO.consultaDepartamentos(mantenimientoUsuariosSap.getPuestoConsultar(), consultaPais(), mantenimientoUsuariosSap.getPuestoDelegado(), mantenimientoUsuariosSap.getEmpleadoDelegado()));
			break;
		case Enum_Consultas_MantenimientoUsuariosSap.empleados:
			mantenimientoUsuariosSapBean.setEmpleadosOperar(mantenimientoUsuariosSapDAO.consultaEmpleados(mantenimientoUsuariosSap.getGerenciaConsultar(), mantenimientoUsuariosSap.getPuestoConsultar()));
			break;
			
		default:
			break;
		}
		return mantenimientoUsuariosSapBean;
	}
	
	public	List<CatalogoBean>	consultaPuestos(int puestoOperador) {
		List<CatalogoBean> puestos = new ArrayList<CatalogoBean>();
		
		switch (puestoOperador) {
		case Enum_Constantes_MantenimientoUsuariosSap.adminRdfLam:
		case Enum_Constantes_MantenimientoUsuariosSap.adminSrcu:
		case Enum_Constantes_MantenimientoUsuariosSap.adminZonificacion:
		case Enum_Constantes_MantenimientoUsuariosSap.asistenteJefePlaza:
		case Enum_Constantes_MantenimientoUsuariosSap.direccionCyc:
		case Enum_Constantes_MantenimientoUsuariosSap.jefeGeografia:
		case Enum_Constantes_MantenimientoUsuariosSap.sistemas:
			puestos = mantenimientoUsuariosSapDAO.consultaPuestosAdministrativos();
			break;

		default:
			puestos = mantenimientoUsuariosSapDAO.consultaPuestosGeografia(puestoOperador);
			break;
		}
		
		return puestos;
	}
	
	private	MensajeTransaccionBean altaVacante(MantenimientoUsuariosSapBean mantenimientoUsuariosSapBean) {
		MensajeTransaccionBean mensajeTransaccionBean = new MensajeTransaccionBean();
		RespuestaAltaPosicionBean respuestaAltaPosicionBean	= 	new RespuestaAltaPosicionBean();
		@SuppressWarnings("unused")
		RespuestaLimitaPosicionBean	respuestaLimitaPosicionBean = new RespuestaLimitaPosicionBean();
		VacantesBean vacantesBean = new VacantesBean();
		CatalogoBean replicaSap = new CatalogoBean();
		SimpleBean registroMovimiento = new SimpleBean();
		
		respuestaAltaPosicionBean = serviciosSAP.creaVacante(	mantenimientoUsuariosSapBean.getGerenciaConsultar(), 	mantenimientoUsuariosSapBean.getSegmentoOperar(), 
																mantenimientoUsuariosSapBean.getPuestoConsultar(), 		mantenimientoUsuariosSapBean.getEmpleadoOpera());
		
		if(respuestaAltaPosicionBean.getCodigo() != Enum_Constantes_MantenimientoUsuariosSap.exito) {
			mensajeTransaccionBean.setNumeroMensaje(Enum_Constantes_MantenimientoUsuariosSap.errorDesconocido);
			mensajeTransaccionBean.setDescripcionMensaje(respuestaAltaPosicionBean.getDescripcion());
			return mensajeTransaccionBean;
		}
		
		vacantesBean = mantenimientoUsuariosSapDAO.consultaVirtualDisponible(mantenimientoUsuariosSapBean.getGerenciaConsultar(), mantenimientoUsuariosSapBean.getPuestoConsultar());
		
		if(vacantesBean.getNumeroVacante().equals(Enum_Constantes_MantenimientoUsuariosSap.cadenaVacia)) {
			respuestaLimitaPosicionBean = serviciosSAP.limitaPosicion(respuestaAltaPosicionBean.getNumPosicion(), mantenimientoUsuariosSapBean.getEmpleadoOpera(), Enum_Constantes_MantenimientoUsuariosSap.cadenaVacia);
			mensajeTransaccionBean.setNumeroMensaje(Enum_Constantes_MantenimientoUsuariosSap.errorDesconocido);
			mensajeTransaccionBean.setDescripcionMensaje("NO FUE POSIBLE OBTENER UN NUMERO DE EMPLEADO VACANTE.");
			return mensajeTransaccionBean;
		}
		
		replicaSap = consultaSubItem(Enum_Catalogos_MantenimientoUsuariosSap.replicaSap, Enum_SubItems_MantenimientoUsuariosSap.replicaSap);
		
		if(replicaSap.getDescCorta().contains(Enum_Constantes_MantenimientoUsuariosSap.catalogoActivo)) {
			registroMovimiento = mantenimientoUsuariosSapDAO.registraMovimientoVacantes(	respuestaAltaPosicionBean.getNumPosicion(), 			vacantesBean.getNumeroVacante(), 							Enum_Constantes_MantenimientoUsuariosSap.estatusActivo, 
																							Enum_Constantes_MantenimientoUsuariosSap.cadenaVacia, 	respuestaAltaPosicionBean.getMensaje(), 					respuestaAltaPosicionBean.getDescripcion(), 
																							mantenimientoUsuariosSapBean.getEmpleadoOpera(), 		Enum_Operaciones_MantenimientoUsuariosSap.resgitraVacante);
		}else {
			registroMovimiento.setCodigo(Enum_Constantes_MantenimientoUsuariosSap.exito);
			registroMovimiento.setDescripcion("NO SE REGISTRA EL MOVIMIENTO");
		}
		
		if(registroMovimiento.getCodigo() != Enum_Constantes_MantenimientoUsuariosSap.exito) {
			respuestaLimitaPosicionBean = serviciosSAP.limitaPosicion(respuestaAltaPosicionBean.getNumPosicion(), mantenimientoUsuariosSapBean.getEmpleadoOpera(), Enum_Constantes_MantenimientoUsuariosSap.cadenaVacia);
			mensajeTransaccionBean.setNumeroMensaje(Enum_Constantes_MantenimientoUsuariosSap.errorDesconocido);
			mensajeTransaccionBean.setDescripcionMensaje("NO FUE POSIBLE REGISTRAR LA VACANTE EN EL SRCU.");
			return mensajeTransaccionBean;
		}
		
		mensajeTransaccionBean = mantenimientoUsuariosSapDAO.altaEmpleado(	vacantesBean.getNumeroVacante(), 							mantenimientoUsuariosSapBean.getGerenciaConsultar(), 
																			mantenimientoUsuariosSapBean.getPuestoConsultar(), 			Enum_Constantes_MantenimientoUsuariosSap.enteroCero, 
																			Enum_Constantes_MantenimientoUsuariosSap.empleadoVirtual, 	mantenimientoUsuariosSapBean.getEmpleadoOpera(), 
																			mantenimientoUsuariosSapBean.getSegmentoOperar());
		
		if(mensajeTransaccionBean.getNumeroMensaje() != Enum_Constantes_MantenimientoUsuariosSap.exito) {
			respuestaLimitaPosicionBean = serviciosSAP.limitaPosicion(respuestaAltaPosicionBean.getNumPosicion(), mantenimientoUsuariosSapBean.getEmpleadoOpera(), Enum_Constantes_MantenimientoUsuariosSap.cadenaVacia);
			
			registroMovimiento	=	mantenimientoUsuariosSapDAO.registraMovimientoVacantes(	respuestaAltaPosicionBean.getNumPosicion(), 			vacantesBean.getNumeroVacante(), 						Enum_Constantes_MantenimientoUsuariosSap.estatusActivo, 
																							Enum_Constantes_MantenimientoUsuariosSap.cadenaVacia, 	respuestaAltaPosicionBean.getMensaje(),					respuestaAltaPosicionBean.getDescripcion(),
																							mantenimientoUsuariosSapBean.getEmpleadoOpera(),		Enum_Operaciones_MantenimientoUsuariosSap.limitaVacante);
		}
		
		return mensajeTransaccionBean;
	} 
	
	
//	private MensajeTransaccionBean	altaEmpleado(MantenimientoUsuariosSapBean mantenimientoUsuariosSapBean) {
//		MensajeTransaccionBean mensajeTransaccionBean = new MensajeTransaccionBean();
//		
//		return mensajeTransaccionBean;
//	}

}
