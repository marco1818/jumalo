package com.bancoazteca.srcu.spring.daos.utilerias;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;
import org.yaml.snakeyaml.Yaml;
import com.bancoazteca.srcu.spring.beans.utilerias.Funcion;
import com.bancoazteca.srcu.spring.beans.utilerias.YamlUtils;

public class FuncionesSistema {
	private final static Logger logger = Logger.getLogger("FuncionesSistema");
	private static FuncionesSistema funcionesSistema;
	private Map<String,Funcion> mapFuncionesSistema;
	
	private FuncionesSistema() {
		mapFuncionesSistema	=	new HashMap<String,Funcion>();
	}
	
	public static FuncionesSistema getInstance() {
		if(funcionesSistema == null) {
			funcionesSistema = new FuncionesSistema();
			funcionesSistema.cargaFunciones();
		}
		
		return funcionesSistema;
	}
	
	private void cargaFunciones() {
		Yaml yaml = new Yaml();
		try {
			logger.info("Cargando Funciones del Sistema.");
			
			List<InputStream> recursos = new ArrayList<InputStream>(); 
			recursos.add(BaseDAO.class.getResourceAsStream("properties/Administracion.yml"));
			recursos.add(BaseDAO.class.getResourceAsStream("properties/Utilerias.yml"));
			
			for(InputStream recurso: recursos) {
				YamlUtils yamlUtils = yaml.loadAs(recurso, YamlUtils.class);
				for (Funcion funcion : yamlUtils.getFunciones()) {
					mapFuncionesSistema.put(funcion.getLlaveFuncion().trim(), funcion);
					logger.info("Funcion:"+funcion.getLlaveFuncion().trim()+"-Cargada Exitosamente.");
				}
		  
				recurso.close();
			}
			
			logger.info("Funciones del Sistema Cargadas Exitosamente.");
		} catch (IOException e) {
			logger.info("Ocurrio un detalle al Cargar la Funciones del Sistema.");
		}
	}
	
	public Funcion obtenerFuncion(String clave) {
		return mapFuncionesSistema.get(clave);
	}
}
