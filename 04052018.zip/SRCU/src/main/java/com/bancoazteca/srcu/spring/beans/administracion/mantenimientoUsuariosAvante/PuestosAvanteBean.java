package com.bancoazteca.srcu.spring.beans.administracion.mantenimientoUsuariosAvante;

import java.math.BigDecimal;

public class PuestosAvanteBean {
	private	int	puestoId;
	private String descripcionPuesto;
	
	public PuestosAvanteBean() {
		
	}

	public int getPuestoId() {
		return puestoId;
	}

	public void setPuestoId(int puestoId) {
		this.puestoId = puestoId;
	}

	public void setPuestoId(BigDecimal puestoId) {
		this.puestoId = puestoId.intValue();
	}
	
	public String getDescripcionPuesto() {
		return descripcionPuesto;
	}

	public void setDescripcionPuesto(String descripcionPuesto) {
		this.descripcionPuesto = descripcionPuesto;
	}
	
}
