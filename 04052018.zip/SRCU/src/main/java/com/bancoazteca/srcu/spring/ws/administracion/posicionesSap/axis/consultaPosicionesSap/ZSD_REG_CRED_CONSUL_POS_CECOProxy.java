package com.bancoazteca.srcu.spring.ws.administracion.posicionesSap.axis.consultaPosicionesSap;

public class ZSD_REG_CRED_CONSUL_POS_CECOProxy implements ZSD_REG_CRED_CONSUL_POS_CECO {
  private String _endpoint = null;
  private String usuario;
  private String contrasenia;
  private int timeout;
  private ZSD_REG_CRED_CONSUL_POS_CECO zSD_REG_CRED_CONSUL_POS_CECO = null;
  
  public ZSD_REG_CRED_CONSUL_POS_CECOProxy() {
    _initZSD_REG_CRED_CONSUL_POS_CECOProxy();
  }
  
  public ZSD_REG_CRED_CONSUL_POS_CECOProxy(String endpoint,String usuario, String contrasenia, int timeout) {
    _endpoint = endpoint;
    this.usuario = usuario;
    this.contrasenia = contrasenia;
    this.timeout = timeout;
    _initZSD_REG_CRED_CONSUL_POS_CECOProxy();
  }
  
  private void _initZSD_REG_CRED_CONSUL_POS_CECOProxy() {
    try {
      zSD_REG_CRED_CONSUL_POS_CECO = (new ZSN_REG_CRED_CONSUL_POS_CECOLocator()).getZBN_REG_CRED_CONSUL_POS_CECO();
      if (zSD_REG_CRED_CONSUL_POS_CECO != null) {
        if (_endpoint != null) {
        	 ((javax.xml.rpc.Stub)zSD_REG_CRED_CONSUL_POS_CECO)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
         	((javax.xml.rpc.Stub)zSD_REG_CRED_CONSUL_POS_CECO)._setProperty(javax.xml.rpc.Stub.USERNAME_PROPERTY, usuario);
         	((javax.xml.rpc.Stub)zSD_REG_CRED_CONSUL_POS_CECO)._setProperty(javax.xml.rpc.Stub.PASSWORD_PROPERTY, contrasenia);
         	((javax.xml.rpc.Stub)zSD_REG_CRED_CONSUL_POS_CECO)._setProperty("axis.connection.timeout",timeout);
        }
       
        else
          _endpoint = (String)((javax.xml.rpc.Stub)zSD_REG_CRED_CONSUL_POS_CECO)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (zSD_REG_CRED_CONSUL_POS_CECO != null)
      ((javax.xml.rpc.Stub)zSD_REG_CRED_CONSUL_POS_CECO)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public ZSD_REG_CRED_CONSUL_POS_CECO getZSD_REG_CRED_CONSUL_POS_CECO() {
    if (zSD_REG_CRED_CONSUL_POS_CECO == null)
      _initZSD_REG_CRED_CONSUL_POS_CECOProxy();
    return zSD_REG_CRED_CONSUL_POS_CECO;
  }
  
  public void ZRH_REG_CRED_CONSUL_POS_CECO(java.lang.String CECO, java.lang.String ESTATUS_POSICION, java.lang.String FUNCION_SAP, TABLE_OF_BAPIRETURN1Holder ERR, TABLE_OF_ZST_RH_REGIONAL_CREDITOHolder IT_RES) throws java.rmi.RemoteException{
    if (zSD_REG_CRED_CONSUL_POS_CECO == null)
      _initZSD_REG_CRED_CONSUL_POS_CECOProxy();
    zSD_REG_CRED_CONSUL_POS_CECO.ZRH_REG_CRED_CONSUL_POS_CECO(CECO, ESTATUS_POSICION, FUNCION_SAP, ERR, IT_RES);
  }
  
  
}