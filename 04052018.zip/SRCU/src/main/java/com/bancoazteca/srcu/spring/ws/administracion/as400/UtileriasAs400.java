package com.bancoazteca.srcu.spring.ws.administracion.as400;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.springframework.stereotype.Service;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;

import com.bancoazteca.srcu.spring.servicios.utilerias.BaseServicio;

@Service
public class UtileriasAs400 extends BaseServicio{
	private	String nombrePorperties	=	"StoreProcedures.properties";
	private static Pattern tokenPattern = Pattern.compile("\\{([^}]*)\\}");
	private Properties properties;
	private String ip;
	
	public UtileriasAs400() {
		properties = new Properties();
		try {
			properties.load(getClass().getResourceAsStream(nombrePorperties));
			ip = "http://10.50.109.75:8080/WSConsultaCentral/servicio/wspot?jndi=dsRegCobranza&query=CALL%20";
		} catch (IOException e) {
			
		}
	}
	
	public Respuesta400Bean consultaEmpleado(String numeroEmpleado) {
		Respuesta400Bean respuesta400Bean = new Respuesta400Bean();
		String peticion = "";
		Map<String,Object> parametros = new HashMap<String, Object>();
		parametros.put("EMPLEADO", numeroEmpleado.trim());
		
		peticion = properties.getProperty("MANTTO_USUARIOS_VALIDAR_EMPLEADO.scheme")+"."+properties.getProperty("MANTTO_USUARIOS_VALIDAR_EMPLEADO.sp");
		peticion = armaPeticion(peticion, parametros);
		
		peticion = ip+peticion;
		
		int geografia = 0;
		String[] respuesta = peticionAS400(peticion).split("\\|");
		try {
			geografia = Integer.parseInt(respuesta[5].trim());
		}catch (NumberFormatException e) {
			// TODO: handle exception
		}
		
		
		respuesta400Bean.setMensajeId(Integer.parseInt(respuesta[0].trim()));
		respuesta400Bean.setMensaje(respuesta[1]);
		respuesta400Bean.setNumeroEmpleado(respuesta[2]);
		respuesta400Bean.setNombreEmpleado(respuesta[3]);
		respuesta400Bean.setPuesto(respuesta[4]);
		respuesta400Bean.setUltimoMovimiento(respuesta[6]);
		respuesta400Bean.setSegmento(respuesta[7]);
		respuesta400Bean.setGeografia(geografia);
		
		if(respuesta400Bean.getMensajeId() == 0) {
			respuesta400Bean.setCodigo(0);
		}else {
			respuesta400Bean.setCodigo(999);
		}
		
		return respuesta400Bean;
	}
	
	public Respuesta400Bean negociaVacante(int puesto, String numeroVacante, String empleadoOpera) {
		Respuesta400Bean respuesta400Bean = new Respuesta400Bean();
		String peticion = "";
		Map<String,Object> parametros = new HashMap<String, Object>();
		parametros.put("PUESTO", puesto);
		parametros.put("CONFIRMACION", "0");
		parametros.put("EMPLEADO_VIRTUAL", numeroVacante);
		parametros.put("EMPLEADO_MODIFICACION", empleadoOpera);
		
		peticion = properties.getProperty("MANTTO_USUARIOS_GENERACION_VACANTE.scheme")+"."+properties.getProperty("MANTTO_USUARIOS_GENERACION_VACANTE.sp");
		peticion = armaPeticion(peticion, parametros);
		
		peticion = ip+peticion;
		
		String[] respuesta = peticionAS400(peticion).split("\\|");
		respuesta400Bean.setMensajeId(Integer.parseInt(respuesta[1].trim()));
		respuesta400Bean.setMensaje(respuesta[0]);
		respuesta400Bean.setNumeroEmpleado(respuesta[2]);
		
		return respuesta400Bean;
	}
	
	public Respuesta400Bean confirmaVacante(int segmento, String numeroVacante, String empleadoOpera) {
		Respuesta400Bean respuesta400Bean = new Respuesta400Bean();
		String peticion = "";
		
		int puesto = (segmento>0?Integer.parseInt(consultaSubItem(414, segmento).getDescCorta()):segmento );
		
		Map<String,Object> parametros = new HashMap<String, Object>();
		parametros.put("PUESTO", puesto);
		parametros.put("CONFIRMACION", "1");
		parametros.put("EMPLEADO_VIRTUAL", numeroVacante);
		parametros.put("EMPLEADO_MODIFICACION", empleadoOpera);
		
		peticion = properties.getProperty("MANTTO_USUARIOS_GENERACION_VACANTE.scheme")+"."+properties.getProperty("MANTTO_USUARIOS_GENERACION_VACANTE.sp");
		peticion = armaPeticion(peticion, parametros);
		
		peticion = ip+peticion;
		String[] respuesta = peticionAS400(peticion).split("\\|");
		respuesta400Bean.setMensajeId(Integer.parseInt(respuesta[1].trim()));
		respuesta400Bean.setMensaje(respuesta[0]);
		respuesta400Bean.setNumeroEmpleado(respuesta[2]);
		
		if(respuesta400Bean.getMensajeId() == 1) {
			respuesta400Bean.setCodigo(0);
		}else {
			respuesta400Bean.setCodigo(999);
		}
		
		return respuesta400Bean;
	}
	
	
	public Respuesta400Bean altaEmpleado(String numeroEmpleado,  String empleadoOpera, int deptoId, int segmento, String jefeOracle) {
		Respuesta400Bean respuesta400Bean = new Respuesta400Bean();
		String peticion = "";
		
		int puesto400 		=	(segmento>0?Integer.parseInt(consultaSubItem(414, segmento).getDescCorta()):segmento );
		int regional400 	=	(deptoId>0?Integer.parseInt(consultaSubItem(103, deptoId).getDescCorta()):0);
		String segmento400	=	(segmento>0?consultaSubItem(415, segmento).getDescCorta():"");
		int puestoJefe		=	(segmento>0?Integer.parseInt(consultaSubItem(416, segmento).getDescCorta()):0);
		int plazaJefe		=	consultaJefeInmediato(jefeOracle,regional400,segmento);
		int zona=0;
		if(plazaJefe == 0) {
			respuesta400Bean.setCodigo(999);
			respuesta400Bean.setMensaje("NO SE ENCONTRO AL JEFE:"+jefeOracle+" EN CREDIMAX.");
			return respuesta400Bean;
		}
		
		Map<String,Object> parametros = new HashMap<String, Object>();
		parametros.put("EMPLEADO_ALTA", numeroEmpleado);
		parametros.put("REGIONAL", regional400);
		parametros.put("PUESTO", puesto400);
		parametros.put("EMPLEADO_MODIFICACION", empleadoOpera);
		parametros.put("PUESTO_JEFE", puestoJefe);
		parametros.put("PLAZA_JEFE", plazaJefe);
		parametros.put("SEGMENTO", segmento400.trim());
		
		peticion = properties.getProperty("MANTTO_USUARIOS_ALTA_2.scheme")+"."+properties.getProperty("MANTTO_USUARIOS_ALTA_2.sp");
		peticion = armaPeticion(peticion, parametros);
		
		peticion = ip+peticion;
		
		String[] respuesta = peticionAS400(peticion).split("\\|");
		try {
			zona = Integer.parseInt(respuesta[2].trim());
		}catch (NumberFormatException e) {
			zona = 0;
		}
		
		
		respuesta400Bean.setMensajeId(Integer.parseInt(respuesta[1].trim()));
		respuesta400Bean.setMensaje(respuesta[0]);
		
		respuesta400Bean.setZona(zona);
		
		if(respuesta400Bean.getMensajeId() == 0) {
			respuesta400Bean.setCodigo(0);
		}else {
			respuesta400Bean.setCodigo(999);
		}
		
		return respuesta400Bean;
	}
	
	public Respuesta400Bean bajaEmpleado(String numeroEmpleado, String empleadoOpera) {
		Respuesta400Bean respuesta400Bean = new Respuesta400Bean();
		String peticion ="";
		Map<String,Object> parametros = new HashMap<String, Object>();
		parametros.put("EMPLEADO_BAJA", numeroEmpleado);
		parametros.put("EMPLEADO_MODIFICACION", empleadoOpera);
		
		peticion = properties.getProperty("MANTTO_USUARIOS_BAJA_2.scheme")+"."+properties.getProperty("MANTTO_USUARIOS_BAJA_2.sp");
		peticion = armaPeticion(peticion, parametros);
		
		peticion = ip+peticion;
		int mensajeId = 999;
		String[] respuesta = peticionAS400(peticion).split("\\|");
		respuesta400Bean.setMensaje(respuesta[0]);
		try {
			mensajeId = Integer.parseInt(respuesta[1].trim());
		}catch (NumberFormatException e) {
			mensajeId = 999;
		}
		respuesta400Bean.setMensajeId(mensajeId);
		
		if(respuesta400Bean.getMensajeId() != 0) {
			respuesta400Bean.setCodigo(999);
		}else {
			respuesta400Bean.setCodigo(0);
		}
		
		return respuesta400Bean;
		
	}
	
	public	Respuesta400Bean bajaXSustitucion(String empeladoOrigen, String empleadoDestino, String empleadoOpera) {
		Respuesta400Bean respuesta400Bean = new Respuesta400Bean();
		String peticion ="";
		int mensajeId;
		Map<String,Object> parametros = new HashMap<String, Object>();
		parametros.put("EMPLEADO_ORIGEN", empeladoOrigen.trim());
		parametros.put("EMPLEADO_DESTINO", empleadoDestino.trim());
		parametros.put("EMPLEADO_MODIFICACION", empleadoOpera.trim());
		
		peticion = properties.getProperty("MANTTO_USUARIOS_BAJA_POR_SUSTITUCION_2.scheme")+"."+properties.getProperty("MANTTO_USUARIOS_BAJA_POR_SUSTITUCION_2.sp");
		peticion = armaPeticion(peticion, parametros);
		
		peticion = ip+peticion;
		
		String[] respuesta = peticionAS400(peticion).split("\\|");
		try {
			mensajeId = Integer.parseInt(respuesta[1].trim());
		}catch (NumberFormatException e) {
			mensajeId = 999;
		}
		respuesta400Bean.setMensajeId(mensajeId);
		respuesta400Bean.setMensaje(respuesta[0]);
		
		if(respuesta400Bean.getMensajeId() != 0) {
			respuesta400Bean.setCodigo(999);
		}else {
			respuesta400Bean.setCodigo(0);
		}
		
		return respuesta400Bean;
	}
	
	private String peticionAS400(String query){
		String respuestaWS = "";
		StringBuffer response = new StringBuffer();
		URL obj;
		HttpURLConnection con = null;
		try {
			
			obj = new URL(query);
			
			con = (HttpURLConnection) obj.openConnection();

			con.setRequestMethod("GET");
			con.setRequestProperty("Accept", "application/xml");
			con.setRequestProperty("charset", "UTF-8");
			con.setConnectTimeout(60000);
			con.setReadTimeout(120000);
			
			int responseCode = con.getResponseCode();
	        if(responseCode == 200)
	        {
				BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
				String inputLine;
	
				while ((inputLine = in.readLine()) != null) {
					response.append(inputLine);
				}
				in.close();
	        }else{
	        	respuestaWS ="Peticion Erronea";
	        	return respuestaWS;
	        }
	        respuestaWS =  response.toString();
	        
	        
	        DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            InputSource is = new InputSource();
            is.setCharacterStream(new StringReader(respuestaWS));
            Document doc = dBuilder.parse(is);
            doc.getDocumentElement().normalize();
	        
            if(respuestaWS != null){
            	if(respuestaWS.contains("REGISTRO1")){
            		respuestaWS =doc.getElementsByTagName("REGISTRO1").item(0).getAttributes().getNamedItem("cadena").getNodeValue();
                }else{
                	respuestaWS= "Peticion Erronea";
                }
            }
            
		} catch (Throwable e) {
			respuestaWS ="Peticion Erronea";
		}finally {
			con.disconnect();
		}
		
		
		return respuestaWS;
	}
	
	
	private List<String> peticioAs400All(String query){
		List<String> registros	=	new ArrayList<String>();
		StringBuffer response = new StringBuffer();
		URL obj;
		HttpURLConnection con = null;
		String respuestaWS = "";
		try {
			
			obj = new URL(query);
			
			con = (HttpURLConnection) obj.openConnection();

			con.setRequestMethod("GET");
			con.setRequestProperty("Accept", "application/xml");
			con.setRequestProperty("charset", "UTF-8");
			con.setConnectTimeout(60000);
			con.setReadTimeout(120000);
			
			int responseCode = con.getResponseCode();
	        if(responseCode == 200)
	        {
				BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
				String inputLine;
	
				while ((inputLine = in.readLine()) != null) {
					response.append(inputLine);
				}
				in.close();
	        }else{
	        	return registros;
	        }
	        respuestaWS =  response.toString();
	        
	        DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            InputSource is = new InputSource();
            is.setCharacterStream(new StringReader(respuestaWS));
            Document doc = dBuilder.parse(is);
            doc.getDocumentElement().normalize();
	        
            if(respuestaWS != null){
            	String registro = "";
            	String respuesta;
            	for(int x=1;x<100;x++) {
            		if(x<10) {
            			registro ="REGISTRO"+x;
            		}else {
            			registro ="REGISTRO"+x;
            		}
            		if(respuestaWS.contains(registro)){
            			respuesta =doc.getElementsByTagName(registro).item(0).getAttributes().getNamedItem("cadena").getNodeValue();
                		registros.add(respuesta);
                    }else {
                    	break;
                    }
            	}
            	
            	
            }
            
		} catch (Throwable e) {
		}finally {
			con.disconnect();
		}
		
		
		return registros;
	}
	
	private int	consultaJefeInmediato(String empleadoJefe,int regionalCredimax, int segmento) {
		int plazaJefe = 0;
		String peticion = "";
		Map<String,Object> parametros = new HashMap<String, Object>();
		
		if(segmento == 138) {
			return 1;
		}
		
		if(segmento <138) {
			peticion = properties.getProperty("MANTTO_USUARIOS_OBTENER_GERENTES.scheme")+"."+properties.getProperty("MANTTO_USUARIOS_OBTENER_GERENTES.sp");
			parametros.put("REGIONAL", regionalCredimax);
		}else {
			peticion = properties.getProperty("MANTTO_USUARIOS_JEFES_INMEDIATOS.scheme")+"."+properties.getProperty("MANTTO_USUARIOS_JEFES_INMEDIATOS.sp");
			parametros.put("REGIONAL", regionalCredimax);
			parametros.put("PUESTO", segmento);
		}
		
		peticion = armaPeticion(peticion, parametros);
		
		peticion = ip+peticion;
		
		List<String> respuesta = peticioAs400All(peticion);
		
		if(respuesta.size()>0) {
			for(String jefe:respuesta) {
				String[] jefeAs = jefe.split("\\|");
				if(jefeAs[0].trim().equals(empleadoJefe.trim())) {
					plazaJefe = Integer.parseInt(jefeAs[2].trim());
				}
			}
		}else {
			plazaJefe = 0;
		}
		
		return plazaJefe;
	}
	
	private String armaPeticion(String plantilla, Map<String,Object> parametros){
	    StringBuffer sb = new StringBuffer();
	    Matcher myMatcher = tokenPattern.matcher(plantilla);
	    while (myMatcher.find()) {
	        String field = myMatcher.group(1);
	        myMatcher.appendReplacement(sb, "");
	        sb.append(doParameter(field, parametros));
	   }
	   myMatcher.appendTail(sb);
	   return sb.toString();
	}
	
	private String doParameter(String field, Map<String, Object> params){
		if(params.containsKey(field)){
			return params.get(field).toString();
		}
		return "";
	}

}
