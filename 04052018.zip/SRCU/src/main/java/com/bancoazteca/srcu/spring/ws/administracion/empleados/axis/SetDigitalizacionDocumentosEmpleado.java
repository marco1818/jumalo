/**
 * SetDigitalizacionDocumentosEmpleado.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.bancoazteca.srcu.spring.ws.administracion.empleados.axis;
@SuppressWarnings({ "unused", "rawtypes", "serial" })
public class SetDigitalizacionDocumentosEmpleado  implements java.io.Serializable {
    private java.lang.String usuario;

    private java.lang.String contrase�a;

    private int empleado;

    private int pais;

    private java.lang.String documento;

    private int tipo;

    private int etapa;

    private boolean existeError;

    private java.lang.String mensaje;

    public SetDigitalizacionDocumentosEmpleado() {
    }

    public SetDigitalizacionDocumentosEmpleado(
           java.lang.String usuario,
           java.lang.String contrase�a,
           int empleado,
           int pais,
           java.lang.String documento,
           int tipo,
           int etapa,
           boolean existeError,
           java.lang.String mensaje) {
           this.usuario = usuario;
           this.contrase�a = contrase�a;
           this.empleado = empleado;
           this.pais = pais;
           this.documento = documento;
           this.tipo = tipo;
           this.etapa = etapa;
           this.existeError = existeError;
           this.mensaje = mensaje;
    }


    /**
     * Gets the usuario value for this SetDigitalizacionDocumentosEmpleado.
     * 
     * @return usuario
     */
    public java.lang.String getUsuario() {
        return usuario;
    }


    /**
     * Sets the usuario value for this SetDigitalizacionDocumentosEmpleado.
     * 
     * @param usuario
     */
    public void setUsuario(java.lang.String usuario) {
        this.usuario = usuario;
    }


    /**
     * Gets the contrase�a value for this SetDigitalizacionDocumentosEmpleado.
     * 
     * @return contrase�a
     */
    public java.lang.String getContrase�a() {
        return contrase�a;
    }


    /**
     * Sets the contrase�a value for this SetDigitalizacionDocumentosEmpleado.
     * 
     * @param contrase�a
     */
    public void setContrase�a(java.lang.String contrase�a) {
        this.contrase�a = contrase�a;
    }


    /**
     * Gets the empleado value for this SetDigitalizacionDocumentosEmpleado.
     * 
     * @return empleado
     */
    public int getEmpleado() {
        return empleado;
    }


    /**
     * Sets the empleado value for this SetDigitalizacionDocumentosEmpleado.
     * 
     * @param empleado
     */
    public void setEmpleado(int empleado) {
        this.empleado = empleado;
    }


    /**
     * Gets the pais value for this SetDigitalizacionDocumentosEmpleado.
     * 
     * @return pais
     */
    public int getPais() {
        return pais;
    }


    /**
     * Sets the pais value for this SetDigitalizacionDocumentosEmpleado.
     * 
     * @param pais
     */
    public void setPais(int pais) {
        this.pais = pais;
    }


    /**
     * Gets the documento value for this SetDigitalizacionDocumentosEmpleado.
     * 
     * @return documento
     */
    public java.lang.String getDocumento() {
        return documento;
    }


    /**
     * Sets the documento value for this SetDigitalizacionDocumentosEmpleado.
     * 
     * @param documento
     */
    public void setDocumento(java.lang.String documento) {
        this.documento = documento;
    }


    /**
     * Gets the tipo value for this SetDigitalizacionDocumentosEmpleado.
     * 
     * @return tipo
     */
    public int getTipo() {
        return tipo;
    }


    /**
     * Sets the tipo value for this SetDigitalizacionDocumentosEmpleado.
     * 
     * @param tipo
     */
    public void setTipo(int tipo) {
        this.tipo = tipo;
    }


    /**
     * Gets the etapa value for this SetDigitalizacionDocumentosEmpleado.
     * 
     * @return etapa
     */
    public int getEtapa() {
        return etapa;
    }


    /**
     * Sets the etapa value for this SetDigitalizacionDocumentosEmpleado.
     * 
     * @param etapa
     */
    public void setEtapa(int etapa) {
        this.etapa = etapa;
    }


    /**
     * Gets the existeError value for this SetDigitalizacionDocumentosEmpleado.
     * 
     * @return existeError
     */
    public boolean isExisteError() {
        return existeError;
    }


    /**
     * Sets the existeError value for this SetDigitalizacionDocumentosEmpleado.
     * 
     * @param existeError
     */
    public void setExisteError(boolean existeError) {
        this.existeError = existeError;
    }


    /**
     * Gets the mensaje value for this SetDigitalizacionDocumentosEmpleado.
     * 
     * @return mensaje
     */
    public java.lang.String getMensaje() {
        return mensaje;
    }


    /**
     * Sets the mensaje value for this SetDigitalizacionDocumentosEmpleado.
     * 
     * @param mensaje
     */
    public void setMensaje(java.lang.String mensaje) {
        this.mensaje = mensaje;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof SetDigitalizacionDocumentosEmpleado)) return false;
        SetDigitalizacionDocumentosEmpleado other = (SetDigitalizacionDocumentosEmpleado) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.usuario==null && other.getUsuario()==null) || 
             (this.usuario!=null &&
              this.usuario.equals(other.getUsuario()))) &&
            ((this.contrase�a==null && other.getContrase�a()==null) || 
             (this.contrase�a!=null &&
              this.contrase�a.equals(other.getContrase�a()))) &&
            this.empleado == other.getEmpleado() &&
            this.pais == other.getPais() &&
            ((this.documento==null && other.getDocumento()==null) || 
             (this.documento!=null &&
              this.documento.equals(other.getDocumento()))) &&
            this.tipo == other.getTipo() &&
            this.etapa == other.getEtapa() &&
            this.existeError == other.isExisteError() &&
            ((this.mensaje==null && other.getMensaje()==null) || 
             (this.mensaje!=null &&
              this.mensaje.equals(other.getMensaje())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getUsuario() != null) {
            _hashCode += getUsuario().hashCode();
        }
        if (getContrase�a() != null) {
            _hashCode += getContrase�a().hashCode();
        }
        _hashCode += getEmpleado();
        _hashCode += getPais();
        if (getDocumento() != null) {
            _hashCode += getDocumento().hashCode();
        }
        _hashCode += getTipo();
        _hashCode += getEtapa();
        _hashCode += (isExisteError() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        if (getMensaje() != null) {
            _hashCode += getMensaje().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(SetDigitalizacionDocumentosEmpleado.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", ">setDigitalizacionDocumentosEmpleado"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("usuario");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Usuario"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("contrase�a");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Contrase�a"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("empleado");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Empleado"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("pais");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Pais"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("documento");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Documento"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("tipo");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Tipo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("etapa");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Etapa"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("existeError");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("mensaje");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
