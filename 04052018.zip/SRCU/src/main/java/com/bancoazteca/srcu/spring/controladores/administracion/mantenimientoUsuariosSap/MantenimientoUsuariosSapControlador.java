package com.bancoazteca.srcu.spring.controladores.administracion.mantenimientoUsuariosSap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.ModelAndView;

import com.bancoazteca.srcu.spring.beans.administracion.mantenimientoUsuariosSap.MantenimientoUsuariosSapBean;
import com.bancoazteca.srcu.spring.beans.sistema.MensajeTransaccionBean;
import com.bancoazteca.srcu.spring.beans.utilerias.DatosSessionStruts;
import com.bancoazteca.srcu.spring.servicios.administracion.mantenimientoUsuariosSap.MantenimientoUsuariosSapServicio;
import com.bancoazteca.srcu.spring.servicios.administracion.mantenimientoUsuariosSap.MantenimientoUsuariosSapServicioImpl.Enum_Consultas_MantenimientoUsuariosSap;

@Controller
public class MantenimientoUsuariosSapControlador {
	
	@Autowired
	MantenimientoUsuariosSapServicio mantenimientoUsuariosSapServicio;
	
	@InitBinder
	public void InitBinder(WebDataBinder webDataBinder, WebRequest webRequest) {
		webDataBinder.setDisallowedFields("");
	}
	
	@RequestMapping(value= {"/mantenimientoUsuariosSapSRCU.htm"}, method=RequestMethod.GET)
	public ModelAndView mantenimientoUsuariosSap(@ModelAttribute("datosSession") DatosSessionStruts datosSessionStruts) {
		MantenimientoUsuariosSapBean mantenimientoUsuariosSapBean = new MantenimientoUsuariosSapBean();
		mantenimientoUsuariosSapBean.setEmpleadoOpera(datosSessionStruts.getNumeroEmpleado());
		mantenimientoUsuariosSapBean.setEmpleadoDelegado(datosSessionStruts.getNumeroEmpleadoDelegado());
		mantenimientoUsuariosSapBean.setPuestoDelegado(datosSessionStruts.getPuestoDelegado());
		
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("administracion/mantenimientoUsuariosSap/mantenimientoUsuariosSap");
		mantenimientoUsuariosSapBean = mantenimientoUsuariosSapServicio.consulta(mantenimientoUsuariosSapBean, Enum_Consultas_MantenimientoUsuariosSap.datosEmpleado);
		mantenimientoUsuariosSapBean.setPuestosBeans(mantenimientoUsuariosSapServicio.consulta(mantenimientoUsuariosSapBean, Enum_Consultas_MantenimientoUsuariosSap.puestos).getPuestosBeans());
		
		modelAndView.addObject("mantenimientoUsuariosSapBean",mantenimientoUsuariosSapBean);
		
		return modelAndView;
	}
	
	@RequestMapping(value= {"mantenimientoUsuariosSap.htm"},method=RequestMethod.POST)
	public ModelAndView mantenimientoUsuariosSap(@RequestParam("tipoOperacion") int tipoOperacion,@ModelAttribute("mantenimientoUsuariosSapBean") MantenimientoUsuariosSapBean mantenimientoUsuariosSapBean) {
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("sistema/resultadoTransaccion");
		
		MensajeTransaccionBean mensajeTransaccionBean = mantenimientoUsuariosSapServicio.grabaTrasaccion(mantenimientoUsuariosSapBean, tipoOperacion);
		modelAndView.addObject("mensajeTransaccionBean", mensajeTransaccionBean);
		
		return modelAndView;
	}
	
	public void setMantenimientoUsuariosSapServicio(MantenimientoUsuariosSapServicio mantenimientoUsuariosSapServicio) {
		this.mantenimientoUsuariosSapServicio = mantenimientoUsuariosSapServicio;
	}
	
}
