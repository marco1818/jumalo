package com.bancoazteca.srcu.spring.servicios.administracion.mantenimientoUsuariosCentral;

import com.bancoazteca.srcu.spring.beans.administracion.mantenimientoUsuariosCentral.MantenimientoUsuariosCentralBean;
import com.bancoazteca.srcu.spring.beans.sistema.MensajeTransaccionBean;

public interface MantenimientoUsuariosCentralServicio {
	public MantenimientoUsuariosCentralBean consulta(MantenimientoUsuariosCentralBean mantenimientoUsuariosCentral, int tipoConsulta);
	public MensajeTransaccionBean grabaTransaccion(MantenimientoUsuariosCentralBean mantenimientoUsuariosCentralBean, int tipoOperacion); 
}
