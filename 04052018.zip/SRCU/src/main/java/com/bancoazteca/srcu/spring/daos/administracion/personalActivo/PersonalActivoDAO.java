package com.bancoazteca.srcu.spring.daos.administracion.personalActivo;

import java.util.List;

import com.bancoazteca.srcu.spring.beans.administracion.personalActivo.PersonalActivoBean;

public interface PersonalActivoDAO{
	public	List<PersonalActivoBean> consultaPersonalActivo(int gerenciaId);

}
