/**
 * Empleado.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.bancoazteca.srcu.spring.ws.administracion.empleados.axis;

public class Empleado  implements java.io.Serializable {
    /**
	 * 
	 */
	private static final long serialVersionUID = 4631253163014170497L;

	private java.lang.String empresa;

    private int numeroEmpleado;

    private java.lang.String idCompa�ia;

    private java.lang.String desCompa�ia;

    private java.lang.String nombreInicial;

    private java.lang.String apellidoPaterno;

    private java.lang.String apellidoMaterno;

    private java.lang.String genero;

    private java.lang.String estadoCivil;

    private int idCentroCostos;

    private java.lang.String desCentroCostos;

    private boolean activo;

    private java.lang.String idHorario;

    private java.lang.String desHorario;

    private int idPuesto;

    private java.lang.String desPuesto;

    private java.lang.String desPuestoBreve;

    private java.lang.String periodoPago;

    private java.lang.String idFuncion;

    private java.lang.String desFuncion;

    private int idDependencia;

    private java.lang.String desDependencia;

    private java.lang.String idPais;

    private int idPuestoJefe;

    private int idNumeroEmpleadoJefe;

    private java.lang.String cuentaBanco;

    private int idPuestoRH;

    private int idNumeroEmpleadoRH;

    private int idSucursal;

    private java.lang.String correoElectronico;

    private java.lang.String idNegocio;

    private java.lang.String desNegocio;

    private Direccion direccionEmpleado;

    private Sueldo sueldoEmpleado;

    private Fecha fechasEmpleado;

    private Afiliacion afiliacionEmpleado;

    private Nomina datosNomina;

    private Familia[] familiares;

    private Incapacidad[] incapacidades;

    private Subordinado[] subordinados;

    public Empleado() {
    }

    public Empleado(
           java.lang.String empresa,
           int numeroEmpleado,
           java.lang.String idCompa�ia,
           java.lang.String desCompa�ia,
           java.lang.String nombreInicial,
           java.lang.String apellidoPaterno,
           java.lang.String apellidoMaterno,
           java.lang.String genero,
           java.lang.String estadoCivil,
           int idCentroCostos,
           java.lang.String desCentroCostos,
           boolean activo,
           java.lang.String idHorario,
           java.lang.String desHorario,
           int idPuesto,
           java.lang.String desPuesto,
           java.lang.String desPuestoBreve,
           java.lang.String periodoPago,
           java.lang.String idFuncion,
           java.lang.String desFuncion,
           int idDependencia,
           java.lang.String desDependencia,
           java.lang.String idPais,
           int idPuestoJefe,
           int idNumeroEmpleadoJefe,
           java.lang.String cuentaBanco,
           int idPuestoRH,
           int idNumeroEmpleadoRH,
           int idSucursal,
           java.lang.String correoElectronico,
           java.lang.String idNegocio,
           java.lang.String desNegocio,
           Direccion direccionEmpleado,
           Sueldo sueldoEmpleado,
           Fecha fechasEmpleado,
           Afiliacion afiliacionEmpleado,
           Nomina datosNomina,
           Familia[] familiares,
           Incapacidad[] incapacidades,
           Subordinado[] subordinados) {
           this.empresa = empresa;
           this.numeroEmpleado = numeroEmpleado;
           this.idCompa�ia = idCompa�ia;
           this.desCompa�ia = desCompa�ia;
           this.nombreInicial = nombreInicial;
           this.apellidoPaterno = apellidoPaterno;
           this.apellidoMaterno = apellidoMaterno;
           this.genero = genero;
           this.estadoCivil = estadoCivil;
           this.idCentroCostos = idCentroCostos;
           this.desCentroCostos = desCentroCostos;
           this.activo = activo;
           this.idHorario = idHorario;
           this.desHorario = desHorario;
           this.idPuesto = idPuesto;
           this.desPuesto = desPuesto;
           this.desPuestoBreve = desPuestoBreve;
           this.periodoPago = periodoPago;
           this.idFuncion = idFuncion;
           this.desFuncion = desFuncion;
           this.idDependencia = idDependencia;
           this.desDependencia = desDependencia;
           this.idPais = idPais;
           this.idPuestoJefe = idPuestoJefe;
           this.idNumeroEmpleadoJefe = idNumeroEmpleadoJefe;
           this.cuentaBanco = cuentaBanco;
           this.idPuestoRH = idPuestoRH;
           this.idNumeroEmpleadoRH = idNumeroEmpleadoRH;
           this.idSucursal = idSucursal;
           this.correoElectronico = correoElectronico;
           this.idNegocio = idNegocio;
           this.desNegocio = desNegocio;
           this.direccionEmpleado = direccionEmpleado;
           this.sueldoEmpleado = sueldoEmpleado;
           this.fechasEmpleado = fechasEmpleado;
           this.afiliacionEmpleado = afiliacionEmpleado;
           this.datosNomina = datosNomina;
           this.familiares = familiares;
           this.incapacidades = incapacidades;
           this.subordinados = subordinados;
    }


    /**
     * Gets the empresa value for this Empleado.
     * 
     * @return empresa
     */
    public java.lang.String getEmpresa() {
        return empresa;
    }


    /**
     * Sets the empresa value for this Empleado.
     * 
     * @param empresa
     */
    public void setEmpresa(java.lang.String empresa) {
        this.empresa = empresa;
    }


    /**
     * Gets the numeroEmpleado value for this Empleado.
     * 
     * @return numeroEmpleado
     */
    public int getNumeroEmpleado() {
        return numeroEmpleado;
    }


    /**
     * Sets the numeroEmpleado value for this Empleado.
     * 
     * @param numeroEmpleado
     */
    public void setNumeroEmpleado(int numeroEmpleado) {
        this.numeroEmpleado = numeroEmpleado;
    }


    /**
     * Gets the idCompa�ia value for this Empleado.
     * 
     * @return idCompa�ia
     */
    public java.lang.String getIdCompa�ia() {
        return idCompa�ia;
    }


    /**
     * Sets the idCompa�ia value for this Empleado.
     * 
     * @param idCompa�ia
     */
    public void setIdCompa�ia(java.lang.String idCompa�ia) {
        this.idCompa�ia = idCompa�ia;
    }


    /**
     * Gets the desCompa�ia value for this Empleado.
     * 
     * @return desCompa�ia
     */
    public java.lang.String getDesCompa�ia() {
        return desCompa�ia;
    }


    /**
     * Sets the desCompa�ia value for this Empleado.
     * 
     * @param desCompa�ia
     */
    public void setDesCompa�ia(java.lang.String desCompa�ia) {
        this.desCompa�ia = desCompa�ia;
    }


    /**
     * Gets the nombreInicial value for this Empleado.
     * 
     * @return nombreInicial
     */
    public java.lang.String getNombreInicial() {
        return nombreInicial;
    }


    /**
     * Sets the nombreInicial value for this Empleado.
     * 
     * @param nombreInicial
     */
    public void setNombreInicial(java.lang.String nombreInicial) {
        this.nombreInicial = nombreInicial;
    }


    /**
     * Gets the apellidoPaterno value for this Empleado.
     * 
     * @return apellidoPaterno
     */
    public java.lang.String getApellidoPaterno() {
        return apellidoPaterno;
    }


    /**
     * Sets the apellidoPaterno value for this Empleado.
     * 
     * @param apellidoPaterno
     */
    public void setApellidoPaterno(java.lang.String apellidoPaterno) {
        this.apellidoPaterno = apellidoPaterno;
    }


    /**
     * Gets the apellidoMaterno value for this Empleado.
     * 
     * @return apellidoMaterno
     */
    public java.lang.String getApellidoMaterno() {
        return apellidoMaterno;
    }


    /**
     * Sets the apellidoMaterno value for this Empleado.
     * 
     * @param apellidoMaterno
     */
    public void setApellidoMaterno(java.lang.String apellidoMaterno) {
        this.apellidoMaterno = apellidoMaterno;
    }


    /**
     * Gets the genero value for this Empleado.
     * 
     * @return genero
     */
    public java.lang.String getGenero() {
        return genero;
    }


    /**
     * Sets the genero value for this Empleado.
     * 
     * @param genero
     */
    public void setGenero(java.lang.String genero) {
        this.genero = genero;
    }


    /**
     * Gets the estadoCivil value for this Empleado.
     * 
     * @return estadoCivil
     */
    public java.lang.String getEstadoCivil() {
        return estadoCivil;
    }


    /**
     * Sets the estadoCivil value for this Empleado.
     * 
     * @param estadoCivil
     */
    public void setEstadoCivil(java.lang.String estadoCivil) {
        this.estadoCivil = estadoCivil;
    }


    /**
     * Gets the idCentroCostos value for this Empleado.
     * 
     * @return idCentroCostos
     */
    public int getIdCentroCostos() {
        return idCentroCostos;
    }


    /**
     * Sets the idCentroCostos value for this Empleado.
     * 
     * @param idCentroCostos
     */
    public void setIdCentroCostos(int idCentroCostos) {
        this.idCentroCostos = idCentroCostos;
    }


    /**
     * Gets the desCentroCostos value for this Empleado.
     * 
     * @return desCentroCostos
     */
    public java.lang.String getDesCentroCostos() {
        return desCentroCostos;
    }


    /**
     * Sets the desCentroCostos value for this Empleado.
     * 
     * @param desCentroCostos
     */
    public void setDesCentroCostos(java.lang.String desCentroCostos) {
        this.desCentroCostos = desCentroCostos;
    }


    /**
     * Gets the activo value for this Empleado.
     * 
     * @return activo
     */
    public boolean isActivo() {
        return activo;
    }


    /**
     * Sets the activo value for this Empleado.
     * 
     * @param activo
     */
    public void setActivo(boolean activo) {
        this.activo = activo;
    }


    /**
     * Gets the idHorario value for this Empleado.
     * 
     * @return idHorario
     */
    public java.lang.String getIdHorario() {
        return idHorario;
    }


    /**
     * Sets the idHorario value for this Empleado.
     * 
     * @param idHorario
     */
    public void setIdHorario(java.lang.String idHorario) {
        this.idHorario = idHorario;
    }


    /**
     * Gets the desHorario value for this Empleado.
     * 
     * @return desHorario
     */
    public java.lang.String getDesHorario() {
        return desHorario;
    }


    /**
     * Sets the desHorario value for this Empleado.
     * 
     * @param desHorario
     */
    public void setDesHorario(java.lang.String desHorario) {
        this.desHorario = desHorario;
    }


    /**
     * Gets the idPuesto value for this Empleado.
     * 
     * @return idPuesto
     */
    public int getIdPuesto() {
        return idPuesto;
    }


    /**
     * Sets the idPuesto value for this Empleado.
     * 
     * @param idPuesto
     */
    public void setIdPuesto(int idPuesto) {
        this.idPuesto = idPuesto;
    }


    /**
     * Gets the desPuesto value for this Empleado.
     * 
     * @return desPuesto
     */
    public java.lang.String getDesPuesto() {
        return desPuesto;
    }


    /**
     * Sets the desPuesto value for this Empleado.
     * 
     * @param desPuesto
     */
    public void setDesPuesto(java.lang.String desPuesto) {
        this.desPuesto = desPuesto;
    }


    /**
     * Gets the desPuestoBreve value for this Empleado.
     * 
     * @return desPuestoBreve
     */
    public java.lang.String getDesPuestoBreve() {
        return desPuestoBreve;
    }


    /**
     * Sets the desPuestoBreve value for this Empleado.
     * 
     * @param desPuestoBreve
     */
    public void setDesPuestoBreve(java.lang.String desPuestoBreve) {
        this.desPuestoBreve = desPuestoBreve;
    }


    /**
     * Gets the periodoPago value for this Empleado.
     * 
     * @return periodoPago
     */
    public java.lang.String getPeriodoPago() {
        return periodoPago;
    }


    /**
     * Sets the periodoPago value for this Empleado.
     * 
     * @param periodoPago
     */
    public void setPeriodoPago(java.lang.String periodoPago) {
        this.periodoPago = periodoPago;
    }


    /**
     * Gets the idFuncion value for this Empleado.
     * 
     * @return idFuncion
     */
    public java.lang.String getIdFuncion() {
        return idFuncion;
    }


    /**
     * Sets the idFuncion value for this Empleado.
     * 
     * @param idFuncion
     */
    public void setIdFuncion(java.lang.String idFuncion) {
        this.idFuncion = idFuncion;
    }


    /**
     * Gets the desFuncion value for this Empleado.
     * 
     * @return desFuncion
     */
    public java.lang.String getDesFuncion() {
        return desFuncion;
    }


    /**
     * Sets the desFuncion value for this Empleado.
     * 
     * @param desFuncion
     */
    public void setDesFuncion(java.lang.String desFuncion) {
        this.desFuncion = desFuncion;
    }


    /**
     * Gets the idDependencia value for this Empleado.
     * 
     * @return idDependencia
     */
    public int getIdDependencia() {
        return idDependencia;
    }


    /**
     * Sets the idDependencia value for this Empleado.
     * 
     * @param idDependencia
     */
    public void setIdDependencia(int idDependencia) {
        this.idDependencia = idDependencia;
    }


    /**
     * Gets the desDependencia value for this Empleado.
     * 
     * @return desDependencia
     */
    public java.lang.String getDesDependencia() {
        return desDependencia;
    }


    /**
     * Sets the desDependencia value for this Empleado.
     * 
     * @param desDependencia
     */
    public void setDesDependencia(java.lang.String desDependencia) {
        this.desDependencia = desDependencia;
    }


    /**
     * Gets the idPais value for this Empleado.
     * 
     * @return idPais
     */
    public java.lang.String getIdPais() {
        return idPais;
    }


    /**
     * Sets the idPais value for this Empleado.
     * 
     * @param idPais
     */
    public void setIdPais(java.lang.String idPais) {
        this.idPais = idPais;
    }


    /**
     * Gets the idPuestoJefe value for this Empleado.
     * 
     * @return idPuestoJefe
     */
    public int getIdPuestoJefe() {
        return idPuestoJefe;
    }


    /**
     * Sets the idPuestoJefe value for this Empleado.
     * 
     * @param idPuestoJefe
     */
    public void setIdPuestoJefe(int idPuestoJefe) {
        this.idPuestoJefe = idPuestoJefe;
    }


    /**
     * Gets the idNumeroEmpleadoJefe value for this Empleado.
     * 
     * @return idNumeroEmpleadoJefe
     */
    public int getIdNumeroEmpleadoJefe() {
        return idNumeroEmpleadoJefe;
    }


    /**
     * Sets the idNumeroEmpleadoJefe value for this Empleado.
     * 
     * @param idNumeroEmpleadoJefe
     */
    public void setIdNumeroEmpleadoJefe(int idNumeroEmpleadoJefe) {
        this.idNumeroEmpleadoJefe = idNumeroEmpleadoJefe;
    }


    /**
     * Gets the cuentaBanco value for this Empleado.
     * 
     * @return cuentaBanco
     */
    public java.lang.String getCuentaBanco() {
        return cuentaBanco;
    }


    /**
     * Sets the cuentaBanco value for this Empleado.
     * 
     * @param cuentaBanco
     */
    public void setCuentaBanco(java.lang.String cuentaBanco) {
        this.cuentaBanco = cuentaBanco;
    }


    /**
     * Gets the idPuestoRH value for this Empleado.
     * 
     * @return idPuestoRH
     */
    public int getIdPuestoRH() {
        return idPuestoRH;
    }


    /**
     * Sets the idPuestoRH value for this Empleado.
     * 
     * @param idPuestoRH
     */
    public void setIdPuestoRH(int idPuestoRH) {
        this.idPuestoRH = idPuestoRH;
    }


    /**
     * Gets the idNumeroEmpleadoRH value for this Empleado.
     * 
     * @return idNumeroEmpleadoRH
     */
    public int getIdNumeroEmpleadoRH() {
        return idNumeroEmpleadoRH;
    }


    /**
     * Sets the idNumeroEmpleadoRH value for this Empleado.
     * 
     * @param idNumeroEmpleadoRH
     */
    public void setIdNumeroEmpleadoRH(int idNumeroEmpleadoRH) {
        this.idNumeroEmpleadoRH = idNumeroEmpleadoRH;
    }


    /**
     * Gets the idSucursal value for this Empleado.
     * 
     * @return idSucursal
     */
    public int getIdSucursal() {
        return idSucursal;
    }


    /**
     * Sets the idSucursal value for this Empleado.
     * 
     * @param idSucursal
     */
    public void setIdSucursal(int idSucursal) {
        this.idSucursal = idSucursal;
    }


    /**
     * Gets the correoElectronico value for this Empleado.
     * 
     * @return correoElectronico
     */
    public java.lang.String getCorreoElectronico() {
        return correoElectronico;
    }


    /**
     * Sets the correoElectronico value for this Empleado.
     * 
     * @param correoElectronico
     */
    public void setCorreoElectronico(java.lang.String correoElectronico) {
        this.correoElectronico = correoElectronico;
    }


    /**
     * Gets the idNegocio value for this Empleado.
     * 
     * @return idNegocio
     */
    public java.lang.String getIdNegocio() {
        return idNegocio;
    }


    /**
     * Sets the idNegocio value for this Empleado.
     * 
     * @param idNegocio
     */
    public void setIdNegocio(java.lang.String idNegocio) {
        this.idNegocio = idNegocio;
    }


    /**
     * Gets the desNegocio value for this Empleado.
     * 
     * @return desNegocio
     */
    public java.lang.String getDesNegocio() {
        return desNegocio;
    }


    /**
     * Sets the desNegocio value for this Empleado.
     * 
     * @param desNegocio
     */
    public void setDesNegocio(java.lang.String desNegocio) {
        this.desNegocio = desNegocio;
    }


    /**
     * Gets the direccionEmpleado value for this Empleado.
     * 
     * @return direccionEmpleado
     */
    public Direccion getDireccionEmpleado() {
        return direccionEmpleado;
    }


    /**
     * Sets the direccionEmpleado value for this Empleado.
     * 
     * @param direccionEmpleado
     */
    public void setDireccionEmpleado(Direccion direccionEmpleado) {
        this.direccionEmpleado = direccionEmpleado;
    }


    /**
     * Gets the sueldoEmpleado value for this Empleado.
     * 
     * @return sueldoEmpleado
     */
    public Sueldo getSueldoEmpleado() {
        return sueldoEmpleado;
    }


    /**
     * Sets the sueldoEmpleado value for this Empleado.
     * 
     * @param sueldoEmpleado
     */
    public void setSueldoEmpleado(Sueldo sueldoEmpleado) {
        this.sueldoEmpleado = sueldoEmpleado;
    }


    /**
     * Gets the fechasEmpleado value for this Empleado.
     * 
     * @return fechasEmpleado
     */
    public Fecha getFechasEmpleado() {
        return fechasEmpleado;
    }


    /**
     * Sets the fechasEmpleado value for this Empleado.
     * 
     * @param fechasEmpleado
     */
    public void setFechasEmpleado(Fecha fechasEmpleado) {
        this.fechasEmpleado = fechasEmpleado;
    }


    /**
     * Gets the afiliacionEmpleado value for this Empleado.
     * 
     * @return afiliacionEmpleado
     */
    public Afiliacion getAfiliacionEmpleado() {
        return afiliacionEmpleado;
    }


    /**
     * Sets the afiliacionEmpleado value for this Empleado.
     * 
     * @param afiliacionEmpleado
     */
    public void setAfiliacionEmpleado(Afiliacion afiliacionEmpleado) {
        this.afiliacionEmpleado = afiliacionEmpleado;
    }


    /**
     * Gets the datosNomina value for this Empleado.
     * 
     * @return datosNomina
     */
    public Nomina getDatosNomina() {
        return datosNomina;
    }


    /**
     * Sets the datosNomina value for this Empleado.
     * 
     * @param datosNomina
     */
    public void setDatosNomina(Nomina datosNomina) {
        this.datosNomina = datosNomina;
    }


    /**
     * Gets the familiares value for this Empleado.
     * 
     * @return familiares
     */
    public Familia[] getFamiliares() {
        return familiares;
    }


    /**
     * Sets the familiares value for this Empleado.
     * 
     * @param familiares
     */
    public void setFamiliares(Familia[] familiares) {
        this.familiares = familiares;
    }


    /**
     * Gets the incapacidades value for this Empleado.
     * 
     * @return incapacidades
     */
    public Incapacidad[] getIncapacidades() {
        return incapacidades;
    }


    /**
     * Sets the incapacidades value for this Empleado.
     * 
     * @param incapacidades
     */
    public void setIncapacidades(Incapacidad[] incapacidades) {
        this.incapacidades = incapacidades;
    }


    /**
     * Gets the subordinados value for this Empleado.
     * 
     * @return subordinados
     */
    public Subordinado[] getSubordinados() {
        return subordinados;
    }


    /**
     * Sets the subordinados value for this Empleado.
     * 
     * @param subordinados
     */
    public void setSubordinados(Subordinado[] subordinados) {
        this.subordinados = subordinados;
    }

    private java.lang.Object __equalsCalc = null;
    @SuppressWarnings("unused")
	public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Empleado)) return false;
        Empleado other = (Empleado) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.empresa==null && other.getEmpresa()==null) || 
             (this.empresa!=null &&
              this.empresa.equals(other.getEmpresa()))) &&
            this.numeroEmpleado == other.getNumeroEmpleado() &&
            ((this.idCompa�ia==null && other.getIdCompa�ia()==null) || 
             (this.idCompa�ia!=null &&
              this.idCompa�ia.equals(other.getIdCompa�ia()))) &&
            ((this.desCompa�ia==null && other.getDesCompa�ia()==null) || 
             (this.desCompa�ia!=null &&
              this.desCompa�ia.equals(other.getDesCompa�ia()))) &&
            ((this.nombreInicial==null && other.getNombreInicial()==null) || 
             (this.nombreInicial!=null &&
              this.nombreInicial.equals(other.getNombreInicial()))) &&
            ((this.apellidoPaterno==null && other.getApellidoPaterno()==null) || 
             (this.apellidoPaterno!=null &&
              this.apellidoPaterno.equals(other.getApellidoPaterno()))) &&
            ((this.apellidoMaterno==null && other.getApellidoMaterno()==null) || 
             (this.apellidoMaterno!=null &&
              this.apellidoMaterno.equals(other.getApellidoMaterno()))) &&
            ((this.genero==null && other.getGenero()==null) || 
             (this.genero!=null &&
              this.genero.equals(other.getGenero()))) &&
            ((this.estadoCivil==null && other.getEstadoCivil()==null) || 
             (this.estadoCivil!=null &&
              this.estadoCivil.equals(other.getEstadoCivil()))) &&
            this.idCentroCostos == other.getIdCentroCostos() &&
            ((this.desCentroCostos==null && other.getDesCentroCostos()==null) || 
             (this.desCentroCostos!=null &&
              this.desCentroCostos.equals(other.getDesCentroCostos()))) &&
            this.activo == other.isActivo() &&
            ((this.idHorario==null && other.getIdHorario()==null) || 
             (this.idHorario!=null &&
              this.idHorario.equals(other.getIdHorario()))) &&
            ((this.desHorario==null && other.getDesHorario()==null) || 
             (this.desHorario!=null &&
              this.desHorario.equals(other.getDesHorario()))) &&
            this.idPuesto == other.getIdPuesto() &&
            ((this.desPuesto==null && other.getDesPuesto()==null) || 
             (this.desPuesto!=null &&
              this.desPuesto.equals(other.getDesPuesto()))) &&
            ((this.desPuestoBreve==null && other.getDesPuestoBreve()==null) || 
             (this.desPuestoBreve!=null &&
              this.desPuestoBreve.equals(other.getDesPuestoBreve()))) &&
            ((this.periodoPago==null && other.getPeriodoPago()==null) || 
             (this.periodoPago!=null &&
              this.periodoPago.equals(other.getPeriodoPago()))) &&
            ((this.idFuncion==null && other.getIdFuncion()==null) || 
             (this.idFuncion!=null &&
              this.idFuncion.equals(other.getIdFuncion()))) &&
            ((this.desFuncion==null && other.getDesFuncion()==null) || 
             (this.desFuncion!=null &&
              this.desFuncion.equals(other.getDesFuncion()))) &&
            this.idDependencia == other.getIdDependencia() &&
            ((this.desDependencia==null && other.getDesDependencia()==null) || 
             (this.desDependencia!=null &&
              this.desDependencia.equals(other.getDesDependencia()))) &&
            ((this.idPais==null && other.getIdPais()==null) || 
             (this.idPais!=null &&
              this.idPais.equals(other.getIdPais()))) &&
            this.idPuestoJefe == other.getIdPuestoJefe() &&
            this.idNumeroEmpleadoJefe == other.getIdNumeroEmpleadoJefe() &&
            ((this.cuentaBanco==null && other.getCuentaBanco()==null) || 
             (this.cuentaBanco!=null &&
              this.cuentaBanco.equals(other.getCuentaBanco()))) &&
            this.idPuestoRH == other.getIdPuestoRH() &&
            this.idNumeroEmpleadoRH == other.getIdNumeroEmpleadoRH() &&
            this.idSucursal == other.getIdSucursal() &&
            ((this.correoElectronico==null && other.getCorreoElectronico()==null) || 
             (this.correoElectronico!=null &&
              this.correoElectronico.equals(other.getCorreoElectronico()))) &&
            ((this.idNegocio==null && other.getIdNegocio()==null) || 
             (this.idNegocio!=null &&
              this.idNegocio.equals(other.getIdNegocio()))) &&
            ((this.desNegocio==null && other.getDesNegocio()==null) || 
             (this.desNegocio!=null &&
              this.desNegocio.equals(other.getDesNegocio()))) &&
            ((this.direccionEmpleado==null && other.getDireccionEmpleado()==null) || 
             (this.direccionEmpleado!=null &&
              this.direccionEmpleado.equals(other.getDireccionEmpleado()))) &&
            ((this.sueldoEmpleado==null && other.getSueldoEmpleado()==null) || 
             (this.sueldoEmpleado!=null &&
              this.sueldoEmpleado.equals(other.getSueldoEmpleado()))) &&
            ((this.fechasEmpleado==null && other.getFechasEmpleado()==null) || 
             (this.fechasEmpleado!=null &&
              this.fechasEmpleado.equals(other.getFechasEmpleado()))) &&
            ((this.afiliacionEmpleado==null && other.getAfiliacionEmpleado()==null) || 
             (this.afiliacionEmpleado!=null &&
              this.afiliacionEmpleado.equals(other.getAfiliacionEmpleado()))) &&
            ((this.datosNomina==null && other.getDatosNomina()==null) || 
             (this.datosNomina!=null &&
              this.datosNomina.equals(other.getDatosNomina()))) &&
            ((this.familiares==null && other.getFamiliares()==null) || 
             (this.familiares!=null &&
              java.util.Arrays.equals(this.familiares, other.getFamiliares()))) &&
            ((this.incapacidades==null && other.getIncapacidades()==null) || 
             (this.incapacidades!=null &&
              java.util.Arrays.equals(this.incapacidades, other.getIncapacidades()))) &&
            ((this.subordinados==null && other.getSubordinados()==null) || 
             (this.subordinados!=null &&
              java.util.Arrays.equals(this.subordinados, other.getSubordinados())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getEmpresa() != null) {
            _hashCode += getEmpresa().hashCode();
        }
        _hashCode += getNumeroEmpleado();
        if (getIdCompa�ia() != null) {
            _hashCode += getIdCompa�ia().hashCode();
        }
        if (getDesCompa�ia() != null) {
            _hashCode += getDesCompa�ia().hashCode();
        }
        if (getNombreInicial() != null) {
            _hashCode += getNombreInicial().hashCode();
        }
        if (getApellidoPaterno() != null) {
            _hashCode += getApellidoPaterno().hashCode();
        }
        if (getApellidoMaterno() != null) {
            _hashCode += getApellidoMaterno().hashCode();
        }
        if (getGenero() != null) {
            _hashCode += getGenero().hashCode();
        }
        if (getEstadoCivil() != null) {
            _hashCode += getEstadoCivil().hashCode();
        }
        _hashCode += getIdCentroCostos();
        if (getDesCentroCostos() != null) {
            _hashCode += getDesCentroCostos().hashCode();
        }
        _hashCode += (isActivo() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        if (getIdHorario() != null) {
            _hashCode += getIdHorario().hashCode();
        }
        if (getDesHorario() != null) {
            _hashCode += getDesHorario().hashCode();
        }
        _hashCode += getIdPuesto();
        if (getDesPuesto() != null) {
            _hashCode += getDesPuesto().hashCode();
        }
        if (getDesPuestoBreve() != null) {
            _hashCode += getDesPuestoBreve().hashCode();
        }
        if (getPeriodoPago() != null) {
            _hashCode += getPeriodoPago().hashCode();
        }
        if (getIdFuncion() != null) {
            _hashCode += getIdFuncion().hashCode();
        }
        if (getDesFuncion() != null) {
            _hashCode += getDesFuncion().hashCode();
        }
        _hashCode += getIdDependencia();
        if (getDesDependencia() != null) {
            _hashCode += getDesDependencia().hashCode();
        }
        if (getIdPais() != null) {
            _hashCode += getIdPais().hashCode();
        }
        _hashCode += getIdPuestoJefe();
        _hashCode += getIdNumeroEmpleadoJefe();
        if (getCuentaBanco() != null) {
            _hashCode += getCuentaBanco().hashCode();
        }
        _hashCode += getIdPuestoRH();
        _hashCode += getIdNumeroEmpleadoRH();
        _hashCode += getIdSucursal();
        if (getCorreoElectronico() != null) {
            _hashCode += getCorreoElectronico().hashCode();
        }
        if (getIdNegocio() != null) {
            _hashCode += getIdNegocio().hashCode();
        }
        if (getDesNegocio() != null) {
            _hashCode += getDesNegocio().hashCode();
        }
        if (getDireccionEmpleado() != null) {
            _hashCode += getDireccionEmpleado().hashCode();
        }
        if (getSueldoEmpleado() != null) {
            _hashCode += getSueldoEmpleado().hashCode();
        }
        if (getFechasEmpleado() != null) {
            _hashCode += getFechasEmpleado().hashCode();
        }
        if (getAfiliacionEmpleado() != null) {
            _hashCode += getAfiliacionEmpleado().hashCode();
        }
        if (getDatosNomina() != null) {
            _hashCode += getDatosNomina().hashCode();
        }
        if (getFamiliares() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getFamiliares());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getFamiliares(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getIncapacidades() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getIncapacidades());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getIncapacidades(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getSubordinados() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getSubordinados());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getSubordinados(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Empleado.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Empleado"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("empresa");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Empresa"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroEmpleado");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "NumeroEmpleado"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("idCompa�ia");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "idCompa�ia"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("desCompa�ia");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "DesCompa�ia"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nombreInicial");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "NombreInicial"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("apellidoPaterno");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ApellidoPaterno"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("apellidoMaterno");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ApellidoMaterno"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("genero");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Genero"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("estadoCivil");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "EstadoCivil"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("idCentroCostos");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "idCentroCostos"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("desCentroCostos");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "DesCentroCostos"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("activo");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Activo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("idHorario");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "idHorario"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("desHorario");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "DesHorario"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("idPuesto");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "idPuesto"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("desPuesto");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "DesPuesto"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("desPuestoBreve");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "DesPuestoBreve"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("periodoPago");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "PeriodoPago"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("idFuncion");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "idFuncion"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("desFuncion");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "DesFuncion"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("idDependencia");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "idDependencia"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("desDependencia");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "DesDependencia"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("idPais");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "idPais"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("idPuestoJefe");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "idPuestoJefe"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("idNumeroEmpleadoJefe");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "idNumeroEmpleadoJefe"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("cuentaBanco");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "CuentaBanco"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("idPuestoRH");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "idPuestoRH"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("idNumeroEmpleadoRH");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "idNumeroEmpleadoRH"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("idSucursal");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "idSucursal"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("correoElectronico");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "CorreoElectronico"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("idNegocio");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "idNegocio"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("desNegocio");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "DesNegocio"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("direccionEmpleado");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "DireccionEmpleado"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Direccion"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("sueldoEmpleado");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "SueldoEmpleado"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Sueldo"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("fechasEmpleado");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "FechasEmpleado"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Fecha"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("afiliacionEmpleado");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "AfiliacionEmpleado"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Afiliacion"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("datosNomina");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "DatosNomina"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Nomina"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("familiares");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Familiares"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Familia"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Familia"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("incapacidades");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Incapacidades"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Incapacidad"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Incapacidad"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("subordinados");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Subordinados"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Subordinado"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Subordinado"));
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    @SuppressWarnings("rawtypes")
	public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    @SuppressWarnings("rawtypes")
	public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
