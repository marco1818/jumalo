/**
 * EmpleadoPromocion.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.bancoazteca.srcu.spring.ws.administracion.empleados.axis;
@SuppressWarnings({ "unused", "rawtypes" })
public class EmpleadoPromocion  implements java.io.Serializable {
    /**
	 * 
	 */
	private static final long serialVersionUID = 7569198138358675147L;

	private int idPromocion;

    private int numeroEmpleao;

    private java.util.Calendar fechaPromocion;

    private int idFuncionDestino;

    private java.lang.String funcionDestino;

    private int idFuncionOrigen;

    private java.lang.String funcionOrigen;

    public EmpleadoPromocion() {
    }

    public EmpleadoPromocion(
           int idPromocion,
           int numeroEmpleao,
           java.util.Calendar fechaPromocion,
           int idFuncionDestino,
           java.lang.String funcionDestino,
           int idFuncionOrigen,
           java.lang.String funcionOrigen) {
           this.idPromocion = idPromocion;
           this.numeroEmpleao = numeroEmpleao;
           this.fechaPromocion = fechaPromocion;
           this.idFuncionDestino = idFuncionDestino;
           this.funcionDestino = funcionDestino;
           this.idFuncionOrigen = idFuncionOrigen;
           this.funcionOrigen = funcionOrigen;
    }


    /**
     * Gets the idPromocion value for this EmpleadoPromocion.
     * 
     * @return idPromocion
     */
    public int getIdPromocion() {
        return idPromocion;
    }


    /**
     * Sets the idPromocion value for this EmpleadoPromocion.
     * 
     * @param idPromocion
     */
    public void setIdPromocion(int idPromocion) {
        this.idPromocion = idPromocion;
    }


    /**
     * Gets the numeroEmpleao value for this EmpleadoPromocion.
     * 
     * @return numeroEmpleao
     */
    public int getNumeroEmpleao() {
        return numeroEmpleao;
    }


    /**
     * Sets the numeroEmpleao value for this EmpleadoPromocion.
     * 
     * @param numeroEmpleao
     */
    public void setNumeroEmpleao(int numeroEmpleao) {
        this.numeroEmpleao = numeroEmpleao;
    }


    /**
     * Gets the fechaPromocion value for this EmpleadoPromocion.
     * 
     * @return fechaPromocion
     */
    public java.util.Calendar getFechaPromocion() {
        return fechaPromocion;
    }


    /**
     * Sets the fechaPromocion value for this EmpleadoPromocion.
     * 
     * @param fechaPromocion
     */
    public void setFechaPromocion(java.util.Calendar fechaPromocion) {
        this.fechaPromocion = fechaPromocion;
    }


    /**
     * Gets the idFuncionDestino value for this EmpleadoPromocion.
     * 
     * @return idFuncionDestino
     */
    public int getIdFuncionDestino() {
        return idFuncionDestino;
    }


    /**
     * Sets the idFuncionDestino value for this EmpleadoPromocion.
     * 
     * @param idFuncionDestino
     */
    public void setIdFuncionDestino(int idFuncionDestino) {
        this.idFuncionDestino = idFuncionDestino;
    }


    /**
     * Gets the funcionDestino value for this EmpleadoPromocion.
     * 
     * @return funcionDestino
     */
    public java.lang.String getFuncionDestino() {
        return funcionDestino;
    }


    /**
     * Sets the funcionDestino value for this EmpleadoPromocion.
     * 
     * @param funcionDestino
     */
    public void setFuncionDestino(java.lang.String funcionDestino) {
        this.funcionDestino = funcionDestino;
    }


    /**
     * Gets the idFuncionOrigen value for this EmpleadoPromocion.
     * 
     * @return idFuncionOrigen
     */
    public int getIdFuncionOrigen() {
        return idFuncionOrigen;
    }


    /**
     * Sets the idFuncionOrigen value for this EmpleadoPromocion.
     * 
     * @param idFuncionOrigen
     */
    public void setIdFuncionOrigen(int idFuncionOrigen) {
        this.idFuncionOrigen = idFuncionOrigen;
    }


    /**
     * Gets the funcionOrigen value for this EmpleadoPromocion.
     * 
     * @return funcionOrigen
     */
    public java.lang.String getFuncionOrigen() {
        return funcionOrigen;
    }


    /**
     * Sets the funcionOrigen value for this EmpleadoPromocion.
     * 
     * @param funcionOrigen
     */
    public void setFuncionOrigen(java.lang.String funcionOrigen) {
        this.funcionOrigen = funcionOrigen;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof EmpleadoPromocion)) return false;
        EmpleadoPromocion other = (EmpleadoPromocion) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this.idPromocion == other.getIdPromocion() &&
            this.numeroEmpleao == other.getNumeroEmpleao() &&
            ((this.fechaPromocion==null && other.getFechaPromocion()==null) || 
             (this.fechaPromocion!=null &&
              this.fechaPromocion.equals(other.getFechaPromocion()))) &&
            this.idFuncionDestino == other.getIdFuncionDestino() &&
            ((this.funcionDestino==null && other.getFuncionDestino()==null) || 
             (this.funcionDestino!=null &&
              this.funcionDestino.equals(other.getFuncionDestino()))) &&
            this.idFuncionOrigen == other.getIdFuncionOrigen() &&
            ((this.funcionOrigen==null && other.getFuncionOrigen()==null) || 
             (this.funcionOrigen!=null &&
              this.funcionOrigen.equals(other.getFuncionOrigen())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += getIdPromocion();
        _hashCode += getNumeroEmpleao();
        if (getFechaPromocion() != null) {
            _hashCode += getFechaPromocion().hashCode();
        }
        _hashCode += getIdFuncionDestino();
        if (getFuncionDestino() != null) {
            _hashCode += getFuncionDestino().hashCode();
        }
        _hashCode += getIdFuncionOrigen();
        if (getFuncionOrigen() != null) {
            _hashCode += getFuncionOrigen().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(EmpleadoPromocion.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "EmpleadoPromocion"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("idPromocion");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "IdPromocion"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroEmpleao");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "NumeroEmpleao"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("fechaPromocion");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "FechaPromocion"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("idFuncionDestino");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "IdFuncionDestino"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("funcionDestino");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "FuncionDestino"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("idFuncionOrigen");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "IdFuncionOrigen"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("funcionOrigen");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "FuncionOrigen"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
