package com.bancoazteca.srcu.spring.servicios.administracion.mantenimientoUsuariosAvante;

import com.bancoazteca.srcu.spring.beans.administracion.mantenimientoUsuariosAvante.MantenimientoUsuariosAvanteBean;
import com.bancoazteca.srcu.spring.beans.sistema.MensajeTransaccionBean;

public interface MantenimientoUsuariosAvanteServicio {
	public	MantenimientoUsuariosAvanteBean consulta(MantenimientoUsuariosAvanteBean mantenimientoUsuariosAvanteBean, int tipoConsulta);
	public	MensajeTransaccionBean grabaTransaccion(MantenimientoUsuariosAvanteBean mantenimientoUsuariosAvanteBean, int tipoOperacion);
}
