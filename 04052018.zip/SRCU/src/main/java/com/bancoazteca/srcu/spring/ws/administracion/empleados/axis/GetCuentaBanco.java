/**
 * GetCuentaBanco.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.bancoazteca.srcu.spring.ws.administracion.empleados.axis;
@SuppressWarnings({ "unused", "rawtypes" })
public class GetCuentaBanco  implements java.io.Serializable {
    /**
	 * 
	 */
	private static final long serialVersionUID = 385438522059408537L;

	private java.lang.String usuario;

    private java.lang.String contrasenia;

    private int empleado;

    private java.lang.String empresa;

    private java.lang.String cuentaBanco;

    private boolean existeError;

    private java.lang.String mensaje;

    public GetCuentaBanco() {
    }

    public GetCuentaBanco(
           java.lang.String usuario,
           java.lang.String contrasenia,
           int empleado,
           java.lang.String empresa,
           java.lang.String cuentaBanco,
           boolean existeError,
           java.lang.String mensaje) {
           this.usuario = usuario;
           this.contrasenia = contrasenia;
           this.empleado = empleado;
           this.empresa = empresa;
           this.cuentaBanco = cuentaBanco;
           this.existeError = existeError;
           this.mensaje = mensaje;
    }


    /**
     * Gets the usuario value for this GetCuentaBanco.
     * 
     * @return usuario
     */
    public java.lang.String getUsuario() {
        return usuario;
    }


    /**
     * Sets the usuario value for this GetCuentaBanco.
     * 
     * @param usuario
     */
    public void setUsuario(java.lang.String usuario) {
        this.usuario = usuario;
    }


    /**
     * Gets the contrasenia value for this GetCuentaBanco.
     * 
     * @return contrasenia
     */
    public java.lang.String getContrasenia() {
        return contrasenia;
    }


    /**
     * Sets the contrasenia value for this GetCuentaBanco.
     * 
     * @param contrasenia
     */
    public void setContrasenia(java.lang.String contrasenia) {
        this.contrasenia = contrasenia;
    }


    /**
     * Gets the empleado value for this GetCuentaBanco.
     * 
     * @return empleado
     */
    public int getEmpleado() {
        return empleado;
    }


    /**
     * Sets the empleado value for this GetCuentaBanco.
     * 
     * @param empleado
     */
    public void setEmpleado(int empleado) {
        this.empleado = empleado;
    }


    /**
     * Gets the empresa value for this GetCuentaBanco.
     * 
     * @return empresa
     */
    public java.lang.String getEmpresa() {
        return empresa;
    }


    /**
     * Sets the empresa value for this GetCuentaBanco.
     * 
     * @param empresa
     */
    public void setEmpresa(java.lang.String empresa) {
        this.empresa = empresa;
    }


    /**
     * Gets the cuentaBanco value for this GetCuentaBanco.
     * 
     * @return cuentaBanco
     */
    public java.lang.String getCuentaBanco() {
        return cuentaBanco;
    }


    /**
     * Sets the cuentaBanco value for this GetCuentaBanco.
     * 
     * @param cuentaBanco
     */
    public void setCuentaBanco(java.lang.String cuentaBanco) {
        this.cuentaBanco = cuentaBanco;
    }


    /**
     * Gets the existeError value for this GetCuentaBanco.
     * 
     * @return existeError
     */
    public boolean isExisteError() {
        return existeError;
    }


    /**
     * Sets the existeError value for this GetCuentaBanco.
     * 
     * @param existeError
     */
    public void setExisteError(boolean existeError) {
        this.existeError = existeError;
    }


    /**
     * Gets the mensaje value for this GetCuentaBanco.
     * 
     * @return mensaje
     */
    public java.lang.String getMensaje() {
        return mensaje;
    }


    /**
     * Sets the mensaje value for this GetCuentaBanco.
     * 
     * @param mensaje
     */
    public void setMensaje(java.lang.String mensaje) {
        this.mensaje = mensaje;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof GetCuentaBanco)) return false;
        GetCuentaBanco other = (GetCuentaBanco) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.usuario==null && other.getUsuario()==null) || 
             (this.usuario!=null &&
              this.usuario.equals(other.getUsuario()))) &&
            ((this.contrasenia==null && other.getContrasenia()==null) || 
             (this.contrasenia!=null &&
              this.contrasenia.equals(other.getContrasenia()))) &&
            this.empleado == other.getEmpleado() &&
            ((this.empresa==null && other.getEmpresa()==null) || 
             (this.empresa!=null &&
              this.empresa.equals(other.getEmpresa()))) &&
            ((this.cuentaBanco==null && other.getCuentaBanco()==null) || 
             (this.cuentaBanco!=null &&
              this.cuentaBanco.equals(other.getCuentaBanco()))) &&
            this.existeError == other.isExisteError() &&
            ((this.mensaje==null && other.getMensaje()==null) || 
             (this.mensaje!=null &&
              this.mensaje.equals(other.getMensaje())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getUsuario() != null) {
            _hashCode += getUsuario().hashCode();
        }
        if (getContrasenia() != null) {
            _hashCode += getContrasenia().hashCode();
        }
        _hashCode += getEmpleado();
        if (getEmpresa() != null) {
            _hashCode += getEmpresa().hashCode();
        }
        if (getCuentaBanco() != null) {
            _hashCode += getCuentaBanco().hashCode();
        }
        _hashCode += (isExisteError() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        if (getMensaje() != null) {
            _hashCode += getMensaje().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(GetCuentaBanco.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", ">getCuentaBanco"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("usuario");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Usuario"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("contrasenia");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Contrasenia"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("empleado");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Empleado"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("empresa");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Empresa"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("cuentaBanco");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "CuentaBanco"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("existeError");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("mensaje");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
