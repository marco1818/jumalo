package com.bancoazteca.srcu.spring.beans.utilerias;

import java.math.BigDecimal;

public class SimpleBean {
	private	int codigo;
	private String descripcion;
	
	public SimpleBean() {
		
	}

	public int getCodigo() {
		return codigo;
	}

	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}

	public void setCodigo(BigDecimal codigo) {
		this.codigo = codigo.intValue();
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	
	
	
}
