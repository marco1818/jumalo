package com.bancoazteca.srcu.spring.beans.administracion.mantenimientoUsuariosUnificado;

import java.math.BigDecimal;

public class EmpleadosBean {
	private	String numeroEmpleado;
	private String nombreEmpleado;
	private int puestoId;
	private String desptoDesc;
	private String puestoDesc;
	private String segmentoDesc;
	private int segmentoId;
	private int	plazaid;
	private	String	fechaAlta;
	public EmpleadosBean() {
		
	}

	public String getNumeroEmpleado() {
		return numeroEmpleado;
	}

	public void setNumeroEmpleado(String numeroEmpleado) {
		this.numeroEmpleado = numeroEmpleado;
	}

	public String getNombreEmpleado() {
		return nombreEmpleado;
	}

	public void setNombreEmpleado(String nombreEmpleado) {
		this.nombreEmpleado = nombreEmpleado;
	}

	public int getPuestoId() {
		return puestoId;
	}

	public void setPuestoId(int puestoId) {
		this.puestoId = puestoId;
	}
	
	public void setPuestoId(BigDecimal puestoId) {
		this.puestoId = puestoId.intValue();
	}

	public String getDesptoDesc() {
		return desptoDesc;
	}

	public void setDesptoDesc(String desptoDesc) {
		this.desptoDesc = desptoDesc;
	}

	public String getPuestoDesc() {
		return puestoDesc;
	}

	public void setPuestoDesc(String puestoDesc) {
		this.puestoDesc = puestoDesc;
	}

	public String getSegmentoDesc() {
		return segmentoDesc;
	}

	public void setSegmentoDesc(String segmentoDesc) {
		this.segmentoDesc = segmentoDesc;
	}

	public int getSegmentoId() {
		return segmentoId;
	}

	public void setSegmentoId(int segmentoId) {
		this.segmentoId = segmentoId;
	}
	
	public void setSegmentoId(BigDecimal segmentoId) {
		this.segmentoId = segmentoId.intValue();
	}

	public int getPlazaid() {
		return plazaid;
	}

	public void setPlazaid(int plazaid) {
		this.plazaid = plazaid;
	}
	
	public void setPlazaid(BigDecimal plazaid) {
		this.plazaid = plazaid.intValue();
	}

	public String getFechaAlta() {
		return fechaAlta;
	}

	public void setFechaAlta(String fechaAlta) {
		this.fechaAlta = fechaAlta;
	}
}
