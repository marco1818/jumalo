package com.bancoazteca.srcu.spring.beans.administracion.personalActivo;

import java.math.BigDecimal;

public class VacantesSrcuBean {
	private int	deptoId;
	private String deptoDesc;
	private int segmento;
	private int totalVirtuales;
	
	public VacantesSrcuBean() {
		
	}
	
	public int getDeptoId() {
		return deptoId;
	}
	public void setDeptoId(int deptoId) {
		this.deptoId = deptoId;
	}
	public void setDeptoId(BigDecimal deptoId) {
		this.deptoId = deptoId.intValue();
	}
	public String getDeptoDesc() {
		return deptoDesc;
	}
	public void setDeptoDesc(String deptoDesc) {
		this.deptoDesc = deptoDesc;
	}
	public int getSegmento() {
		return segmento;
	}
	public void setSegmento(int segmento) {
		this.segmento = segmento;
	}
	public void setSegmento(BigDecimal segmento) {
		this.segmento = segmento.intValue();
	}
	public int getTotalVirtuales() {
		return totalVirtuales;
	}
	public void setTotalVirtuales(int totalVirtuales) {
		this.totalVirtuales = totalVirtuales;
	}
	public void setTotalVirtuales(BigDecimal totalVirtuales) {
		this.totalVirtuales = totalVirtuales.intValue();
	}
}
