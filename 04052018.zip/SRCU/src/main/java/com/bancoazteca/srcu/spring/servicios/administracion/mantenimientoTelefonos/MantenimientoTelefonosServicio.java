package com.bancoazteca.srcu.spring.servicios.administracion.mantenimientoTelefonos;

import com.bancoazteca.srcu.spring.beans.administracion.mantenimientoTelefonos.MantenimientoTelefonosBean;
import com.bancoazteca.srcu.spring.beans.sistema.MensajeTransaccionBean;

public interface MantenimientoTelefonosServicio {
	public	MensajeTransaccionBean	grabaTransaccion(int tipoOperacion, MantenimientoTelefonosBean mantenimientoTelefonosBean);
	public	MantenimientoTelefonosBean consulta(int tipoConsulta,MantenimientoTelefonosBean mantenimientoTelefonosBean);
}
