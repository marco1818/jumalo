package com.bancoazteca.srcu.spring.servicios.seguridad;

import java.util.logging.Logger;

import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
//import org.springframework.security.web.authentication.WebAuthenticationDetails;
import org.springframework.stereotype.Component;

@Component
public class AutenticacionServicio implements AuthenticationProvider{
	private final static Logger logger = Logger.getLogger("AuthenticationProvider");
	@Override
	public Authentication authenticate(Authentication authentication) throws AuthenticationException {
		logger.info("Autenticando a:"+authentication.getName());
//		WebAuthenticationDetails  webAuthenticationDetails = (WebAuthenticationDetails) authentication.getDetails();
		return  new UsernamePasswordAuthenticationToken("mluis", "123");
	}

	@Override
	public boolean supports(Class<?> authentication) {
		return true;
	}
	
}
