package com.bancoazteca.srcu.spring.beans.administracion.mantenimientoUsuariosAvante;

import java.math.BigDecimal;

public class DepartamentosAvanteBean {
	private int	departamentoId;
	private String descripcionDepto;
	
	public DepartamentosAvanteBean() {
		
	}

	public int getDepartamentoId() {
		return departamentoId;
	}

	public void setDepartamentoId(int departamentoId) {
		this.departamentoId = departamentoId;
	}
	
	public void setDepartamentoId(BigDecimal departamentoId) {
		this.departamentoId = departamentoId.intValue();
	}
	
	public String getDescripcionDepto() {
		return descripcionDepto;
	}

	public void setDescripcionDepto(String descripcionDepto) {
		this.descripcionDepto = descripcionDepto;
	}
	
}
