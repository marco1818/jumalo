/**
 * Coincidencia.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.bancoazteca.srcu.spring.ws.administracion.empleados.axis;

public class Coincidencia  implements java.io.Serializable {

	private static final long serialVersionUID = 8775395567765781716L;

	private java.lang.String empresa;

    private int numeroEmpleado;

    private java.lang.String nombreCompleto;

    private boolean activo;

    private java.lang.String idCompa�ia;

    public Coincidencia() {
    }

    public Coincidencia(
           java.lang.String empresa,
           int numeroEmpleado,
           java.lang.String nombreCompleto,
           boolean activo,
           java.lang.String idCompa�ia) {
           this.empresa = empresa;
           this.numeroEmpleado = numeroEmpleado;
           this.nombreCompleto = nombreCompleto;
           this.activo = activo;
           this.idCompa�ia = idCompa�ia;
    }


    /**
     * Gets the empresa value for this Coincidencia.
     * 
     * @return empresa
     */
    public java.lang.String getEmpresa() {
        return empresa;
    }


    /**
     * Sets the empresa value for this Coincidencia.
     * 
     * @param empresa
     */
    public void setEmpresa(java.lang.String empresa) {
        this.empresa = empresa;
    }


    /**
     * Gets the numeroEmpleado value for this Coincidencia.
     * 
     * @return numeroEmpleado
     */
    public int getNumeroEmpleado() {
        return numeroEmpleado;
    }


    /**
     * Sets the numeroEmpleado value for this Coincidencia.
     * 
     * @param numeroEmpleado
     */
    public void setNumeroEmpleado(int numeroEmpleado) {
        this.numeroEmpleado = numeroEmpleado;
    }


    /**
     * Gets the nombreCompleto value for this Coincidencia.
     * 
     * @return nombreCompleto
     */
    public java.lang.String getNombreCompleto() {
        return nombreCompleto;
    }


    /**
     * Sets the nombreCompleto value for this Coincidencia.
     * 
     * @param nombreCompleto
     */
    public void setNombreCompleto(java.lang.String nombreCompleto) {
        this.nombreCompleto = nombreCompleto;
    }


    /**
     * Gets the activo value for this Coincidencia.
     * 
     * @return activo
     */
    public boolean isActivo() {
        return activo;
    }


    /**
     * Sets the activo value for this Coincidencia.
     * 
     * @param activo
     */
    public void setActivo(boolean activo) {
        this.activo = activo;
    }


    /**
     * Gets the idCompa�ia value for this Coincidencia.
     * 
     * @return idCompa�ia
     */
    public java.lang.String getIdCompa�ia() {
        return idCompa�ia;
    }


    /**
     * Sets the idCompa�ia value for this Coincidencia.
     * 
     * @param idCompa�ia
     */
    public void setIdCompa�ia(java.lang.String idCompa�ia) {
        this.idCompa�ia = idCompa�ia;
    }

    private java.lang.Object __equalsCalc = null;
    @SuppressWarnings("unused")
	public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Coincidencia)) return false;
        Coincidencia other = (Coincidencia) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.empresa==null && other.getEmpresa()==null) || 
             (this.empresa!=null &&
              this.empresa.equals(other.getEmpresa()))) &&
            this.numeroEmpleado == other.getNumeroEmpleado() &&
            ((this.nombreCompleto==null && other.getNombreCompleto()==null) || 
             (this.nombreCompleto!=null &&
              this.nombreCompleto.equals(other.getNombreCompleto()))) &&
            this.activo == other.isActivo() &&
            ((this.idCompa�ia==null && other.getIdCompa�ia()==null) || 
             (this.idCompa�ia!=null &&
              this.idCompa�ia.equals(other.getIdCompa�ia())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getEmpresa() != null) {
            _hashCode += getEmpresa().hashCode();
        }
        _hashCode += getNumeroEmpleado();
        if (getNombreCompleto() != null) {
            _hashCode += getNombreCompleto().hashCode();
        }
        _hashCode += (isActivo() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        if (getIdCompa�ia() != null) {
            _hashCode += getIdCompa�ia().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Coincidencia.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Coincidencia"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("empresa");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Empresa"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroEmpleado");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "NumeroEmpleado"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nombreCompleto");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "NombreCompleto"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("activo");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Activo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("idCompa�ia");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "idCompa�ia"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    @SuppressWarnings("rawtypes")
	public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    @SuppressWarnings("rawtypes")
	public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
