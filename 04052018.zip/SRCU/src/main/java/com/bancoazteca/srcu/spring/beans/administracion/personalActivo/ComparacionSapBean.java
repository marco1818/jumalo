package com.bancoazteca.srcu.spring.beans.administracion.personalActivo;

public class ComparacionSapBean {
	private int	deptoId;
	private int funcionSap;
	private int vacantesSrcu;
	private int vacantesSap;
	private int segmento;
	private String segmentoDesc;
	private int diferencia;
	private String diferenciaDesc;
	
	public ComparacionSapBean() {
		
	}
	
	public ComparacionSapBean(int deptoId, int funcionSap, int vacantesSrcu, int vacantesSap, int segmento, int diferencia) {
		this.deptoId = deptoId;
		this.funcionSap = funcionSap;
		this.vacantesSap = vacantesSap;
		this.vacantesSrcu = vacantesSrcu;
		this.segmento = segmento;
		this.diferencia = diferencia;
	}
	
	
	public int getDeptoId() {
		return deptoId;
	}
	public void setDeptoId(int deptoId) {
		this.deptoId = deptoId;
	}
	public int getFuncionSap() {
		return funcionSap;
	}
	public void setFuncionSap(int funcionSap) {
		this.funcionSap = funcionSap;
	}
	
	public int getVacantesSrcu() {
		return vacantesSrcu;
	}

	public void setVacantesSrcu(int vacantesSrcu) {
		this.vacantesSrcu = vacantesSrcu;
	}

	public int getVacantesSap() {
		return vacantesSap;
	}
	public void setVacantesSap(int vacantesSap) {
		this.vacantesSap = vacantesSap;
	}
	public int getSegmento() {
		return segmento;
	}
	public void setSegmento(int segmento) {
		this.segmento = segmento;
	}
	public int getDiferencia() {
		return diferencia;
	}
	public void setDiferencia(int diferencia) {
		this.diferencia = diferencia;
	}

	public String getSegmentoDesc() {
		return segmentoDesc;
	}

	public void setSegmentoDesc(String segmentoDesc) {
		this.segmentoDesc = segmentoDesc;
	}

	public String getDiferenciaDesc() {
		return diferenciaDesc;
	}

	public void setDiferenciaDesc(String diferenciaDesc) {
		this.diferenciaDesc = diferenciaDesc;
	}
	
}
