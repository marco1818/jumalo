/**
 * TABLE_OF_BAPIRETURN1Holder.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.bancoazteca.srcu.spring.ws.administracion.posicionesSap.axis.consultaPosicionesSap;

public final class TABLE_OF_BAPIRETURN1Holder implements javax.xml.rpc.holders.Holder {
    public BAPIRETURN1[] value;

    public TABLE_OF_BAPIRETURN1Holder() {
    }

    public TABLE_OF_BAPIRETURN1Holder(BAPIRETURN1[] value) {
        this.value = value;
    }

}
