/**
 * Fecha.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.bancoazteca.srcu.spring.ws.administracion.empleados.axis;
@SuppressWarnings({ "unused", "rawtypes" })
public class Fecha  implements java.io.Serializable {
    /**
	 * 
	 */
	private static final long serialVersionUID = -3327019003872590976L;

	private int fechaAntiguedad;

    private int fechaAltaTecnica;

    private int fechaIngreso;

    private int fechaBaja;

    private int fechaNacimiento;

    private int fechaMovimiento;

    public Fecha() {
    }

    public Fecha(
           int fechaAntiguedad,
           int fechaAltaTecnica,
           int fechaIngreso,
           int fechaBaja,
           int fechaNacimiento,
           int fechaMovimiento) {
           this.fechaAntiguedad = fechaAntiguedad;
           this.fechaAltaTecnica = fechaAltaTecnica;
           this.fechaIngreso = fechaIngreso;
           this.fechaBaja = fechaBaja;
           this.fechaNacimiento = fechaNacimiento;
           this.fechaMovimiento = fechaMovimiento;
    }


    /**
     * Gets the fechaAntiguedad value for this Fecha.
     * 
     * @return fechaAntiguedad
     */
    public int getFechaAntiguedad() {
        return fechaAntiguedad;
    }


    /**
     * Sets the fechaAntiguedad value for this Fecha.
     * 
     * @param fechaAntiguedad
     */
    public void setFechaAntiguedad(int fechaAntiguedad) {
        this.fechaAntiguedad = fechaAntiguedad;
    }


    /**
     * Gets the fechaAltaTecnica value for this Fecha.
     * 
     * @return fechaAltaTecnica
     */
    public int getFechaAltaTecnica() {
        return fechaAltaTecnica;
    }


    /**
     * Sets the fechaAltaTecnica value for this Fecha.
     * 
     * @param fechaAltaTecnica
     */
    public void setFechaAltaTecnica(int fechaAltaTecnica) {
        this.fechaAltaTecnica = fechaAltaTecnica;
    }


    /**
     * Gets the fechaIngreso value for this Fecha.
     * 
     * @return fechaIngreso
     */
    public int getFechaIngreso() {
        return fechaIngreso;
    }


    /**
     * Sets the fechaIngreso value for this Fecha.
     * 
     * @param fechaIngreso
     */
    public void setFechaIngreso(int fechaIngreso) {
        this.fechaIngreso = fechaIngreso;
    }


    /**
     * Gets the fechaBaja value for this Fecha.
     * 
     * @return fechaBaja
     */
    public int getFechaBaja() {
        return fechaBaja;
    }


    /**
     * Sets the fechaBaja value for this Fecha.
     * 
     * @param fechaBaja
     */
    public void setFechaBaja(int fechaBaja) {
        this.fechaBaja = fechaBaja;
    }


    /**
     * Gets the fechaNacimiento value for this Fecha.
     * 
     * @return fechaNacimiento
     */
    public int getFechaNacimiento() {
        return fechaNacimiento;
    }


    /**
     * Sets the fechaNacimiento value for this Fecha.
     * 
     * @param fechaNacimiento
     */
    public void setFechaNacimiento(int fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }


    /**
     * Gets the fechaMovimiento value for this Fecha.
     * 
     * @return fechaMovimiento
     */
    public int getFechaMovimiento() {
        return fechaMovimiento;
    }


    /**
     * Sets the fechaMovimiento value for this Fecha.
     * 
     * @param fechaMovimiento
     */
    public void setFechaMovimiento(int fechaMovimiento) {
        this.fechaMovimiento = fechaMovimiento;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Fecha)) return false;
        Fecha other = (Fecha) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this.fechaAntiguedad == other.getFechaAntiguedad() &&
            this.fechaAltaTecnica == other.getFechaAltaTecnica() &&
            this.fechaIngreso == other.getFechaIngreso() &&
            this.fechaBaja == other.getFechaBaja() &&
            this.fechaNacimiento == other.getFechaNacimiento() &&
            this.fechaMovimiento == other.getFechaMovimiento();
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += getFechaAntiguedad();
        _hashCode += getFechaAltaTecnica();
        _hashCode += getFechaIngreso();
        _hashCode += getFechaBaja();
        _hashCode += getFechaNacimiento();
        _hashCode += getFechaMovimiento();
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Fecha.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Fecha"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("fechaAntiguedad");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "FechaAntiguedad"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("fechaAltaTecnica");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "FechaAltaTecnica"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("fechaIngreso");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "FechaIngreso"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("fechaBaja");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "FechaBaja"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("fechaNacimiento");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "FechaNacimiento"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("fechaMovimiento");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "FechaMovimiento"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
