package com.bancoazteca.srcu.spring.servicios.administracion.mantenimientoUsuariosAvante;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bancoazteca.srcu.spring.beans.administracion.mantenimientoUsuariosAvante.MantenimientoUsuariosAvanteBean;
import com.bancoazteca.srcu.spring.beans.sistema.MensajeTransaccionBean;
import com.bancoazteca.srcu.spring.daos.administracion.mantenimientoUsuariosAvante.MantenimientoUsuariosAvanteDAO;
import com.bancoazteca.srcu.spring.servicios.utilerias.BaseServicio;
import com.bancoazteca.srcu.spring.ws.administracion.empleados.DatosEmpleadoImpl;
import com.bancoazteca.srcu.spring.ws.administracion.empleados.axis.Empleado;

@Service
public class MantenimientoUsuariosAvanteServicioImpl extends BaseServicio implements MantenimientoUsuariosAvanteServicio{

	public interface Enum_Consultas_MantenimientoUsuariosAvanteServicio {
		int	consultaPuestosAvante			=	1;
		int	consultaCoordinadores			=	2;
		int	consultaEmpleados				=	3;
	}
	
	public interface Enum_Operaciones_MantenimientoUsuariosAvanteServicio{
		int	altaUsuarioAvante	=	1;
		int	bajaUsuarioAvante	=	2;
	}
	
	@Autowired
	MantenimientoUsuariosAvanteDAO mantenimientoUsuariosAvanteDAO;
	
	@Autowired
	DatosEmpleadoImpl datosEmpleadoImpl;
	
	@Override
	public MantenimientoUsuariosAvanteBean consulta(MantenimientoUsuariosAvanteBean mantenimientoUsuariosAvante,
			int tipoConsulta) {
		MantenimientoUsuariosAvanteBean mantenimientoUsuariosAvanteBean = new MantenimientoUsuariosAvanteBean();
		
		switch (tipoConsulta) {
		case Enum_Consultas_MantenimientoUsuariosAvanteServicio.consultaPuestosAvante:
			mantenimientoUsuariosAvanteBean.setPuestosAlta(mantenimientoUsuariosAvanteDAO.consultaPuestosAvante(mantenimientoUsuariosAvante.getEmpleadoOpera()));
			break;
		case Enum_Consultas_MantenimientoUsuariosAvanteServicio.consultaCoordinadores:
			mantenimientoUsuariosAvanteBean.setJefesAvante(mantenimientoUsuariosAvanteDAO.consultaCoordinadores());
			break;
		case Enum_Consultas_MantenimientoUsuariosAvanteServicio.consultaEmpleados:			
			mantenimientoUsuariosAvanteBean.setEmpleadosAvante(mantenimientoUsuariosAvanteDAO.consultaEmpleados(mantenimientoUsuariosAvante.getJefeOperar(), mantenimientoUsuariosAvante.getPuestoOperar()));
			break;
			
		default:
			break;
		}
		
		
		return mantenimientoUsuariosAvanteBean;
	}

	@Override
	public MensajeTransaccionBean grabaTransaccion(MantenimientoUsuariosAvanteBean mantenimientoUsuariosAvanteBean,
			int tipoOperacion) {
		MensajeTransaccionBean mensajeTransaccionBean = new MensajeTransaccionBean();
		
		switch (tipoOperacion) {
		case Enum_Operaciones_MantenimientoUsuariosAvanteServicio.altaUsuarioAvante:
			mensajeTransaccionBean = altaEmpleadoAvante(mantenimientoUsuariosAvanteBean);
			break;
		case Enum_Operaciones_MantenimientoUsuariosAvanteServicio.bajaUsuarioAvante:
			mensajeTransaccionBean = mantenimientoUsuariosAvanteDAO.bajaUsuarioAvante(mantenimientoUsuariosAvanteBean);
			break;
		default:
			break;
		}
		
		return mensajeTransaccionBean;
	}
	
	private MensajeTransaccionBean altaEmpleadoAvante(MantenimientoUsuariosAvanteBean mantenimientoUsuariosAvanteBean) {
		MensajeTransaccionBean mensajeTransaccionBean = new MensajeTransaccionBean();
		Empleado empleado = datosEmpleadoImpl.consultaEmpleadoSap(mantenimientoUsuariosAvanteBean.getEmpleadoAlta());
		
		if(empleado.getNumeroEmpleado() == 0) {
			mensajeTransaccionBean.setNumeroMensaje(999);
			mensajeTransaccionBean.setDescripcionMensaje("No se encontro informacion del Empleado en SAP.");
			return mensajeTransaccionBean;
		}
		
		mensajeTransaccionBean = mantenimientoUsuariosAvanteDAO.altaUsuarioAvante(mantenimientoUsuariosAvanteBean);
		
		return mensajeTransaccionBean;
	}

}
