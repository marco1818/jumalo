/**
 * ZSN_REG_CRED_CONSUL_POS_CECOLocator.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.bancoazteca.srcu.spring.ws.administracion.posicionesSap.axis.consultaPosicionesSap;

@SuppressWarnings("serial")
public class ZSN_REG_CRED_CONSUL_POS_CECOLocator extends org.apache.axis.client.Service implements ZSN_REG_CRED_CONSUL_POS_CECO {

    public ZSN_REG_CRED_CONSUL_POS_CECOLocator() {
    }


    public ZSN_REG_CRED_CONSUL_POS_CECOLocator(org.apache.axis.EngineConfiguration config) {
        super(config);
    }

    public ZSN_REG_CRED_CONSUL_POS_CECOLocator(java.lang.String wsdlLoc, javax.xml.namespace.QName sName) throws javax.xml.rpc.ServiceException {
        super(wsdlLoc, sName);
    }

    // Use to get a proxy class for ZBN_REG_CRED_CONSUL_POS_CECO
    private java.lang.String ZBN_REG_CRED_CONSUL_POS_CECO_address = "http://10.60.25.96:8000/sap/bc/srt/rfc/sap/zsd_reg_cred_consul_pos_ceco/700/zsn_reg_cred_consul_pos_ceco/zbn_reg_cred_consul_pos_ceco";

    public java.lang.String getZBN_REG_CRED_CONSUL_POS_CECOAddress() {
        return ZBN_REG_CRED_CONSUL_POS_CECO_address;
    }

    // The WSDD service name defaults to the port name.
    private java.lang.String ZBN_REG_CRED_CONSUL_POS_CECOWSDDServiceName = "ZBN_REG_CRED_CONSUL_POS_CECO";

    public java.lang.String getZBN_REG_CRED_CONSUL_POS_CECOWSDDServiceName() {
        return ZBN_REG_CRED_CONSUL_POS_CECOWSDDServiceName;
    }

    public void setZBN_REG_CRED_CONSUL_POS_CECOWSDDServiceName(java.lang.String name) {
        ZBN_REG_CRED_CONSUL_POS_CECOWSDDServiceName = name;
    }

    public ZSD_REG_CRED_CONSUL_POS_CECO getZBN_REG_CRED_CONSUL_POS_CECO() throws javax.xml.rpc.ServiceException {
       java.net.URL endpoint;
        try {
            endpoint = new java.net.URL(ZBN_REG_CRED_CONSUL_POS_CECO_address);
        }
        catch (java.net.MalformedURLException e) {
            throw new javax.xml.rpc.ServiceException(e);
        }
        return getZBN_REG_CRED_CONSUL_POS_CECO(endpoint);
    }

    public ZSD_REG_CRED_CONSUL_POS_CECO getZBN_REG_CRED_CONSUL_POS_CECO(java.net.URL portAddress) throws javax.xml.rpc.ServiceException {
        try {
            ZBN_REG_CRED_CONSUL_POS_CECOStub _stub = new ZBN_REG_CRED_CONSUL_POS_CECOStub(portAddress, this);
            _stub.setPortName(getZBN_REG_CRED_CONSUL_POS_CECOWSDDServiceName());
            return _stub;
        }
        catch (org.apache.axis.AxisFault e) {
            return null;
        }
    }

    public void setZBN_REG_CRED_CONSUL_POS_CECOEndpointAddress(java.lang.String address) {
        ZBN_REG_CRED_CONSUL_POS_CECO_address = address;
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    @SuppressWarnings("rawtypes")
	public java.rmi.Remote getPort(Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        try {
            if (ZSD_REG_CRED_CONSUL_POS_CECO.class.isAssignableFrom(serviceEndpointInterface)) {
                ZBN_REG_CRED_CONSUL_POS_CECOStub _stub = new ZBN_REG_CRED_CONSUL_POS_CECOStub(new java.net.URL(ZBN_REG_CRED_CONSUL_POS_CECO_address), this);
                _stub.setPortName(getZBN_REG_CRED_CONSUL_POS_CECOWSDDServiceName());
                return _stub;
            }
        }
        catch (java.lang.Throwable t) {
            throw new javax.xml.rpc.ServiceException(t);
        }
        throw new javax.xml.rpc.ServiceException("There is no stub implementation for the interface:  " + (serviceEndpointInterface == null ? "null" : serviceEndpointInterface.getName()));
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    @SuppressWarnings("rawtypes")
	public java.rmi.Remote getPort(javax.xml.namespace.QName portName, Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        if (portName == null) {
            return getPort(serviceEndpointInterface);
        }
        java.lang.String inputPortName = portName.getLocalPart();
        if ("ZBN_REG_CRED_CONSUL_POS_CECO".equals(inputPortName)) {
            return getZBN_REG_CRED_CONSUL_POS_CECO();
        }
        else  {
            java.rmi.Remote _stub = getPort(serviceEndpointInterface);
            ((org.apache.axis.client.Stub) _stub).setPortName(portName);
            return _stub;
        }
    }

    public javax.xml.namespace.QName getServiceName() {
        return new javax.xml.namespace.QName("urn:sap-com:document:sap:rfc:functions", "ZSN_REG_CRED_CONSUL_POS_CECO");
    }

    @SuppressWarnings("rawtypes")
	private java.util.HashSet ports = null;

    @SuppressWarnings({ "rawtypes", "unchecked" })
	public java.util.Iterator getPorts() {
        if (ports == null) {
            ports = new java.util.HashSet();
            ports.add(new javax.xml.namespace.QName("urn:sap-com:document:sap:rfc:functions", "ZBN_REG_CRED_CONSUL_POS_CECO"));
        }
        return ports.iterator();
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(java.lang.String portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        
if ("ZBN_REG_CRED_CONSUL_POS_CECO".equals(portName)) {
            setZBN_REG_CRED_CONSUL_POS_CECOEndpointAddress(address);
        }
        else 
{ // Unknown Port Name
            throw new javax.xml.rpc.ServiceException(" Cannot set Endpoint Address for Unknown Port" + portName);
        }
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(javax.xml.namespace.QName portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        setEndpointAddress(portName.getLocalPart(), address);
    }

}
