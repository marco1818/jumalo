/**
 * GetTarjetaAmarilla_Periodo.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.bancoazteca.srcu.spring.ws.administracion.empleados.axis;
@SuppressWarnings({ "unused", "rawtypes", "serial" })
public class GetTarjetaAmarilla_Periodo  implements java.io.Serializable {
    private java.lang.String usuario;

    private java.lang.String contrase�a;

    private int fecha;

    private boolean existeError;

    private java.lang.String mensaje;

    public GetTarjetaAmarilla_Periodo() {
    }

    public GetTarjetaAmarilla_Periodo(
           java.lang.String usuario,
           java.lang.String contrase�a,
           int fecha,
           boolean existeError,
           java.lang.String mensaje) {
           this.usuario = usuario;
           this.contrase�a = contrase�a;
           this.fecha = fecha;
           this.existeError = existeError;
           this.mensaje = mensaje;
    }


    /**
     * Gets the usuario value for this GetTarjetaAmarilla_Periodo.
     * 
     * @return usuario
     */
    public java.lang.String getUsuario() {
        return usuario;
    }


    /**
     * Sets the usuario value for this GetTarjetaAmarilla_Periodo.
     * 
     * @param usuario
     */
    public void setUsuario(java.lang.String usuario) {
        this.usuario = usuario;
    }


    /**
     * Gets the contrase�a value for this GetTarjetaAmarilla_Periodo.
     * 
     * @return contrase�a
     */
    public java.lang.String getContrase�a() {
        return contrase�a;
    }


    /**
     * Sets the contrase�a value for this GetTarjetaAmarilla_Periodo.
     * 
     * @param contrase�a
     */
    public void setContrase�a(java.lang.String contrase�a) {
        this.contrase�a = contrase�a;
    }


    /**
     * Gets the fecha value for this GetTarjetaAmarilla_Periodo.
     * 
     * @return fecha
     */
    public int getFecha() {
        return fecha;
    }


    /**
     * Sets the fecha value for this GetTarjetaAmarilla_Periodo.
     * 
     * @param fecha
     */
    public void setFecha(int fecha) {
        this.fecha = fecha;
    }


    /**
     * Gets the existeError value for this GetTarjetaAmarilla_Periodo.
     * 
     * @return existeError
     */
    public boolean isExisteError() {
        return existeError;
    }


    /**
     * Sets the existeError value for this GetTarjetaAmarilla_Periodo.
     * 
     * @param existeError
     */
    public void setExisteError(boolean existeError) {
        this.existeError = existeError;
    }


    /**
     * Gets the mensaje value for this GetTarjetaAmarilla_Periodo.
     * 
     * @return mensaje
     */
    public java.lang.String getMensaje() {
        return mensaje;
    }


    /**
     * Sets the mensaje value for this GetTarjetaAmarilla_Periodo.
     * 
     * @param mensaje
     */
    public void setMensaje(java.lang.String mensaje) {
        this.mensaje = mensaje;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof GetTarjetaAmarilla_Periodo)) return false;
        GetTarjetaAmarilla_Periodo other = (GetTarjetaAmarilla_Periodo) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.usuario==null && other.getUsuario()==null) || 
             (this.usuario!=null &&
              this.usuario.equals(other.getUsuario()))) &&
            ((this.contrase�a==null && other.getContrase�a()==null) || 
             (this.contrase�a!=null &&
              this.contrase�a.equals(other.getContrase�a()))) &&
            this.fecha == other.getFecha() &&
            this.existeError == other.isExisteError() &&
            ((this.mensaje==null && other.getMensaje()==null) || 
             (this.mensaje!=null &&
              this.mensaje.equals(other.getMensaje())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getUsuario() != null) {
            _hashCode += getUsuario().hashCode();
        }
        if (getContrase�a() != null) {
            _hashCode += getContrase�a().hashCode();
        }
        _hashCode += getFecha();
        _hashCode += (isExisteError() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        if (getMensaje() != null) {
            _hashCode += getMensaje().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(GetTarjetaAmarilla_Periodo.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", ">getTarjetaAmarilla_Periodo"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("usuario");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Usuario"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("contrase�a");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Contrase�a"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("fecha");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Fecha"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("existeError");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("mensaje");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
