package com.bancoazteca.srcu.spring.daos.administracion.mantenimientoUsuariosUnificado;

import java.util.List;

import com.bancoazteca.srcu.spring.beans.administracion.mantenimientoTelefonos.DatosEmpleadoBean;
import com.bancoazteca.srcu.spring.beans.administracion.mantenimientoUsuariosUnificado.DepartamentosBean;
import com.bancoazteca.srcu.spring.beans.administracion.mantenimientoUsuariosUnificado.EmpleadosBean;
import com.bancoazteca.srcu.spring.beans.administracion.mantenimientoUsuariosUnificado.MantenimientoUsuariosUnificadoBean;
import com.bancoazteca.srcu.spring.beans.administracion.mantenimientoUsuariosUnificado.PuestoBean;
import com.bancoazteca.srcu.spring.beans.administracion.mantenimientoUsuariosUnificado.VacantesxPuestoBean;
import com.bancoazteca.srcu.spring.beans.sistema.MensajeTransaccionBean;
import com.bancoazteca.srcu.spring.beans.utilerias.SimpleBean;

public interface MantenimientoUsuariosUnificadoDAO {
	public	List<PuestoBean> consultaPuestosOperar(MantenimientoUsuariosUnificadoBean mantenimientoUsuariosUnificadoBean);
	public	List<DepartamentosBean> consultaDepartamentos(MantenimientoUsuariosUnificadoBean mantenimientoUsuariosUnificadoBean);
	public	List<EmpleadosBean>	consultaEmpleados(MantenimientoUsuariosUnificadoBean mantenimientoUsuariosUnificadoBean);
	public	MensajeTransaccionBean	consultaVacante(String numeroEmpleado);
	public	MensajeTransaccionBean	altaEmpleado(MantenimientoUsuariosUnificadoBean mantenimientoUsuariosUnificadoBean);
	public	MensajeTransaccionBean	bajaEmpleado(MantenimientoUsuariosUnificadoBean mantenimientoUsuariosUnificadoBean);
	public 	MensajeTransaccionBean	bajaxSustitucion(MantenimientoUsuariosUnificadoBean mantenimientoUsuariosUnificadoBean);
	public	MensajeTransaccionBean	validaAltaEmpleado(MantenimientoUsuariosUnificadoBean mantenimientoUsuariosUnificadoBean);
	public	MensajeTransaccionBean	validaBajaEmpleado(MantenimientoUsuariosUnificadoBean mantenimientoUsuariosUnificadoBean);
	public	MensajeTransaccionBean	validaBajaxSustitucion(MantenimientoUsuariosUnificadoBean mantenimientoUsuariosUnificadoBean);
	public	EmpleadosBean	consultaJefeOracle(MantenimientoUsuariosUnificadoBean mantenimientoUsuariosUnificadoBean);
	public	List<VacantesxPuestoBean>	consultaVacantesxPuesto(MantenimientoUsuariosUnificadoBean mantenimientoUsuariosUnificadoBean, int tipoConsulta);
	public	DatosEmpleadoBean	datosEmpleado(MantenimientoUsuariosUnificadoBean mantenimientoUsuariosUnificadoBean);
	public	List<EmpleadosBean> consultaEmpleadosCambio(MantenimientoUsuariosUnificadoBean mantenimientoUsuariosUnificadoBean);
	public	SimpleBean paisxGerencia(int gerenciaId);
	public	SimpleBean	validaFuncionSap(int segmentoId, int funcionSap);
}
