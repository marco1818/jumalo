package com.bancoazteca.srcu.spring.ws.administracion.empleados;

import java.rmi.RemoteException;

import javax.xml.rpc.holders.BooleanHolder;
import javax.xml.rpc.holders.StringHolder;

import org.springframework.stereotype.Service;

import com.bancoazteca.srcu.spring.beans.utilerias.CatalogoBean;
import com.bancoazteca.srcu.spring.servicios.utilerias.BaseServicio;
import com.bancoazteca.srcu.spring.ws.administracion.empleados.axis.Empleado;
import com.bancoazteca.srcu.spring.ws.administracion.empleados.axis.EmpleadoGeneralSoapProxy;

@Service
public class DatosEmpleadoImpl extends BaseServicio implements DatosEmpleado{
	
	private interface Enum_Constantes_DatosEmpleadoImpl{
		String	nombreEmpresa	=	"EKT";
	}
	
	private interface Enum_Catalogos_Web_Services{
		int	credencialesConsultaEmpleadoSap	=	367;
		int endPoinfConsultaEmpleadoSap		=	361;
	}
	
	private interface Enum_SubItems_WebServices	{
		int	usuarioConsultaEmpleadoSap		=	7;
		int contraseniaConsultaEmpleadoSap	=	8;
		int	endPointConsultaEmpleadoSap_1	=	5;
		int	endPointConsultaEmpleadoSap_2	=	6;
	}
	
	@Override
	public Empleado consultaEmpleadoSap(String numeroEmpleado) {
		
		Empleado empleado = new Empleado();
		try {
			CatalogoBean usuario = consultaSubItem(Enum_Catalogos_Web_Services.credencialesConsultaEmpleadoSap, Enum_SubItems_WebServices.usuarioConsultaEmpleadoSap);
			CatalogoBean contrasenia = consultaSubItem(Enum_Catalogos_Web_Services.credencialesConsultaEmpleadoSap, Enum_SubItems_WebServices.contraseniaConsultaEmpleadoSap);
			CatalogoBean endPoint1 = consultaSubItem(Enum_Catalogos_Web_Services.endPoinfConsultaEmpleadoSap, Enum_SubItems_WebServices.endPointConsultaEmpleadoSap_1);
			CatalogoBean endPoint2 = consultaSubItem(Enum_Catalogos_Web_Services.endPoinfConsultaEmpleadoSap, Enum_SubItems_WebServices.endPointConsultaEmpleadoSap_2);
			String endPoint = endPoint1.getDescLarga()+endPoint2.getDescLarga();
			
			EmpleadoGeneralSoapProxy empleadoGeneral = new EmpleadoGeneralSoapProxy(endPoint);
			
			empleado = empleadoGeneral.getEmpleadoGeneral(usuario.getDescLarga(), contrasenia.getDescLarga(), Integer.parseInt(numeroEmpleado), Enum_Constantes_DatosEmpleadoImpl.nombreEmpresa, new BooleanHolder(false), new StringHolder(""));
			
		} catch (NumberFormatException e) {
		} catch (RemoteException e) {
		}
		return empleado;
	}
}
