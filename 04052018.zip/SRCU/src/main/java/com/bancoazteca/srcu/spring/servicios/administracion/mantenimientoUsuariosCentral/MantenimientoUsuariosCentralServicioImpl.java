package com.bancoazteca.srcu.spring.servicios.administracion.mantenimientoUsuariosCentral;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bancoazteca.srcu.spring.beans.administracion.mantenimientoUsuariosCentral.MantenimientoUsuariosCentralBean;
import com.bancoazteca.srcu.spring.beans.sistema.MensajeTransaccionBean;
import com.bancoazteca.srcu.spring.daos.administracion.mantenimientoUsuariosCentral.MantenimientoUsuariosCentralDAO;
import com.bancoazteca.srcu.spring.servicios.utilerias.BaseServicio;

@Service
public class MantenimientoUsuariosCentralServicioImpl extends BaseServicio implements MantenimientoUsuariosCentralServicio {
	
	public interface Enum_Consultas_MttoUsuariosCentral{
		int consultaEmpleado	=	1;
	}
	
	public interface Enum_Operacion_MttoUsuariosCentral{
		int reinicioContrasenia	=	1;
		int desbloqueoUsuario	=	2;
	} 
	
	public interface Enum_Contantes_MttoUsuariosCentral{
		int errorDesconocido	=	999;
	}
	
	@Autowired
	private MantenimientoUsuariosCentralDAO mantenimientoUsuariosCentralDAO;
	
	@Override
	public MantenimientoUsuariosCentralBean consulta(MantenimientoUsuariosCentralBean mantenimientoUsuariosCentral, int tipoConsulta) {
		MantenimientoUsuariosCentralBean mantenimientoUsuariosCentralBean = new MantenimientoUsuariosCentralBean();
		
		switch (tipoConsulta) {
		case Enum_Consultas_MttoUsuariosCentral.consultaEmpleado:
			mantenimientoUsuariosCentralBean.setDatosEmpleado(mantenimientoUsuariosCentralDAO.consultaEmpleado(mantenimientoUsuariosCentral.getNumeroEmpleado()));
			break;

		default:
			mantenimientoUsuariosCentralBean = new MantenimientoUsuariosCentralBean();
			break;
		}
		
		return mantenimientoUsuariosCentralBean;
	}
	
	@Override
	public MensajeTransaccionBean grabaTransaccion(MantenimientoUsuariosCentralBean mantenimientoUsuariosCentralBean, int tipoOperacion) {
		MensajeTransaccionBean mensajeTransaccionBean = new MensajeTransaccionBean();
		
		switch (tipoOperacion) {
		case Enum_Operacion_MttoUsuariosCentral.reinicioContrasenia:
			mensajeTransaccionBean = mantenimientoUsuariosCentralDAO.reiniciaContrasenia(mantenimientoUsuariosCentralBean);
			break;
		case Enum_Operacion_MttoUsuariosCentral.desbloqueoUsuario:
			mensajeTransaccionBean = mantenimientoUsuariosCentralDAO.desbloqueaUsuario(mantenimientoUsuariosCentralBean);
			break;
		default:
			mensajeTransaccionBean.setNumeroMensaje(Enum_Contantes_MttoUsuariosCentral.errorDesconocido);
			mensajeTransaccionBean.setDescripcionMensaje("NO SE REALIZO NINGUNA ACCION.");
			break;
		}
		
		return mensajeTransaccionBean;
	}

}
