/**
 * ResumenCuotaPatronal.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.bancoazteca.srcu.spring.ws.administracion.empleados.axis;
@SuppressWarnings({ "unused", "rawtypes", "serial" })
public class ResumenCuotaPatronal  implements java.io.Serializable {
    private int FIPERIODOID;

    private int FIEJERCICIOID;

    private int FINUMERODETRABAJADORES;

    private java.lang.String FCSOCIEDADID;

    public ResumenCuotaPatronal() {
    }

    public ResumenCuotaPatronal(
           int FIPERIODOID,
           int FIEJERCICIOID,
           int FINUMERODETRABAJADORES,
           java.lang.String FCSOCIEDADID) {
           this.FIPERIODOID = FIPERIODOID;
           this.FIEJERCICIOID = FIEJERCICIOID;
           this.FINUMERODETRABAJADORES = FINUMERODETRABAJADORES;
           this.FCSOCIEDADID = FCSOCIEDADID;
    }


    /**
     * Gets the FIPERIODOID value for this ResumenCuotaPatronal.
     * 
     * @return FIPERIODOID
     */
    public int getFIPERIODOID() {
        return FIPERIODOID;
    }


    /**
     * Sets the FIPERIODOID value for this ResumenCuotaPatronal.
     * 
     * @param FIPERIODOID
     */
    public void setFIPERIODOID(int FIPERIODOID) {
        this.FIPERIODOID = FIPERIODOID;
    }


    /**
     * Gets the FIEJERCICIOID value for this ResumenCuotaPatronal.
     * 
     * @return FIEJERCICIOID
     */
    public int getFIEJERCICIOID() {
        return FIEJERCICIOID;
    }


    /**
     * Sets the FIEJERCICIOID value for this ResumenCuotaPatronal.
     * 
     * @param FIEJERCICIOID
     */
    public void setFIEJERCICIOID(int FIEJERCICIOID) {
        this.FIEJERCICIOID = FIEJERCICIOID;
    }


    /**
     * Gets the FINUMERODETRABAJADORES value for this ResumenCuotaPatronal.
     * 
     * @return FINUMERODETRABAJADORES
     */
    public int getFINUMERODETRABAJADORES() {
        return FINUMERODETRABAJADORES;
    }


    /**
     * Sets the FINUMERODETRABAJADORES value for this ResumenCuotaPatronal.
     * 
     * @param FINUMERODETRABAJADORES
     */
    public void setFINUMERODETRABAJADORES(int FINUMERODETRABAJADORES) {
        this.FINUMERODETRABAJADORES = FINUMERODETRABAJADORES;
    }


    /**
     * Gets the FCSOCIEDADID value for this ResumenCuotaPatronal.
     * 
     * @return FCSOCIEDADID
     */
    public java.lang.String getFCSOCIEDADID() {
        return FCSOCIEDADID;
    }


    /**
     * Sets the FCSOCIEDADID value for this ResumenCuotaPatronal.
     * 
     * @param FCSOCIEDADID
     */
    public void setFCSOCIEDADID(java.lang.String FCSOCIEDADID) {
        this.FCSOCIEDADID = FCSOCIEDADID;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ResumenCuotaPatronal)) return false;
        ResumenCuotaPatronal other = (ResumenCuotaPatronal) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this.FIPERIODOID == other.getFIPERIODOID() &&
            this.FIEJERCICIOID == other.getFIEJERCICIOID() &&
            this.FINUMERODETRABAJADORES == other.getFINUMERODETRABAJADORES() &&
            ((this.FCSOCIEDADID==null && other.getFCSOCIEDADID()==null) || 
             (this.FCSOCIEDADID!=null &&
              this.FCSOCIEDADID.equals(other.getFCSOCIEDADID())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += getFIPERIODOID();
        _hashCode += getFIEJERCICIOID();
        _hashCode += getFINUMERODETRABAJADORES();
        if (getFCSOCIEDADID() != null) {
            _hashCode += getFCSOCIEDADID().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ResumenCuotaPatronal.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ResumenCuotaPatronal"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("FIPERIODOID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "FIPERIODOID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("FIEJERCICIOID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "FIEJERCICIOID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("FINUMERODETRABAJADORES");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "FINUMERODETRABAJADORES"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("FCSOCIEDADID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "FCSOCIEDADID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
