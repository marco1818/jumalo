package com.bancoazteca.srcu.spring.ws.administracion.posicionesSap;

import java.math.BigDecimal;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.bancoazteca.srcu.spring.beans.utilerias.CatalogoBean;
import com.bancoazteca.srcu.spring.beans.utilerias.SimpleBean;
import com.bancoazteca.srcu.spring.daos.administracion.mantenimientoUsuariosSap.MantenimientoUsuariosSapDAO;
import com.bancoazteca.srcu.spring.servicios.administracion.mantenimientoUsuariosSap.MantenimientoUsuariosSapServicioImpl;
import com.bancoazteca.srcu.spring.servicios.utilerias.BaseServicio;
import com.bancoazteca.srcu.spring.ws.administracion.posicionesSap.axis.altaBajaPosicionesSap.ArrayOfZHRLOGERR_VNTEMPHolder;
import com.bancoazteca.srcu.spring.ws.administracion.posicionesSap.axis.altaBajaPosicionesSap.Srv_PosicionSoapProxy;
import com.bancoazteca.srcu.spring.ws.administracion.posicionesSap.axis.altaBajaPosicionesSap.ZHRLOGERR_VNTEMP;
import com.bancoazteca.srcu.spring.ws.administracion.posicionesSap.axis.consultaPosicionesSap.TABLE_OF_BAPIRETURN1Holder;
import com.bancoazteca.srcu.spring.ws.administracion.posicionesSap.axis.consultaPosicionesSap.TABLE_OF_ZST_RH_REGIONAL_CREDITOHolder;
import com.bancoazteca.srcu.spring.ws.administracion.posicionesSap.axis.consultaPosicionesSap.ZSD_REG_CRED_CONSUL_POS_CECOProxy;
import com.bancoazteca.srcu.spring.ws.administracion.posicionesSap.axis.consultaPosicionesSap.ZST_RH_REGIONAL_CREDITO;

@Service
public class ServiciosSAPImpl extends BaseServicio implements ServiciosSAP{
	private final static Logger logger = Logger.getLogger("ServiciosSAPImpl");
	
	public interface Enum_Constantes_ServiciosSAP{
		String	cadenaVacia		=	"";
		String	posicionVacante	=	"99999999";
		int	enteroCero			=	0;
		int	obtenerVacantes		=	1;
		int obtenerTodas		=	0;
	}
	
	public interface Enum_ServiciosSAP_Consulta{
		int	posiciones_x_ceco				=	1;
		int	posiciones_x_funcion			=	2;
		int posiciones_vacantes_x_ceco		=	3;
		int posiciones_vacantes_x_funcion	=	4;
	}
	
	public interface Enum_Catalogos_WebServices{
		int	endPoints_WebServices_Sap	=	361;
		int credenciales_WebServicesSap	=	367;
		int puestosExentanValidacion	=	350;
	}
	
	public interface Enum_SubItem_CatUnico2{
		int altaLimitacionPosiciones_1	=	1;
		int altaLimitacionPosiciones_2	=	2;
		int consultaPosiciones_1		=	3;
		int consultaPosiciones_2		=	4;
		int usuarioConsultaSap			=	1;
		int	contraseniaConsultaSap		=	2;
		int usuarioAltaLimitacionSap	=	3;
		int	contraseniaAltaLimitacion	=	4;
	}
	@Autowired
	MantenimientoUsuariosSapDAO mantenimientoUsuariosSapDAO;
	
	@Autowired
	MantenimientoUsuariosSapServicioImpl mantenimientoUsuariosSapServicioImpl;
	@Override
	public List<PosicionesSapBean> consultaPosicionesSAP(int tipoConsulta, String ceco, int funcionSAP) {
		List<PosicionesSapBean> posicionesSap = new  ArrayList<PosicionesSapBean>();
		
		switch (tipoConsulta) {
		case Enum_ServiciosSAP_Consulta.posiciones_x_ceco:
			posicionesSap = posiciones(Enum_Constantes_ServiciosSAP.obtenerTodas,ceco,Enum_Constantes_ServiciosSAP.enteroCero);
			break;
		case Enum_ServiciosSAP_Consulta.posiciones_x_funcion:
			posicionesSap = posiciones(Enum_Constantes_ServiciosSAP.obtenerTodas,ceco,funcionSAP);
			break;
		case Enum_ServiciosSAP_Consulta.posiciones_vacantes_x_ceco:
			posicionesSap = posiciones(Enum_Constantes_ServiciosSAP.obtenerVacantes ,ceco,Enum_Constantes_ServiciosSAP.enteroCero);
			break;
		case Enum_ServiciosSAP_Consulta.posiciones_vacantes_x_funcion:
			posicionesSap = posiciones(Enum_Constantes_ServiciosSAP.obtenerVacantes,ceco,funcionSAP);
			break;
		default:
			break;
		}
		
		return posicionesSap;
	}

	public List<PosicionesSapBean> posiciones(int vacantes, String ceco, int funcionSAP){
		List<PosicionesSapBean> posicionesSap = null;
		CatalogoBean endPoint		=	consultaSubItem(Enum_Catalogos_WebServices.endPoints_WebServices_Sap, Enum_SubItem_CatUnico2.consultaPosiciones_1);
		CatalogoBean endPoint_1		=	consultaSubItem(Enum_Catalogos_WebServices.endPoints_WebServices_Sap, Enum_SubItem_CatUnico2.consultaPosiciones_2);
		CatalogoBean usuario		=	consultaSubItem(Enum_Catalogos_WebServices.credenciales_WebServicesSap, Enum_SubItem_CatUnico2.usuarioConsultaSap);
		CatalogoBean contrasenia	=	consultaSubItem(Enum_Catalogos_WebServices.credenciales_WebServicesSap, Enum_SubItem_CatUnico2.contraseniaConsultaSap);
		
		ZSD_REG_CRED_CONSUL_POS_CECOProxy consultaPosiciones = new ZSD_REG_CRED_CONSUL_POS_CECOProxy((endPoint.getDescLarga()+endPoint_1.getDescLarga()),usuario.getDescLarga(),contrasenia.getDescLarga(),60000);
		TABLE_OF_BAPIRETURN1Holder mensajeSAP = new TABLE_OF_BAPIRETURN1Holder();
		TABLE_OF_ZST_RH_REGIONAL_CREDITOHolder posicionesSAP = new TABLE_OF_ZST_RH_REGIONAL_CREDITOHolder();
		String funcionConsulta = funcionSAP > Enum_Constantes_ServiciosSAP.enteroCero ? String.valueOf(funcionSAP):Enum_Constantes_ServiciosSAP.cadenaVacia;
		
		try {
			consultaPosiciones.ZRH_REG_CRED_CONSUL_POS_CECO(ceco, Enum_Constantes_ServiciosSAP.cadenaVacia, funcionConsulta, mensajeSAP, posicionesSAP);
			
			if(posicionesSAP.value != null){
				posicionesSap = new  ArrayList<PosicionesSapBean>();
				for(ZST_RH_REGIONAL_CREDITO posicion: posicionesSAP.value){
					if(vacantes == 1) {
						if(posicion.getPERNR().equals(Enum_Constantes_ServiciosSAP.posicionVacante)){
							PosicionesSapBean posicionesSapBean = new PosicionesSapBean(posicion.getCECO(), Integer.parseInt(posicion.getFNSAP()), posicion.getIDPOS(), posicion.getPERNR());
							posicionesSap.add(posicionesSapBean);
						}
						
					}else {
						PosicionesSapBean posicionesSapBean = new PosicionesSapBean(posicion.getCECO(), Integer.parseInt(posicion.getFNSAP()), posicion.getIDPOS(), posicion.getPERNR());
						posicionesSap.add(posicionesSapBean);
					}
					
				}
			}
			
		} catch (RemoteException e) {
			logger.info("Ocurrio un detalle al consultar las Posiciones en SAP.");
		}
		
		return posicionesSap;
	}
	
	@Override
	public RespuestaAltaPosicionBean creaVacante(int gerenciaId, int segmento, int puestoOpera, String empleadoOpera) {
		RespuestaAltaPosicionBean respuestaAltaPosicionBean = new RespuestaAltaPosicionBean();
		
		respuestaAltaPosicionBean = validaCreacionVacante(gerenciaId, segmento, puestoOpera, empleadoOpera);
		
		if(respuestaAltaPosicionBean.getCodigo() != 0) {
			System.out.println(respuestaAltaPosicionBean.getDescripcion());
		}
		
		return respuestaAltaPosicionBean;
	}
	
	private	RespuestaAltaPosicionBean validaCreacionVacante(int gerenciaId, int segmento,int puestoOpera, String empleadoOpera) {
		RespuestaAltaPosicionBean respuestaAltaPosicionBean = new RespuestaAltaPosicionBean();
		SimpleBean validaCreacion	= new SimpleBean();
		CatalogoBean exentaValidacion = consultaSubItem(Enum_Catalogos_WebServices.puestosExentanValidacion, puestoOpera);
		
		if(exentaValidacion.getItemId()>0) {
			respuestaAltaPosicionBean.setCodigo(0);
			respuestaAltaPosicionBean.setDescripcion("Validacion Exitosa.");
			return respuestaAltaPosicionBean;
		}
		
		validaCreacion = mantenimientoUsuariosSapDAO.validaCreacionxClientes(gerenciaId, segmento); 
		
		if(validaCreacion.getCodigo() != 0) {
			respuestaAltaPosicionBean.setCodigo(999);
			respuestaAltaPosicionBean.setDescripcion(validaCreacion.getDescripcion());
			return respuestaAltaPosicionBean;
		}
		
		validaCreacion = mantenimientoUsuariosSapDAO.validaCreacionxEliminacion(gerenciaId, segmento, empleadoOpera);
		
		if(validaCreacion.getCodigo() != 0) {
			respuestaAltaPosicionBean.setCodigo(999);
			respuestaAltaPosicionBean.setDescripcion(validaCreacion.getDescripcion());
			return respuestaAltaPosicionBean;
		}
		
		respuestaAltaPosicionBean	=	creaPosicionSAP(gerenciaId, segmento);
		
		if(respuestaAltaPosicionBean.getCodigo() != 0) {
			return respuestaAltaPosicionBean;
		}
		
		respuestaAltaPosicionBean.setCodigo(0);
		respuestaAltaPosicionBean.setDescripcion("Validacion Exitosa");
		
		return respuestaAltaPosicionBean;
	}
	
	private RespuestaAltaPosicionBean creaPosicionSAP(int gerenciaId, int segmentoId) {
		List<PosicionesSapBean> posicionInformar = new ArrayList<PosicionesSapBean>();
		RespuestaAltaPosicionBean respuestaAltaPosicionBean = new RespuestaAltaPosicionBean();
		CatalogoBean replicaSap	= consultaSubItem(351, 1);
		
		if(replicaSap.getDescCorta().contains("1")) {
			CatalogoBean endPoint		=	consultaSubItem(Enum_Catalogos_WebServices.endPoints_WebServices_Sap, Enum_SubItem_CatUnico2.altaLimitacionPosiciones_1);
			CatalogoBean endPoint_1		=	consultaSubItem(Enum_Catalogos_WebServices.endPoints_WebServices_Sap, Enum_SubItem_CatUnico2.altaLimitacionPosiciones_2);
			CatalogoBean usuario		=	consultaSubItem(Enum_Catalogos_WebServices.credenciales_WebServicesSap, Enum_SubItem_CatUnico2.usuarioConsultaSap);
			CatalogoBean contrasenia	=	consultaSubItem(Enum_Catalogos_WebServices.credenciales_WebServicesSap, Enum_SubItem_CatUnico2.contraseniaConsultaSap);
			
			Srv_PosicionSoapProxy creaPosicion = new Srv_PosicionSoapProxy((endPoint.getDescLarga()+endPoint_1.getDescLarga()));
			ArrayOfZHRLOGERR_VNTEMPHolder respuesta = new ArrayOfZHRLOGERR_VNTEMPHolder();
			SimpleBean centroCostos = mantenimientoUsuariosSapServicioImpl.consultaCentroCostos(gerenciaId);
			ParametrosWSBean parametrosWSBean = mantenimientoUsuariosSapDAO.consultaParametrosWS(centroCostos.getCodigo(), equivalenciaSAP(segmentoId));
			
			if(centroCostos.getCodigo() == 0) {
				respuestaAltaPosicionBean.setCodigo(999);
				respuestaAltaPosicionBean.setDescripcion("NO SE ENCONTRO EL CENTRO DE COSTOS.");
				return respuestaAltaPosicionBean;
			}
			CatalogoBean funcionInforma = consultaSubItem(358, equivalenciaSAP(segmentoId));

			posicionInformar = posiciones(0, String.valueOf(centroCostos.getCodigo()), Integer.valueOf(funcionInforma.getDescCorta()));
			
			try {
				creaPosicion.crea_Posicion(	parametrosWSBean.getFcsidNeg(), usuario.getDescLarga(), contrasenia.getDescLarga(), parametrosWSBean.getFcsMedia(), parametrosWSBean.getFcsShort(),
											parametrosWSBean.getFcssText(),posicionInformar.get(0).getPosicionId(),String.valueOf(("0000"+centroCostos.getCodigo()+"GSAL")),parametrosWSBean.getFcsFuncion(),
											parametrosWSBean.getFcsTipoPos(),parametrosWSBean.getFcsSociedad(),parametrosWSBean.getFcsDivision(),parametrosWSBean.getFcsSubDivision(),parametrosWSBean.getFcsAreaPersonal(),
											parametrosWSBean.getFcsEdificio(),String.valueOf(parametrosWSBean.getFisUnidadOrg()),parametrosWSBean.getFcsClaseConv(),parametrosWSBean.getFcsAreaConv(),
											parametrosWSBean.getFcsAgrupConv(),parametrosWSBean.getFcsGrupoProf(),new BigDecimal(parametrosWSBean.getFcssDosAbruto()),new BigDecimal(parametrosWSBean.getFcssDosAbruto()),
											new BigDecimal(parametrosWSBean.getFcsDoscNeto()), posicionInformar.get(0).getPosicionId(), respuesta);
				
				if(respuesta.value != null) {
					ZHRLOGERR_VNTEMP posicionSAP = null;
					posicionSAP = respuesta.value[0];
					int numeroPosicion = 0;
					try{
						numeroPosicion = Integer.parseInt(posicionSAP.getPERNR());
					}catch(NumberFormatException e){
						respuestaAltaPosicionBean.setCodigo(999);
						respuestaAltaPosicionBean.setNumPosicion("0");
						respuestaAltaPosicionBean.setMensaje("NO FUE POSIBLE RECUPERAR LA POSICION DE SAP.");
						respuestaAltaPosicionBean.setDescripcion("NO FUE POSIBLE RECUPERAR LA POSICION DE SAP.");
						return respuestaAltaPosicionBean;
					}
					if(numeroPosicion > 0){
						respuestaAltaPosicionBean.setCodigo(0);
						respuestaAltaPosicionBean.setNumPosicion(posicionSAP.getPERNR());
						respuestaAltaPosicionBean.setMensaje(posicionSAP.getTEXT());
						respuestaAltaPosicionBean.setDescripcion(posicionSAP.getTEXT());
						return respuestaAltaPosicionBean;
					}else{
						respuestaAltaPosicionBean.setCodigo(999);
						respuestaAltaPosicionBean.setNumPosicion("0");
						respuestaAltaPosicionBean.setMensaje(posicionSAP.getTEXT());
						respuestaAltaPosicionBean.setDescripcion(posicionSAP.getTEXT());
						return respuestaAltaPosicionBean;
					}
				}
				respuestaAltaPosicionBean.setCodigo(999);
				respuestaAltaPosicionBean.setNumPosicion("0");
				respuestaAltaPosicionBean.setMensaje("NO FUE POSIBLE CREAR LA POSICION EN SAP.");
				respuestaAltaPosicionBean.setDescripcion("NO FUE POSIBLE CREAR LA POSICION EN SAP.");
				return respuestaAltaPosicionBean;
				
			} catch (RemoteException e) {
				respuestaAltaPosicionBean.setCodigo(999);
				respuestaAltaPosicionBean.setNumPosicion("0");
				respuestaAltaPosicionBean.setMensaje("NO FUE POSIBLE CREAR LA POSICION EN SAP.");
				respuestaAltaPosicionBean.setDescripcion("NO FUE POSIBLE CREAR LA POSICION EN SAP.");
				return respuestaAltaPosicionBean;
			}
			
			
		}else {
			respuestaAltaPosicionBean.setCodigo(0);
			respuestaAltaPosicionBean.setNumPosicion("-1");
			respuestaAltaPosicionBean.setMensaje("NO SE CREA POSICION SAP");
			respuestaAltaPosicionBean.setDescripcion("NO SE CREA POSICION SAP");
		}
		
		
		
		return respuestaAltaPosicionBean;
	}
	
	private int equivalenciaSAP(int segmento) {
		int funcionSAP;
		
		switch (segmento) {
		case 1:
			funcionSAP = 215;
			break;

		case 2:
			funcionSAP = 8342;
			break;	
		
		case 3:
			funcionSAP = 276;
			break;
		default:
			funcionSAP = 0;
			break;
		}
		
		return funcionSAP;
	}

	@Override
	public RespuestaLimitaPosicionBean limitaPosicion(String numPosicion, String empleadoOpera, String numVacante) {
		RespuestaLimitaPosicionBean respuestaLimitaPosicionBean = new RespuestaLimitaPosicionBean();
		
		CatalogoBean replicaSap	= consultaSubItem(351, 1);
		if(!replicaSap.getDescCorta().contains("1")) {
			respuestaLimitaPosicionBean.setCodigo(0);
			respuestaLimitaPosicionBean.setDescripcion("NO SE LIMITA EN SAP");
			respuestaLimitaPosicionBean.setFechaLimita("");
			respuestaLimitaPosicionBean.setMensaje("NO SE LIMITA EN SAP");
			respuestaLimitaPosicionBean.setMensajeError("NO SE LIMITA EN SAP");
			respuestaLimitaPosicionBean.setNumPosicionLimita("-999");
			return respuestaLimitaPosicionBean;
		}
		
		if(numPosicion.equals("")) {
			
		}
		
		
		
		return respuestaLimitaPosicionBean;
	}

}
