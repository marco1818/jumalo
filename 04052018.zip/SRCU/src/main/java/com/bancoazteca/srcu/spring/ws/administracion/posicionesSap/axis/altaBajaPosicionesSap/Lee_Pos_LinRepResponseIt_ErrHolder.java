/**
 * Lee_Pos_LinRepResponseIt_ErrHolder.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.bancoazteca.srcu.spring.ws.administracion.posicionesSap.axis.altaBajaPosicionesSap;

public final class Lee_Pos_LinRepResponseIt_ErrHolder implements javax.xml.rpc.holders.Holder {
    public Lee_Pos_LinRepResponseIt_Err value;

    public Lee_Pos_LinRepResponseIt_ErrHolder() {
    }

    public Lee_Pos_LinRepResponseIt_ErrHolder(Lee_Pos_LinRepResponseIt_Err value) {
        this.value = value;
    }

}
