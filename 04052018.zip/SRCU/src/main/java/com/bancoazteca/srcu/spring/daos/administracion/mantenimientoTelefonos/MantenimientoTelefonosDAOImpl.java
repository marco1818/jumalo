package com.bancoazteca.srcu.spring.daos.administracion.mantenimientoTelefonos;

import java.util.ArrayList;
import org.springframework.stereotype.Repository;

import com.bancoazteca.srcu.spring.beans.administracion.mantenimientoTelefonos.DatosEmpleadoBean;
import com.bancoazteca.srcu.spring.beans.administracion.mantenimientoTelefonos.MantenimientoTelefonosBean;
import com.bancoazteca.srcu.spring.beans.sistema.MensajeTransaccionBean;
import com.bancoazteca.srcu.spring.daos.utilerias.BaseDAO;

@Repository
public class MantenimientoTelefonosDAOImpl extends BaseDAO implements MantenimientoTelefonosDAO{
	
	public interface Enum_Constantes_MantenimientoTelefonosDAO{
		int		enteroCero			=	0;
		String	cadenaVacia			=	" ";
		int		errorInterno		=	999;
		int		transaccionExitosa	=	0;
	}
	
	public interface Enum_Funciones_MantenimientoTelefonosDAO{
		String	consultaDatosEmpleado		=	"CONSULTA_MTTO_TELEFONOS_DATOS_EMPLEADO";
		String	actualizaTelefonoEmpleado	=	"ACTUALIZA_MTTO_TELEFONOS_EMPLEADO";
		String 	consultaDatosGenerales		=	"CONSULTA_GENERAL_DATOS_EMPLEADO";
	}
	
	public interface Enum_Operaciones_MantenimientoTelefonosDAO{
		int	consultaDatosEmpleado		=	1;
		int	insertarTelefono			=	0;
		int	actualizaTelefonoEmpleado	=	1;
	}
	@Override
	public MensajeTransaccionBean insertaTelefono(MantenimientoTelefonosBean mantenimientoTelefonosBean) {
		MensajeTransaccionBean	mensajeTransaccionBean	=	new MensajeTransaccionBean();
		mensajeTransaccionBean.setNumeroMensaje(Enum_Constantes_MantenimientoTelefonosDAO.errorInterno);
		
		ArrayList<Object> parametros = new ArrayList<Object>();
		parametros.add(Enum_Operaciones_MantenimientoTelefonosDAO.insertarTelefono);
		parametros.add(mantenimientoTelefonosBean.getNumeroEmpleado());
		parametros.add(Enum_Constantes_MantenimientoTelefonosDAO.cadenaVacia);
		parametros.add(mantenimientoTelefonosBean.getTelefono());
		parametros.add(mantenimientoTelefonosBean.getCorreo());
		parametros.add(Enum_Constantes_MantenimientoTelefonosDAO.enteroCero);
		parametros.add(Enum_Constantes_MantenimientoTelefonosDAO.enteroCero);
		parametros.add(mantenimientoTelefonosBean.getNumeroEmpleado());
		
		mensajeTransaccionBean	=	(MensajeTransaccionBean) ejecutaFuncion(Enum_Funciones_MantenimientoTelefonosDAO.actualizaTelefonoEmpleado, parametros, mensajeTransaccionBean.getClass());
		
		return mensajeTransaccionBean;
	}
	
	@Override
	public MensajeTransaccionBean actualizaTelefono(MantenimientoTelefonosBean mantenimientoTelefonosBean) {
		MensajeTransaccionBean	mensajeTransaccionBean	=	new MensajeTransaccionBean();
		mensajeTransaccionBean.setNumeroMensaje(Enum_Constantes_MantenimientoTelefonosDAO.errorInterno);
		
		ArrayList<Object> parametros = new ArrayList<Object>();
		parametros.add(Enum_Operaciones_MantenimientoTelefonosDAO.actualizaTelefonoEmpleado);
		parametros.add(mantenimientoTelefonosBean.getNumeroEmpleado());
		parametros.add(null);
		parametros.add(mantenimientoTelefonosBean.getTelefono());
		parametros.add(mantenimientoTelefonosBean.getCorreo());
		parametros.add(null);
		parametros.add(null);
		parametros.add(null);
		
		mensajeTransaccionBean	=	(MensajeTransaccionBean) ejecutaFuncion(Enum_Funciones_MantenimientoTelefonosDAO.actualizaTelefonoEmpleado, parametros, mensajeTransaccionBean.getClass());
		
		if(mensajeTransaccionBean.getMensajeId() > Enum_Constantes_MantenimientoTelefonosDAO.enteroCero) {
			mensajeTransaccionBean.setNumeroMensaje(Enum_Constantes_MantenimientoTelefonosDAO.transaccionExitosa);
		}
		
		return mensajeTransaccionBean;
	}
	
	@Override
	public MantenimientoTelefonosBean consultaDatosEmpleado(MantenimientoTelefonosBean mantenimientoTelefonos) {
		MantenimientoTelefonosBean mantenimientoTelefonosBean = new MantenimientoTelefonosBean();
		ArrayList<Object> parametros = new ArrayList<Object>();
		parametros.add(Enum_Operaciones_MantenimientoTelefonosDAO.consultaDatosEmpleado);
		parametros.add(mantenimientoTelefonos.getNumeroEmpleado());
		
		mantenimientoTelefonosBean = (MantenimientoTelefonosBean) ejecutaFuncion(Enum_Funciones_MantenimientoTelefonosDAO.consultaDatosEmpleado, parametros, mantenimientoTelefonosBean.getClass());
		
		return mantenimientoTelefonosBean;
	}

	@Override
	public DatosEmpleadoBean consultaDatosGenerales(String numeroEmpleado) {
		DatosEmpleadoBean datosEmpleadoBean = new DatosEmpleadoBean();
		ArrayList<Object> parametros = new ArrayList<Object>();
		parametros.add(numeroEmpleado);
		
		datosEmpleadoBean =	(DatosEmpleadoBean) ejecutaFuncion(Enum_Funciones_MantenimientoTelefonosDAO.consultaDatosGenerales, parametros, datosEmpleadoBean.getClass());
		
		return datosEmpleadoBean;
	}



}
