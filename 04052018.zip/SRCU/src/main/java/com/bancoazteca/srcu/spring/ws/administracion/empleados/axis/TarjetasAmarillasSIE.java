/**
 * TarjetasAmarillasSIE.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.bancoazteca.srcu.spring.ws.administracion.empleados.axis;
@SuppressWarnings({ "unused", "rawtypes", "serial" })
public class TarjetasAmarillasSIE  implements java.io.Serializable {
    private int anio;

    private int semana;

    private int tarjetaAmarilla;

    public TarjetasAmarillasSIE() {
    }

    public TarjetasAmarillasSIE(
           int anio,
           int semana,
           int tarjetaAmarilla) {
           this.anio = anio;
           this.semana = semana;
           this.tarjetaAmarilla = tarjetaAmarilla;
    }


    /**
     * Gets the anio value for this TarjetasAmarillasSIE.
     * 
     * @return anio
     */
    public int getAnio() {
        return anio;
    }


    /**
     * Sets the anio value for this TarjetasAmarillasSIE.
     * 
     * @param anio
     */
    public void setAnio(int anio) {
        this.anio = anio;
    }


    /**
     * Gets the semana value for this TarjetasAmarillasSIE.
     * 
     * @return semana
     */
    public int getSemana() {
        return semana;
    }


    /**
     * Sets the semana value for this TarjetasAmarillasSIE.
     * 
     * @param semana
     */
    public void setSemana(int semana) {
        this.semana = semana;
    }


    /**
     * Gets the tarjetaAmarilla value for this TarjetasAmarillasSIE.
     * 
     * @return tarjetaAmarilla
     */
    public int getTarjetaAmarilla() {
        return tarjetaAmarilla;
    }


    /**
     * Sets the tarjetaAmarilla value for this TarjetasAmarillasSIE.
     * 
     * @param tarjetaAmarilla
     */
    public void setTarjetaAmarilla(int tarjetaAmarilla) {
        this.tarjetaAmarilla = tarjetaAmarilla;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof TarjetasAmarillasSIE)) return false;
        TarjetasAmarillasSIE other = (TarjetasAmarillasSIE) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this.anio == other.getAnio() &&
            this.semana == other.getSemana() &&
            this.tarjetaAmarilla == other.getTarjetaAmarilla();
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += getAnio();
        _hashCode += getSemana();
        _hashCode += getTarjetaAmarilla();
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(TarjetasAmarillasSIE.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "TarjetasAmarillasSIE"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("anio");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Anio"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("semana");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Semana"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("tarjetaAmarilla");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "TarjetaAmarilla"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
