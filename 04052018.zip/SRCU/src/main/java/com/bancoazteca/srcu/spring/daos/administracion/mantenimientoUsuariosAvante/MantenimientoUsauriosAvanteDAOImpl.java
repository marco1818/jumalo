package com.bancoazteca.srcu.spring.daos.administracion.mantenimientoUsuariosAvante;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;
import com.bancoazteca.srcu.spring.beans.administracion.mantenimientoUsuariosAvante.EmpleadosAvanteBean;
import com.bancoazteca.srcu.spring.beans.administracion.mantenimientoUsuariosAvante.MantenimientoUsuariosAvanteBean;
import com.bancoazteca.srcu.spring.beans.administracion.mantenimientoUsuariosAvante.PuestosAvanteBean;
import com.bancoazteca.srcu.spring.beans.sistema.MensajeTransaccionBean;
import com.bancoazteca.srcu.spring.daos.utilerias.BaseDAO;

@Repository
public class MantenimientoUsauriosAvanteDAOImpl extends BaseDAO implements MantenimientoUsuariosAvanteDAO{

	public interface Enum_Funciones_MantenimientoUsauriosAvante {
		String consultaPuestosAvanate			=	"MTTO_USUARIOS_AVANTE_CONSULTA_PUESTOS_AVANTE";
		String consultaCoordinadores			=	"MTTO_USUARIOS_AVANTE_CONSULTA_COORDINADORES";
		String consultaEspecialistas			=	"MTTO_USUARIOS_AVANTE_CONSULTA_ESPECIALISTAS";
		String altaUsuarioAvanate				=	"MTTO_USUARIOS_AVANTE_ALTA_USUARIO_AVANTE";
		String bajaUsuarioAvanate				=	"MTTO_USUARIOS_AVANTE_BAJA_USUARIO_AVANTE";
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<PuestosAvanteBean> consultaPuestosAvante(String empleadoOpera) {
		List<PuestosAvanteBean> puestoAvanteBean = new ArrayList<PuestosAvanteBean>();
		ArrayList<Object> parametros = new ArrayList<Object>();
		parametros.add(empleadoOpera);
		
		puestoAvanteBean	= 	(List<PuestosAvanteBean>) ejecutaFuncionAll(Enum_Funciones_MantenimientoUsauriosAvante.consultaPuestosAvanate, parametros, new PuestosAvanteBean().getClass());	

		return puestoAvanteBean;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<EmpleadosAvanteBean> consultaCoordinadores() {
		List<EmpleadosAvanteBean> empleadosAvanteBean = new ArrayList<EmpleadosAvanteBean>();
		ArrayList<Object> parametros = new ArrayList<Object>();
		
		empleadosAvanteBean = (List<EmpleadosAvanteBean>) ejecutaFuncionAll(Enum_Funciones_MantenimientoUsauriosAvante.consultaCoordinadores, parametros, new EmpleadosAvanteBean().getClass());
		
		return empleadosAvanteBean;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<EmpleadosAvanteBean> consultaEmpleados(String empleadoJefe, int puestoConsultar) {
		List<EmpleadosAvanteBean> empleadosAvanteBean = new ArrayList<EmpleadosAvanteBean>();
		ArrayList<Object> parametros = new ArrayList<Object>();
		parametros.add(empleadoJefe);
		parametros.add(puestoConsultar);
		
		empleadosAvanteBean = (List<EmpleadosAvanteBean>) ejecutaFuncionAll(Enum_Funciones_MantenimientoUsauriosAvante.consultaEspecialistas, parametros, new EmpleadosAvanteBean().getClass());

		return empleadosAvanteBean;
	}

	@Override
	public MensajeTransaccionBean altaUsuarioAvante(MantenimientoUsuariosAvanteBean mantenimientoUsuariosAvanteBean) {
		MensajeTransaccionBean mensajeTransaccionBean = new MensajeTransaccionBean();
		ArrayList<Object> parametros = new ArrayList<Object>();
		parametros.add(1);
		parametros.add(mantenimientoUsuariosAvanteBean.getEmpleadoAlta());
		parametros.add(mantenimientoUsuariosAvanteBean.getNombreEmpleadoAlta());
		parametros.add(mantenimientoUsuariosAvanteBean.getDepartamentoOperar());
		parametros.add(mantenimientoUsuariosAvanteBean.getPuestoOperar());
		parametros.add(mantenimientoUsuariosAvanteBean.getJefeOperar());
		parametros.add(mantenimientoUsuariosAvanteBean.getEmpleadoOpera());
		
		mensajeTransaccionBean = (MensajeTransaccionBean) ejecutaFuncion(Enum_Funciones_MantenimientoUsauriosAvante.altaUsuarioAvanate, parametros, mensajeTransaccionBean.getClass());
		
		
		if(mensajeTransaccionBean.getMensajeId() == 0) {
			mensajeTransaccionBean.setNumeroMensaje(0);
		}else {
			mensajeTransaccionBean.setNumeroMensaje(999);
		}

		
		return mensajeTransaccionBean;
	}

	@Override
	public MensajeTransaccionBean bajaUsuarioAvante(MantenimientoUsuariosAvanteBean mantenimientoUsuariosAvanteBean) {
		MensajeTransaccionBean mensajeTransaccionBean = new MensajeTransaccionBean();
		ArrayList<Object> parametros = new ArrayList<Object>();
		parametros.add(2);
		parametros.add(mantenimientoUsuariosAvanteBean.getEmpleadoBaja());
		parametros.add(mantenimientoUsuariosAvanteBean.getNombreEmpleadoAlta());
		parametros.add(mantenimientoUsuariosAvanteBean.getDepartamentoOperar());
		parametros.add(mantenimientoUsuariosAvanteBean.getPuestoOperar());
		parametros.add(mantenimientoUsuariosAvanteBean.getJefeOperar());
		parametros.add(mantenimientoUsuariosAvanteBean.getEmpleadoOpera());
		
		mensajeTransaccionBean = (MensajeTransaccionBean) ejecutaFuncion(Enum_Funciones_MantenimientoUsauriosAvante.bajaUsuarioAvanate, parametros, mensajeTransaccionBean.getClass());
		
		
		if(mensajeTransaccionBean.getMensajeId() == 0) {
			mensajeTransaccionBean.setNumeroMensaje(0);
		}else {
			mensajeTransaccionBean.setNumeroMensaje(999);
		}

		
		return mensajeTransaccionBean;
	}

}
