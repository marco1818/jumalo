package com.bancoazteca.srcu.spring.beans.administracion.mantenimientoUsuariosSap;

import java.util.List;

import com.bancoazteca.srcu.spring.beans.utilerias.BaseBean;
import com.bancoazteca.srcu.spring.beans.utilerias.CatalogoBean;

public class MantenimientoUsuariosSapBean extends BaseBean{
	private String empleadoOpera;
	private String empleadoDelegado;
	private int	puestoDelegado;
	private	int puestoIdEmpleadoOpera;
	private int deptoIdEmpleadoOpera;
	private	List<CatalogoBean> puestosBeans;
	private	List<DepartamentosBean> departamentos; 
	private int puestoConsultar;
	private int gerenciaConsultar;
	private List<EmpleadosBean> empleadosOperar;
	private	int segmentoOperar;
	
	public String getEmpleadoOpera() {
		return empleadoOpera;
	}

	public void setEmpleadoOpera(String empleadoOpera) {
		this.empleadoOpera = empleadoOpera;
	}

	public String getEmpleadoDelegado() {
		return empleadoDelegado;
	}

	public void setEmpleadoDelegado(String empleadoDelegado) {
		this.empleadoDelegado = empleadoDelegado;
	}

	public List<CatalogoBean> getPuestosBeans() {
		return puestosBeans;
	}

	public void setPuestosBeans(List<CatalogoBean> puestosBeans) {
		this.puestosBeans = puestosBeans;
	}

	public List<DepartamentosBean> getDepartamentos() {
		return departamentos;
	}

	public void setDepartamentos(List<DepartamentosBean> departamentos) {
		this.departamentos = departamentos;
	}

	public int getPuestoIdEmpleadoOpera() {
		return puestoIdEmpleadoOpera;
	}

	public void setPuestoIdEmpleadoOpera(int puestoIdEmpleadoOpera) {
		this.puestoIdEmpleadoOpera = puestoIdEmpleadoOpera;
	}

	public int getDeptoIdEmpleadoOpera() {
		return deptoIdEmpleadoOpera;
	}

	public void setDeptoIdEmpleadoOpera(int deptoIdEmpleadoOpera) {
		this.deptoIdEmpleadoOpera = deptoIdEmpleadoOpera;
	}

	public int getPuestoConsultar() {
		return puestoConsultar;
	}

	public void setPuestoConsultar(int puestoConsultar) {
		this.puestoConsultar = puestoConsultar;
	}

	public int getGerenciaConsultar() {
		return gerenciaConsultar;
	}

	public void setGerenciaConsultar(int gerenciaConsultar) {
		this.gerenciaConsultar = gerenciaConsultar;
	}

	public List<EmpleadosBean> getEmpleadosOperar() {
		return empleadosOperar;
	}

	public void setEmpleadosOperar(List<EmpleadosBean> empleadosOperar) {
		this.empleadosOperar = empleadosOperar;
	}

	public int getSegmentoOperar() {
		return segmentoOperar;
	}

	public void setSegmentoOperar(int segmentoOperar) {
		this.segmentoOperar = segmentoOperar;
	}

	public int getPuestoDelegado() {
		return puestoDelegado;
	}

	public void setPuestoDelegado(int puestoDelegado) {
		this.puestoDelegado = puestoDelegado;
	}
	
}
