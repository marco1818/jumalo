/**
 * TABLE_OF_ZST_RH_REGIONAL_CREDITOHolder.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.bancoazteca.srcu.spring.ws.administracion.posicionesSap.axis.consultaPosicionesSap;

public final class TABLE_OF_ZST_RH_REGIONAL_CREDITOHolder implements javax.xml.rpc.holders.Holder {
    public ZST_RH_REGIONAL_CREDITO[] value;

    public TABLE_OF_ZST_RH_REGIONAL_CREDITOHolder() {
    }

    public TABLE_OF_ZST_RH_REGIONAL_CREDITOHolder(ZST_RH_REGIONAL_CREDITO[] value) {
        this.value = value;
    }

}
