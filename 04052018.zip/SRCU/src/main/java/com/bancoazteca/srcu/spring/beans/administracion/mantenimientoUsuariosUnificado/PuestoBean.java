package com.bancoazteca.srcu.spring.beans.administracion.mantenimientoUsuariosUnificado;

import java.math.BigDecimal;

public class PuestoBean {
	private	int	puestoId;
	private String puestoDesc;
	
	public PuestoBean() {
		
	}

	public int getPuestoId() {
		return puestoId;
	}

	public void setPuestoId(int puestoId) {
		this.puestoId = puestoId;
	}
	
	public void setPuestoId(BigDecimal puestoId) {
		this.puestoId = puestoId.intValue();
	}

	public String getPuestoDesc() {
		return puestoDesc;
	}

	public void setPuestoDesc(String puestoDesc) {
		this.puestoDesc = puestoDesc;
	}

}
