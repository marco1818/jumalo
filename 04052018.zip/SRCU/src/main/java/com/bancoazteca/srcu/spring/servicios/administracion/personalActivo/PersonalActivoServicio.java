package com.bancoazteca.srcu.spring.servicios.administracion.personalActivo;

import java.util.List;

import com.bancoazteca.srcu.spring.beans.administracion.personalActivo.ComparacionSapBean;
import com.bancoazteca.srcu.spring.beans.administracion.personalActivo.PersonalActivoBean;

public interface PersonalActivoServicio {
	public List<PersonalActivoBean> consulta(int gerenciaId, int opcion);
	public List<ComparacionSapBean> comparacionSap(int deptoId);
}
