package com.bancoazteca.srcu.spring.ws.administracion.as400;

public class Respuesta400Bean {
	private int	codigo;
	private int mensajeId;
	private String mensaje;
	private String numeroEmpleado;
	private String nombreEmpleado;
	private String puesto;
	private int geografia;
	private String ultimoMovimiento;
	private String segmento;
	private int	zona;
	
	public Respuesta400Bean() {
		
	}

	public int getCodigo() {
		return codigo;
	}

	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}

	public int getMensajeId() {
		return mensajeId;
	}

	public void setMensajeId(int mensajeId) {
		this.mensajeId = mensajeId;
	}

	public String getMensaje() {
		return mensaje;
	}

	public void setMensaje(String mensaje) {
		this.mensaje = mensaje;
	}

	public String getNumeroEmpleado() {
		return numeroEmpleado;
	}

	public void setNumeroEmpleado(String numeroEmpleado) {
		this.numeroEmpleado = numeroEmpleado;
	}

	public String getNombreEmpleado() {
		return nombreEmpleado;
	}

	public void setNombreEmpleado(String nombreEmpleado) {
		this.nombreEmpleado = nombreEmpleado;
	}

	public String getPuesto() {
		return puesto;
	}

	public void setPuesto(String puesto) {
		this.puesto = puesto;
	}

	
	public int getGeografia() {
		return geografia;
	}

	public void setGeografia(int geografia) {
		this.geografia = geografia;
	}

	public String getUltimoMovimiento() {
		return ultimoMovimiento;
	}

	public void setUltimoMovimiento(String ultimoMovimiento) {
		this.ultimoMovimiento = ultimoMovimiento;
	}

	public String getSegmento() {
		return segmento;
	}

	public void setSegmento(String segmento) {
		this.segmento = segmento;
	}

	public int getZona() {
		return zona;
	}

	public void setZona(int zona) {
		this.zona = zona;
	}
}
