/**
 * ZHRLOGERR_VNTEMPHolder.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.bancoazteca.srcu.spring.ws.administracion.posicionesSap.axis.altaBajaPosicionesSap;

public final class ZHRLOGERR_VNTEMPHolder implements javax.xml.rpc.holders.Holder {
    public ZHRLOGERR_VNTEMP value;

    public ZHRLOGERR_VNTEMPHolder() {
    }

    public ZHRLOGERR_VNTEMPHolder(ZHRLOGERR_VNTEMP value) {
        this.value = value;
    }

}
