/**
 * ArrayOfZRH_REG_CRED_UOHolder.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.bancoazteca.srcu.spring.ws.administracion.posicionesSap.axis.altaBajaPosicionesSap;

public final class ArrayOfZRH_REG_CRED_UOHolder implements javax.xml.rpc.holders.Holder {
    public ZRH_REG_CRED_UO[] value;

    public ArrayOfZRH_REG_CRED_UOHolder() {
    }

    public ArrayOfZRH_REG_CRED_UOHolder(ZRH_REG_CRED_UO[] value) {
        this.value = value;
    }

}
