/**
 * ZRH_CATALOGOS.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.bancoazteca.srcu.spring.ws.administracion.posicionesSap.axis.altaBajaPosicionesSap;

public class ZRH_CATALOGOS  extends SAPStructure  implements java.io.Serializable {

	private static final long serialVersionUID = 369386343523130261L;

	private java.lang.String IDCAMPO;

    private java.lang.String VALCAMPO;

    public ZRH_CATALOGOS() {
    }

    public ZRH_CATALOGOS(
           java.lang.String IDCAMPO,
           java.lang.String VALCAMPO) {
        this.IDCAMPO = IDCAMPO;
        this.VALCAMPO = VALCAMPO;
    }


    /**
     * Gets the IDCAMPO value for this ZRH_CATALOGOS.
     * 
     * @return IDCAMPO
     */
    public java.lang.String getIDCAMPO() {
        return IDCAMPO;
    }


    /**
     * Sets the IDCAMPO value for this ZRH_CATALOGOS.
     * 
     * @param IDCAMPO
     */
    public void setIDCAMPO(java.lang.String IDCAMPO) {
        this.IDCAMPO = IDCAMPO;
    }


    /**
     * Gets the VALCAMPO value for this ZRH_CATALOGOS.
     * 
     * @return VALCAMPO
     */
    public java.lang.String getVALCAMPO() {
        return VALCAMPO;
    }


    /**
     * Sets the VALCAMPO value for this ZRH_CATALOGOS.
     * 
     * @param VALCAMPO
     */
    public void setVALCAMPO(java.lang.String VALCAMPO) {
        this.VALCAMPO = VALCAMPO;
    }

    private java.lang.Object __equalsCalc = null;
    @SuppressWarnings("unused")
	public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ZRH_CATALOGOS)) return false;
        ZRH_CATALOGOS other = (ZRH_CATALOGOS) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.IDCAMPO==null && other.getIDCAMPO()==null) || 
             (this.IDCAMPO!=null &&
              this.IDCAMPO.equals(other.getIDCAMPO()))) &&
            ((this.VALCAMPO==null && other.getVALCAMPO()==null) || 
             (this.VALCAMPO!=null &&
              this.VALCAMPO.equals(other.getVALCAMPO())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getIDCAMPO() != null) {
            _hashCode += getIDCAMPO().hashCode();
        }
        if (getVALCAMPO() != null) {
            _hashCode += getVALCAMPO().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ZRH_CATALOGOS.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://tempuri.org/", "ZRH_CATALOGOS"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("IDCAMPO");
        elemField.setXmlName(new javax.xml.namespace.QName("", "IDCAMPO"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("VALCAMPO");
        elemField.setXmlName(new javax.xml.namespace.QName("", "VALCAMPO"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    @SuppressWarnings("rawtypes")
	public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    @SuppressWarnings("rawtypes")
	public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
