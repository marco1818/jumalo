package com.bancoazteca.srcu.spring.daos.utilerias;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.bancoazteca.srcu.spring.beans.utilerias.CatalogoBean;

@Repository
public class UtileriasDAO extends BaseDAO{
	
	public interface Enum_Funciones_Utilerias{
		String	consultaItem	=	"CONSULTA_CAT_UNICO_2";
	}
	
	@SuppressWarnings("unchecked")
	public List<CatalogoBean> consultaItem(int catalogoId){
		List<CatalogoBean> catalogo = new ArrayList<CatalogoBean>();
		ArrayList<Object> parametros = new ArrayList<Object>();
		parametros.add(catalogoId);
		parametros.add("ES");
		
		catalogo = (List<CatalogoBean>) ejecutaFuncionAll(Enum_Funciones_Utilerias.consultaItem, parametros, new CatalogoBean().getClass());
		
		return catalogo;
	}
}
