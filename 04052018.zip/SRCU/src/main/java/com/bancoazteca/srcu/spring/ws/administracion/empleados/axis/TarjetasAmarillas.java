/**
 * TarjetasAmarillas.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.bancoazteca.srcu.spring.ws.administracion.empleados.axis;
@SuppressWarnings({ "unused", "rawtypes", "serial" })
public class TarjetasAmarillas  implements java.io.Serializable {
    private int empleado;

    private java.lang.String companiaPagadora;

    private int numeroTarjeta;

    public TarjetasAmarillas() {
    }

    public TarjetasAmarillas(
           int empleado,
           java.lang.String companiaPagadora,
           int numeroTarjeta) {
           this.empleado = empleado;
           this.companiaPagadora = companiaPagadora;
           this.numeroTarjeta = numeroTarjeta;
    }


    /**
     * Gets the empleado value for this TarjetasAmarillas.
     * 
     * @return empleado
     */
    public int getEmpleado() {
        return empleado;
    }


    /**
     * Sets the empleado value for this TarjetasAmarillas.
     * 
     * @param empleado
     */
    public void setEmpleado(int empleado) {
        this.empleado = empleado;
    }


    /**
     * Gets the companiaPagadora value for this TarjetasAmarillas.
     * 
     * @return companiaPagadora
     */
    public java.lang.String getCompaniaPagadora() {
        return companiaPagadora;
    }


    /**
     * Sets the companiaPagadora value for this TarjetasAmarillas.
     * 
     * @param companiaPagadora
     */
    public void setCompaniaPagadora(java.lang.String companiaPagadora) {
        this.companiaPagadora = companiaPagadora;
    }


    /**
     * Gets the numeroTarjeta value for this TarjetasAmarillas.
     * 
     * @return numeroTarjeta
     */
    public int getNumeroTarjeta() {
        return numeroTarjeta;
    }


    /**
     * Sets the numeroTarjeta value for this TarjetasAmarillas.
     * 
     * @param numeroTarjeta
     */
    public void setNumeroTarjeta(int numeroTarjeta) {
        this.numeroTarjeta = numeroTarjeta;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof TarjetasAmarillas)) return false;
        TarjetasAmarillas other = (TarjetasAmarillas) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this.empleado == other.getEmpleado() &&
            ((this.companiaPagadora==null && other.getCompaniaPagadora()==null) || 
             (this.companiaPagadora!=null &&
              this.companiaPagadora.equals(other.getCompaniaPagadora()))) &&
            this.numeroTarjeta == other.getNumeroTarjeta();
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += getEmpleado();
        if (getCompaniaPagadora() != null) {
            _hashCode += getCompaniaPagadora().hashCode();
        }
        _hashCode += getNumeroTarjeta();
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(TarjetasAmarillas.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "TarjetasAmarillas"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("empleado");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Empleado"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("companiaPagadora");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "CompaniaPagadora"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroTarjeta");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "NumeroTarjeta"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
