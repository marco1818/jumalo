package com.bancoazteca.srcu.spring.beans.utilerias;

public class DatosSessionStruts {
	// Personal Activo
	private int gerenciaId;
	// Mantenimiento a Telefonos, Mantenimiento Usuarios Sap
	private String numeroEmpleado;	
	// MantenimientoUsuariosSap
	private String numeroEmpleadoDelegado;
	private int	puestoDelegado;
	private int puestoOpera;
	
	public DatosSessionStruts() {
		
	}

	public int getGerenciaId() {
		return gerenciaId;
	}

	public void setGerenciaId(int gerenciaId) {
		this.gerenciaId = gerenciaId;
	}

	public String getNumeroEmpleado() {
		return numeroEmpleado;
	}

	public void setNumeroEmpleado(String numeroEmpleado) {
		this.numeroEmpleado = numeroEmpleado;
	}

	public String getNumeroEmpleadoDelegado() {
		return numeroEmpleadoDelegado;
	}

	public void setNumeroEmpleadoDelegado(String numeroEmpleadoDelegado) {
		this.numeroEmpleadoDelegado = numeroEmpleadoDelegado;
	}

	public int getPuestoDelegado() {
		return puestoDelegado;
	}

	public void setPuestoDelegado(int puestoDelegado) {
		this.puestoDelegado = puestoDelegado;
	}

	public int getPuestoOpera() {
		return puestoOpera;
	}

	public void setPuestoOpera(int puestoOpera) {
		this.puestoOpera = puestoOpera;
	}
	
}
