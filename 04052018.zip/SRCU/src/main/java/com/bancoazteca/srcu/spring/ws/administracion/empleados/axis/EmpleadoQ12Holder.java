/**
 * EmpleadoQ12Holder.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.bancoazteca.srcu.spring.ws.administracion.empleados.axis;

public final class EmpleadoQ12Holder implements javax.xml.rpc.holders.Holder {
    public EmpleadoQ12 value;

    public EmpleadoQ12Holder() {
    }

    public EmpleadoQ12Holder(EmpleadoQ12 value) {
        this.value = value;
    }

}
