package com.bancoazteca.srcu.spring.daos.administracion.mantenimientoTelefonos;

import com.bancoazteca.srcu.spring.beans.administracion.mantenimientoTelefonos.DatosEmpleadoBean;
import com.bancoazteca.srcu.spring.beans.administracion.mantenimientoTelefonos.MantenimientoTelefonosBean;
import com.bancoazteca.srcu.spring.beans.sistema.MensajeTransaccionBean;

public interface MantenimientoTelefonosDAO {
	public	DatosEmpleadoBean			consultaDatosGenerales(String numeroEmpleado);
	public	MensajeTransaccionBean		insertaTelefono(MantenimientoTelefonosBean mantenimientoTelefonosBean);
	public 	MensajeTransaccionBean		actualizaTelefono(MantenimientoTelefonosBean mantenimientoTelefonosBean);
	public	MantenimientoTelefonosBean 	consultaDatosEmpleado(MantenimientoTelefonosBean mantenimientoTelefonosBean);
}
