/**
 * Lee_Pos_LinRepResponseIt_LinrepHolder.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.bancoazteca.srcu.spring.ws.administracion.posicionesSap.axis.altaBajaPosicionesSap;

public final class Lee_Pos_LinRepResponseIt_LinrepHolder implements javax.xml.rpc.holders.Holder {
    public Lee_Pos_LinRepResponseIt_Linrep value;

    public Lee_Pos_LinRepResponseIt_LinrepHolder() {
    }

    public Lee_Pos_LinRepResponseIt_LinrepHolder(Lee_Pos_LinRepResponseIt_Linrep value) {
        this.value = value;
    }

}
