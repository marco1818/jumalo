/**
 * EmpleadoQ12.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.bancoazteca.srcu.spring.ws.administracion.empleados.axis;
@SuppressWarnings({ "unused", "rawtypes" })
public class EmpleadoQ12  implements java.io.Serializable {
    /**
	 * 
	 */
	private static final long serialVersionUID = 7887946085755368166L;

	private java.lang.String patron;

    private int pregunta;

    private int resultado;

    private int calificacion;

    public EmpleadoQ12() {
    }

    public EmpleadoQ12(
           java.lang.String patron,
           int pregunta,
           int resultado,
           int calificacion) {
           this.patron = patron;
           this.pregunta = pregunta;
           this.resultado = resultado;
           this.calificacion = calificacion;
    }


    /**
     * Gets the patron value for this EmpleadoQ12.
     * 
     * @return patron
     */
    public java.lang.String getPatron() {
        return patron;
    }


    /**
     * Sets the patron value for this EmpleadoQ12.
     * 
     * @param patron
     */
    public void setPatron(java.lang.String patron) {
        this.patron = patron;
    }


    /**
     * Gets the pregunta value for this EmpleadoQ12.
     * 
     * @return pregunta
     */
    public int getPregunta() {
        return pregunta;
    }


    /**
     * Sets the pregunta value for this EmpleadoQ12.
     * 
     * @param pregunta
     */
    public void setPregunta(int pregunta) {
        this.pregunta = pregunta;
    }


    /**
     * Gets the resultado value for this EmpleadoQ12.
     * 
     * @return resultado
     */
    public int getResultado() {
        return resultado;
    }


    /**
     * Sets the resultado value for this EmpleadoQ12.
     * 
     * @param resultado
     */
    public void setResultado(int resultado) {
        this.resultado = resultado;
    }


    /**
     * Gets the calificacion value for this EmpleadoQ12.
     * 
     * @return calificacion
     */
    public int getCalificacion() {
        return calificacion;
    }


    /**
     * Sets the calificacion value for this EmpleadoQ12.
     * 
     * @param calificacion
     */
    public void setCalificacion(int calificacion) {
        this.calificacion = calificacion;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof EmpleadoQ12)) return false;
        EmpleadoQ12 other = (EmpleadoQ12) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.patron==null && other.getPatron()==null) || 
             (this.patron!=null &&
              this.patron.equals(other.getPatron()))) &&
            this.pregunta == other.getPregunta() &&
            this.resultado == other.getResultado() &&
            this.calificacion == other.getCalificacion();
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getPatron() != null) {
            _hashCode += getPatron().hashCode();
        }
        _hashCode += getPregunta();
        _hashCode += getResultado();
        _hashCode += getCalificacion();
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(EmpleadoQ12.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "EmpleadoQ12"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("patron");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Patron"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("pregunta");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Pregunta"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("resultado");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "resultado"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("calificacion");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Calificacion"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
