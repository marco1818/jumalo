package com.bancoazteca.srcu.spring.daos.administracion.mantenimientoUsuariosAvante;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.bancoazteca.srcu.spring.beans.administracion.mantenimientoUsuariosAvante.AsignacionAvanteBean;
import com.bancoazteca.srcu.spring.beans.administracion.mantenimientoUsuariosAvante.AsignacionDepartamentosAvanteBean;
import com.bancoazteca.srcu.spring.beans.administracion.mantenimientoUsuariosAvante.DepartamentosAvanteBean;
import com.bancoazteca.srcu.spring.beans.administracion.mantenimientoUsuariosAvante.EmpleadosAvanteBean;
import com.bancoazteca.srcu.spring.beans.administracion.mantenimientoUsuariosAvante.JefesCobranzaBean;
import com.bancoazteca.srcu.spring.beans.sistema.MensajeTransaccionBean;
import com.bancoazteca.srcu.spring.daos.utilerias.BaseDAO;

@Repository
public class AsignacionAvanteDAOImpl extends BaseDAO implements AsignacionAvanteDAO{
	
	public interface Enum_Funciones_AsignacionAvanteDAO{
		String	consultaZonas			=	"ASIGNACION_AVANTE_CONSULTA_ZONAS";
		String	consultaCoordinadores	=	"ASIGNACION_AVANTE_CONSULTA_COORDINADORES";
		String	consultaRegiones		=	"ASIGNACION_AVANTE_CONSULTA_REGIONES";
		String	consultaGerencias		=	"ASIGNACION_AVANTE_CONSULTA_GERENCIAS";
		String	consultaJefesCobranza	=	"ASIGNACION_AVANTE_CONSULTA_JEFE_DE_COBRANZA";
		String	consultaEspecialistas	=	"ASIGNACION_AVANATE_CONSULTA_ESPECIALISTAS";
		String	insertaAsignacion		=	"ASIGNACION_AVANTE_INSERTA_ASIGNACION";
		String	eliminaAsignacion		=	"ASIGNACION_AVANTE_ELIMINA_ASIGNACION";
	}

	@Override
	public MensajeTransaccionBean eliminarAsignacion(AsignacionAvanteBean asignacionAvanteBean) {
		MensajeTransaccionBean mensajeTransaccionBean = new MensajeTransaccionBean();
		
		for(int x = 0; x < asignacionAvanteBean.getJcsAsignar().size(); x++) {
			if(asignacionAvanteBean.getEspeacialistaAsignado()!= null &&  asignacionAvanteBean.getEspeacialistaAsignado().size()>0) {
				ArrayList<Object> parametros = new ArrayList<Object>();
				parametros.add(asignacionAvanteBean.getGerenciaOperar());
				parametros.add(asignacionAvanteBean.getJcsAsignar().get(x));
				parametros.add(asignacionAvanteBean.getEspeacialistaAsignado().get(x));
				parametros.add(asignacionAvanteBean.getEmpleadoOpera());
				
				mensajeTransaccionBean = (MensajeTransaccionBean) ejecutaFuncion(Enum_Funciones_AsignacionAvanteDAO.eliminaAsignacion, parametros, new MensajeTransaccionBean().getClass());
				
				if(mensajeTransaccionBean.getMensajeId()!=0) {
					mensajeTransaccionBean.setNumeroMensaje(999);
					mensajeTransaccionBean.setDescripcionMensaje("NO FUE POSIBLE DES ASIGNAR A UNO O MAS ESPECIALISTAS, INTENTELO NUEVAMENTE.");
					break;
				}else {
					mensajeTransaccionBean.setNumeroMensaje(0);
					mensajeTransaccionBean.setDescripcionMensaje("DES ASIGNACION REALIZADA EXITOSAMENTE.");
				}
				
			}else {
				mensajeTransaccionBean.setNumeroMensaje(0);
				mensajeTransaccionBean.setDescripcionMensaje("DES ASIGNACION REALIZADA EXITOSAMENTE.");
			}
		}
		
		return mensajeTransaccionBean;
	}

	@Override
	public MensajeTransaccionBean insertaAsignacion(AsignacionAvanteBean asignacionAvanteBean) {
		MensajeTransaccionBean mensajeTransaccionBean = new MensajeTransaccionBean();
		
		for(int x = 0; x<asignacionAvanteBean.getJcsAsignar().size(); x++) {
			ArrayList<Object> parametros = new ArrayList<Object>();
			parametros.add(asignacionAvanteBean.getGerenciaOperar());
			parametros.add(asignacionAvanteBean.getJcsAsignar().get(x));
			parametros.add(asignacionAvanteBean.getEspecialistaAsignar().get(x));
			parametros.add(asignacionAvanteBean.getEmpleadoOpera());
			
			mensajeTransaccionBean = (MensajeTransaccionBean) ejecutaFuncion(Enum_Funciones_AsignacionAvanteDAO.insertaAsignacion, parametros, new MensajeTransaccionBean().getClass());
			
			if(mensajeTransaccionBean.getMensajeId()!=0) {
				mensajeTransaccionBean.setNumeroMensaje(999);
				mensajeTransaccionBean.setDescripcionMensaje("NO FUE POSIBLE ASIGNAR A UNO O MAS ESPECIALISTAS, INTENTELO NUEVAMENTE.");
				break;
			}else {
				mensajeTransaccionBean.setNumeroMensaje(0);
				mensajeTransaccionBean.setDescripcionMensaje("ASIGNACION REALIZADA EXITOSAMENTE.");
			}
			
		}
		
		return mensajeTransaccionBean;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<DepartamentosAvanteBean> consultaZonas(AsignacionAvanteBean asignacionAvanteBean) {
		List<DepartamentosAvanteBean> zonas = new ArrayList<DepartamentosAvanteBean>();
		ArrayList<Object> parametros = new ArrayList<Object>();
		parametros.add(asignacionAvanteBean.getEmpleadoOpera());
		
		zonas = (List<DepartamentosAvanteBean>) ejecutaFuncionAll(Enum_Funciones_AsignacionAvanteDAO.consultaZonas, parametros, new DepartamentosAvanteBean().getClass());
	
		return zonas;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<EmpleadosAvanteBean> consultaCoordinadores() {
		List<EmpleadosAvanteBean> coordinadores = new ArrayList<EmpleadosAvanteBean>();
		ArrayList<Object> parametros = new ArrayList<Object>();
		
		coordinadores = (List<EmpleadosAvanteBean>) ejecutaFuncionAll(Enum_Funciones_AsignacionAvanteDAO.consultaCoordinadores, parametros, new EmpleadosAvanteBean().getClass());
		
		return coordinadores;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<AsignacionDepartamentosAvanteBean> consultaRegiones(AsignacionAvanteBean asignacionAvanteBean) {
		List<AsignacionDepartamentosAvanteBean> regiones = new ArrayList<AsignacionDepartamentosAvanteBean>();
		ArrayList<Object> parametros = new ArrayList<Object>();
		parametros.add(asignacionAvanteBean.getCoordinadorOperar());
		parametros.add(asignacionAvanteBean.getZonaOperar());
		
		regiones = (List<AsignacionDepartamentosAvanteBean>) ejecutaFuncionAll(Enum_Funciones_AsignacionAvanteDAO.consultaRegiones, parametros, new AsignacionDepartamentosAvanteBean().getClass());

		return regiones;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<AsignacionDepartamentosAvanteBean> consultaGerencias(AsignacionAvanteBean asignacionAvanteBean) {
		List<AsignacionDepartamentosAvanteBean> gerencias = new ArrayList<AsignacionDepartamentosAvanteBean>();
		ArrayList<Object> parametros = new ArrayList<Object>();
		parametros.add(asignacionAvanteBean.getCoordinadorOperar());
		parametros.add(asignacionAvanteBean.getRegionOperar());
		
		gerencias = (List<AsignacionDepartamentosAvanteBean>) ejecutaFuncionAll(Enum_Funciones_AsignacionAvanteDAO.consultaGerencias, parametros, new AsignacionDepartamentosAvanteBean().getClass());
	
		return gerencias;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<JefesCobranzaBean> jefesCobranza(AsignacionAvanteBean asignacionAvanteBean) {
		List<JefesCobranzaBean> jefesCobranza = new ArrayList<JefesCobranzaBean>();
		ArrayList<Object> parametros = new ArrayList<Object>();
		parametros.add(asignacionAvanteBean.getGerenciaOperar());
		parametros.add(asignacionAvanteBean.getCoordinadorOperar());
		
		jefesCobranza = (List<JefesCobranzaBean>) ejecutaFuncionAll(Enum_Funciones_AsignacionAvanteDAO.consultaJefesCobranza, parametros, new JefesCobranzaBean().getClass());
		
		return jefesCobranza;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<EmpleadosAvanteBean> especialistasRegion(AsignacionAvanteBean asignacionAvanteBean) {
		List<EmpleadosAvanteBean> especialistas = new ArrayList<EmpleadosAvanteBean>();
		ArrayList<Object> parametros = new ArrayList<Object>();
		parametros.add(asignacionAvanteBean.getCoordinadorOperar());
		especialistas = (List<EmpleadosAvanteBean>) ejecutaFuncionAll(Enum_Funciones_AsignacionAvanteDAO.consultaEspecialistas, parametros, new EmpleadosAvanteBean().getClass());
		
		return especialistas;
	}

}
