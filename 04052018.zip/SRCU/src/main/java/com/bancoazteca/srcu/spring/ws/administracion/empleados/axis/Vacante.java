/**
 * Vacante.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.bancoazteca.srcu.spring.ws.administracion.empleados.axis;
@SuppressWarnings({ "unused", "rawtypes", "serial" })
public class Vacante  implements java.io.Serializable {
    private java.lang.String idPais;

    private java.lang.String canal;

    private int tienda;

    private int idPuesto;

    private int idFuncion;

    private java.lang.String desFuncion;

    private java.lang.String fechaVacante;

    public Vacante() {
    }

    public Vacante(
           java.lang.String idPais,
           java.lang.String canal,
           int tienda,
           int idPuesto,
           int idFuncion,
           java.lang.String desFuncion,
           java.lang.String fechaVacante) {
           this.idPais = idPais;
           this.canal = canal;
           this.tienda = tienda;
           this.idPuesto = idPuesto;
           this.idFuncion = idFuncion;
           this.desFuncion = desFuncion;
           this.fechaVacante = fechaVacante;
    }


    /**
     * Gets the idPais value for this Vacante.
     * 
     * @return idPais
     */
    public java.lang.String getIdPais() {
        return idPais;
    }


    /**
     * Sets the idPais value for this Vacante.
     * 
     * @param idPais
     */
    public void setIdPais(java.lang.String idPais) {
        this.idPais = idPais;
    }


    /**
     * Gets the canal value for this Vacante.
     * 
     * @return canal
     */
    public java.lang.String getCanal() {
        return canal;
    }


    /**
     * Sets the canal value for this Vacante.
     * 
     * @param canal
     */
    public void setCanal(java.lang.String canal) {
        this.canal = canal;
    }


    /**
     * Gets the tienda value for this Vacante.
     * 
     * @return tienda
     */
    public int getTienda() {
        return tienda;
    }


    /**
     * Sets the tienda value for this Vacante.
     * 
     * @param tienda
     */
    public void setTienda(int tienda) {
        this.tienda = tienda;
    }


    /**
     * Gets the idPuesto value for this Vacante.
     * 
     * @return idPuesto
     */
    public int getIdPuesto() {
        return idPuesto;
    }


    /**
     * Sets the idPuesto value for this Vacante.
     * 
     * @param idPuesto
     */
    public void setIdPuesto(int idPuesto) {
        this.idPuesto = idPuesto;
    }


    /**
     * Gets the idFuncion value for this Vacante.
     * 
     * @return idFuncion
     */
    public int getIdFuncion() {
        return idFuncion;
    }


    /**
     * Sets the idFuncion value for this Vacante.
     * 
     * @param idFuncion
     */
    public void setIdFuncion(int idFuncion) {
        this.idFuncion = idFuncion;
    }


    /**
     * Gets the desFuncion value for this Vacante.
     * 
     * @return desFuncion
     */
    public java.lang.String getDesFuncion() {
        return desFuncion;
    }


    /**
     * Sets the desFuncion value for this Vacante.
     * 
     * @param desFuncion
     */
    public void setDesFuncion(java.lang.String desFuncion) {
        this.desFuncion = desFuncion;
    }


    /**
     * Gets the fechaVacante value for this Vacante.
     * 
     * @return fechaVacante
     */
    public java.lang.String getFechaVacante() {
        return fechaVacante;
    }


    /**
     * Sets the fechaVacante value for this Vacante.
     * 
     * @param fechaVacante
     */
    public void setFechaVacante(java.lang.String fechaVacante) {
        this.fechaVacante = fechaVacante;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Vacante)) return false;
        Vacante other = (Vacante) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.idPais==null && other.getIdPais()==null) || 
             (this.idPais!=null &&
              this.idPais.equals(other.getIdPais()))) &&
            ((this.canal==null && other.getCanal()==null) || 
             (this.canal!=null &&
              this.canal.equals(other.getCanal()))) &&
            this.tienda == other.getTienda() &&
            this.idPuesto == other.getIdPuesto() &&
            this.idFuncion == other.getIdFuncion() &&
            ((this.desFuncion==null && other.getDesFuncion()==null) || 
             (this.desFuncion!=null &&
              this.desFuncion.equals(other.getDesFuncion()))) &&
            ((this.fechaVacante==null && other.getFechaVacante()==null) || 
             (this.fechaVacante!=null &&
              this.fechaVacante.equals(other.getFechaVacante())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getIdPais() != null) {
            _hashCode += getIdPais().hashCode();
        }
        if (getCanal() != null) {
            _hashCode += getCanal().hashCode();
        }
        _hashCode += getTienda();
        _hashCode += getIdPuesto();
        _hashCode += getIdFuncion();
        if (getDesFuncion() != null) {
            _hashCode += getDesFuncion().hashCode();
        }
        if (getFechaVacante() != null) {
            _hashCode += getFechaVacante().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Vacante.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Vacante"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("idPais");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "idPais"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("canal");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Canal"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("tienda");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Tienda"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("idPuesto");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "idPuesto"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("idFuncion");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "idFuncion"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("desFuncion");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "DesFuncion"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("fechaVacante");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "FechaVacante"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
