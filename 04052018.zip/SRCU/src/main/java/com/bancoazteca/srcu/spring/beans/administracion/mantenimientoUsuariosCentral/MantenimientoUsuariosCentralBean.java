package com.bancoazteca.srcu.spring.beans.administracion.mantenimientoUsuariosCentral;

import com.bancoazteca.srcu.spring.beans.administracion.mantenimientoTelefonos.DatosEmpleadoBean;
import com.bancoazteca.srcu.spring.beans.utilerias.BaseBean;

public class MantenimientoUsuariosCentralBean extends BaseBean{
	private DatosEmpleadoBean datosEmpleado;
	private String numeroEmpleado;
	private String empleadoOpera;
	private int deptoSeleccionado;
	private String ip;
	
	public MantenimientoUsuariosCentralBean() {
		
	}

	public DatosEmpleadoBean getDatosEmpleado() {
		return datosEmpleado;
	}

	public void setDatosEmpleado(DatosEmpleadoBean datosEmpleado) {
		this.datosEmpleado = datosEmpleado;
	}

	public String getNumeroEmpleado() {
		return numeroEmpleado;
	}

	public void setNumeroEmpleado(String numeroEmpleado) {
		this.numeroEmpleado = numeroEmpleado;
	}

	public String getEmpleadoOpera() {
		return empleadoOpera;
	}

	public void setEmpleadoOpera(String empleadoOpera) {
		this.empleadoOpera = empleadoOpera;
	}

	public int getDeptoSeleccionado() {
		return deptoSeleccionado;
	}

	public void setDeptoSeleccionado(int deptoSeleccionado) {
		this.deptoSeleccionado = deptoSeleccionado;
	}

	public String getIp() {
		return ip;
	}

	public void setIp(String ip) {
		this.ip = ip;
	}	
}
