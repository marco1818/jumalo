/**
 * Estructura_DatosCorreo.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.bancoazteca.srcu.spring.ws.administracion.empleados.axis;
@SuppressWarnings({ "unused", "rawtypes" })
public class Estructura_DatosCorreo  implements java.io.Serializable {
    /**
	 * 
	 */
	private static final long serialVersionUID = -1275418495207312577L;

	private java.lang.String APaterno;

    private java.lang.String AMaterno;

    private java.lang.String nombre;

    private java.lang.String tienda;

    private java.lang.String nombre_Tienda;

    private int funcion;

    private java.lang.String nombreFuncion;

    private int CC;

    private long CC_TVA;

    private java.lang.String negocio;

    private int posicion;

    private int jefe;

    private java.lang.String nombre_Jefe;

    private int pais;

    public Estructura_DatosCorreo() {
    }

    public Estructura_DatosCorreo(
           java.lang.String APaterno,
           java.lang.String AMaterno,
           java.lang.String nombre,
           java.lang.String tienda,
           java.lang.String nombre_Tienda,
           int funcion,
           java.lang.String nombreFuncion,
           int CC,
           long CC_TVA,
           java.lang.String negocio,
           int posicion,
           int jefe,
           java.lang.String nombre_Jefe,
           int pais) {
           this.APaterno = APaterno;
           this.AMaterno = AMaterno;
           this.nombre = nombre;
           this.tienda = tienda;
           this.nombre_Tienda = nombre_Tienda;
           this.funcion = funcion;
           this.nombreFuncion = nombreFuncion;
           this.CC = CC;
           this.CC_TVA = CC_TVA;
           this.negocio = negocio;
           this.posicion = posicion;
           this.jefe = jefe;
           this.nombre_Jefe = nombre_Jefe;
           this.pais = pais;
    }


    /**
     * Gets the APaterno value for this Estructura_DatosCorreo.
     * 
     * @return APaterno
     */
    public java.lang.String getAPaterno() {
        return APaterno;
    }


    /**
     * Sets the APaterno value for this Estructura_DatosCorreo.
     * 
     * @param APaterno
     */
    public void setAPaterno(java.lang.String APaterno) {
        this.APaterno = APaterno;
    }


    /**
     * Gets the AMaterno value for this Estructura_DatosCorreo.
     * 
     * @return AMaterno
     */
    public java.lang.String getAMaterno() {
        return AMaterno;
    }


    /**
     * Sets the AMaterno value for this Estructura_DatosCorreo.
     * 
     * @param AMaterno
     */
    public void setAMaterno(java.lang.String AMaterno) {
        this.AMaterno = AMaterno;
    }


    /**
     * Gets the nombre value for this Estructura_DatosCorreo.
     * 
     * @return nombre
     */
    public java.lang.String getNombre() {
        return nombre;
    }


    /**
     * Sets the nombre value for this Estructura_DatosCorreo.
     * 
     * @param nombre
     */
    public void setNombre(java.lang.String nombre) {
        this.nombre = nombre;
    }


    /**
     * Gets the tienda value for this Estructura_DatosCorreo.
     * 
     * @return tienda
     */
    public java.lang.String getTienda() {
        return tienda;
    }


    /**
     * Sets the tienda value for this Estructura_DatosCorreo.
     * 
     * @param tienda
     */
    public void setTienda(java.lang.String tienda) {
        this.tienda = tienda;
    }


    /**
     * Gets the nombre_Tienda value for this Estructura_DatosCorreo.
     * 
     * @return nombre_Tienda
     */
    public java.lang.String getNombre_Tienda() {
        return nombre_Tienda;
    }


    /**
     * Sets the nombre_Tienda value for this Estructura_DatosCorreo.
     * 
     * @param nombre_Tienda
     */
    public void setNombre_Tienda(java.lang.String nombre_Tienda) {
        this.nombre_Tienda = nombre_Tienda;
    }


    /**
     * Gets the funcion value for this Estructura_DatosCorreo.
     * 
     * @return funcion
     */
    public int getFuncion() {
        return funcion;
    }


    /**
     * Sets the funcion value for this Estructura_DatosCorreo.
     * 
     * @param funcion
     */
    public void setFuncion(int funcion) {
        this.funcion = funcion;
    }


    /**
     * Gets the nombreFuncion value for this Estructura_DatosCorreo.
     * 
     * @return nombreFuncion
     */
    public java.lang.String getNombreFuncion() {
        return nombreFuncion;
    }


    /**
     * Sets the nombreFuncion value for this Estructura_DatosCorreo.
     * 
     * @param nombreFuncion
     */
    public void setNombreFuncion(java.lang.String nombreFuncion) {
        this.nombreFuncion = nombreFuncion;
    }


    /**
     * Gets the CC value for this Estructura_DatosCorreo.
     * 
     * @return CC
     */
    public int getCC() {
        return CC;
    }


    /**
     * Sets the CC value for this Estructura_DatosCorreo.
     * 
     * @param CC
     */
    public void setCC(int CC) {
        this.CC = CC;
    }


    /**
     * Gets the CC_TVA value for this Estructura_DatosCorreo.
     * 
     * @return CC_TVA
     */
    public long getCC_TVA() {
        return CC_TVA;
    }


    /**
     * Sets the CC_TVA value for this Estructura_DatosCorreo.
     * 
     * @param CC_TVA
     */
    public void setCC_TVA(long CC_TVA) {
        this.CC_TVA = CC_TVA;
    }


    /**
     * Gets the negocio value for this Estructura_DatosCorreo.
     * 
     * @return negocio
     */
    public java.lang.String getNegocio() {
        return negocio;
    }


    /**
     * Sets the negocio value for this Estructura_DatosCorreo.
     * 
     * @param negocio
     */
    public void setNegocio(java.lang.String negocio) {
        this.negocio = negocio;
    }


    /**
     * Gets the posicion value for this Estructura_DatosCorreo.
     * 
     * @return posicion
     */
    public int getPosicion() {
        return posicion;
    }


    /**
     * Sets the posicion value for this Estructura_DatosCorreo.
     * 
     * @param posicion
     */
    public void setPosicion(int posicion) {
        this.posicion = posicion;
    }


    /**
     * Gets the jefe value for this Estructura_DatosCorreo.
     * 
     * @return jefe
     */
    public int getJefe() {
        return jefe;
    }


    /**
     * Sets the jefe value for this Estructura_DatosCorreo.
     * 
     * @param jefe
     */
    public void setJefe(int jefe) {
        this.jefe = jefe;
    }


    /**
     * Gets the nombre_Jefe value for this Estructura_DatosCorreo.
     * 
     * @return nombre_Jefe
     */
    public java.lang.String getNombre_Jefe() {
        return nombre_Jefe;
    }


    /**
     * Sets the nombre_Jefe value for this Estructura_DatosCorreo.
     * 
     * @param nombre_Jefe
     */
    public void setNombre_Jefe(java.lang.String nombre_Jefe) {
        this.nombre_Jefe = nombre_Jefe;
    }


    /**
     * Gets the pais value for this Estructura_DatosCorreo.
     * 
     * @return pais
     */
    public int getPais() {
        return pais;
    }


    /**
     * Sets the pais value for this Estructura_DatosCorreo.
     * 
     * @param pais
     */
    public void setPais(int pais) {
        this.pais = pais;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Estructura_DatosCorreo)) return false;
        Estructura_DatosCorreo other = (Estructura_DatosCorreo) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.APaterno==null && other.getAPaterno()==null) || 
             (this.APaterno!=null &&
              this.APaterno.equals(other.getAPaterno()))) &&
            ((this.AMaterno==null && other.getAMaterno()==null) || 
             (this.AMaterno!=null &&
              this.AMaterno.equals(other.getAMaterno()))) &&
            ((this.nombre==null && other.getNombre()==null) || 
             (this.nombre!=null &&
              this.nombre.equals(other.getNombre()))) &&
            ((this.tienda==null && other.getTienda()==null) || 
             (this.tienda!=null &&
              this.tienda.equals(other.getTienda()))) &&
            ((this.nombre_Tienda==null && other.getNombre_Tienda()==null) || 
             (this.nombre_Tienda!=null &&
              this.nombre_Tienda.equals(other.getNombre_Tienda()))) &&
            this.funcion == other.getFuncion() &&
            ((this.nombreFuncion==null && other.getNombreFuncion()==null) || 
             (this.nombreFuncion!=null &&
              this.nombreFuncion.equals(other.getNombreFuncion()))) &&
            this.CC == other.getCC() &&
            this.CC_TVA == other.getCC_TVA() &&
            ((this.negocio==null && other.getNegocio()==null) || 
             (this.negocio!=null &&
              this.negocio.equals(other.getNegocio()))) &&
            this.posicion == other.getPosicion() &&
            this.jefe == other.getJefe() &&
            ((this.nombre_Jefe==null && other.getNombre_Jefe()==null) || 
             (this.nombre_Jefe!=null &&
              this.nombre_Jefe.equals(other.getNombre_Jefe()))) &&
            this.pais == other.getPais();
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getAPaterno() != null) {
            _hashCode += getAPaterno().hashCode();
        }
        if (getAMaterno() != null) {
            _hashCode += getAMaterno().hashCode();
        }
        if (getNombre() != null) {
            _hashCode += getNombre().hashCode();
        }
        if (getTienda() != null) {
            _hashCode += getTienda().hashCode();
        }
        if (getNombre_Tienda() != null) {
            _hashCode += getNombre_Tienda().hashCode();
        }
        _hashCode += getFuncion();
        if (getNombreFuncion() != null) {
            _hashCode += getNombreFuncion().hashCode();
        }
        _hashCode += getCC();
        _hashCode += new Long(getCC_TVA()).hashCode();
        if (getNegocio() != null) {
            _hashCode += getNegocio().hashCode();
        }
        _hashCode += getPosicion();
        _hashCode += getJefe();
        if (getNombre_Jefe() != null) {
            _hashCode += getNombre_Jefe().hashCode();
        }
        _hashCode += getPais();
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Estructura_DatosCorreo.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Estructura_DatosCorreo"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("APaterno");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "APaterno"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMaterno");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "AMaterno"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nombre");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Nombre"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("tienda");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Tienda"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nombre_Tienda");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Nombre_Tienda"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("funcion");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Funcion"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nombreFuncion");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "NombreFuncion"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CC");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "CC"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CC_TVA");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "CC_TVA"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("negocio");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Negocio"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("posicion");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Posicion"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("jefe");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Jefe"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nombre_Jefe");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Nombre_Jefe"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("pais");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Pais"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
