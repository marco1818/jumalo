package com.bancoazteca.srcu.spring.servicios.utilerias;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.bancoazteca.srcu.spring.beans.utilerias.CatalogoBean;
import com.bancoazteca.srcu.spring.daos.utilerias.UtileriasDAO;

@Component
public class BaseServicio {
	
	public interface Enum_Contantes{
		int	activo	=	1;
	}
	
	@Autowired
	private UtileriasDAO utileriasDAO;
	
	
	public	List<CatalogoBean> consultaItem(int catalogoId){
		return utileriasDAO.consultaItem(catalogoId);
	}
	
	public	CatalogoBean consultaSubItem(int catalogoId,int subItemId){
		List<CatalogoBean> catalogo	= new ArrayList<CatalogoBean>();
		CatalogoBean	catalogoBean = new CatalogoBean();
		
		catalogo = utileriasDAO.consultaItem(catalogoId);
		
		for(CatalogoBean item: catalogo) {
			if(item.getSubItemStat() == Enum_Contantes.activo && item.getSubItemId() == subItemId) {
				catalogoBean = item;
				break;
			}
		}
		
		return catalogoBean;
	}

	public int consultaPais() {
		try {
			System.out.println("Verificando Pais...:"+java.net.InetAddress.getLocalHost().getCanonicalHostName().toLowerCase());
			System.out.println("Verificando Pais...:"+InetAddress.getLocalHost().getHostAddress());
			String ip = InetAddress.getLocalHost().getHostAddress();
			 InetAddress addr = InetAddress.getByName(ip);
			 System.out.println(addr.getHostName());
		} catch (UnknownHostException e) {
		}
		return 1;
	}
	public void setUtileriasDAO(UtileriasDAO utileriasDAO) {
		this.utileriasDAO = utileriasDAO;
	} 
		
}
