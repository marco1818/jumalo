/**
 * ZSN_REG_CRED_CONSUL_POS_CECO.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.bancoazteca.srcu.spring.ws.administracion.posicionesSap.axis.consultaPosicionesSap;

public interface ZSN_REG_CRED_CONSUL_POS_CECO extends javax.xml.rpc.Service {
    public java.lang.String getZBN_REG_CRED_CONSUL_POS_CECOAddress();

    public ZSD_REG_CRED_CONSUL_POS_CECO getZBN_REG_CRED_CONSUL_POS_CECO() throws javax.xml.rpc.ServiceException;

    public ZSD_REG_CRED_CONSUL_POS_CECO getZBN_REG_CRED_CONSUL_POS_CECO(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
