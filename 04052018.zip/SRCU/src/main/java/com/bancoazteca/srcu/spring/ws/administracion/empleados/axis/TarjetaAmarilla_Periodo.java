/**
 * TarjetaAmarilla_Periodo.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.bancoazteca.srcu.spring.ws.administracion.empleados.axis;
@SuppressWarnings({ "unused", "rawtypes", "serial" })
public class TarjetaAmarilla_Periodo  implements java.io.Serializable {
    private int anio;

    private int semana;

    private int empleado;

    private int noTarjetas;

    public TarjetaAmarilla_Periodo() {
    }

    public TarjetaAmarilla_Periodo(
           int anio,
           int semana,
           int empleado,
           int noTarjetas) {
           this.anio = anio;
           this.semana = semana;
           this.empleado = empleado;
           this.noTarjetas = noTarjetas;
    }


    /**
     * Gets the anio value for this TarjetaAmarilla_Periodo.
     * 
     * @return anio
     */
    public int getAnio() {
        return anio;
    }


    /**
     * Sets the anio value for this TarjetaAmarilla_Periodo.
     * 
     * @param anio
     */
    public void setAnio(int anio) {
        this.anio = anio;
    }


    /**
     * Gets the semana value for this TarjetaAmarilla_Periodo.
     * 
     * @return semana
     */
    public int getSemana() {
        return semana;
    }


    /**
     * Sets the semana value for this TarjetaAmarilla_Periodo.
     * 
     * @param semana
     */
    public void setSemana(int semana) {
        this.semana = semana;
    }


    /**
     * Gets the empleado value for this TarjetaAmarilla_Periodo.
     * 
     * @return empleado
     */
    public int getEmpleado() {
        return empleado;
    }


    /**
     * Sets the empleado value for this TarjetaAmarilla_Periodo.
     * 
     * @param empleado
     */
    public void setEmpleado(int empleado) {
        this.empleado = empleado;
    }


    /**
     * Gets the noTarjetas value for this TarjetaAmarilla_Periodo.
     * 
     * @return noTarjetas
     */
    public int getNoTarjetas() {
        return noTarjetas;
    }


    /**
     * Sets the noTarjetas value for this TarjetaAmarilla_Periodo.
     * 
     * @param noTarjetas
     */
    public void setNoTarjetas(int noTarjetas) {
        this.noTarjetas = noTarjetas;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof TarjetaAmarilla_Periodo)) return false;
        TarjetaAmarilla_Periodo other = (TarjetaAmarilla_Periodo) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this.anio == other.getAnio() &&
            this.semana == other.getSemana() &&
            this.empleado == other.getEmpleado() &&
            this.noTarjetas == other.getNoTarjetas();
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += getAnio();
        _hashCode += getSemana();
        _hashCode += getEmpleado();
        _hashCode += getNoTarjetas();
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(TarjetaAmarilla_Periodo.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "TarjetaAmarilla_Periodo"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("anio");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Anio"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("semana");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Semana"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("empleado");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Empleado"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("noTarjetas");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "NoTarjetas"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
