package com.bancoazteca.srcu.spring.controladores.administracion.mantenimientoTelefonos;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.ModelAndView;

import com.bancoazteca.srcu.spring.beans.administracion.mantenimientoTelefonos.MantenimientoTelefonosBean;
import com.bancoazteca.srcu.spring.beans.sistema.MensajeTransaccionBean;
import com.bancoazteca.srcu.spring.beans.utilerias.DatosSessionStruts;
import com.bancoazteca.srcu.spring.servicios.administracion.mantenimientoTelefonos.MantenimientoTelefonosServicio;
import com.bancoazteca.srcu.spring.servicios.administracion.mantenimientoTelefonos.MantenimientoTelefonosServicioImpl.Enum_Consultas_MantenimientoTelefonosServicio;

@Controller
public class MantenimientoTelefonosControlador {
	
	@Autowired
	private MantenimientoTelefonosServicio mantenimientoTelefonosServicio; 
	
	@InitBinder
	public void InitBinder(WebDataBinder webDataBinder, WebRequest webRequest) {
		webDataBinder.setDisallowedFields("");
	}
	
	@RequestMapping(value= {"/mantenimientoTelefonos.htm"}, method=RequestMethod.GET)
	public ModelAndView mantenimientoTelefonos() {
		ModelAndView modelAndView = new ModelAndView();
		
		return modelAndView;
	}
	
	@RequestMapping(value= {"/mantenimientoTelefonosSRCU.htm"}, method=RequestMethod.GET)
	public ModelAndView mantenimientoTelefonos(@ModelAttribute("datosSessionStruts") DatosSessionStruts datosSessionStruts) {
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("administracion/mantenimientoTelefonos/mantenimientoTelefonos");
		
		MantenimientoTelefonosBean mantenimientoTelefonos = new MantenimientoTelefonosBean();
		mantenimientoTelefonos.setNumeroEmpleado(datosSessionStruts.getNumeroEmpleado());
		MantenimientoTelefonosBean mantenimientoTelefonosBean = mantenimientoTelefonosServicio.consulta(Enum_Consultas_MantenimientoTelefonosServicio.datosEmpleado, mantenimientoTelefonos);
		
		modelAndView.addObject("mantenimientoTelefonosBean",mantenimientoTelefonosBean);
		
		return modelAndView;
	}
	
	@RequestMapping(value= {"/mantenimientoTelefonos.htm"}, method=RequestMethod.POST)
	public ModelAndView mantenimientoTelefonos1(@ModelAttribute("mantenimientoTelefonosBean")MantenimientoTelefonosBean mantenimientoTelefonosBean, @RequestParam("tipoOperacion") int tipoOperacion) {
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("sistema/resultadoTransaccion");
		
		MensajeTransaccionBean mensajeTransaccionBean = mantenimientoTelefonosServicio.grabaTransaccion(tipoOperacion, mantenimientoTelefonosBean);
		
		modelAndView.addObject("mensajeTransaccionBean",mensajeTransaccionBean);
		return modelAndView;
	}

	public void setMantenimientoTelefonosServicio(MantenimientoTelefonosServicio mantenimientoTelefonosServicio) {
		this.mantenimientoTelefonosServicio = mantenimientoTelefonosServicio;
	}
	
}
