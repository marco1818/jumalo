/**
 * CuotaPatronal.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.bancoazteca.srcu.spring.ws.administracion.empleados.axis;

public class CuotaPatronal  implements java.io.Serializable {

	private static final long serialVersionUID = 7976517145651582303L;

	private int FICONCEPTOID;

    private int FIPERIODOID;

    private int FIEJERCICIOID;

    private int FIOBREROPATRONALID;

    private java.math.BigDecimal FNIMPORTE;

    private java.lang.String FCSOCIEDAD;

    public CuotaPatronal() {
    }

    public CuotaPatronal(
           int FICONCEPTOID,
           int FIPERIODOID,
           int FIEJERCICIOID,
           int FIOBREROPATRONALID,
           java.math.BigDecimal FNIMPORTE,
           java.lang.String FCSOCIEDAD) {
           this.FICONCEPTOID = FICONCEPTOID;
           this.FIPERIODOID = FIPERIODOID;
           this.FIEJERCICIOID = FIEJERCICIOID;
           this.FIOBREROPATRONALID = FIOBREROPATRONALID;
           this.FNIMPORTE = FNIMPORTE;
           this.FCSOCIEDAD = FCSOCIEDAD;
    }


    /**
     * Gets the FICONCEPTOID value for this CuotaPatronal.
     * 
     * @return FICONCEPTOID
     */
    public int getFICONCEPTOID() {
        return FICONCEPTOID;
    }


    /**
     * Sets the FICONCEPTOID value for this CuotaPatronal.
     * 
     * @param FICONCEPTOID
     */
    public void setFICONCEPTOID(int FICONCEPTOID) {
        this.FICONCEPTOID = FICONCEPTOID;
    }


    /**
     * Gets the FIPERIODOID value for this CuotaPatronal.
     * 
     * @return FIPERIODOID
     */
    public int getFIPERIODOID() {
        return FIPERIODOID;
    }


    /**
     * Sets the FIPERIODOID value for this CuotaPatronal.
     * 
     * @param FIPERIODOID
     */
    public void setFIPERIODOID(int FIPERIODOID) {
        this.FIPERIODOID = FIPERIODOID;
    }


    /**
     * Gets the FIEJERCICIOID value for this CuotaPatronal.
     * 
     * @return FIEJERCICIOID
     */
    public int getFIEJERCICIOID() {
        return FIEJERCICIOID;
    }


    /**
     * Sets the FIEJERCICIOID value for this CuotaPatronal.
     * 
     * @param FIEJERCICIOID
     */
    public void setFIEJERCICIOID(int FIEJERCICIOID) {
        this.FIEJERCICIOID = FIEJERCICIOID;
    }


    /**
     * Gets the FIOBREROPATRONALID value for this CuotaPatronal.
     * 
     * @return FIOBREROPATRONALID
     */
    public int getFIOBREROPATRONALID() {
        return FIOBREROPATRONALID;
    }


    /**
     * Sets the FIOBREROPATRONALID value for this CuotaPatronal.
     * 
     * @param FIOBREROPATRONALID
     */
    public void setFIOBREROPATRONALID(int FIOBREROPATRONALID) {
        this.FIOBREROPATRONALID = FIOBREROPATRONALID;
    }


    /**
     * Gets the FNIMPORTE value for this CuotaPatronal.
     * 
     * @return FNIMPORTE
     */
    public java.math.BigDecimal getFNIMPORTE() {
        return FNIMPORTE;
    }


    /**
     * Sets the FNIMPORTE value for this CuotaPatronal.
     * 
     * @param FNIMPORTE
     */
    public void setFNIMPORTE(java.math.BigDecimal FNIMPORTE) {
        this.FNIMPORTE = FNIMPORTE;
    }


    /**
     * Gets the FCSOCIEDAD value for this CuotaPatronal.
     * 
     * @return FCSOCIEDAD
     */
    public java.lang.String getFCSOCIEDAD() {
        return FCSOCIEDAD;
    }


    /**
     * Sets the FCSOCIEDAD value for this CuotaPatronal.
     * 
     * @param FCSOCIEDAD
     */
    public void setFCSOCIEDAD(java.lang.String FCSOCIEDAD) {
        this.FCSOCIEDAD = FCSOCIEDAD;
    }

    private java.lang.Object __equalsCalc = null;
    @SuppressWarnings("unused")
	public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof CuotaPatronal)) return false;
        CuotaPatronal other = (CuotaPatronal) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this.FICONCEPTOID == other.getFICONCEPTOID() &&
            this.FIPERIODOID == other.getFIPERIODOID() &&
            this.FIEJERCICIOID == other.getFIEJERCICIOID() &&
            this.FIOBREROPATRONALID == other.getFIOBREROPATRONALID() &&
            ((this.FNIMPORTE==null && other.getFNIMPORTE()==null) || 
             (this.FNIMPORTE!=null &&
              this.FNIMPORTE.equals(other.getFNIMPORTE()))) &&
            ((this.FCSOCIEDAD==null && other.getFCSOCIEDAD()==null) || 
             (this.FCSOCIEDAD!=null &&
              this.FCSOCIEDAD.equals(other.getFCSOCIEDAD())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += getFICONCEPTOID();
        _hashCode += getFIPERIODOID();
        _hashCode += getFIEJERCICIOID();
        _hashCode += getFIOBREROPATRONALID();
        if (getFNIMPORTE() != null) {
            _hashCode += getFNIMPORTE().hashCode();
        }
        if (getFCSOCIEDAD() != null) {
            _hashCode += getFCSOCIEDAD().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(CuotaPatronal.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "CuotaPatronal"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("FICONCEPTOID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "FICONCEPTOID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("FIPERIODOID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "FIPERIODOID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("FIEJERCICIOID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "FIEJERCICIOID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("FIOBREROPATRONALID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "FIOBREROPATRONALID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("FNIMPORTE");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "FNIMPORTE"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("FCSOCIEDAD");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "FCSOCIEDAD"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    @SuppressWarnings("rawtypes")
	public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    @SuppressWarnings("rawtypes")
	public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
