package com.bancoazteca.srcu.spring.daos.administracion.mantenimientoUsuariosAvante;

import java.util.List;

import com.bancoazteca.srcu.spring.beans.administracion.mantenimientoUsuariosAvante.AsignacionAvanteBean;
import com.bancoazteca.srcu.spring.beans.administracion.mantenimientoUsuariosAvante.AsignacionDepartamentosAvanteBean;
import com.bancoazteca.srcu.spring.beans.administracion.mantenimientoUsuariosAvante.DepartamentosAvanteBean;
import com.bancoazteca.srcu.spring.beans.administracion.mantenimientoUsuariosAvante.EmpleadosAvanteBean;
import com.bancoazteca.srcu.spring.beans.administracion.mantenimientoUsuariosAvante.JefesCobranzaBean;
import com.bancoazteca.srcu.spring.beans.sistema.MensajeTransaccionBean;

public interface AsignacionAvanteDAO {
	public	List<DepartamentosAvanteBean> consultaZonas(AsignacionAvanteBean asignacionAvanteBean);
	public	List<EmpleadosAvanteBean> consultaCoordinadores();
	public	List<AsignacionDepartamentosAvanteBean> consultaRegiones(AsignacionAvanteBean asignacionAvanteBean);
	public	List<AsignacionDepartamentosAvanteBean> consultaGerencias(AsignacionAvanteBean asignacionAvanteBean);
	public	List<JefesCobranzaBean> jefesCobranza(AsignacionAvanteBean asignacionAvanteBean);
	public	List<EmpleadosAvanteBean>	especialistasRegion(AsignacionAvanteBean asignacionAvanteBean);
	public	MensajeTransaccionBean eliminarAsignacion(AsignacionAvanteBean asignacionAvanteBean);
	public	MensajeTransaccionBean insertaAsignacion(AsignacionAvanteBean asignacionAvanteBean);
}
