package com.bancoazteca.srcu.spring.beans.utilerias;

import java.math.BigDecimal;

public class CatalogoBean {
	private int itemId;
	private int subItemId;
	private String descCorta;
	private String descLarga;
	private int subItemStat;
	private String usuarioModifico;
	private String ultimaModificacion;
	
	public CatalogoBean() {
		
	}

	public int getItemId() {
		return itemId;
	}

	public void setItemId(int itemId) {
		this.itemId = itemId;
	}

	public void setItemId(BigDecimal itemId) {
		this.itemId = itemId.intValue();
	}
	
	public int getSubItemId() {
		return subItemId;
	}

	public void setSubItemId(int subItemId) {
		this.subItemId = subItemId;
	}

	public void setSubItemId(BigDecimal subItemId) {
		this.subItemId = subItemId.intValue();
	}
	
	public String getDescCorta() {
		return descCorta;
	}

	public void setDescCorta(String descCorta) {
		this.descCorta = descCorta;
	}

	public String getDescLarga() {
		return descLarga;
	}

	public void setDescLarga(String descLarga) {
		this.descLarga = descLarga;
	}

	public int getSubItemStat() {
		return subItemStat;
	}

	public void setSubItemStat(int subItemStat) {
		this.subItemStat = subItemStat;
	}

	public void setSubItemStat(BigDecimal subItemStat) {
		this.subItemStat = subItemStat.intValue();
	}
	
	public String getUsuarioModifico() {
		return usuarioModifico;
	}

	public void setUsuarioModifico(String usuarioModifico) {
		this.usuarioModifico = usuarioModifico;
	}

	public String getUltimaModificacion() {
		return ultimaModificacion;
	}

	public void setUltimaModificacion(String ultimaModificacion) {
		this.ultimaModificacion = ultimaModificacion;
	}
	
}
