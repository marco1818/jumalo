/**
 * Superiores.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.bancoazteca.srcu.spring.ws.administracion.empleados.axis;
@SuppressWarnings({ "unused", "rawtypes", "serial" })
public class Superiores  implements java.io.Serializable {
    private int numeroEmpleado;

    private java.lang.String nombreEmpleado;

    private int idPosicionEmpleado;

    private java.lang.String desPosicion;

    private long idCentroCostos;

    private java.lang.String desCentroCostos;

    private java.lang.String idCompa�ia;

    private java.lang.String desCompa�ia;

    private int idFuncion;

    private java.lang.String desFuncion;

    private java.lang.String idPais;

    private int numeroJefe;

    private java.lang.String nombreJefe;

    private int idPosicionJefe;

    public Superiores() {
    }

    public Superiores(
           int numeroEmpleado,
           java.lang.String nombreEmpleado,
           int idPosicionEmpleado,
           java.lang.String desPosicion,
           long idCentroCostos,
           java.lang.String desCentroCostos,
           java.lang.String idCompa�ia,
           java.lang.String desCompa�ia,
           int idFuncion,
           java.lang.String desFuncion,
           java.lang.String idPais,
           int numeroJefe,
           java.lang.String nombreJefe,
           int idPosicionJefe) {
           this.numeroEmpleado = numeroEmpleado;
           this.nombreEmpleado = nombreEmpleado;
           this.idPosicionEmpleado = idPosicionEmpleado;
           this.desPosicion = desPosicion;
           this.idCentroCostos = idCentroCostos;
           this.desCentroCostos = desCentroCostos;
           this.idCompa�ia = idCompa�ia;
           this.desCompa�ia = desCompa�ia;
           this.idFuncion = idFuncion;
           this.desFuncion = desFuncion;
           this.idPais = idPais;
           this.numeroJefe = numeroJefe;
           this.nombreJefe = nombreJefe;
           this.idPosicionJefe = idPosicionJefe;
    }


    /**
     * Gets the numeroEmpleado value for this Superiores.
     * 
     * @return numeroEmpleado
     */
    public int getNumeroEmpleado() {
        return numeroEmpleado;
    }


    /**
     * Sets the numeroEmpleado value for this Superiores.
     * 
     * @param numeroEmpleado
     */
    public void setNumeroEmpleado(int numeroEmpleado) {
        this.numeroEmpleado = numeroEmpleado;
    }


    /**
     * Gets the nombreEmpleado value for this Superiores.
     * 
     * @return nombreEmpleado
     */
    public java.lang.String getNombreEmpleado() {
        return nombreEmpleado;
    }


    /**
     * Sets the nombreEmpleado value for this Superiores.
     * 
     * @param nombreEmpleado
     */
    public void setNombreEmpleado(java.lang.String nombreEmpleado) {
        this.nombreEmpleado = nombreEmpleado;
    }


    /**
     * Gets the idPosicionEmpleado value for this Superiores.
     * 
     * @return idPosicionEmpleado
     */
    public int getIdPosicionEmpleado() {
        return idPosicionEmpleado;
    }


    /**
     * Sets the idPosicionEmpleado value for this Superiores.
     * 
     * @param idPosicionEmpleado
     */
    public void setIdPosicionEmpleado(int idPosicionEmpleado) {
        this.idPosicionEmpleado = idPosicionEmpleado;
    }


    /**
     * Gets the desPosicion value for this Superiores.
     * 
     * @return desPosicion
     */
    public java.lang.String getDesPosicion() {
        return desPosicion;
    }


    /**
     * Sets the desPosicion value for this Superiores.
     * 
     * @param desPosicion
     */
    public void setDesPosicion(java.lang.String desPosicion) {
        this.desPosicion = desPosicion;
    }


    /**
     * Gets the idCentroCostos value for this Superiores.
     * 
     * @return idCentroCostos
     */
    public long getIdCentroCostos() {
        return idCentroCostos;
    }


    /**
     * Sets the idCentroCostos value for this Superiores.
     * 
     * @param idCentroCostos
     */
    public void setIdCentroCostos(long idCentroCostos) {
        this.idCentroCostos = idCentroCostos;
    }


    /**
     * Gets the desCentroCostos value for this Superiores.
     * 
     * @return desCentroCostos
     */
    public java.lang.String getDesCentroCostos() {
        return desCentroCostos;
    }


    /**
     * Sets the desCentroCostos value for this Superiores.
     * 
     * @param desCentroCostos
     */
    public void setDesCentroCostos(java.lang.String desCentroCostos) {
        this.desCentroCostos = desCentroCostos;
    }


    /**
     * Gets the idCompa�ia value for this Superiores.
     * 
     * @return idCompa�ia
     */
    public java.lang.String getIdCompa�ia() {
        return idCompa�ia;
    }


    /**
     * Sets the idCompa�ia value for this Superiores.
     * 
     * @param idCompa�ia
     */
    public void setIdCompa�ia(java.lang.String idCompa�ia) {
        this.idCompa�ia = idCompa�ia;
    }


    /**
     * Gets the desCompa�ia value for this Superiores.
     * 
     * @return desCompa�ia
     */
    public java.lang.String getDesCompa�ia() {
        return desCompa�ia;
    }


    /**
     * Sets the desCompa�ia value for this Superiores.
     * 
     * @param desCompa�ia
     */
    public void setDesCompa�ia(java.lang.String desCompa�ia) {
        this.desCompa�ia = desCompa�ia;
    }


    /**
     * Gets the idFuncion value for this Superiores.
     * 
     * @return idFuncion
     */
    public int getIdFuncion() {
        return idFuncion;
    }


    /**
     * Sets the idFuncion value for this Superiores.
     * 
     * @param idFuncion
     */
    public void setIdFuncion(int idFuncion) {
        this.idFuncion = idFuncion;
    }


    /**
     * Gets the desFuncion value for this Superiores.
     * 
     * @return desFuncion
     */
    public java.lang.String getDesFuncion() {
        return desFuncion;
    }


    /**
     * Sets the desFuncion value for this Superiores.
     * 
     * @param desFuncion
     */
    public void setDesFuncion(java.lang.String desFuncion) {
        this.desFuncion = desFuncion;
    }


    /**
     * Gets the idPais value for this Superiores.
     * 
     * @return idPais
     */
    public java.lang.String getIdPais() {
        return idPais;
    }


    /**
     * Sets the idPais value for this Superiores.
     * 
     * @param idPais
     */
    public void setIdPais(java.lang.String idPais) {
        this.idPais = idPais;
    }


    /**
     * Gets the numeroJefe value for this Superiores.
     * 
     * @return numeroJefe
     */
    public int getNumeroJefe() {
        return numeroJefe;
    }


    /**
     * Sets the numeroJefe value for this Superiores.
     * 
     * @param numeroJefe
     */
    public void setNumeroJefe(int numeroJefe) {
        this.numeroJefe = numeroJefe;
    }


    /**
     * Gets the nombreJefe value for this Superiores.
     * 
     * @return nombreJefe
     */
    public java.lang.String getNombreJefe() {
        return nombreJefe;
    }


    /**
     * Sets the nombreJefe value for this Superiores.
     * 
     * @param nombreJefe
     */
    public void setNombreJefe(java.lang.String nombreJefe) {
        this.nombreJefe = nombreJefe;
    }


    /**
     * Gets the idPosicionJefe value for this Superiores.
     * 
     * @return idPosicionJefe
     */
    public int getIdPosicionJefe() {
        return idPosicionJefe;
    }


    /**
     * Sets the idPosicionJefe value for this Superiores.
     * 
     * @param idPosicionJefe
     */
    public void setIdPosicionJefe(int idPosicionJefe) {
        this.idPosicionJefe = idPosicionJefe;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Superiores)) return false;
        Superiores other = (Superiores) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this.numeroEmpleado == other.getNumeroEmpleado() &&
            ((this.nombreEmpleado==null && other.getNombreEmpleado()==null) || 
             (this.nombreEmpleado!=null &&
              this.nombreEmpleado.equals(other.getNombreEmpleado()))) &&
            this.idPosicionEmpleado == other.getIdPosicionEmpleado() &&
            ((this.desPosicion==null && other.getDesPosicion()==null) || 
             (this.desPosicion!=null &&
              this.desPosicion.equals(other.getDesPosicion()))) &&
            this.idCentroCostos == other.getIdCentroCostos() &&
            ((this.desCentroCostos==null && other.getDesCentroCostos()==null) || 
             (this.desCentroCostos!=null &&
              this.desCentroCostos.equals(other.getDesCentroCostos()))) &&
            ((this.idCompa�ia==null && other.getIdCompa�ia()==null) || 
             (this.idCompa�ia!=null &&
              this.idCompa�ia.equals(other.getIdCompa�ia()))) &&
            ((this.desCompa�ia==null && other.getDesCompa�ia()==null) || 
             (this.desCompa�ia!=null &&
              this.desCompa�ia.equals(other.getDesCompa�ia()))) &&
            this.idFuncion == other.getIdFuncion() &&
            ((this.desFuncion==null && other.getDesFuncion()==null) || 
             (this.desFuncion!=null &&
              this.desFuncion.equals(other.getDesFuncion()))) &&
            ((this.idPais==null && other.getIdPais()==null) || 
             (this.idPais!=null &&
              this.idPais.equals(other.getIdPais()))) &&
            this.numeroJefe == other.getNumeroJefe() &&
            ((this.nombreJefe==null && other.getNombreJefe()==null) || 
             (this.nombreJefe!=null &&
              this.nombreJefe.equals(other.getNombreJefe()))) &&
            this.idPosicionJefe == other.getIdPosicionJefe();
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += getNumeroEmpleado();
        if (getNombreEmpleado() != null) {
            _hashCode += getNombreEmpleado().hashCode();
        }
        _hashCode += getIdPosicionEmpleado();
        if (getDesPosicion() != null) {
            _hashCode += getDesPosicion().hashCode();
        }
        _hashCode += new Long(getIdCentroCostos()).hashCode();
        if (getDesCentroCostos() != null) {
            _hashCode += getDesCentroCostos().hashCode();
        }
        if (getIdCompa�ia() != null) {
            _hashCode += getIdCompa�ia().hashCode();
        }
        if (getDesCompa�ia() != null) {
            _hashCode += getDesCompa�ia().hashCode();
        }
        _hashCode += getIdFuncion();
        if (getDesFuncion() != null) {
            _hashCode += getDesFuncion().hashCode();
        }
        if (getIdPais() != null) {
            _hashCode += getIdPais().hashCode();
        }
        _hashCode += getNumeroJefe();
        if (getNombreJefe() != null) {
            _hashCode += getNombreJefe().hashCode();
        }
        _hashCode += getIdPosicionJefe();
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Superiores.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Superiores"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroEmpleado");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "NumeroEmpleado"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nombreEmpleado");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "NombreEmpleado"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("idPosicionEmpleado");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "idPosicionEmpleado"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("desPosicion");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "DesPosicion"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("idCentroCostos");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "idCentroCostos"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("desCentroCostos");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "DesCentroCostos"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("idCompa�ia");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "idCompa�ia"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("desCompa�ia");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "DesCompa�ia"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("idFuncion");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "idFuncion"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("desFuncion");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "DesFuncion"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("idPais");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "idPais"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroJefe");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "NumeroJefe"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nombreJefe");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "NombreJefe"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("idPosicionJefe");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "idPosicionJefe"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
