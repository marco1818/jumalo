/**
 * Lee_Pos_LinRepResponse.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.bancoazteca.srcu.spring.ws.administracion.posicionesSap.axis.altaBajaPosicionesSap;

public class Lee_Pos_LinRepResponse  implements java.io.Serializable {

	private static final long serialVersionUID = 4958029961126295759L;

	private Lee_Pos_LinRepResponseIt_Linrep it_Linrep;

    private Lee_Pos_LinRepResponseIt_Err it_Err;

    public Lee_Pos_LinRepResponse() {
    }

    public Lee_Pos_LinRepResponse(
           Lee_Pos_LinRepResponseIt_Linrep it_Linrep,
           Lee_Pos_LinRepResponseIt_Err it_Err) {
           this.it_Linrep = it_Linrep;
           this.it_Err = it_Err;
    }


    /**
     * Gets the it_Linrep value for this Lee_Pos_LinRepResponse.
     * 
     * @return it_Linrep
     */
    public Lee_Pos_LinRepResponseIt_Linrep getIt_Linrep() {
        return it_Linrep;
    }


    /**
     * Sets the it_Linrep value for this Lee_Pos_LinRepResponse.
     * 
     * @param it_Linrep
     */
    public void setIt_Linrep(Lee_Pos_LinRepResponseIt_Linrep it_Linrep) {
        this.it_Linrep = it_Linrep;
    }


    /**
     * Gets the it_Err value for this Lee_Pos_LinRepResponse.
     * 
     * @return it_Err
     */
    public Lee_Pos_LinRepResponseIt_Err getIt_Err() {
        return it_Err;
    }


    /**
     * Sets the it_Err value for this Lee_Pos_LinRepResponse.
     * 
     * @param it_Err
     */
    public void setIt_Err(Lee_Pos_LinRepResponseIt_Err it_Err) {
        this.it_Err = it_Err;
    }

    private java.lang.Object __equalsCalc = null;
    @SuppressWarnings("unused")
	public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Lee_Pos_LinRepResponse)) return false;
        Lee_Pos_LinRepResponse other = (Lee_Pos_LinRepResponse) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.it_Linrep==null && other.getIt_Linrep()==null) || 
             (this.it_Linrep!=null &&
              this.it_Linrep.equals(other.getIt_Linrep()))) &&
            ((this.it_Err==null && other.getIt_Err()==null) || 
             (this.it_Err!=null &&
              this.it_Err.equals(other.getIt_Err())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getIt_Linrep() != null) {
            _hashCode += getIt_Linrep().hashCode();
        }
        if (getIt_Err() != null) {
            _hashCode += getIt_Err().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Lee_Pos_LinRepResponse.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://tempuri.org/", ">Lee_Pos_LinRepResponse"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("it_Linrep");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "It_Linrep"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://tempuri.org/", ">>Lee_Pos_LinRepResponse>It_Linrep"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("it_Err");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "It_Err"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://tempuri.org/", ">>Lee_Pos_LinRepResponse>It_Err"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    @SuppressWarnings("rawtypes")
	public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    @SuppressWarnings("rawtypes")
	public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
