/**
 * Nomina.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.bancoazteca.srcu.spring.ws.administracion.empleados.axis;
@SuppressWarnings({ "unused", "rawtypes", "serial" })
public class Nomina  implements java.io.Serializable {
    private java.lang.String grupoProfesional;

    private java.lang.String idCompa�iaSC;

    private java.lang.String areaNominaSA;

    private java.lang.String areaNominaSC;

    private int unidadOrganizativa;

    private java.lang.String desUnidadOrganizativa;

    private int unidadOrganizativaPadre;

    private java.lang.String desUnidadOrganizativaPadre;

    private java.lang.String divisionPersonal;

    private java.lang.String areaPersonal;

    private java.lang.String claveBanco;

    private java.lang.String cuentaBanco;

    private boolean pagoSA;

    private boolean pagoSC;

    public Nomina() {
    }

    public Nomina(
           java.lang.String grupoProfesional,
           java.lang.String idCompa�iaSC,
           java.lang.String areaNominaSA,
           java.lang.String areaNominaSC,
           int unidadOrganizativa,
           java.lang.String desUnidadOrganizativa,
           int unidadOrganizativaPadre,
           java.lang.String desUnidadOrganizativaPadre,
           java.lang.String divisionPersonal,
           java.lang.String areaPersonal,
           java.lang.String claveBanco,
           java.lang.String cuentaBanco,
           boolean pagoSA,
           boolean pagoSC) {
           this.grupoProfesional = grupoProfesional;
           this.idCompa�iaSC = idCompa�iaSC;
           this.areaNominaSA = areaNominaSA;
           this.areaNominaSC = areaNominaSC;
           this.unidadOrganizativa = unidadOrganizativa;
           this.desUnidadOrganizativa = desUnidadOrganizativa;
           this.unidadOrganizativaPadre = unidadOrganizativaPadre;
           this.desUnidadOrganizativaPadre = desUnidadOrganizativaPadre;
           this.divisionPersonal = divisionPersonal;
           this.areaPersonal = areaPersonal;
           this.claveBanco = claveBanco;
           this.cuentaBanco = cuentaBanco;
           this.pagoSA = pagoSA;
           this.pagoSC = pagoSC;
    }


    /**
     * Gets the grupoProfesional value for this Nomina.
     * 
     * @return grupoProfesional
     */
    public java.lang.String getGrupoProfesional() {
        return grupoProfesional;
    }


    /**
     * Sets the grupoProfesional value for this Nomina.
     * 
     * @param grupoProfesional
     */
    public void setGrupoProfesional(java.lang.String grupoProfesional) {
        this.grupoProfesional = grupoProfesional;
    }


    /**
     * Gets the idCompa�iaSC value for this Nomina.
     * 
     * @return idCompa�iaSC
     */
    public java.lang.String getIdCompa�iaSC() {
        return idCompa�iaSC;
    }


    /**
     * Sets the idCompa�iaSC value for this Nomina.
     * 
     * @param idCompa�iaSC
     */
    public void setIdCompa�iaSC(java.lang.String idCompa�iaSC) {
        this.idCompa�iaSC = idCompa�iaSC;
    }


    /**
     * Gets the areaNominaSA value for this Nomina.
     * 
     * @return areaNominaSA
     */
    public java.lang.String getAreaNominaSA() {
        return areaNominaSA;
    }


    /**
     * Sets the areaNominaSA value for this Nomina.
     * 
     * @param areaNominaSA
     */
    public void setAreaNominaSA(java.lang.String areaNominaSA) {
        this.areaNominaSA = areaNominaSA;
    }


    /**
     * Gets the areaNominaSC value for this Nomina.
     * 
     * @return areaNominaSC
     */
    public java.lang.String getAreaNominaSC() {
        return areaNominaSC;
    }


    /**
     * Sets the areaNominaSC value for this Nomina.
     * 
     * @param areaNominaSC
     */
    public void setAreaNominaSC(java.lang.String areaNominaSC) {
        this.areaNominaSC = areaNominaSC;
    }


    /**
     * Gets the unidadOrganizativa value for this Nomina.
     * 
     * @return unidadOrganizativa
     */
    public int getUnidadOrganizativa() {
        return unidadOrganizativa;
    }


    /**
     * Sets the unidadOrganizativa value for this Nomina.
     * 
     * @param unidadOrganizativa
     */
    public void setUnidadOrganizativa(int unidadOrganizativa) {
        this.unidadOrganizativa = unidadOrganizativa;
    }


    /**
     * Gets the desUnidadOrganizativa value for this Nomina.
     * 
     * @return desUnidadOrganizativa
     */
    public java.lang.String getDesUnidadOrganizativa() {
        return desUnidadOrganizativa;
    }


    /**
     * Sets the desUnidadOrganizativa value for this Nomina.
     * 
     * @param desUnidadOrganizativa
     */
    public void setDesUnidadOrganizativa(java.lang.String desUnidadOrganizativa) {
        this.desUnidadOrganizativa = desUnidadOrganizativa;
    }


    /**
     * Gets the unidadOrganizativaPadre value for this Nomina.
     * 
     * @return unidadOrganizativaPadre
     */
    public int getUnidadOrganizativaPadre() {
        return unidadOrganizativaPadre;
    }


    /**
     * Sets the unidadOrganizativaPadre value for this Nomina.
     * 
     * @param unidadOrganizativaPadre
     */
    public void setUnidadOrganizativaPadre(int unidadOrganizativaPadre) {
        this.unidadOrganizativaPadre = unidadOrganizativaPadre;
    }


    /**
     * Gets the desUnidadOrganizativaPadre value for this Nomina.
     * 
     * @return desUnidadOrganizativaPadre
     */
    public java.lang.String getDesUnidadOrganizativaPadre() {
        return desUnidadOrganizativaPadre;
    }


    /**
     * Sets the desUnidadOrganizativaPadre value for this Nomina.
     * 
     * @param desUnidadOrganizativaPadre
     */
    public void setDesUnidadOrganizativaPadre(java.lang.String desUnidadOrganizativaPadre) {
        this.desUnidadOrganizativaPadre = desUnidadOrganizativaPadre;
    }


    /**
     * Gets the divisionPersonal value for this Nomina.
     * 
     * @return divisionPersonal
     */
    public java.lang.String getDivisionPersonal() {
        return divisionPersonal;
    }


    /**
     * Sets the divisionPersonal value for this Nomina.
     * 
     * @param divisionPersonal
     */
    public void setDivisionPersonal(java.lang.String divisionPersonal) {
        this.divisionPersonal = divisionPersonal;
    }


    /**
     * Gets the areaPersonal value for this Nomina.
     * 
     * @return areaPersonal
     */
    public java.lang.String getAreaPersonal() {
        return areaPersonal;
    }


    /**
     * Sets the areaPersonal value for this Nomina.
     * 
     * @param areaPersonal
     */
    public void setAreaPersonal(java.lang.String areaPersonal) {
        this.areaPersonal = areaPersonal;
    }


    /**
     * Gets the claveBanco value for this Nomina.
     * 
     * @return claveBanco
     */
    public java.lang.String getClaveBanco() {
        return claveBanco;
    }


    /**
     * Sets the claveBanco value for this Nomina.
     * 
     * @param claveBanco
     */
    public void setClaveBanco(java.lang.String claveBanco) {
        this.claveBanco = claveBanco;
    }


    /**
     * Gets the cuentaBanco value for this Nomina.
     * 
     * @return cuentaBanco
     */
    public java.lang.String getCuentaBanco() {
        return cuentaBanco;
    }


    /**
     * Sets the cuentaBanco value for this Nomina.
     * 
     * @param cuentaBanco
     */
    public void setCuentaBanco(java.lang.String cuentaBanco) {
        this.cuentaBanco = cuentaBanco;
    }


    /**
     * Gets the pagoSA value for this Nomina.
     * 
     * @return pagoSA
     */
    public boolean isPagoSA() {
        return pagoSA;
    }


    /**
     * Sets the pagoSA value for this Nomina.
     * 
     * @param pagoSA
     */
    public void setPagoSA(boolean pagoSA) {
        this.pagoSA = pagoSA;
    }


    /**
     * Gets the pagoSC value for this Nomina.
     * 
     * @return pagoSC
     */
    public boolean isPagoSC() {
        return pagoSC;
    }


    /**
     * Sets the pagoSC value for this Nomina.
     * 
     * @param pagoSC
     */
    public void setPagoSC(boolean pagoSC) {
        this.pagoSC = pagoSC;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Nomina)) return false;
        Nomina other = (Nomina) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.grupoProfesional==null && other.getGrupoProfesional()==null) || 
             (this.grupoProfesional!=null &&
              this.grupoProfesional.equals(other.getGrupoProfesional()))) &&
            ((this.idCompa�iaSC==null && other.getIdCompa�iaSC()==null) || 
             (this.idCompa�iaSC!=null &&
              this.idCompa�iaSC.equals(other.getIdCompa�iaSC()))) &&
            ((this.areaNominaSA==null && other.getAreaNominaSA()==null) || 
             (this.areaNominaSA!=null &&
              this.areaNominaSA.equals(other.getAreaNominaSA()))) &&
            ((this.areaNominaSC==null && other.getAreaNominaSC()==null) || 
             (this.areaNominaSC!=null &&
              this.areaNominaSC.equals(other.getAreaNominaSC()))) &&
            this.unidadOrganizativa == other.getUnidadOrganizativa() &&
            ((this.desUnidadOrganizativa==null && other.getDesUnidadOrganizativa()==null) || 
             (this.desUnidadOrganizativa!=null &&
              this.desUnidadOrganizativa.equals(other.getDesUnidadOrganizativa()))) &&
            this.unidadOrganizativaPadre == other.getUnidadOrganizativaPadre() &&
            ((this.desUnidadOrganizativaPadre==null && other.getDesUnidadOrganizativaPadre()==null) || 
             (this.desUnidadOrganizativaPadre!=null &&
              this.desUnidadOrganizativaPadre.equals(other.getDesUnidadOrganizativaPadre()))) &&
            ((this.divisionPersonal==null && other.getDivisionPersonal()==null) || 
             (this.divisionPersonal!=null &&
              this.divisionPersonal.equals(other.getDivisionPersonal()))) &&
            ((this.areaPersonal==null && other.getAreaPersonal()==null) || 
             (this.areaPersonal!=null &&
              this.areaPersonal.equals(other.getAreaPersonal()))) &&
            ((this.claveBanco==null && other.getClaveBanco()==null) || 
             (this.claveBanco!=null &&
              this.claveBanco.equals(other.getClaveBanco()))) &&
            ((this.cuentaBanco==null && other.getCuentaBanco()==null) || 
             (this.cuentaBanco!=null &&
              this.cuentaBanco.equals(other.getCuentaBanco()))) &&
            this.pagoSA == other.isPagoSA() &&
            this.pagoSC == other.isPagoSC();
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getGrupoProfesional() != null) {
            _hashCode += getGrupoProfesional().hashCode();
        }
        if (getIdCompa�iaSC() != null) {
            _hashCode += getIdCompa�iaSC().hashCode();
        }
        if (getAreaNominaSA() != null) {
            _hashCode += getAreaNominaSA().hashCode();
        }
        if (getAreaNominaSC() != null) {
            _hashCode += getAreaNominaSC().hashCode();
        }
        _hashCode += getUnidadOrganizativa();
        if (getDesUnidadOrganizativa() != null) {
            _hashCode += getDesUnidadOrganizativa().hashCode();
        }
        _hashCode += getUnidadOrganizativaPadre();
        if (getDesUnidadOrganizativaPadre() != null) {
            _hashCode += getDesUnidadOrganizativaPadre().hashCode();
        }
        if (getDivisionPersonal() != null) {
            _hashCode += getDivisionPersonal().hashCode();
        }
        if (getAreaPersonal() != null) {
            _hashCode += getAreaPersonal().hashCode();
        }
        if (getClaveBanco() != null) {
            _hashCode += getClaveBanco().hashCode();
        }
        if (getCuentaBanco() != null) {
            _hashCode += getCuentaBanco().hashCode();
        }
        _hashCode += (isPagoSA() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += (isPagoSC() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Nomina.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Nomina"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("grupoProfesional");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "GrupoProfesional"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("idCompa�iaSC");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "idCompa�iaSC"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("areaNominaSA");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "AreaNominaSA"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("areaNominaSC");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "AreaNominaSC"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("unidadOrganizativa");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "UnidadOrganizativa"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("desUnidadOrganizativa");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "DesUnidadOrganizativa"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("unidadOrganizativaPadre");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "UnidadOrganizativaPadre"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("desUnidadOrganizativaPadre");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "DesUnidadOrganizativaPadre"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("divisionPersonal");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "DivisionPersonal"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("areaPersonal");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "AreaPersonal"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("claveBanco");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ClaveBanco"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("cuentaBanco");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "CuentaBanco"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("pagoSA");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "PagoSA"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("pagoSC");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "PagoSC"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
