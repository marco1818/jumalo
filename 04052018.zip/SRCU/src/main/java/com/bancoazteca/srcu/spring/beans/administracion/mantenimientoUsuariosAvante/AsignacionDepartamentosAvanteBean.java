package com.bancoazteca.srcu.spring.beans.administracion.mantenimientoUsuariosAvante;

import java.math.BigDecimal;

public class AsignacionDepartamentosAvanteBean {
	private	int	departamentoId;
	private	String	descripcionDepto;
	private	int clientesFocoFraude;
	private	BigDecimal saldo;
	private	BigDecimal saldoAtrasado;
	private BigDecimal moratorios;
	private int especialistasAsignados;
	private	int especialistasNoAsignados;
	private int pagosParciales;
	private int pagosNoAbonados;
	
	public AsignacionDepartamentosAvanteBean() {
		
	}

	public int getDepartamentoId() {
		return departamentoId;
	}

	public void setDepartamentoId(int departamentoId) {
		this.departamentoId = departamentoId;
	}

	public void setDepartamentoId(BigDecimal departamentoId) {
		this.departamentoId = departamentoId.intValue();
	}
	
	public String getDescripcionDepto() {
		return descripcionDepto;
	}

	public void setDescripcionDepto(String descripcionDepto) {
		this.descripcionDepto = descripcionDepto;
	}

	public int getClientesFocoFraude() {
		return clientesFocoFraude;
	}

	public void setClientesFocoFraude(int clientesFocoFraude) {
		this.clientesFocoFraude = clientesFocoFraude;
	}

	public void setClientesFocoFraude(BigDecimal clientesFocoFraude) {
		this.clientesFocoFraude = clientesFocoFraude.intValue();
	}
	
	public BigDecimal getSaldo() {
		return saldo;
	}

	public void setSaldo(BigDecimal saldo) {
		this.saldo = saldo;
	}

	public BigDecimal getSaldoAtrasado() {
		return saldoAtrasado;
	}

	public void setSaldoAtrasado(BigDecimal saldoAtrasado) {
		this.saldoAtrasado = saldoAtrasado;
	}

	public int getEspecialistasAsignados() {
		return especialistasAsignados;
	}

	public void setEspecialistasAsignados(int especialistasAsignados) {
		this.especialistasAsignados = especialistasAsignados;
	}

	public void setEspecialistasAsignados(BigDecimal especialistasAsignados) {
		this.especialistasAsignados = especialistasAsignados.intValue();
	}
	
	public int getEspecialistasNoAsignados() {
		return especialistasNoAsignados;
	}

	public void setEspecialistasNoAsignados(int especialistasNoAsignados) {
		this.especialistasNoAsignados = especialistasNoAsignados;
	}
	
	public void setEspecialistasNoAsignados(BigDecimal especialistasNoAsignados) {
		this.especialistasNoAsignados = especialistasNoAsignados.intValue();
	}

	public BigDecimal getMoratorios() {
		return moratorios;
	}

	public void setMoratorios(BigDecimal moratorios) {
		this.moratorios = moratorios;
	}

	public int getPagosParciales() {
		return pagosParciales;
	}

	public void setPagosParciales(int pagosParciales) {
		this.pagosParciales = pagosParciales;
	}

	public void setPagosParciales(BigDecimal pagosParciales) {
		this.pagosParciales = pagosParciales.intValue();
	}
	
	public int getPagosNoAbonados() {
		return pagosNoAbonados;
	}

	public void setPagosNoAbonados(int pagosNoAbonados) {
		this.pagosNoAbonados = pagosNoAbonados;
	}
	
	public void setPagosNoAbonados(BigDecimal pagosNoAbonados) {
		this.pagosNoAbonados = pagosNoAbonados.intValue();
	}
}
