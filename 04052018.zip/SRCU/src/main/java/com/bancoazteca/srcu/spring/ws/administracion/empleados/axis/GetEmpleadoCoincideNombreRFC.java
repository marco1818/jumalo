/**
 * GetEmpleadoCoincideNombreRFC.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.bancoazteca.srcu.spring.ws.administracion.empleados.axis;
@SuppressWarnings({ "unused", "rawtypes", "serial" })
public class GetEmpleadoCoincideNombreRFC  implements java.io.Serializable {
    private java.lang.String usuario;

    private java.lang.String contrase�a;

    private java.lang.String nombre;

    private java.lang.String apPaterno;

    private java.lang.String apMaterno;

    private java.lang.String pais;

    private java.lang.String empresa;

    private java.lang.String regCed;

    private boolean existeError;

    private java.lang.String mensaje;

    public GetEmpleadoCoincideNombreRFC() {
    }

    public GetEmpleadoCoincideNombreRFC(
           java.lang.String usuario,
           java.lang.String contrase�a,
           java.lang.String nombre,
           java.lang.String apPaterno,
           java.lang.String apMaterno,
           java.lang.String pais,
           java.lang.String empresa,
           java.lang.String regCed,
           boolean existeError,
           java.lang.String mensaje) {
           this.usuario = usuario;
           this.contrase�a = contrase�a;
           this.nombre = nombre;
           this.apPaterno = apPaterno;
           this.apMaterno = apMaterno;
           this.pais = pais;
           this.empresa = empresa;
           this.regCed = regCed;
           this.existeError = existeError;
           this.mensaje = mensaje;
    }


    /**
     * Gets the usuario value for this GetEmpleadoCoincideNombreRFC.
     * 
     * @return usuario
     */
    public java.lang.String getUsuario() {
        return usuario;
    }


    /**
     * Sets the usuario value for this GetEmpleadoCoincideNombreRFC.
     * 
     * @param usuario
     */
    public void setUsuario(java.lang.String usuario) {
        this.usuario = usuario;
    }


    /**
     * Gets the contrase�a value for this GetEmpleadoCoincideNombreRFC.
     * 
     * @return contrase�a
     */
    public java.lang.String getContrase�a() {
        return contrase�a;
    }


    /**
     * Sets the contrase�a value for this GetEmpleadoCoincideNombreRFC.
     * 
     * @param contrase�a
     */
    public void setContrase�a(java.lang.String contrase�a) {
        this.contrase�a = contrase�a;
    }


    /**
     * Gets the nombre value for this GetEmpleadoCoincideNombreRFC.
     * 
     * @return nombre
     */
    public java.lang.String getNombre() {
        return nombre;
    }


    /**
     * Sets the nombre value for this GetEmpleadoCoincideNombreRFC.
     * 
     * @param nombre
     */
    public void setNombre(java.lang.String nombre) {
        this.nombre = nombre;
    }


    /**
     * Gets the apPaterno value for this GetEmpleadoCoincideNombreRFC.
     * 
     * @return apPaterno
     */
    public java.lang.String getApPaterno() {
        return apPaterno;
    }


    /**
     * Sets the apPaterno value for this GetEmpleadoCoincideNombreRFC.
     * 
     * @param apPaterno
     */
    public void setApPaterno(java.lang.String apPaterno) {
        this.apPaterno = apPaterno;
    }


    /**
     * Gets the apMaterno value for this GetEmpleadoCoincideNombreRFC.
     * 
     * @return apMaterno
     */
    public java.lang.String getApMaterno() {
        return apMaterno;
    }


    /**
     * Sets the apMaterno value for this GetEmpleadoCoincideNombreRFC.
     * 
     * @param apMaterno
     */
    public void setApMaterno(java.lang.String apMaterno) {
        this.apMaterno = apMaterno;
    }


    /**
     * Gets the pais value for this GetEmpleadoCoincideNombreRFC.
     * 
     * @return pais
     */
    public java.lang.String getPais() {
        return pais;
    }


    /**
     * Sets the pais value for this GetEmpleadoCoincideNombreRFC.
     * 
     * @param pais
     */
    public void setPais(java.lang.String pais) {
        this.pais = pais;
    }


    /**
     * Gets the empresa value for this GetEmpleadoCoincideNombreRFC.
     * 
     * @return empresa
     */
    public java.lang.String getEmpresa() {
        return empresa;
    }


    /**
     * Sets the empresa value for this GetEmpleadoCoincideNombreRFC.
     * 
     * @param empresa
     */
    public void setEmpresa(java.lang.String empresa) {
        this.empresa = empresa;
    }


    /**
     * Gets the regCed value for this GetEmpleadoCoincideNombreRFC.
     * 
     * @return regCed
     */
    public java.lang.String getRegCed() {
        return regCed;
    }


    /**
     * Sets the regCed value for this GetEmpleadoCoincideNombreRFC.
     * 
     * @param regCed
     */
    public void setRegCed(java.lang.String regCed) {
        this.regCed = regCed;
    }


    /**
     * Gets the existeError value for this GetEmpleadoCoincideNombreRFC.
     * 
     * @return existeError
     */
    public boolean isExisteError() {
        return existeError;
    }


    /**
     * Sets the existeError value for this GetEmpleadoCoincideNombreRFC.
     * 
     * @param existeError
     */
    public void setExisteError(boolean existeError) {
        this.existeError = existeError;
    }


    /**
     * Gets the mensaje value for this GetEmpleadoCoincideNombreRFC.
     * 
     * @return mensaje
     */
    public java.lang.String getMensaje() {
        return mensaje;
    }


    /**
     * Sets the mensaje value for this GetEmpleadoCoincideNombreRFC.
     * 
     * @param mensaje
     */
    public void setMensaje(java.lang.String mensaje) {
        this.mensaje = mensaje;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof GetEmpleadoCoincideNombreRFC)) return false;
        GetEmpleadoCoincideNombreRFC other = (GetEmpleadoCoincideNombreRFC) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.usuario==null && other.getUsuario()==null) || 
             (this.usuario!=null &&
              this.usuario.equals(other.getUsuario()))) &&
            ((this.contrase�a==null && other.getContrase�a()==null) || 
             (this.contrase�a!=null &&
              this.contrase�a.equals(other.getContrase�a()))) &&
            ((this.nombre==null && other.getNombre()==null) || 
             (this.nombre!=null &&
              this.nombre.equals(other.getNombre()))) &&
            ((this.apPaterno==null && other.getApPaterno()==null) || 
             (this.apPaterno!=null &&
              this.apPaterno.equals(other.getApPaterno()))) &&
            ((this.apMaterno==null && other.getApMaterno()==null) || 
             (this.apMaterno!=null &&
              this.apMaterno.equals(other.getApMaterno()))) &&
            ((this.pais==null && other.getPais()==null) || 
             (this.pais!=null &&
              this.pais.equals(other.getPais()))) &&
            ((this.empresa==null && other.getEmpresa()==null) || 
             (this.empresa!=null &&
              this.empresa.equals(other.getEmpresa()))) &&
            ((this.regCed==null && other.getRegCed()==null) || 
             (this.regCed!=null &&
              this.regCed.equals(other.getRegCed()))) &&
            this.existeError == other.isExisteError() &&
            ((this.mensaje==null && other.getMensaje()==null) || 
             (this.mensaje!=null &&
              this.mensaje.equals(other.getMensaje())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getUsuario() != null) {
            _hashCode += getUsuario().hashCode();
        }
        if (getContrase�a() != null) {
            _hashCode += getContrase�a().hashCode();
        }
        if (getNombre() != null) {
            _hashCode += getNombre().hashCode();
        }
        if (getApPaterno() != null) {
            _hashCode += getApPaterno().hashCode();
        }
        if (getApMaterno() != null) {
            _hashCode += getApMaterno().hashCode();
        }
        if (getPais() != null) {
            _hashCode += getPais().hashCode();
        }
        if (getEmpresa() != null) {
            _hashCode += getEmpresa().hashCode();
        }
        if (getRegCed() != null) {
            _hashCode += getRegCed().hashCode();
        }
        _hashCode += (isExisteError() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        if (getMensaje() != null) {
            _hashCode += getMensaje().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(GetEmpleadoCoincideNombreRFC.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", ">getEmpleadoCoincideNombreRFC"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("usuario");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Usuario"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("contrase�a");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Contrase�a"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nombre");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Nombre"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("apPaterno");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ApPaterno"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("apMaterno");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ApMaterno"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("pais");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Pais"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("empresa");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Empresa"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("regCed");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "RegCed"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("existeError");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ExisteError"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("mensaje");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Mensaje"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
