/**
 * Incapacidad.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.bancoazteca.srcu.spring.ws.administracion.empleados.axis;
@SuppressWarnings({ "unused", "rawtypes", "serial" })
public class Incapacidad  implements java.io.Serializable {
    private int numeroEmpleado;

    private int fechaInicialSAP_Incapacidad;

    private int fechaFinal_Incapacidad;

    private int dias_Incapacidad;

    private int fechaInicialIMSS_Incapacidad;

    private int fechaInicialNotificacion_Incapacidad;

    public Incapacidad() {
    }

    public Incapacidad(
           int numeroEmpleado,
           int fechaInicialSAP_Incapacidad,
           int fechaFinal_Incapacidad,
           int dias_Incapacidad,
           int fechaInicialIMSS_Incapacidad,
           int fechaInicialNotificacion_Incapacidad) {
           this.numeroEmpleado = numeroEmpleado;
           this.fechaInicialSAP_Incapacidad = fechaInicialSAP_Incapacidad;
           this.fechaFinal_Incapacidad = fechaFinal_Incapacidad;
           this.dias_Incapacidad = dias_Incapacidad;
           this.fechaInicialIMSS_Incapacidad = fechaInicialIMSS_Incapacidad;
           this.fechaInicialNotificacion_Incapacidad = fechaInicialNotificacion_Incapacidad;
    }


    /**
     * Gets the numeroEmpleado value for this Incapacidad.
     * 
     * @return numeroEmpleado
     */
    public int getNumeroEmpleado() {
        return numeroEmpleado;
    }


    /**
     * Sets the numeroEmpleado value for this Incapacidad.
     * 
     * @param numeroEmpleado
     */
    public void setNumeroEmpleado(int numeroEmpleado) {
        this.numeroEmpleado = numeroEmpleado;
    }


    /**
     * Gets the fechaInicialSAP_Incapacidad value for this Incapacidad.
     * 
     * @return fechaInicialSAP_Incapacidad
     */
    public int getFechaInicialSAP_Incapacidad() {
        return fechaInicialSAP_Incapacidad;
    }


    /**
     * Sets the fechaInicialSAP_Incapacidad value for this Incapacidad.
     * 
     * @param fechaInicialSAP_Incapacidad
     */
    public void setFechaInicialSAP_Incapacidad(int fechaInicialSAP_Incapacidad) {
        this.fechaInicialSAP_Incapacidad = fechaInicialSAP_Incapacidad;
    }


    /**
     * Gets the fechaFinal_Incapacidad value for this Incapacidad.
     * 
     * @return fechaFinal_Incapacidad
     */
    public int getFechaFinal_Incapacidad() {
        return fechaFinal_Incapacidad;
    }


    /**
     * Sets the fechaFinal_Incapacidad value for this Incapacidad.
     * 
     * @param fechaFinal_Incapacidad
     */
    public void setFechaFinal_Incapacidad(int fechaFinal_Incapacidad) {
        this.fechaFinal_Incapacidad = fechaFinal_Incapacidad;
    }


    /**
     * Gets the dias_Incapacidad value for this Incapacidad.
     * 
     * @return dias_Incapacidad
     */
    public int getDias_Incapacidad() {
        return dias_Incapacidad;
    }


    /**
     * Sets the dias_Incapacidad value for this Incapacidad.
     * 
     * @param dias_Incapacidad
     */
    public void setDias_Incapacidad(int dias_Incapacidad) {
        this.dias_Incapacidad = dias_Incapacidad;
    }


    /**
     * Gets the fechaInicialIMSS_Incapacidad value for this Incapacidad.
     * 
     * @return fechaInicialIMSS_Incapacidad
     */
    public int getFechaInicialIMSS_Incapacidad() {
        return fechaInicialIMSS_Incapacidad;
    }


    /**
     * Sets the fechaInicialIMSS_Incapacidad value for this Incapacidad.
     * 
     * @param fechaInicialIMSS_Incapacidad
     */
    public void setFechaInicialIMSS_Incapacidad(int fechaInicialIMSS_Incapacidad) {
        this.fechaInicialIMSS_Incapacidad = fechaInicialIMSS_Incapacidad;
    }


    /**
     * Gets the fechaInicialNotificacion_Incapacidad value for this Incapacidad.
     * 
     * @return fechaInicialNotificacion_Incapacidad
     */
    public int getFechaInicialNotificacion_Incapacidad() {
        return fechaInicialNotificacion_Incapacidad;
    }


    /**
     * Sets the fechaInicialNotificacion_Incapacidad value for this Incapacidad.
     * 
     * @param fechaInicialNotificacion_Incapacidad
     */
    public void setFechaInicialNotificacion_Incapacidad(int fechaInicialNotificacion_Incapacidad) {
        this.fechaInicialNotificacion_Incapacidad = fechaInicialNotificacion_Incapacidad;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Incapacidad)) return false;
        Incapacidad other = (Incapacidad) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this.numeroEmpleado == other.getNumeroEmpleado() &&
            this.fechaInicialSAP_Incapacidad == other.getFechaInicialSAP_Incapacidad() &&
            this.fechaFinal_Incapacidad == other.getFechaFinal_Incapacidad() &&
            this.dias_Incapacidad == other.getDias_Incapacidad() &&
            this.fechaInicialIMSS_Incapacidad == other.getFechaInicialIMSS_Incapacidad() &&
            this.fechaInicialNotificacion_Incapacidad == other.getFechaInicialNotificacion_Incapacidad();
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += getNumeroEmpleado();
        _hashCode += getFechaInicialSAP_Incapacidad();
        _hashCode += getFechaFinal_Incapacidad();
        _hashCode += getDias_Incapacidad();
        _hashCode += getFechaInicialIMSS_Incapacidad();
        _hashCode += getFechaInicialNotificacion_Incapacidad();
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Incapacidad.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Incapacidad"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroEmpleado");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "NumeroEmpleado"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("fechaInicialSAP_Incapacidad");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "FechaInicialSAP_Incapacidad"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("fechaFinal_Incapacidad");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "FechaFinal_Incapacidad"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dias_Incapacidad");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Dias_Incapacidad"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("fechaInicialIMSS_Incapacidad");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "FechaInicialIMSS_Incapacidad"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("fechaInicialNotificacion_Incapacidad");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "FechaInicialNotificacion_Incapacidad"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
