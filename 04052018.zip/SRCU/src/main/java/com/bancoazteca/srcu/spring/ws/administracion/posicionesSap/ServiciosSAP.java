package com.bancoazteca.srcu.spring.ws.administracion.posicionesSap;

import java.util.List;

public interface ServiciosSAP {
	public	List<PosicionesSapBean> consultaPosicionesSAP(int tipoConsulta,String ceco, int funcioSAP);
	public	RespuestaAltaPosicionBean creaVacante(int gerenciaId, int segmento, int puestoOpera, String empleadoOpera);
	public	RespuestaLimitaPosicionBean	limitaPosicion(String numPosicion, String empleadoOpera, String numVacante);
}
