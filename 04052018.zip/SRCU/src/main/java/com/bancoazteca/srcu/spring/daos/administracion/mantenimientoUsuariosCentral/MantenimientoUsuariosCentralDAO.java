package com.bancoazteca.srcu.spring.daos.administracion.mantenimientoUsuariosCentral;

import com.bancoazteca.srcu.spring.beans.administracion.mantenimientoTelefonos.DatosEmpleadoBean;
import com.bancoazteca.srcu.spring.beans.administracion.mantenimientoUsuariosCentral.MantenimientoUsuariosCentralBean;
import com.bancoazteca.srcu.spring.beans.sistema.MensajeTransaccionBean;

public interface MantenimientoUsuariosCentralDAO {
	public DatosEmpleadoBean consultaEmpleado(String numeroEmpleado);
	public MensajeTransaccionBean reiniciaContrasenia(MantenimientoUsuariosCentralBean mantenimientoUsuariosCentralBean);
	public MensajeTransaccionBean desbloqueaUsuario(MantenimientoUsuariosCentralBean mantenimientoUsuariosCentralBean);
}
