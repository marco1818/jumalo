package com.bancoazteca.srcu.spring.beans.administracion.mantenimientoTelefonos;

import java.math.BigDecimal;

public class DatosEmpleadoBean {
	private	int	idMensaje;
	private String numeroEmpleado;
	private String nombreEmpleado;
	private int	puestoId;
	private int deptoId;
	private String deptoDesc;
	private String puestoDesc;
	private int segmento;
	private String fechaAlta;
	
	public int getIdMensaje() {
		return idMensaje;
	}
	public void setIdMensaje(int idMensaje) {
		this.idMensaje = idMensaje;
	}
	public void setIdMensaje(BigDecimal idMensaje) {
		this.idMensaje = idMensaje.intValue();
	}
	public String getNombreEmpleado() {
		return nombreEmpleado;
	}
	public void setNombreEmpleado(String nombreEmpleado) {
		this.nombreEmpleado = nombreEmpleado;
	}
	public int getPuestoId() {
		return puestoId;
	}
	public void setPuestoId(int puestoId) {
		this.puestoId = puestoId;
	}
	public void setPuestoId(BigDecimal puestoId) {
		this.puestoId = puestoId.intValue();
	}
	public int getDeptoId() {
		return deptoId;
	}
	public void setDeptoId(int deptoId) {
		this.deptoId = deptoId;
	}
	public void setDeptoId(BigDecimal deptoId) {
		this.deptoId = deptoId.intValue();
	}
	public String getNumeroEmpleado() {
		return numeroEmpleado;
	}
	public void setNumeroEmpleado(String numeroEmpleado) {
		this.numeroEmpleado = numeroEmpleado;
	}
	public String getDeptoDesc() {
		return deptoDesc;
	}
	public void setDeptoDesc(String deptoDesc) {
		this.deptoDesc = deptoDesc;
	}
	public String getPuestoDesc() {
		return puestoDesc;
	}
	public void setPuestoDesc(String puestoDesc) {
		this.puestoDesc = puestoDesc;
	}
	public int getSegmento() {
		return segmento;
	}
	public void setSegmento(int segmento) {
		this.segmento = segmento;
	}
	public void setSegmento(BigDecimal segmento) {
		this.segmento = segmento.intValue();
	}
	public String getFechaAlta() {
		return fechaAlta;
	}
	public void setFechaAlta(String fechaAlta) {
		this.fechaAlta = fechaAlta;
	}
}
