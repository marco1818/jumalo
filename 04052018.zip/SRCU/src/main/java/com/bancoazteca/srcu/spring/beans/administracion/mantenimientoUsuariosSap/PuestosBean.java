package com.bancoazteca.srcu.spring.beans.administracion.mantenimientoUsuariosSap;

import java.math.BigDecimal;

public class PuestosBean {
	private	int	puestoId;
	private String descripcionPuesto;
	
	public PuestosBean() {
		
	}

	public int getPuestoId() {
		return puestoId;
	}

	public void setPuestoId(int puestoId) {
		this.puestoId = puestoId;
	}
	
	public void setPuestoId(BigDecimal puestoId) {
		this.puestoId = puestoId.intValue();
	}
	
	public String getDescripcionPuesto() {
		return descripcionPuesto;
	}

	public void setDescripcionPuesto(String descripcionPuesto) {
		this.descripcionPuesto = descripcionPuesto;
	}
	
}
