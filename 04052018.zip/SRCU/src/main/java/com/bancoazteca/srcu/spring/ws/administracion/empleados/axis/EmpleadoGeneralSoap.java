/**
 * EmpleadoGeneralSoap.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.bancoazteca.srcu.spring.ws.administracion.empleados.axis;

public interface EmpleadoGeneralSoap extends java.rmi.Remote {

    /**
     * Obtiene la información general del empleado
     */
    public Empleado getEmpleadoGeneral(java.lang.String usuario, java.lang.String contrase�a, int empleado, java.lang.String empresa, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException;

    /**
     * Obtiene la información general del empleado para Dinero Express
     */
    public EmpleadoDExpress getEmpleadoGeneralDineroExpress(java.lang.String usuario, java.lang.String contrase�a, int empleado, java.lang.String empresa, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException;

    /**
     * Obtiene la información de Tarjeta Amarilla de Empleado
     */
    public TarjetasAmarillas getTarjetaAmarillaEmpleado(java.lang.String usuario, java.lang.String contrase�a, int empleado, java.lang.String empresa, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException;

    /**
     * Obtiene la información de Tarjeta Amarilla de Empleado por
     * Cuenta de Banco
     */
    public TarjetasAmarillasCtaBanco getTarjetaAmarillaCtaBanco(java.lang.String usuario, java.lang.String contrase�a, java.lang.String cuentaBanco, java.lang.String empresa, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException;

    /**
     * Obtiene la información de tarjeta Amarilla de las ultimas 13
     * semanas para Empleado SIE
     */
    public TarjetasAmarillasSIE[] getTarjetaAmarillaEmpleadoSIE(java.lang.String usuario, java.lang.String contrase�a, int empleado, int fecha, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException;

    /**
     * Obtiene la información de tarjeta Amarilla de las ultimas 13
     * semanas para Empleado SIE
     */
    public java.lang.String getTarjetaAmarillaEmpleadoSIE_Tabla(java.lang.String usuario, java.lang.String contrase�a, java.lang.String empleado, java.lang.String fecha, javax.xml.rpc.holders.StringHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException;

    /**
     * Obtiene la información general del empleado por Centro de Costos
     */
    public Empleado[] getEmpleadoPorCentroCostos(java.lang.String usuario, java.lang.String contrase�a, int centroCostos, java.lang.String empresa, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException;

    /**
     * Obtiene la información general del empleado por situación en
     * una fecha determinada
     */
    public Empleado[] getEmpleadoPorSituacion(java.lang.String usuario, java.lang.String contrase�a, java.lang.String situacion, int fecha, java.lang.String pais, java.lang.String empresa, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException;

    /**
     * Obtiene la información general del empleado
     */
    public Estructura_DatosCorreo getDatosCorreo(java.lang.String usuario, java.lang.String contrase�a, int empleado, java.lang.String empresa, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException;

    /**
     * Obtiene los campos correspondientes al respeto de la función
     * de un empleado.
     */
    public Funcion getFuncionEmpleado(java.lang.String usuario, java.lang.String contrase�a, int empleado, java.lang.String empresa, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException;

    /**
     * Obtiene las vacantes del día.
     */
    public Vacante[] getVacantes(java.lang.String usuario, java.lang.String contrase�a, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException;

    /**
     * Obtiene la información general del empleado de una función
     * y de un país específico
     */
    public Empleado[] getEmpleadoPorFuncion(java.lang.String usuario, java.lang.String contrase�a, int funcion, java.lang.String pais, java.lang.String empresa, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException;

    /**
     * Obtiene la información de empleados que fueron dados de alta,
     * baja o movimiento dentro de la estructura
     */
    public Empleado[] getEmpleadoPorMovimiento(java.lang.String usuario, java.lang.String contrase�a, int fecha, java.lang.String empresa, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException;

    /**
     * Obtiene los ultimos registros de la tabla Empleado_Incapacidad
     * a partir de la fecha de consulta
     */
    public Incapacidad[] getEmpleadoIncapacidad(java.lang.String usuario, java.lang.String contrase�a, java.lang.String empresa, int fechaActualiza, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException;

    /**
     * Obtiene el correo electrónico de un empleado o una sucursal
     */
    public java.lang.String getCorreo(java.lang.String usuario, java.lang.String contrase�a, java.lang.String valor, java.lang.String empresa, java.lang.String pais, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException;

    /**
     * Obtiene el RFC
     */
    public java.lang.String getRFC(java.lang.String nombre, java.lang.String apellidoPaterno, java.lang.String apellidoMaterno, int fechaNacimiento) throws java.rmi.RemoteException;

    /**
     * Obtiene si un empleado se tiene registrado como director
     */
    public void getEsDirector(java.lang.String usuario, java.lang.String contrase�a, int empleado, java.lang.String empresa, javax.xml.rpc.holders.BooleanHolder esDirector, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException;

    /**
     * Obtiene la cuenta clabe de un empleado
     */
    public java.lang.String getCuentaClabe(java.lang.String usuario, java.lang.String contrase�a, int empleado, java.lang.String empresa, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException;

    /**
     * Obtiene la huella registrada en cliente único
     */
    public GetHuellaClienteUnicoResponseGetHuellaClienteUnicoResult getHuellaClienteUnico(java.lang.String usuario, java.lang.String contrase�a, int empleado, java.lang.String empresa, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException;

    /**
     * Obtiene la huella registrada en cliente único para empleados
     * de LAM
     */
    public GetHuellaClienteUnicoLAMResponseGetHuellaClienteUnicoLAMResult getHuellaClienteUnicoLAM(java.lang.String usuario, java.lang.String contrase�a, int empleado, java.lang.String empresa, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException;

    /**
     * Obtiene la huella registrada en cliente único QA
     */
    public GetHuellaClienteUnicoQAResponseGetHuellaClienteUnicoQAResult getHuellaClienteUnicoQA(java.lang.String usuario, java.lang.String contrase�a, int empleado, java.lang.String empresa, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException;

    /**
     * Obtiene la fecha de pago a partir de un empleado
     */
    public java.lang.String getFechaPago(java.lang.String usuario, java.lang.String contrase�a, int empleado, java.lang.String empresa, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException;

    /**
     * Obtiene todos aquellos empleados del Grupo que encuentra con
     * el filtro que se le envía
     */
    public Coincidencia[] getCoincidencias(java.lang.String usuario, java.lang.String contrase�a, java.lang.String filtro, java.lang.String situacion, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException;

    /**
     * Obtiene la lista de superiores de un empleado en particular
     */
    public Superiores[] getLineaSuperior(java.lang.String usuario, java.lang.String contrase�a, int empleado, java.lang.String empresa, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException;

    /**
     * Obtiene la lista de subalternos de un empleado en particular;
     * el valor parametro de entreada EMPLEADO es el puesto del jefe para
     * que se quiere obtener la lista de subalternos.
     */
    public Subordinado[] getLineaInferior(java.lang.String usuario, java.lang.String contrase�a, int empleado, java.lang.String empresa, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException;

    /**
     * Obtiene la lista de subalternos de un empleado en particular;
     * el valor parametro de entreada EMPLEADO es el puesto del jefe para
     * que se quiere obtener la lista de subalternos. El nivel es al que
     * se requiere la consulta, siendo cero toda su plantilla
     */
    public Subordinado[] getLineaInferiorSAP(java.lang.String usuario, java.lang.String contrase�a, int puesto, java.lang.String empresa, int nivel, java.lang.String pais, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException;

    /**
     * Obtiene la lista de subalternos de un empleado en particular;
     * el valor parametro de entreada EMPLEADO es el Numero de Empleado del
     * jefe para que se quiere obtener la lista de subalternos.
     */
    public Subordinado[] getLineaInferiorPorEmpleadoRep(java.lang.String usuario, java.lang.String contrase�a, int empleado, java.lang.String empresa, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException;

    /**
     * Regresa 1 si el empleado existe en la empresa de consulta,
     * 2 si no existe en la empresa de consulta, pero existe en otra empresa,
     * 0 si no existe en ninguna empresa, -1 si se encontraron errores en
     * la consulta
     */
    public int existeEmpleado(java.lang.String usuario, java.lang.String contrase�a, int empleado, java.lang.String empresa, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException;

    /**
     * Regresa el contro de costos de los empleados de TVA
     */
    public long getCentroCostosTVA(java.lang.String usuario, java.lang.String contrase�a, int empleado, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException;

    /**
     * Obtiene si el empleado pertenece al 20% del ranking de Mapa
     * de Talento.
     */
    public void getRankingMapaTalento(java.lang.String usuario, java.lang.String contrase�a, int empleado, java.lang.String empresa, javax.xml.rpc.holders.BooleanHolder perteneceRanking, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException;

    /**
     * Obtiene la cuenta activa de nómina del empleado en SAP.
     */
    public void getCuentaBancoEmpleado(java.lang.String usuario, java.lang.String contrase�a, int empleado, java.lang.String empresa, javax.xml.rpc.holders.StringHolder cuentaBanco, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException;

    /**
     * Obtiene la cuenta activa de nómina del empleado en SAP.
     */
    public void getCuentaBanco(java.lang.String usuario, java.lang.String contrasenia, int empleado, java.lang.String empresa, javax.xml.rpc.holders.StringHolder cuentaBanco, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException;

    /**
     * Obtiene situación de la baja de un arreglo de empleados
     */
    public EmpleadoBaja[] getDatosEmpleadosBaja(java.lang.String usuario, java.lang.String contrase�a, int[] empleado, java.lang.String empresa, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException;

    /**
     * Genera solicitud para baja por FBP(Flujo de bajas de personal)
     * de acuerdo a las especificaciones de plantilla dinamica.
     */
    public void setSolicitudBajaPlantillaDinamica(java.lang.String usuario, java.lang.String contrase�a, int empleadoBaja, java.lang.String empresa, javax.xml.rpc.holders.IntHolder folioFBP, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException;

    /**
     * Genera solicitud para baja por FBP(Flujo de bajas de personal)
     * de acuerdo a las especificaciones de plantilla dinamica Tarjeta Amarilla.
     */
    public void setSolicitudBajaTarjetasAmarillas(java.lang.String usuario, java.lang.String contrase�a, int empleadoBaja, java.lang.String empresa, javax.xml.rpc.holders.IntHolder folioFBP, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException;

    /**
     * Consulta información para seguimiento de solicitud de baja
     * por FBP(Flujo de bajas de personal) de acuerdo a las especificaciones
     * de plantilla dinamica.
     */
    public void getSeguimientoBajaPlantillaDinamica(java.lang.String usuario, java.lang.String contrase�a, int folioFBP, java.lang.String empresa, javax.xml.rpc.holders.IntHolder empleadoGestionBaja, javax.xml.rpc.holders.IntHolder estatus, javax.xml.rpc.holders.StringHolder fechaActualizacion, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException;

    /**
     * Genera digitalizacion de documentos para empleado.
     */
    public void setDigitalizacionDocumentosEmpleado(java.lang.String usuario, java.lang.String contrase�a, int empleado, int pais, java.lang.String documento, int tipo, int etapa, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException;

    /**
     * Obtiene Q12 por Empleado
     */
    public void getQ12Empleado(java.lang.String usuario, java.lang.String contrase�a, int empleado, java.lang.String empresa, int periodo, ArrayOfEmpleadoQ12Holder listaEmpleado, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException;

    /**
     * Obtiene la información del ranking de la linea de reporte
     */
    public void getRanking_Empleado(java.lang.String usuario, java.lang.String contrase�a, java.lang.String empresa, java.lang.String pais, java.lang.String fecha, java.lang.String funcion, java.lang.String nivel, java.lang.String CC, java.lang.String periodo, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException;

    /**
     * Obtiene la información de vacaciones cargadas GEO
     */
    public VacacionesGeo[] getConsultaCargaVacacionesGeo(java.lang.String usuario, java.lang.String contrase�a, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException;

    /**
     * Obtiene el número (suma) de tarjetas Amarillas de las ultimas
     * 13 semanas
     */
    public TarjetaAmarilla_Periodo[] getTarjetaAmarilla_Periodo(java.lang.String usuario, java.lang.String contrase�a, int fecha, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException;

    /**
     * Obtiene los detalles de baja del empleado
     */
    public DetalleBaja[] getDetalleBaja(java.lang.String usuario, java.lang.String contrase�a, int empleado, java.lang.String empresa, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException;

    /**
     * Obtiene el descriptivo de la plaza por el CC y el país
     */
    public Plaza[] getDescPlaza(java.lang.String usuario, java.lang.String contrase�a, int centroCostos, java.lang.String pais, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException;

    /**
     * Obtiene los beneficiarios que tiene registrados un empleado
     * en SAP
     */
    public Beneficiarios getBeneficiariosEmpleado(java.lang.String usuario, java.lang.String contrase�a, int empleado, java.lang.String empresa, int tipoBeneficiario, java.lang.String pais, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException;

    /**
     * Obtiene todos aquellos empleados que coincida el nombre y el
     * RFC
     */
    public DatosCoincidencias[] getEmpleadoCoincideNombreRFC(java.lang.String usuario, java.lang.String contrase�a, java.lang.String nombre, java.lang.String apPaterno, java.lang.String apMaterno, java.lang.String pais, java.lang.String empresa, java.lang.String regCed, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException;

    /**
     * Obtiene las incapacidades capturadas en SAP a partir de la
     * fecha de consulta
     */
    public Auscencia[] getEmpleadoIncapacidadSAP(java.lang.String usuario, java.lang.String contrase�a, int empleado, java.lang.String empresa, int fecha, java.lang.String pais, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException;

    /**
     * Valida si un empleado tiene auscencias a partir de la fecha
     * de consulta
     */
    public Auscencia[] getEmpleadoAuscentismo(java.lang.String usuario, java.lang.String contrase�a, int empleado, java.lang.String empresa, int fecha, java.lang.String pais, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException;

    /**
     * Consultar masivamente los datos de los empleados
     */
    public EmpleadoGral[] getDatosEmpleadosMasivo(java.lang.String usuario, java.lang.String contrase�a, EmpleadoEmp[] empleado, java.lang.String empresa, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException;

    /**
     * Obtiene la cuenta activa de nómina del empleado en SAP.
     */
    public void getValidaCuentaNegocio(java.lang.String usuario, java.lang.String contrase�a, java.lang.String cuentaBanco, java.lang.String empresa, javax.xml.rpc.holders.IntHolder valNegocio, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException;

    /**
     * A partir de la cuenta de BAZ, se busca el empleado al que corresponde
     * dicha cuenta.
     */
    public void getValidaCuentaEmpleado(java.lang.String usuario, java.lang.String contrase�a, java.lang.String cuentaBanco, java.lang.String empresa, javax.xml.rpc.holders.IntHolder empleado, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException;

    /**
     * Obtiene la información de la promoción del empleado
     */
    public EmpleadoPromocion[] getEmpleadoPromocion(java.lang.String usuario, java.lang.String contrase�a, int numeroEmpleado, java.lang.String empresa, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException;

    /**
     * Obtiene la huella registrada en cliente único
     */
    public java.lang.String getClienteUnicoEmpleado(java.lang.String usuario, java.lang.String contrase�a, int empleado, java.lang.String empresa, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException;

    /**
     * Obtiene la información de cuota patronal
     */
    public CuotasPatronales getCuotaPatronal(java.lang.String usuario, java.lang.String contrasena, java.lang.String empresa, java.lang.String compania, int anio, int periodo, javax.xml.rpc.holders.BooleanHolder existeError, javax.xml.rpc.holders.StringHolder mensaje) throws java.rmi.RemoteException;
}
