package com.bancoazteca.srcu.spring.configuracion;

//import org.springframework.security.web.context.AbstractSecurityWebApplicationInitializer;

public class SecurityInit/* extends AbstractSecurityWebApplicationInitializer*/ {
    

    
} 