package com.bancoazteca.srcu.spring.servicios.administracion.mantenimientoUsuariosAvante;

import com.bancoazteca.srcu.spring.beans.administracion.mantenimientoUsuariosAvante.AsignacionAvanteBean;
import com.bancoazteca.srcu.spring.beans.sistema.MensajeTransaccionBean;

public interface AsignacionAvanteServicio {
		public	AsignacionAvanteBean consulta(AsignacionAvanteBean asignacionAvanteBean, int tipoConsulta);
		public	MensajeTransaccionBean grabaTransaccion(AsignacionAvanteBean asignacionAvanteBean, int tipoOperacion);
}
