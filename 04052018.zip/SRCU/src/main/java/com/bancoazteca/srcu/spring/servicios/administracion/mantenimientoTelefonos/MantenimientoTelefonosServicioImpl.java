package com.bancoazteca.srcu.spring.servicios.administracion.mantenimientoTelefonos;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bancoazteca.srcu.spring.beans.administracion.mantenimientoTelefonos.DatosEmpleadoBean;
import com.bancoazteca.srcu.spring.beans.administracion.mantenimientoTelefonos.MantenimientoTelefonosBean;
import com.bancoazteca.srcu.spring.beans.sistema.MensajeTransaccionBean;
import com.bancoazteca.srcu.spring.daos.administracion.mantenimientoTelefonos.MantenimientoTelefonosDAO;
import com.bancoazteca.srcu.spring.servicios.utilerias.BaseServicio;

@Service
public class MantenimientoTelefonosServicioImpl extends BaseServicio implements MantenimientoTelefonosServicio {

	public interface Enum_Operaciones_MantenimientoTelefonos{
		int insertaTelefono		=	1;
		int	actualizaTelefono	=	2;
	}
		
	public interface Enum_Consultas_MantenimientoTelefonosServicio{
		int	datosEmpleado	=	1;
	}
	
	public interface Enum_Constantes_Enum_Consultas_MantenimientoTelefonosServicio{
		int	empleadoEncontrado	=	1;
		int empleadoSinRegistro	=	0;
	}
	
	@Autowired
	private MantenimientoTelefonosDAO mantenimientoTelefonosDAO;
	
	@Override
	public MensajeTransaccionBean grabaTransaccion(int tipoOperacion,MantenimientoTelefonosBean mantenimientoTelefonosBean) {
		MensajeTransaccionBean	mensajeTransaccionBean = new MensajeTransaccionBean();
		
		switch (tipoOperacion) {
		case Enum_Operaciones_MantenimientoTelefonos.insertaTelefono:
			mensajeTransaccionBean	=	mantenimientoTelefonosDAO.insertaTelefono(mantenimientoTelefonosBean);
			break;

			
		case Enum_Operaciones_MantenimientoTelefonos.actualizaTelefono:
			mensajeTransaccionBean	=	mantenimientoTelefonosDAO.actualizaTelefono(mantenimientoTelefonosBean);
			break;

		default:
			break;
		}
		
		return mensajeTransaccionBean;
	}
	
	@Override
	public MantenimientoTelefonosBean consulta(int tipoConsulta, MantenimientoTelefonosBean mantenimientoTelefonos) {
		MantenimientoTelefonosBean mantenimientoTelefonosBean = new MantenimientoTelefonosBean();
		
		switch (tipoConsulta) {
		case Enum_Consultas_MantenimientoTelefonosServicio.datosEmpleado:
			DatosEmpleadoBean datosEmpleadoBean = new DatosEmpleadoBean();
			
			mantenimientoTelefonosBean = mantenimientoTelefonosDAO.consultaDatosEmpleado(mantenimientoTelefonos);
			
			if(mantenimientoTelefonosBean.getNumeroEmpleado() != null) {
				mantenimientoTelefonosBean.setExisteRegistro(Enum_Constantes_Enum_Consultas_MantenimientoTelefonosServicio.empleadoEncontrado);
			}else {
				mantenimientoTelefonosBean.setExisteRegistro(Enum_Constantes_Enum_Consultas_MantenimientoTelefonosServicio.empleadoSinRegistro);
			}
			
			datosEmpleadoBean = mantenimientoTelefonosDAO.consultaDatosGenerales(mantenimientoTelefonos.getNumeroEmpleado());
			mantenimientoTelefonosBean.setNumeroEmpleado(mantenimientoTelefonos.getNumeroEmpleado());
			mantenimientoTelefonosBean.setNombreEmpleado(datosEmpleadoBean.getNombreEmpleado());
			
			break;

		default:
			break;
		}
		
		return mantenimientoTelefonosBean;
	}

	public void setMantenimientoTelefonosDAO(MantenimientoTelefonosDAO mantenimientoTelefonosDAO) {
		this.mantenimientoTelefonosDAO = mantenimientoTelefonosDAO;
	}

}
