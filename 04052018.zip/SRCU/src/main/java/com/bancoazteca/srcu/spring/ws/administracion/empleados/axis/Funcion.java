/**
 * Funcion.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.bancoazteca.srcu.spring.ws.administracion.empleados.axis;
@SuppressWarnings({ "unused", "rawtypes" })
public class Funcion  implements java.io.Serializable {
    /**
	 * 
	 */
	private static final long serialVersionUID = -4369662699144148879L;

	private int idFuncion;

    private java.lang.String desFuncion;

    private int nivel;

    private int nivelDEX;

    private java.lang.String negocio;

    public Funcion() {
    }

    public Funcion(
           int idFuncion,
           java.lang.String desFuncion,
           int nivel,
           int nivelDEX,
           java.lang.String negocio) {
           this.idFuncion = idFuncion;
           this.desFuncion = desFuncion;
           this.nivel = nivel;
           this.nivelDEX = nivelDEX;
           this.negocio = negocio;
    }


    /**
     * Gets the idFuncion value for this Funcion.
     * 
     * @return idFuncion
     */
    public int getIdFuncion() {
        return idFuncion;
    }


    /**
     * Sets the idFuncion value for this Funcion.
     * 
     * @param idFuncion
     */
    public void setIdFuncion(int idFuncion) {
        this.idFuncion = idFuncion;
    }


    /**
     * Gets the desFuncion value for this Funcion.
     * 
     * @return desFuncion
     */
    public java.lang.String getDesFuncion() {
        return desFuncion;
    }


    /**
     * Sets the desFuncion value for this Funcion.
     * 
     * @param desFuncion
     */
    public void setDesFuncion(java.lang.String desFuncion) {
        this.desFuncion = desFuncion;
    }


    /**
     * Gets the nivel value for this Funcion.
     * 
     * @return nivel
     */
    public int getNivel() {
        return nivel;
    }


    /**
     * Sets the nivel value for this Funcion.
     * 
     * @param nivel
     */
    public void setNivel(int nivel) {
        this.nivel = nivel;
    }


    /**
     * Gets the nivelDEX value for this Funcion.
     * 
     * @return nivelDEX
     */
    public int getNivelDEX() {
        return nivelDEX;
    }


    /**
     * Sets the nivelDEX value for this Funcion.
     * 
     * @param nivelDEX
     */
    public void setNivelDEX(int nivelDEX) {
        this.nivelDEX = nivelDEX;
    }


    /**
     * Gets the negocio value for this Funcion.
     * 
     * @return negocio
     */
    public java.lang.String getNegocio() {
        return negocio;
    }


    /**
     * Sets the negocio value for this Funcion.
     * 
     * @param negocio
     */
    public void setNegocio(java.lang.String negocio) {
        this.negocio = negocio;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Funcion)) return false;
        Funcion other = (Funcion) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this.idFuncion == other.getIdFuncion() &&
            ((this.desFuncion==null && other.getDesFuncion()==null) || 
             (this.desFuncion!=null &&
              this.desFuncion.equals(other.getDesFuncion()))) &&
            this.nivel == other.getNivel() &&
            this.nivelDEX == other.getNivelDEX() &&
            ((this.negocio==null && other.getNegocio()==null) || 
             (this.negocio!=null &&
              this.negocio.equals(other.getNegocio())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += getIdFuncion();
        if (getDesFuncion() != null) {
            _hashCode += getDesFuncion().hashCode();
        }
        _hashCode += getNivel();
        _hashCode += getNivelDEX();
        if (getNegocio() != null) {
            _hashCode += getNegocio().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Funcion.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Funcion"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("idFuncion");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "idFuncion"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("desFuncion");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "DesFuncion"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nivel");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Nivel"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nivelDEX");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "NivelDEX"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("negocio");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Negocio"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
