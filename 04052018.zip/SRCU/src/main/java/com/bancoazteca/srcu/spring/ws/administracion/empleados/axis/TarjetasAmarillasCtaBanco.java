/**
 * TarjetasAmarillasCtaBanco.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.bancoazteca.srcu.spring.ws.administracion.empleados.axis;
@SuppressWarnings({ "unused", "rawtypes", "serial" })
public class TarjetasAmarillasCtaBanco  implements java.io.Serializable {
    private java.lang.String cuentaBanco;

    private java.lang.String companiaPagadora;

    private int numeroTarjeta;

    public TarjetasAmarillasCtaBanco() {
    }

    public TarjetasAmarillasCtaBanco(
           java.lang.String cuentaBanco,
           java.lang.String companiaPagadora,
           int numeroTarjeta) {
           this.cuentaBanco = cuentaBanco;
           this.companiaPagadora = companiaPagadora;
           this.numeroTarjeta = numeroTarjeta;
    }


    /**
     * Gets the cuentaBanco value for this TarjetasAmarillasCtaBanco.
     * 
     * @return cuentaBanco
     */
    public java.lang.String getCuentaBanco() {
        return cuentaBanco;
    }


    /**
     * Sets the cuentaBanco value for this TarjetasAmarillasCtaBanco.
     * 
     * @param cuentaBanco
     */
    public void setCuentaBanco(java.lang.String cuentaBanco) {
        this.cuentaBanco = cuentaBanco;
    }


    /**
     * Gets the companiaPagadora value for this TarjetasAmarillasCtaBanco.
     * 
     * @return companiaPagadora
     */
    public java.lang.String getCompaniaPagadora() {
        return companiaPagadora;
    }


    /**
     * Sets the companiaPagadora value for this TarjetasAmarillasCtaBanco.
     * 
     * @param companiaPagadora
     */
    public void setCompaniaPagadora(java.lang.String companiaPagadora) {
        this.companiaPagadora = companiaPagadora;
    }


    /**
     * Gets the numeroTarjeta value for this TarjetasAmarillasCtaBanco.
     * 
     * @return numeroTarjeta
     */
    public int getNumeroTarjeta() {
        return numeroTarjeta;
    }


    /**
     * Sets the numeroTarjeta value for this TarjetasAmarillasCtaBanco.
     * 
     * @param numeroTarjeta
     */
    public void setNumeroTarjeta(int numeroTarjeta) {
        this.numeroTarjeta = numeroTarjeta;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof TarjetasAmarillasCtaBanco)) return false;
        TarjetasAmarillasCtaBanco other = (TarjetasAmarillasCtaBanco) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.cuentaBanco==null && other.getCuentaBanco()==null) || 
             (this.cuentaBanco!=null &&
              this.cuentaBanco.equals(other.getCuentaBanco()))) &&
            ((this.companiaPagadora==null && other.getCompaniaPagadora()==null) || 
             (this.companiaPagadora!=null &&
              this.companiaPagadora.equals(other.getCompaniaPagadora()))) &&
            this.numeroTarjeta == other.getNumeroTarjeta();
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getCuentaBanco() != null) {
            _hashCode += getCuentaBanco().hashCode();
        }
        if (getCompaniaPagadora() != null) {
            _hashCode += getCompaniaPagadora().hashCode();
        }
        _hashCode += getNumeroTarjeta();
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(TarjetasAmarillasCtaBanco.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "TarjetasAmarillasCtaBanco"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("cuentaBanco");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "CuentaBanco"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("companiaPagadora");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "CompaniaPagadora"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroTarjeta");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "NumeroTarjeta"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
