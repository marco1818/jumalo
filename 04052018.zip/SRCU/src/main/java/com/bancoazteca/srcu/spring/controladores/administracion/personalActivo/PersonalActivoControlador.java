package com.bancoazteca.srcu.spring.controladores.administracion.personalActivo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.ModelAndView;
import com.bancoazteca.srcu.spring.beans.administracion.personalActivo.PersonalActivoBean;
import com.bancoazteca.srcu.spring.beans.utilerias.DatosSessionStruts;
import com.bancoazteca.srcu.spring.servicios.administracion.personalActivo.PersonalActivoServicio;
import com.bancoazteca.srcu.spring.servicios.administracion.personalActivo.PersonalActivoServicioImpl.Enum_Consultas_PersonalActivo;

@Controller
public class PersonalActivoControlador {
	
	@Autowired
	PersonalActivoServicio personalActivoServicio;
	
	@InitBinder
	public void InitBinder(WebDataBinder webDataBinder, WebRequest webRequest) {
		webDataBinder.setDisallowedFields("");
	}
	
	@RequestMapping(value= {"/personalActivo.htm"}, method=RequestMethod.GET)
	public ModelAndView personalActivo() {
		ModelAndView modelAndView = new ModelAndView();
		/**
		 * Se obtienen los datos de la session en Spring y se
		 * realizan las consultas correspondientes.
		 */
		modelAndView.setViewName("administracion/personalActivo/personalActivo");
		modelAndView.addObject("gerenciaId",9049);
		return modelAndView;
	}

	@RequestMapping(value= {"/personalActivoSRCU.htm"}, method=RequestMethod.GET)
	public ModelAndView personalActivo(@ModelAttribute("datosSession") DatosSessionStruts datosSessionStruts) {
		
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("administracion/personalActivo/personalActivo");
		List<PersonalActivoBean> personalActivo = personalActivoServicio.consulta(datosSessionStruts.getGerenciaId(), Enum_Consultas_PersonalActivo.consultaPersonalActivo);
		modelAndView.addObject("personalActivo",personalActivo);
		modelAndView.addObject("gerenciaId",datosSessionStruts.getGerenciaId());
		return modelAndView;
	}

	public void setPersonalActivoServicio(PersonalActivoServicio personalActivoServicio) {
		this.personalActivoServicio = personalActivoServicio;
	}
	
}
