package com.bancoazteca.srcu.spring.servicios.administracion.mantenimientoUsuariosUnificado;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bancoazteca.srcu.spring.beans.administracion.mantenimientoUsuariosUnificado.EmpleadosBean;
import com.bancoazteca.srcu.spring.beans.administracion.mantenimientoUsuariosUnificado.MantenimientoUsuariosUnificadoBean;
import com.bancoazteca.srcu.spring.beans.sistema.MensajeTransaccionBean;
import com.bancoazteca.srcu.spring.beans.utilerias.CatalogoBean;
import com.bancoazteca.srcu.spring.beans.utilerias.SimpleBean;
import com.bancoazteca.srcu.spring.daos.administracion.mantenimientoUsuariosUnificado.MantenimientoUsuariosUnificadoDAO;
import com.bancoazteca.srcu.spring.servicios.utilerias.BaseServicio;
import com.bancoazteca.srcu.spring.ws.administracion.as400.Respuesta400Bean;
import com.bancoazteca.srcu.spring.ws.administracion.as400.UtileriasAs400;
import com.bancoazteca.srcu.spring.ws.administracion.empleados.DatosEmpleado;
import com.bancoazteca.srcu.spring.ws.administracion.empleados.axis.Empleado;

@Service
public class MantenimientoUsuariosUnificadoServicioImpl extends BaseServicio implements MantenimientoUsuariosUnificadoServicio{
	
	private interface Consultas{
		int	puestosPermitidos		=	1;
		int consultaDepartamentos	=	2;
		int consultaEmpleados		=	3;
		int	segmentosVacantes		= 	4;
		int	segmentosEmpleados		= 	5;
		int	datosEmpleado			=	6;
		int	cambioEmpleado			=	7;
	}
	
	private interface Transacciones{
		int	altaVacante			=	1;
		int	altaEmpleado		=	2;
		int	bajaEmpleado		=	3;
		int bajaxSustitucion	=	4;
		int cambioEmpleado		=	5;
	}
	
	private interface Catalogos{
		int	puestosReplican400			=	413;
		int geografiasCredimax			=	103;
//		int equivalenciasSap			=	417;
		int equivalenciasSegmentos		=	419;
		int equivalenciasPuestos		=	420;
		int	generanVirtuales8Digitos	=	423;
	}
	
	private interface Constantes{
		String activo				=	"1";
		int	exito					=	0;
		int generaVacante			=	5;
		int empleadoActivo			=	2;
		int	maximo_8_Digitos		=	99;
		int maximo_6_digitos		=	999;
		int error					=	999;
		int multiplicador_6_digitos	=	1000;
		int multiplicador_8_digitos	=	100;
	}
	
	@Autowired
	MantenimientoUsuariosUnificadoDAO mantenimientoUsuariosUnificadoDAO;
	
	@Autowired
	DatosEmpleado	datosEmpleado;
	@Autowired
	UtileriasAs400 utileriasAs400;
	
	@Override
	public MantenimientoUsuariosUnificadoBean consulta(
			MantenimientoUsuariosUnificadoBean mantenimientoUsuariosUnificado, int tipoConsulta) {
		MantenimientoUsuariosUnificadoBean mantenimientoUsuariosUnificadoBean = new MantenimientoUsuariosUnificadoBean();
		switch (tipoConsulta) {
		case Consultas.puestosPermitidos:
			mantenimientoUsuariosUnificadoBean.setPuestos(mantenimientoUsuariosUnificadoDAO.consultaPuestosOperar(mantenimientoUsuariosUnificado));
			break;
		case Consultas.consultaDepartamentos:
			mantenimientoUsuariosUnificadoBean.setDepartamentos(mantenimientoUsuariosUnificadoDAO.consultaDepartamentos(mantenimientoUsuariosUnificado));
			break;
		case Consultas.consultaEmpleados:
			mantenimientoUsuariosUnificadoBean.setEmpleados(mantenimientoUsuariosUnificadoDAO.consultaEmpleados(mantenimientoUsuariosUnificado));
			break;
		case Consultas.segmentosVacantes:
			mantenimientoUsuariosUnificadoBean.setVacantesxPuesto(mantenimientoUsuariosUnificadoDAO.consultaVacantesxPuesto(mantenimientoUsuariosUnificado,1));
			break;
		case Consultas.segmentosEmpleados:
			mantenimientoUsuariosUnificadoBean.setVacantesxPuesto(mantenimientoUsuariosUnificadoDAO.consultaVacantesxPuesto(mantenimientoUsuariosUnificado,2));
			break;
		case Consultas.datosEmpleado:
			mantenimientoUsuariosUnificadoBean.setDatosEmpleado(mantenimientoUsuariosUnificadoDAO.datosEmpleado(mantenimientoUsuariosUnificado));
			break;
		case Consultas.cambioEmpleado:
			mantenimientoUsuariosUnificadoBean = consultaCambioPuesto(mantenimientoUsuariosUnificado);
			break;
			
		default:
			break;
		}
		
		return mantenimientoUsuariosUnificadoBean;
	}

	@Override
	public MensajeTransaccionBean grabaTransaccion(MantenimientoUsuariosUnificadoBean mantenimientoUsuariosUnificadoBean, int tipoOperacion) {
		MensajeTransaccionBean mensajeTransaccionBean = new MensajeTransaccionBean();
		
		switch (tipoOperacion) {
		case Transacciones.altaVacante:
			mensajeTransaccionBean	=	altaVacante(mantenimientoUsuariosUnificadoBean);
			break;
		case Transacciones.altaEmpleado:
			mensajeTransaccionBean	=	altaEmpleado(mantenimientoUsuariosUnificadoBean);
			break;
		case Transacciones.bajaEmpleado:
			mensajeTransaccionBean	=	bajaEmpleado(mantenimientoUsuariosUnificadoBean);
			break;
		case Transacciones.bajaxSustitucion:
			mensajeTransaccionBean	=	bajaxSustitucion(mantenimientoUsuariosUnificadoBean);
			break;
		case Transacciones.cambioEmpleado:
			mensajeTransaccionBean	=	cambioEmpleado(mantenimientoUsuariosUnificadoBean);
			break;
		default:
			break;
		}
		
		return mensajeTransaccionBean;
	}
	
	
	private MensajeTransaccionBean altaVacante(MantenimientoUsuariosUnificadoBean mantenimientoUsuariosUnificadoBean) {
		MensajeTransaccionBean mensajeTransaccionBean = new MensajeTransaccionBean();
		CatalogoBean puestoReplica	=	consultaSubItem(Catalogos.puestosReplican400, mantenimientoUsuariosUnificadoBean.getSegmentoOperar());
		EmpleadosBean empleadoJefe	=	new EmpleadosBean();
		
		mantenimientoUsuariosUnificadoBean.setEmpleadoAlta(generaVacante(mantenimientoUsuariosUnificadoBean.getDepartamentoOperar(), mantenimientoUsuariosUnificadoBean.getSegmentoOperar(), mantenimientoUsuariosUnificadoBean.getEmpleadoOpera(),puestoReplica.getDescCorta()));
		
		if(mantenimientoUsuariosUnificadoBean.getEmpleadoAlta().equals("")) {
			mensajeTransaccionBean.setNumeroMensaje(Constantes.error);
			mensajeTransaccionBean.setDescripcionMensaje("NO FUE POSIBLE GENERAR UN EMPLEADO VACANTE, INTENTELO MAS TARDE.");
			return mensajeTransaccionBean;
		}
		
		mantenimientoUsuariosUnificadoBean.setNombreEmpleadoAlta("EMPLEADO VIRTUAL");		
		mensajeTransaccionBean = mantenimientoUsuariosUnificadoDAO.altaEmpleado(mantenimientoUsuariosUnificadoBean);
		
		empleadoJefe = mantenimientoUsuariosUnificadoDAO.consultaJefeOracle(mantenimientoUsuariosUnificadoBean);
		
		if(mensajeTransaccionBean.getNumeroMensaje() == Constantes.exito) {
			if(puestoReplica.getDescCorta().equals(Constantes.activo)) {			
				Respuesta400Bean respuesta400Bean = utileriasAs400.altaEmpleado(mantenimientoUsuariosUnificadoBean.getEmpleadoAlta(),		mantenimientoUsuariosUnificadoBean.getEmpleadoOpera(), 
																				mantenimientoUsuariosUnificadoBean.getDepartamentoOperar(),	mantenimientoUsuariosUnificadoBean.getSegmentoOperar(),
																				empleadoJefe.getNumeroEmpleado());
				if(respuesta400Bean.getCodigo() != Constantes.exito) {
					mantenimientoUsuariosUnificadoBean.setEmpleadoBaja(mantenimientoUsuariosUnificadoBean.getEmpleadoAlta());
					mensajeTransaccionBean = mantenimientoUsuariosUnificadoDAO.bajaEmpleado(mantenimientoUsuariosUnificadoBean);
					mensajeTransaccionBean.setDescripcionMensaje("NO FUE POSIBLE REALIZAR EL ALTA EN CREDIMAX DEBIDO A:"+respuesta400Bean.getMensaje());
				}
			}
		}
		
		return mensajeTransaccionBean;
	}
	
	private String generaVacante(int departamentoId, int segmentoOperar,String empleadoOpera,String replicaAs400) {
		MensajeTransaccionBean mensajeTransaccionBean = new MensajeTransaccionBean();
		String vacante = "";
		CatalogoBean segmento8Digitos	=	consultaSubItem(Catalogos.generanVirtuales8Digitos, segmentoOperar);
		int vacanteInicial = 0;
		int maximoIntentos;
		if(segmento8Digitos.getDescCorta()!=null) {
			if(segmento8Digitos.getDescCorta().contains(Constantes.activo)) {
				vacanteInicial = departamentoId*Constantes.multiplicador_8_digitos;
				maximoIntentos = Constantes.maximo_8_Digitos;
			}else {
				SimpleBean vacantexPais	=	mantenimientoUsuariosUnificadoDAO.paisxGerencia(departamentoId);
				vacanteInicial	=	vacantexPais.getCodigo()*Constantes.multiplicador_6_digitos;
				maximoIntentos	=	Constantes.maximo_6_digitos;
			}
		}else {
			SimpleBean vacantexPais	=	mantenimientoUsuariosUnificadoDAO.paisxGerencia(departamentoId);
			vacanteInicial	=	vacantexPais.getCodigo()*Constantes.multiplicador_6_digitos;
			maximoIntentos	=	Constantes.maximo_6_digitos;
		}

		for(int consecutivo = 0	;	consecutivo < maximoIntentos	;	consecutivo++) {
			vacante ="00"+(vacanteInicial+consecutivo);
			mensajeTransaccionBean = mantenimientoUsuariosUnificadoDAO.consultaVacante(vacante);
			if(mensajeTransaccionBean.getNumeroMensaje() == Constantes.exito) {
				
				if(replicaAs400.equals(Constantes.activo)) {
					Respuesta400Bean respuesta400Bean =  utileriasAs400.consultaEmpleado(vacante);
					if(respuesta400Bean.getMensajeId() == Constantes.exito) {
						respuesta400Bean = utileriasAs400.confirmaVacante(segmentoOperar, vacante, empleadoOpera);
						if(respuesta400Bean.getCodigo() == Constantes.exito) {
							break;
						}else {
							vacante	="";
							continue;
						}
					}else {
						vacante	="";
					}
				}else {
					break;
				}	
			}else {
				vacante	="";
			}
		}
		
		return vacante;
	}
	
	public MensajeTransaccionBean altaEmpleado(MantenimientoUsuariosUnificadoBean mantenimientoUsuariosUnificadoBean) {
		MensajeTransaccionBean mensajeTransaccionBean = new MensajeTransaccionBean();
		int funcionSapEmpleado = 0;
		Empleado empleado = datosEmpleado.consultaEmpleadoSap(mantenimientoUsuariosUnificadoBean.getEmpleadoAlta());
		CatalogoBean puestoReplica	=	consultaSubItem(Catalogos.puestosReplican400, mantenimientoUsuariosUnificadoBean.getSegmentoOperar());
		EmpleadosBean empleadoJefe	=	new EmpleadosBean();
		SimpleBean validaFnSap	=	null;
		
		if(!empleado.isActivo()) {
			mensajeTransaccionBean.setNumeroMensaje(Constantes.error);
			mensajeTransaccionBean.setDescripcionMensaje("EL EMPLEADO NO SE ENCUENTRA ACTIVO EN SAP.");
			return mensajeTransaccionBean;
		}
		mantenimientoUsuariosUnificadoBean.setNombreEmpleadoAlta(empleado.getNombreInicial()+" "+empleado.getApellidoPaterno()+" "+empleado.getApellidoMaterno());
		
		funcionSapEmpleado = Integer.parseInt(empleado.getIdFuncion());
		
		validaFnSap	=	mantenimientoUsuariosUnificadoDAO.validaFuncionSap(mantenimientoUsuariosUnificadoBean.getSegmentoOperar(), funcionSapEmpleado);
		
		if(validaFnSap.getCodigo() != Constantes.exito) {
			mensajeTransaccionBean.setNumeroMensaje(Constantes.error);
			mensajeTransaccionBean.setDescripcionMensaje("NO SE PUEDE REALIZAR EL ALTA DEL EMPLEADO: "+mantenimientoUsuariosUnificadoBean.getNombreEmpleadoAlta()+" DEBIDO A QUE TIENE UNA FUNCION SAP: "+empleado.getIdFuncion()+" Y SE REQUIERE UNA FUNCION SAP: "+validaFnSap.getDescripcion());
			return mensajeTransaccionBean;
		}
		
		mensajeTransaccionBean = mantenimientoUsuariosUnificadoDAO.validaAltaEmpleado(mantenimientoUsuariosUnificadoBean);
		
		
		if(mensajeTransaccionBean.getNumeroMensaje() != Constantes.exito) {
			mensajeTransaccionBean.setNumeroMensaje(Constantes.error);
			mensajeTransaccionBean.setDescripcionMensaje("NO SE PUEDE REALIZAR EL ALTA DEL EMPLEADO DEBIDO A: "+mensajeTransaccionBean.getDescripcionMensaje());
			return mensajeTransaccionBean;
		}
	
		mensajeTransaccionBean = mantenimientoUsuariosUnificadoDAO.altaEmpleado(mantenimientoUsuariosUnificadoBean);
		
		if(mensajeTransaccionBean.getNumeroMensaje() == Constantes.exito) {			
			if(puestoReplica.getDescCorta().equals(Constantes.activo)) {
				
				empleadoJefe = mantenimientoUsuariosUnificadoDAO.consultaJefeOracle(mantenimientoUsuariosUnificadoBean);
				Respuesta400Bean respuesta400Bean = new Respuesta400Bean();
				
				respuesta400Bean = utileriasAs400.consultaEmpleado(mantenimientoUsuariosUnificadoBean.getEmpleadoAlta());
				
				if(respuesta400Bean.getMensajeId() == 0) {					
					mantenimientoUsuariosUnificadoBean.setEmpleadoBaja(mantenimientoUsuariosUnificadoBean.getEmpleadoAlta());
					mensajeTransaccionBean = mantenimientoUsuariosUnificadoDAO.bajaEmpleado(mantenimientoUsuariosUnificadoBean);
					mensajeTransaccionBean.setNumeroMensaje(999);
					mensajeTransaccionBean.setDescripcionMensaje("NO FUE POSIBLE REALIZAR EL ALTA DEL EMPLEADO EN CREDIMAX DEBIDO A QUE NO EXISTE.");
					return mensajeTransaccionBean;
				}
				
				respuesta400Bean = utileriasAs400.altaEmpleado(	mantenimientoUsuariosUnificadoBean.getEmpleadoAlta(), 		mantenimientoUsuariosUnificadoBean.getEmpleadoOpera(), 
																mantenimientoUsuariosUnificadoBean.getDepartamentoOperar(), mantenimientoUsuariosUnificadoBean.getSegmentoOperar(), 
																empleadoJefe.getNumeroEmpleado());
				if(respuesta400Bean.getCodigo()	!= Constantes.exito) {
					mantenimientoUsuariosUnificadoBean.setEmpleadoBaja(mantenimientoUsuariosUnificadoBean.getEmpleadoAlta());
					mensajeTransaccionBean = mantenimientoUsuariosUnificadoDAO.bajaEmpleado(mantenimientoUsuariosUnificadoBean);
					mensajeTransaccionBean.setNumeroMensaje(Constantes.error);
					mensajeTransaccionBean.setDescripcionMensaje("NO FUE POSIBLE REALIZAR EL ALTA DEL EMPLEADO EN CREDIMAX DEBIDO A: "+respuesta400Bean.getMensaje());
					return mensajeTransaccionBean;
				}
				
				
			}
		}else {
			mensajeTransaccionBean.setNumeroMensaje(Constantes.error);
			mensajeTransaccionBean.setDescripcionMensaje("NO SE PUEDE REALIZAR EL ALTA DEL EMPLEADO DEBIDO A: "+mensajeTransaccionBean.getDescripcionMensaje());
		}
			
		return mensajeTransaccionBean;
	}
	
	public MensajeTransaccionBean bajaEmpleado(MantenimientoUsuariosUnificadoBean mantenimientoUsuariosUnificadoBean) {
		MensajeTransaccionBean mensajeTransaccionBean = new MensajeTransaccionBean();
		Respuesta400Bean respuesta400Bean = new Respuesta400Bean();
		mensajeTransaccionBean = mantenimientoUsuariosUnificadoDAO.validaBajaEmpleado(mantenimientoUsuariosUnificadoBean);
		
		
		
		if(mensajeTransaccionBean.getNumeroMensaje() != Constantes.exito && mensajeTransaccionBean.getMensajeId() != Constantes.generaVacante) {
			mensajeTransaccionBean.setDescripcionMensaje("NO ES POSIBLE REALIZAR LA BAJA DEL EMPLEADO:"+mantenimientoUsuariosUnificadoBean.getEmpleadoBaja()+" DEBIDO A :"+mensajeTransaccionBean.getDescripcionMensaje());
			return mensajeTransaccionBean;
		}
		
		CatalogoBean puestoReplica	=	consultaSubItem(Catalogos.puestosReplican400, mantenimientoUsuariosUnificadoBean.getSegmentoOrigen());
		
		if(mensajeTransaccionBean.getMensajeId() == Constantes.generaVacante || mensajeTransaccionBean.getMensajeId() == 4) {
			
			mantenimientoUsuariosUnificadoBean.setEmpleadoOrigenEje(mantenimientoUsuariosUnificadoBean.getEmpleadoBaja());
			mantenimientoUsuariosUnificadoBean.setEmpleadoDestinoEje(generaVacante(mantenimientoUsuariosUnificadoBean.getDepartamentoOperar(), mantenimientoUsuariosUnificadoBean.getSegmentoOrigen(), mantenimientoUsuariosUnificadoBean.getEmpleadoOpera(), puestoReplica.getDescCorta()));
			
			if(mantenimientoUsuariosUnificadoBean.getEmpleadoDestinoEje().equals("")) {
				mensajeTransaccionBean.setNumeroMensaje(Constantes.error);
				mensajeTransaccionBean.setDescripcionMensaje("NO FUE POSIBLE GENERAR UN EMPLEADO VACANTE PARA LA BAJA DEL EMPLEADO: "+mantenimientoUsuariosUnificadoBean.getEmpleadoBaja()+", POR FAVOR INTENTELO MAS TARDE.");
				return mensajeTransaccionBean;
			}

			mensajeTransaccionBean = mantenimientoUsuariosUnificadoDAO.validaBajaxSustitucion(mantenimientoUsuariosUnificadoBean);
			
			if(mensajeTransaccionBean.getNumeroMensaje()	!=	Constantes.exito) {
				mensajeTransaccionBean.setNumeroMensaje(Constantes.error);
				mensajeTransaccionBean.setDescripcionMensaje("NO ES POSIBLE REALIZAR LA BAJA DEL EMPLEADO DEBIDO A:"+mensajeTransaccionBean.getDescripcionMensaje());
				return mensajeTransaccionBean;
			}
			
			if(puestoReplica.getDescCorta().equals(Constantes.activo)) {
				
				respuesta400Bean = utileriasAs400.consultaEmpleado(mantenimientoUsuariosUnificadoBean.getEmpleadoBaja());
				
				if(respuesta400Bean.getMensajeId() != Constantes.empleadoActivo) {
					mensajeTransaccionBean.setNumeroMensaje(Constantes.error);
					mensajeTransaccionBean.setDescripcionMensaje("NO ES POSIBLE REALIZAR LA BAJA DEL EMPLEADO EN CREDIMAX YA QUE EL EMPLEADO SE ENCUENTRA DADO DE BAJA.");
					return mensajeTransaccionBean;
				}
				
				int geografiaCredimax	=	Integer.parseInt(consultaSubItem(Catalogos.geografiasCredimax, mantenimientoUsuariosUnificadoBean.getDepartamentoOperar()).getDescCorta());
				
				if(geografiaCredimax != respuesta400Bean.getGeografia()) {
					mensajeTransaccionBean.setNumeroMensaje(Constantes.error);
					mensajeTransaccionBean.setDescripcionMensaje("NO ES POSIBLE REALIZAR LA BAJA DEL EMPLEADO :"+mantenimientoUsuariosUnificadoBean.getEmpleadoBaja()+" YA QUE EN LA UNIFICADA TIENE LA GEOGRAFIA :"+geografiaCredimax+" Y EN CREDIMAX TIENE: "+respuesta400Bean.getGeografia());
					return mensajeTransaccionBean;
				}
				
				respuesta400Bean = utileriasAs400.bajaXSustitucion(mantenimientoUsuariosUnificadoBean.getEmpleadoOrigenEje(), mantenimientoUsuariosUnificadoBean.getEmpleadoDestinoEje(), mantenimientoUsuariosUnificadoBean.getEmpleadoOpera());
				
				if(respuesta400Bean.getCodigo() != Constantes.exito) {
					mensajeTransaccionBean.setNumeroMensaje(Constantes.error);
					mensajeTransaccionBean.setDescripcionMensaje("NO ES POSIBLE REALIZAR LA BAJA DEL EMPLEADO EN CREDIMAX DEBIDO A:"+respuesta400Bean.getMensaje());
					return mensajeTransaccionBean;
				}
			}
			
			mensajeTransaccionBean = mantenimientoUsuariosUnificadoDAO.bajaxSustitucion(mantenimientoUsuariosUnificadoBean);
			
			if(mensajeTransaccionBean.getNumeroMensaje() == Constantes.exito) {
				mensajeTransaccionBean.setDescripcionMensaje("SE REALIZO LA BAJA DEL EMPLEADO:"+mantenimientoUsuariosUnificadoBean.getEmpleadoOrigenEje()+" Y EN SU LUGAR QUEDO EL EMPLEADO: "+mantenimientoUsuariosUnificadoBean.getEmpleadoDestinoEje()+" YA QUE TENIA CARTERA ASIGNADA.");
			}
			
		}else {
			if(puestoReplica.getDescCorta().equals(Constantes.activo)) {
				
				respuesta400Bean = utileriasAs400.consultaEmpleado(mantenimientoUsuariosUnificadoBean.getEmpleadoBaja());
				
				if(respuesta400Bean.getMensajeId() != Constantes.empleadoActivo) {
					mensajeTransaccionBean.setNumeroMensaje(Constantes.error);
					mensajeTransaccionBean.setDescripcionMensaje("NO ES POSIBLE REALIZAR LA BAJA DEL EMPLEADO EN CREDIMAX YA QUE EL EMPLEADO SE ENCUENTRA DADO DE BAJA.");
					return mensajeTransaccionBean;
				}
				
				int geografiaCredimax	=	Integer.parseInt(consultaSubItem(Catalogos.geografiasCredimax, mantenimientoUsuariosUnificadoBean.getDepartamentoOperar()).getDescCorta());
				
				if(geografiaCredimax != respuesta400Bean.getGeografia()) {
					mensajeTransaccionBean.setNumeroMensaje(Constantes.error);
					mensajeTransaccionBean.setDescripcionMensaje("NO ES POSIBLE REALIZAR LA BAJA DEL EMPLEADO :"+mantenimientoUsuariosUnificadoBean.getEmpleadoBaja()+" YA QUE EN LA UNIFICADA TIENE LA GEOGRAFIA :"+geografiaCredimax+" Y EN CREDIMAX TIENE: "+respuesta400Bean.getGeografia());
					return mensajeTransaccionBean;
				}
				
				respuesta400Bean	=	utileriasAs400.bajaEmpleado(mantenimientoUsuariosUnificadoBean.getEmpleadoBaja(), mantenimientoUsuariosUnificadoBean.getEmpleadoOpera());
				
				if(respuesta400Bean.getCodigo() != Constantes.exito) {
					mensajeTransaccionBean.setNumeroMensaje(Constantes.error);
					mensajeTransaccionBean.setDescripcionMensaje("NO ES POSIBLE REALIZAR LA BAJA DEL EMPLEADO EN CREDIMAX DEBIDO A:"+respuesta400Bean.getMensaje());
					return mensajeTransaccionBean;
				}
			}
			
			mensajeTransaccionBean = mantenimientoUsuariosUnificadoDAO.bajaEmpleado(mantenimientoUsuariosUnificadoBean);
			
			if(mensajeTransaccionBean.getNumeroMensaje() == Constantes.exito) {
				mensajeTransaccionBean.setDescripcionMensaje("SE REALIZO LA BAJA DEL EMPLEADO:"+mantenimientoUsuariosUnificadoBean.getEmpleadoBaja());
			}
		}
		
		
		
		return mensajeTransaccionBean;
	}
	
	public	MensajeTransaccionBean bajaxSustitucion(MantenimientoUsuariosUnificadoBean mantenimientoUsuariosUnificadoBean) {
		MensajeTransaccionBean mensajeTransaccionBean = new MensajeTransaccionBean();
		int funcionSapEmpleado = 0;
		
		if(!mantenimientoUsuariosUnificadoBean.getEmpleadoDestinoBS().startsWith("00")) {
			Empleado empleado = datosEmpleado.consultaEmpleadoSap(mantenimientoUsuariosUnificadoBean.getEmpleadoDestinoBS().trim());
			SimpleBean validaFnSap = null;
			
			if(!empleado.isActivo()) {
				mensajeTransaccionBean.setNumeroMensaje(Constantes.error);
				mensajeTransaccionBean.setDescripcionMensaje("NO ES POSIBLE REALIZAR EL CAMBIO DEL EMPLEADO: "+mantenimientoUsuariosUnificadoBean.getEmpleadoDestinoBS()+" YA QUE NO SE ENCUENTRA ACTIVO EN SAP.");
				return mensajeTransaccionBean;
			}
			
			funcionSapEmpleado = Integer.parseInt(empleado.getIdFuncion());
			
			validaFnSap	=	mantenimientoUsuariosUnificadoDAO.validaFuncionSap(mantenimientoUsuariosUnificadoBean.getSegmentoDestinoBS(), funcionSapEmpleado);
			
			if(validaFnSap.getCodigo() != Constantes.exito) {
				mensajeTransaccionBean.setNumeroMensaje(Constantes.error);
				mensajeTransaccionBean.setDescripcionMensaje("NO ES POSIBLE REALIZAR EL CAMBIO DEL EMPLEADO: "+mantenimientoUsuariosUnificadoBean.getEmpleadoDestinoBS()+" YA QUE CUENTA CON FUNCION SAP: "+empleado.getIdFuncion()+" Y SE REQUIERE LA FUNCION SAP:"+validaFnSap.getDescripcion());
				return mensajeTransaccionBean;
			}
						
		}
		

		
		// validar cursos en linea aqui.
		
		mantenimientoUsuariosUnificadoBean.setEmpleadoOrigenEje(mantenimientoUsuariosUnificadoBean.getEmpleadoOrigenBS());
		mantenimientoUsuariosUnificadoBean.setEmpleadoDestinoEje(mantenimientoUsuariosUnificadoBean.getEmpleadoDestinoBS());
	
		mensajeTransaccionBean = mantenimientoUsuariosUnificadoDAO.validaBajaxSustitucion(mantenimientoUsuariosUnificadoBean);
		
		if(mensajeTransaccionBean.getNumeroMensaje() != Constantes.exito) {
			mensajeTransaccionBean.setNumeroMensaje(Constantes.error);
			mensajeTransaccionBean.setDescripcionMensaje("NO ES POSIBLE REALIZAR EL CAMBIO DEL EMPLEADO: "+mantenimientoUsuariosUnificadoBean.getEmpleadoDestinoEje()+" DEBIDO A: "+mensajeTransaccionBean.getDescripcionMensaje());
			return mensajeTransaccionBean;
		}
		
		CatalogoBean puestoReplica	=	consultaSubItem(Catalogos.puestosReplican400, mantenimientoUsuariosUnificadoBean.getSegmentoDestinoBS());
		
		if (puestoReplica.getDescCorta().equals(Constantes.activo)) {
			Respuesta400Bean respuesta400Bean = new Respuesta400Bean();
			
			respuesta400Bean = utileriasAs400.consultaEmpleado(mantenimientoUsuariosUnificadoBean.getEmpleadoOrigenEje());
			
			if(respuesta400Bean.getMensajeId() != 2) {
				mensajeTransaccionBean.setNumeroMensaje(999);
				mensajeTransaccionBean.setDescripcionMensaje("NO FUE POSIBLE REALIZAR EL CAMBIO DEL EMPLEADO: "+mantenimientoUsuariosUnificadoBean.getEmpleadoOrigenEje()+" DEBIDO A QUE NO SE ENCUENTRA ACTIVO EN CREDIMAX.");
				return mensajeTransaccionBean;
			}
			
			respuesta400Bean = utileriasAs400.consultaEmpleado(mantenimientoUsuariosUnificadoBean.getEmpleadoDestinoEje());
			
			if(respuesta400Bean.getMensajeId() == 0) {
				mensajeTransaccionBean.setNumeroMensaje(999);
				mensajeTransaccionBean.setDescripcionMensaje("NO FUE POSIBLE REALIZAR EL CAMBIO DEL EMPLEADO: "+mantenimientoUsuariosUnificadoBean.getEmpleadoOrigenEje()+" DEBIDO A QUE NO EXISTE EN CREDIMAX.");
				return mensajeTransaccionBean;
			}
			
			respuesta400Bean = utileriasAs400.bajaXSustitucion(mantenimientoUsuariosUnificadoBean.getEmpleadoOrigenEje(), mantenimientoUsuariosUnificadoBean.getEmpleadoDestinoEje(), mantenimientoUsuariosUnificadoBean.getEmpleadoOpera());
			
			if(respuesta400Bean.getCodigo() != Constantes.exito) {
				mensajeTransaccionBean.setNumeroMensaje(Constantes.error);
				mensajeTransaccionBean.setDescripcionMensaje("NO FUE POSIBLE REALIZAR EL CAMBIO DEL EMPLEADO :"+mantenimientoUsuariosUnificadoBean.getEmpleadoDestinoEje()+" EN CREDIMAX DEBIDO A QUE:"+respuesta400Bean.getMensaje());
				return mensajeTransaccionBean;
			}
			
			mensajeTransaccionBean = mantenimientoUsuariosUnificadoDAO.bajaxSustitucion(mantenimientoUsuariosUnificadoBean);
			
			if(mensajeTransaccionBean.getNumeroMensaje() != Constantes.exito) {
				mensajeTransaccionBean.setDescripcionMensaje("NO FUE POSIBLE REALIZAR LA BAJA X SUSTITUCION DEL EMPLEADO: "+mantenimientoUsuariosUnificadoBean.getEmpleadoOrigenEje()+" DEBIDO A: "+mensajeTransaccionBean.getDescripcionMensaje());
			}else {
				mensajeTransaccionBean.setDescripcionMensaje("SE REALIZO EXITOSAMENTE LA BAJA X SUSTITUCION DE EMPLEADO: "+mantenimientoUsuariosUnificadoBean.getEmpleadoOrigenEje()+" POR EL EMPLEADO: "+mantenimientoUsuariosUnificadoBean.getEmpleadoDestinoEje());
			}
			return mensajeTransaccionBean;
		}
		
		mensajeTransaccionBean = mantenimientoUsuariosUnificadoDAO.bajaxSustitucion(mantenimientoUsuariosUnificadoBean);
		
		if(mensajeTransaccionBean.getNumeroMensaje() != Constantes.exito) {
			mensajeTransaccionBean.setDescripcionMensaje("NO FUE POSIBLE REALIZAR LA BAJA X SUSTITUCION DEL EMPLEADO: "+mantenimientoUsuariosUnificadoBean.getEmpleadoOrigenEje()+" DEBIDO A: "+mensajeTransaccionBean.getDescripcionMensaje());
		}else {
			mensajeTransaccionBean.setDescripcionMensaje("SE REALIZO EXITOSAMENTE LA BAJA X SUSTITUCION DE EMPLEADO: "+mantenimientoUsuariosUnificadoBean.getEmpleadoOrigenEje()+" POR EL EMPLEADO: "+mantenimientoUsuariosUnificadoBean.getEmpleadoDestinoEje());
		}
		
		return mensajeTransaccionBean;
	}
	
	public MensajeTransaccionBean cambioEmpleado(MantenimientoUsuariosUnificadoBean mantenimientoUsuariosUnificadoBean) {
		MensajeTransaccionBean mensajeTransaccionBean = new MensajeTransaccionBean();
		CatalogoBean puestoReplica	=	consultaSubItem(Catalogos.puestosReplican400, mantenimientoUsuariosUnificadoBean.getSegmentoDestinoCE());
		
		Respuesta400Bean respuesta400Bean = new Respuesta400Bean();
//		int funcionDestino	=	0;
		Empleado empleado = null;
		
		if(puestoReplica.getDescCorta().equals(Constantes.activo)) {
			respuesta400Bean = utileriasAs400.consultaEmpleado(mantenimientoUsuariosUnificadoBean.getEmpleadoOrigenCE());
			int regionalCredimax	=	Integer.parseInt(consultaSubItem(Catalogos.geografiasCredimax, mantenimientoUsuariosUnificadoBean.getDepartamentoOperar()).getDescCorta());
			
			if(respuesta400Bean.getMensajeId() != Constantes.empleadoActivo) {
				mensajeTransaccionBean.setNumeroMensaje(Constantes.error);
				mensajeTransaccionBean.setDescripcionMensaje("NO ES POSIBLE REALIZAR EL CAMBIO DEL EMPLEADO: "+mantenimientoUsuariosUnificadoBean.getEmpleadoOrigenCE()+" POR INCONSISTENCIAS EN LA PLANTILLA, YA QUE EN LA UNIFICADA ESTA DADO DE ALTA Y EN CREDIMAX SE ENCUENTRA DADO DE BAJA.");
				return mensajeTransaccionBean;
			}
			
			if(regionalCredimax != respuesta400Bean.getGeografia()) {
				mensajeTransaccionBean.setNumeroMensaje(Constantes.error);
				mensajeTransaccionBean.setDescripcionMensaje("NO ES POSIBLE REALIZAR EL CAMBIO DEL EMPLEADO: "+mantenimientoUsuariosUnificadoBean.getEmpleadoOrigenCE()+" YA QUE LA GEOGRAFIA EN LA UNIFICADA ES: "+regionalCredimax+" Y EN CREDIMAX ES: "+respuesta400Bean.getGeografia());
				return mensajeTransaccionBean;
			}
			
			respuesta400Bean = utileriasAs400.consultaEmpleado(mantenimientoUsuariosUnificadoBean.getEmpleadoDestinoCE());
			
			if(respuesta400Bean.getMensajeId() != Constantes.empleadoActivo) {
				mensajeTransaccionBean.setNumeroMensaje(Constantes.error);
				mensajeTransaccionBean.setDescripcionMensaje("NO ES POSIBLE REALIZAR EL CAMBIO DEL EMPLEADO :"+mantenimientoUsuariosUnificadoBean.getEmpleadoDestinoCE()+" POR INCONSISTENCIAS EN LA PLANTILLA, YA QUE EN LA UNIFICADA ESTA DADO DE ALTA Y EN CREDIMAX SE ENCUENTRA DADO DE BAJA.");
				return mensajeTransaccionBean;
			}
						
			if(regionalCredimax != respuesta400Bean.getGeografia()) {
				mensajeTransaccionBean.setNumeroMensaje(Constantes.error);
				mensajeTransaccionBean.setDescripcionMensaje("NO ES POSIBLE REALIZAR EL CAMBIO DEL EMPLEADO: "+mantenimientoUsuariosUnificadoBean.getEmpleadoDestinoCE()+" YA QUE LA GEOGRAFIA EN LA UNIFICADA ES: "+regionalCredimax+" Y EN CREDIMAX ES: "+respuesta400Bean.getGeografia());
				return mensajeTransaccionBean;
			}
			
		}

		empleado = datosEmpleado.consultaEmpleadoSap(mantenimientoUsuariosUnificadoBean.getEmpleadoOrigenCE().trim());
		
		SimpleBean validaFnSap	=	mantenimientoUsuariosUnificadoDAO.validaFuncionSap(mantenimientoUsuariosUnificadoBean.getSegmentoDestinoCE(), Integer.parseInt(empleado.getIdFuncion()));
		
		if(validaFnSap.getCodigo() != Constantes.exito) {
			mensajeTransaccionBean.setNumeroMensaje(Constantes.error);
			mensajeTransaccionBean.setDescripcionMensaje("NO ES POSIBLE REALIZAR EL CAMBIO DEL EMPLEADO :"+mantenimientoUsuariosUnificadoBean.getEmpleadoOrigenCE()+" YA QUE CUENTA CON UNA FUNCION SAP:"+empleado.getIdFuncion()+" Y SE REQUIERE UNA FUNCION SAP:"+validaFnSap.getDescripcion());
			return mensajeTransaccionBean;
		}

		mensajeTransaccionBean = bajaEmpleado(mantenimientoUsuariosUnificadoBean);
		String msgBaja = mensajeTransaccionBean.getDescripcionMensaje();
		
		if (mensajeTransaccionBean.getNumeroMensaje() != Constantes.exito) {
			return mensajeTransaccionBean;
		}
		mantenimientoUsuariosUnificadoBean.setEmpleadoOrigenEje(mantenimientoUsuariosUnificadoBean.getEmpleadoDestinoCE());
		mantenimientoUsuariosUnificadoBean.setEmpleadoDestinoEje(mantenimientoUsuariosUnificadoBean.getEmpleadoOrigenCE());
		mantenimientoUsuariosUnificadoBean.setPuestoOrigenBS(mantenimientoUsuariosUnificadoBean.getPuestoDestinoCE());
		mantenimientoUsuariosUnificadoBean.setPuestoDestinoBS(mantenimientoUsuariosUnificadoBean.getPuestoDestinoCE());
		
		mensajeTransaccionBean = mantenimientoUsuariosUnificadoDAO.validaBajaxSustitucion(mantenimientoUsuariosUnificadoBean);
		
		if(mensajeTransaccionBean.getNumeroMensaje() != Constantes.exito) {
			mensajeTransaccionBean.setNumeroMensaje(Constantes.error);
			if(msgBaja.contains("Y EN SU LUGAR QUEDO EL EMPLEADO")) {
				mensajeTransaccionBean.setDescripcionMensaje(msgBaja+" SIN EMBARGO NO FUE POSIBLE REALIZAR EL CAMBIO POR EL EMPLEADO: "+mensajeTransaccionBean.getDescripcionMensaje()+" POR EL SIGUIENTE MOTIVO: "+mensajeTransaccionBean.getDescripcionMensaje());

			}else {
				mensajeTransaccionBean.setDescripcionMensaje("SE REALIZO LA BAJA DEL EMPLEADO :"+mantenimientoUsuariosUnificadoBean.getEmpleadoOrigenCE()+" SIN EMBARGO NO FUE POSIBLE REALIZAR EL CAMBIO POR EL EMPLEADO: "+mensajeTransaccionBean.getDescripcionMensaje()+" POR EL SIGUIENTE MOTIVO: "+mensajeTransaccionBean.getDescripcionMensaje());
			}
			return mensajeTransaccionBean;
		}
		
		if(puestoReplica.getDescCorta().equals(Constantes.activo)) {
			respuesta400Bean = utileriasAs400.bajaXSustitucion(mantenimientoUsuariosUnificadoBean.getEmpleadoOrigenEje(), mantenimientoUsuariosUnificadoBean.getEmpleadoDestinoEje(), mantenimientoUsuariosUnificadoBean.getEmpleadoOpera());
			
			if (respuesta400Bean.getCodigo() != Constantes.exito) {
				mensajeTransaccionBean.setNumeroMensaje(Constantes.error);
				mensajeTransaccionBean.setDescripcionMensaje("NO FUE POSIBLE REALIZAR EL CAMBIO DEL EMPLEADO:"+mantenimientoUsuariosUnificadoBean.getEmpleadoOrigenEje()+" POR EL EMPLEADO:"+mantenimientoUsuariosUnificadoBean.getEmpleadoDestinoEje()+" EN CREDIMAX DEBIDO A QUE :"+respuesta400Bean.getMensaje());
				return mensajeTransaccionBean;
			}
			
			
			mensajeTransaccionBean = mantenimientoUsuariosUnificadoDAO.bajaxSustitucion(mantenimientoUsuariosUnificadoBean);
			
			if(mensajeTransaccionBean.getNumeroMensaje() != Constantes.exito) {
				mensajeTransaccionBean.setNumeroMensaje(Constantes.error);
				if(msgBaja.contains("Y EN SU LUGAR QUEDO EL EMPLEADO")) {
					mensajeTransaccionBean.setDescripcionMensaje(msgBaja+" SIN EMBARGO NO FUE POSIBLE REALIZAR EL CAMBIO POR EL EMPLEADO: "+mensajeTransaccionBean.getDescripcionMensaje()+" POR EL SIGUIENTE MOTIVO: "+mensajeTransaccionBean.getDescripcionMensaje());
				}else {
					mensajeTransaccionBean.setDescripcionMensaje("SE REALIZO LA BAJA DEL EMPLEADO :"+mantenimientoUsuariosUnificadoBean.getEmpleadoOrigenCE()+" SIN EMBARGO NO FUE POSIBLE REALIZAR EL CAMBIO POR EL EMPLEADO: "+mensajeTransaccionBean.getDescripcionMensaje()+" POR EL SIGUIENTE MOTIVO: "+mensajeTransaccionBean.getDescripcionMensaje());
				}
				return mensajeTransaccionBean;
			}else {
				mensajeTransaccionBean.setNumeroMensaje(0);
				if(msgBaja.contains("Y EN SU LUGAR QUEDO EL EMPLEADO")) {
					mensajeTransaccionBean.setDescripcionMensaje(msgBaja+" Y EL CAMBIO POR EL EMPLEADO: "+mantenimientoUsuariosUnificadoBean.getEmpleadoDestinoCE());
				}else {
					mensajeTransaccionBean.setDescripcionMensaje("SE REALIZO DE MANREA CORRECTA EL CAMBIO DEL EMPLEADO :"+mantenimientoUsuariosUnificadoBean.getEmpleadoDestinoCE()+" POR EL EMPLEADO: "+mantenimientoUsuariosUnificadoBean.getEmpleadoOrigenCE());
				}
				return mensajeTransaccionBean;
			}
		}
		
		mensajeTransaccionBean = mantenimientoUsuariosUnificadoDAO.bajaxSustitucion(mantenimientoUsuariosUnificadoBean);
		
		if(mensajeTransaccionBean.getNumeroMensaje() != Constantes.exito) {
			mensajeTransaccionBean.setNumeroMensaje(Constantes.error);
			if(msgBaja.contains("Y EN SU LUGAR QUEDO EL EMPLEADO")) {
				mensajeTransaccionBean.setDescripcionMensaje(msgBaja+" SIN EMBARGO NO FUE POSIBLE REALIZAR EL CAMBIO POR EL EMPLEADO: "+mensajeTransaccionBean.getDescripcionMensaje()+" POR EL SIGUIENTE MOTIVO: "+mensajeTransaccionBean.getDescripcionMensaje());
			}else {
				mensajeTransaccionBean.setDescripcionMensaje("SE REALIZO LA BAJA DEL EMPLEADO :"+mantenimientoUsuariosUnificadoBean.getEmpleadoOrigenCE()+" SIN EMBARGO NO FUE POSIBLE REALIZAR EL CAMBIO POR EL EMPLEADO: "+mensajeTransaccionBean.getDescripcionMensaje()+" POR EL SIGUIENTE MOTIVO: "+mensajeTransaccionBean.getDescripcionMensaje());
			}
		}else {
			if(msgBaja.contains("Y EN SU LUGAR QUEDO EL EMPLEADO")) {
				mensajeTransaccionBean.setDescripcionMensaje(msgBaja+" Y EL CAMBIO POR EL EMPLEADO: "+mantenimientoUsuariosUnificadoBean.getEmpleadoDestinoCE());
			}else {
				mensajeTransaccionBean.setDescripcionMensaje("SE REALIZO DE MANREA CORRECTA EL CAMBIO DEL EMPLEADO :"+mantenimientoUsuariosUnificadoBean.getEmpleadoDestinoCE()+" POR EL EMPLEADO: "+mantenimientoUsuariosUnificadoBean.getEmpleadoOrigenCE());
			}
		}
		
		return mensajeTransaccionBean;
	}
	
	
	private MantenimientoUsuariosUnificadoBean consultaCambioPuesto(MantenimientoUsuariosUnificadoBean mantenimientoUsuariosUnificadoBean) {
		mantenimientoUsuariosUnificadoBean.setDatosEmpleado(mantenimientoUsuariosUnificadoDAO.datosEmpleado(mantenimientoUsuariosUnificadoBean));
		
		if(mantenimientoUsuariosUnificadoBean.getEmpleadoConsulta().startsWith("00")) {
			mantenimientoUsuariosUnificadoBean.setEmpleados(new ArrayList<EmpleadosBean>());
			return mantenimientoUsuariosUnificadoBean;
		}
		
		Empleado	empleado = datosEmpleado.consultaEmpleadoSap(mantenimientoUsuariosUnificadoBean.getEmpleadoConsulta());
		int nuevoSeg	= 	0;
		int nuevoPues	=	0;
		try {
			nuevoSeg =	Integer.parseInt(consultaSubItem(Catalogos.equivalenciasSegmentos, Integer.parseInt(empleado.getIdFuncion())).getDescCorta());
			nuevoPues = Integer.parseInt(consultaSubItem(Catalogos.equivalenciasPuestos, nuevoSeg).getDescCorta());
		}catch (NullPointerException|NumberFormatException e) {
			nuevoSeg = 0;
			nuevoPues = 0;
		}
		
		mantenimientoUsuariosUnificadoBean.setNuevoSegmento(nuevoSeg);
		mantenimientoUsuariosUnificadoBean.setNuevoPuesto(nuevoPues);
		
		mantenimientoUsuariosUnificadoBean.setEmpleados(mantenimientoUsuariosUnificadoDAO.consultaEmpleadosCambio(mantenimientoUsuariosUnificadoBean));
		
		return mantenimientoUsuariosUnificadoBean;
	}
}