package com.bancoazteca.srcu.spring.servicios.administracion.mantenimientoUsuariosSap;

import java.util.List;

import com.bancoazteca.srcu.spring.beans.administracion.mantenimientoUsuariosSap.MantenimientoUsuariosSapBean;
import com.bancoazteca.srcu.spring.beans.administracion.personalActivo.VacantesSrcuBean;
import com.bancoazteca.srcu.spring.beans.sistema.MensajeTransaccionBean;
import com.bancoazteca.srcu.spring.beans.utilerias.SimpleBean;

public interface MantenimientoUsuariosSapServicio {
	public	MantenimientoUsuariosSapBean consulta(MantenimientoUsuariosSapBean mantenimientoUsuariosSapBean, int tipoOperacion);
	public	SimpleBean	consultaCentroCostos(int deptoId);
	public	List<VacantesSrcuBean> consultaVacantesSrcu(int deptoId, int tipoConsulta);
	public	MensajeTransaccionBean grabaTrasaccion(MantenimientoUsuariosSapBean mantenimientoUsuariosSapBean, int tipoOperacion);
}
