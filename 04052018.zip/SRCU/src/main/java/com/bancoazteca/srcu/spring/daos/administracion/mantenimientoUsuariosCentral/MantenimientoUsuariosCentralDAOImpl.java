package com.bancoazteca.srcu.spring.daos.administracion.mantenimientoUsuariosCentral;

import java.util.ArrayList;

import org.springframework.stereotype.Repository;

import com.bancoazteca.srcu.spring.beans.administracion.mantenimientoTelefonos.DatosEmpleadoBean;
import com.bancoazteca.srcu.spring.beans.administracion.mantenimientoUsuariosCentral.MantenimientoUsuariosCentralBean;
import com.bancoazteca.srcu.spring.beans.sistema.MensajeTransaccionBean;
import com.bancoazteca.srcu.spring.daos.utilerias.BaseDAO;

@Repository
public class MantenimientoUsuariosCentralDAOImpl extends BaseDAO implements MantenimientoUsuariosCentralDAO{
	
	public interface Enum_Funciones_MttoUsuariosCentralDAO{
		String consultaDatosEmpleado	=	"CONSULTA_GENERAL_DATOS_EMPLEADO";
		String reinicioContrasenia		=	"MTTO_USAURIOS_CENTRAL_REINICIO_CONTRASENIA";
		String desbloqueoUsuario		=	"MTTO_USUARIOS_CENTRAL_DESBLOQUEO_USUARIOS";
	}
	
	public interface Enum_Contantes_MttoUsuariosCentralDAO{
		int consultaDatosEmpleado		=	1;
		int exitoReinicioContrasenia	=	1;
		int error						= 	999;
		int exito						=	0;
		String errorDesbloqueoUsuario	=	"El empleado no esta bloqueado o no existe";
	}
	
	@Override
	public DatosEmpleadoBean consultaEmpleado(String numeroEmpleado) {
		DatosEmpleadoBean datosEmpleadoBean = new DatosEmpleadoBean();
		ArrayList<Object> parametros = new ArrayList<Object>();
		parametros.add(Enum_Contantes_MttoUsuariosCentralDAO.consultaDatosEmpleado);
		parametros.add(numeroEmpleado);
		
		datosEmpleadoBean = (DatosEmpleadoBean) ejecutaFuncion(Enum_Funciones_MttoUsuariosCentralDAO.consultaDatosEmpleado, parametros, datosEmpleadoBean.getClass());
		
		return datosEmpleadoBean;
	}

	@Override
	public MensajeTransaccionBean reiniciaContrasenia(MantenimientoUsuariosCentralBean mantenimientoUsuariosCentralBean) {
		MensajeTransaccionBean mensajeTransaccionBean = new MensajeTransaccionBean();
		ArrayList<Object> parametros = new ArrayList<Object>();
		parametros.add(mantenimientoUsuariosCentralBean.getNumeroEmpleado());
		parametros.add(mantenimientoUsuariosCentralBean.getNumeroEmpleado());
		parametros.add(mantenimientoUsuariosCentralBean.getDeptoSeleccionado());
		parametros.add(mantenimientoUsuariosCentralBean.getIp());
		
		mensajeTransaccionBean = (MensajeTransaccionBean) ejecutaFuncion(Enum_Funciones_MttoUsuariosCentralDAO.reinicioContrasenia, parametros, mensajeTransaccionBean.getClass());
			
		if(mensajeTransaccionBean.getMensajeId() == Enum_Contantes_MttoUsuariosCentralDAO.exitoReinicioContrasenia) {
			mensajeTransaccionBean.setNumeroMensaje(Enum_Contantes_MttoUsuariosCentralDAO.exito);
		}else {
			mensajeTransaccionBean.setNumeroMensaje(Enum_Contantes_MttoUsuariosCentralDAO.error);
		}
		
		return mensajeTransaccionBean;
	}

	@Override
	public MensajeTransaccionBean desbloqueaUsuario(MantenimientoUsuariosCentralBean mantenimientoUsuariosCentralBean) {
		MensajeTransaccionBean mensajeTransaccionBean = new MensajeTransaccionBean();
		ArrayList<Object> parametros = new ArrayList<Object>();
		parametros.add(mantenimientoUsuariosCentralBean.getNumeroEmpleado());
		
		mensajeTransaccionBean = (MensajeTransaccionBean) ejecutaFuncion(Enum_Funciones_MttoUsuariosCentralDAO.desbloqueoUsuario, parametros, mensajeTransaccionBean.getClass());
		
		if(mensajeTransaccionBean.getDescripcionMensaje().equalsIgnoreCase(Enum_Contantes_MttoUsuariosCentralDAO.errorDesbloqueoUsuario)) {
			mensajeTransaccionBean.setNumeroMensaje(Enum_Contantes_MttoUsuariosCentralDAO.error);
		}else {
			mensajeTransaccionBean.setNumeroMensaje(Enum_Contantes_MttoUsuariosCentralDAO.exito);
		}
		
		return mensajeTransaccionBean;
	}

}
