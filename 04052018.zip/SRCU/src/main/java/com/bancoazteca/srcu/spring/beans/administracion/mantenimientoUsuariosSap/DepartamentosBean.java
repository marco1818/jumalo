package com.bancoazteca.srcu.spring.beans.administracion.mantenimientoUsuariosSap;

import java.math.BigDecimal;

public class DepartamentosBean {
	private int	deptoId;
	private String descripcionDepto;
	private int tipodeptoId;
	private int deptoSuperiorId;
	private int paisId;
	private String jefeDepto;
	
	public DepartamentosBean() {
		
	}

	public int getDeptoId() {
		return deptoId;
	}

	public void setDeptoId(int deptoId) {
		this.deptoId = deptoId;
	}

	public void setDeptoId(BigDecimal deptoId) {
		this.deptoId = deptoId.intValue();
	}
	
	public String getDescripcionDepto() {
		return descripcionDepto;
	}

	public void setDescripcionDepto(String descripcionDepto) {
		this.descripcionDepto = descripcionDepto;
	}

	public int getTipodeptoId() {
		return tipodeptoId;
	}

	public void setTipodeptoId(int tipodeptoId) {
		this.tipodeptoId = tipodeptoId;
	}

	public void setTipodeptoId(BigDecimal tipodeptoId) {
		this.tipodeptoId = tipodeptoId.intValue();
	}
	
	public int getDeptoSuperiorId() {
		return deptoSuperiorId;
	}

	public void setDeptoSuperiorId(int deptoSuperiorId) {
		this.deptoSuperiorId = deptoSuperiorId;
	}

	public void setDeptoSuperiorId(BigDecimal deptoSuperiorId) {
		this.deptoSuperiorId = deptoSuperiorId.intValue();
	}
	
	public int getPaisId() {
		return paisId;
	}

	public void setPaisId(int paisId) {
		this.paisId = paisId;
	}

	public void setPaisId(BigDecimal paisId) {
		this.paisId = paisId.intValue();
	}
	
	public String getJefeDepto() {
		return jefeDepto;
	}

	public void setJefeDepto(String jefeDepto) {
		this.jefeDepto = jefeDepto;
	}
	
}
