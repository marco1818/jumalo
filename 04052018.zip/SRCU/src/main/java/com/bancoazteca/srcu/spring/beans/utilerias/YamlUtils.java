package com.bancoazteca.srcu.spring.beans.utilerias;

import java.util.List;

public class YamlUtils {
	List<Funcion> funciones;

	public List<Funcion> getFunciones() {
		return funciones;
	}

	public void setFunciones(List<Funcion> funciones) {
		this.funciones = funciones;
	}
	
}
