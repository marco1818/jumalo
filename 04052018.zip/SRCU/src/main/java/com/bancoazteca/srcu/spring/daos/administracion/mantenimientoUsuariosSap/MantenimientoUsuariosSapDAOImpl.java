package com.bancoazteca.srcu.spring.daos.administracion.mantenimientoUsuariosSap;

import java.util.ArrayList;
import java.util.List;
import org.springframework.stereotype.Repository;

import com.bancoazteca.srcu.spring.beans.administracion.mantenimientoTelefonos.DatosEmpleadoBean;
import com.bancoazteca.srcu.spring.beans.administracion.mantenimientoUsuariosSap.DepartamentosBean;
import com.bancoazteca.srcu.spring.beans.administracion.mantenimientoUsuariosSap.EmpleadosBean;
import com.bancoazteca.srcu.spring.beans.administracion.mantenimientoUsuariosSap.VacantesBean;
import com.bancoazteca.srcu.spring.beans.administracion.personalActivo.VacantesSrcuBean;
import com.bancoazteca.srcu.spring.beans.sistema.MensajeTransaccionBean;
import com.bancoazteca.srcu.spring.beans.utilerias.CatalogoBean;
import com.bancoazteca.srcu.spring.beans.utilerias.SimpleBean;
import com.bancoazteca.srcu.spring.daos.utilerias.BaseDAO;
import com.bancoazteca.srcu.spring.ws.administracion.posicionesSap.ParametrosWSBean;

@Repository
public class MantenimientoUsuariosSapDAOImpl extends BaseDAO implements MantenimientoUsuariosSapDAO{
	
	public interface Enum_Constantes_MantenimientoUsuariosSap{
		int	catPuestoAdmin			=	111;
		int	catPuestosGeografia		=	115;
		String	catIdioma			=	"ES";
		int	validacionxEliminacion	=	2;
		int	consultaEmpleado		=	1;
		int	exito					=	0;
		int	error					=	999;
	}
	
	public interface Enum_Fucniones_MantenimientoUsuariosSap{
		String	consultaCentroCosotos		= 	"CONSULTA_CENTRO_COSTOS_X_DEPTO";
		String	consultaVacantesSrcu		=	"CONSULTA_VACANTES_SRCU";
		String	consultaPuestoAdmin			=	"CONSULTA_CAT_UNICO_2";
		String	consultaPuestosGeografia	=	"CONSULTA_PUESTO_GEOGRAFICA";
		String 	consultaDatosGenerales		=	"CONSULTA_GENERAL_DATOS_EMPLEADO";
		String 	consultaDepartamentosOperar	=	"MTTO_USUARIOS_SAP_CONSULTA_DEPARTAMENTOS_ADMINISTRATIVOS";
		String 	consultaDepartamentosGeo	=	"MTTO_USUARIOS_SAP_CONSULTA_DEPARTAMENTOS_GEOGRAFIA";
		String	consultaEmpleadosOperar		=	"CONSULTA_EMPLEADOS_OPERAR_MTTO_USUARIOS_SAP";
		String	validaCreacionVacantes		=	"VALIDA_CREACION_VACANTES_X_CLIENTES_MTTO_USUARIOS";
		String	validaVacantesxEliminacion	=	"VALIDA_CREACION_VACANTES_X_ELIMINACION_MTTO_USUARIOS";
		String	consultaParamAltaPosiciones	=	"CONSULTA_PARAMETROS_ALTA_POSICIONES_SAP_WS";
		String	consultaVacanteDisponible	=	"MTTO_USUARIOS_SAP_CONSULTA_VACANTE_DISPONIBLE";
		String	registraMovimientoVacantes	=	"MTTO_USUARIOS_SAP_REGISTRA_MOVIMIENTO_VACANTES";
		String	altaEmpleado				=	"MTTO_USUARIOS_SAP_ALTA_EMPLEADO";
	}
	
	@Override
	public SimpleBean consultaCeco(int depto) {
		SimpleBean centroCostos	= new SimpleBean();
		ArrayList<Object> parametros = new ArrayList<Object>();
		parametros.add(depto);
		
		centroCostos = (SimpleBean) ejecutaFuncion(Enum_Fucniones_MantenimientoUsuariosSap.consultaCentroCosotos, parametros, centroCostos.getClass());
		
		return centroCostos;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<VacantesSrcuBean> consultaVacantesSrcu(int deptoId, int tipoConsulta) {
		List<VacantesSrcuBean> vacantes = new ArrayList<VacantesSrcuBean>();
		VacantesSrcuBean	vacantesSrcuBean = new VacantesSrcuBean();
		ArrayList<Object> parametros = new ArrayList<Object>();
		parametros.add(deptoId);
		parametros.add(tipoConsulta);
		
		vacantes = (List<VacantesSrcuBean>) ejecutaFuncionAll(Enum_Fucniones_MantenimientoUsuariosSap.consultaVacantesSrcu, parametros, vacantesSrcuBean.getClass());
		
		return vacantes;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<CatalogoBean> consultaPuestosAdministrativos() {
		List<CatalogoBean> puestosBean = new ArrayList<CatalogoBean>();
		ArrayList<Object> parametros = new  ArrayList<Object>();
		parametros.add(Enum_Constantes_MantenimientoUsuariosSap.catPuestoAdmin);
		parametros.add(Enum_Constantes_MantenimientoUsuariosSap.catIdioma);

		puestosBean = (List<CatalogoBean>) ejecutaFuncionAll(Enum_Fucniones_MantenimientoUsuariosSap.consultaPuestoAdmin, parametros, new CatalogoBean().getClass());
		
		return puestosBean;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<CatalogoBean> consultaPuestosGeografia(int puestoOperador) {
		List<CatalogoBean> puestosBean = new ArrayList<CatalogoBean>();
		ArrayList<Object> parametros = new  ArrayList<Object>();
		parametros.add(Enum_Constantes_MantenimientoUsuariosSap.catPuestosGeografia);
		parametros.add(puestoOperador);
		parametros.add(Enum_Constantes_MantenimientoUsuariosSap.catIdioma);

		puestosBean = (List<CatalogoBean>) ejecutaFuncionAll(Enum_Fucniones_MantenimientoUsuariosSap.consultaPuestosGeografia, parametros, new CatalogoBean().getClass());
		
		return puestosBean;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<DepartamentosBean> consultaDepartamentos(int puestoMovimiento, int pais, int puestoDelegado, String empleadoDelegado) {
		List<DepartamentosBean> departamentos = new ArrayList<DepartamentosBean>();
		ArrayList<Object> parametros = new  ArrayList<Object>();
		
		switch (puestoDelegado) {
		case 900:
		case 817:
		case 1201:
		case 1203:
		case 1204:
		case 1131:
		case 970:
			parametros.add(puestoMovimiento);
			parametros.add(pais);
			departamentos = (List<DepartamentosBean>) ejecutaFuncionAll(Enum_Fucniones_MantenimientoUsuariosSap.consultaDepartamentosOperar, parametros, new DepartamentosBean().getClass());
			break;

		default:
			parametros.add(puestoMovimiento);
			parametros.add(empleadoDelegado);
			departamentos = (List<DepartamentosBean>) ejecutaFuncionAll(Enum_Fucniones_MantenimientoUsuariosSap.consultaDepartamentosGeo, parametros, new DepartamentosBean().getClass());
			break;
		}
		
		
		
		
		return departamentos;
	}

	@Override
	public DatosEmpleadoBean consultaDatosEmpleado(String numeroEmpleado) {
		DatosEmpleadoBean datosEmpleadoBean = new DatosEmpleadoBean();
		ArrayList<Object> parametros = new ArrayList<Object>();
		parametros.add(Enum_Constantes_MantenimientoUsuariosSap.consultaEmpleado);
		parametros.add(numeroEmpleado);
		
		datosEmpleadoBean =	(DatosEmpleadoBean) ejecutaFuncion(Enum_Fucniones_MantenimientoUsuariosSap.consultaDatosGenerales, parametros, datosEmpleadoBean.getClass());
		
		return datosEmpleadoBean;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<EmpleadosBean> consultaEmpleados(int gerenciaId, int puestoId) {
		List<EmpleadosBean> empleados = new ArrayList<EmpleadosBean>();
		ArrayList<Object> parametros = new  ArrayList<Object>();
		parametros.add(gerenciaId);
		parametros.add(puestoId);
		parametros.add(0);
		
		empleados = (List<EmpleadosBean>) ejecutaFuncionAll(Enum_Fucniones_MantenimientoUsuariosSap.consultaEmpleadosOperar, parametros, new EmpleadosBean().getClass());
		
		for(int x=0;x<empleados.size();x++) {
			empleados.get(x).setEsVirtual(empleados.get(x).getNumeroEmpleado().startsWith("00")?1:0);
			
		}
		
		return empleados;
	}

	@Override
	public SimpleBean validaCreacionxClientes(int gerenciaId, int segmento) {
		SimpleBean validaCreacion = new SimpleBean();
		ArrayList<Object> parametros = new  ArrayList<Object>();
		parametros.add(segmento);
		parametros.add(gerenciaId);
		
		validaCreacion = (SimpleBean) ejecutaFuncion(Enum_Fucniones_MantenimientoUsuariosSap.validaCreacionVacantes, parametros, new SimpleBean().getClass());
		
		return validaCreacion;
	}

	@Override
	public SimpleBean validaCreacionxEliminacion(int gerenciaId, int segmento, String empleadoOpera) {
		SimpleBean validaCreacion = new SimpleBean();
		ArrayList<Object> parametros = new  ArrayList<Object>();
		parametros.add(gerenciaId);
		parametros.add(segmento);
		parametros.add(empleadoOpera);
		parametros.add(Enum_Constantes_MantenimientoUsuariosSap.validacionxEliminacion);
		validaCreacion = (SimpleBean) ejecutaFuncion(Enum_Fucniones_MantenimientoUsuariosSap.validaVacantesxEliminacion, parametros, new SimpleBean().getClass());
		
		return validaCreacion;
	}

	@Override
	public ParametrosWSBean consultaParametrosWS(int ceco, int funcionSAP) {
		ParametrosWSBean parametrosWSBean = new ParametrosWSBean();
		ArrayList<Object> parametros = new  ArrayList<Object>();
		parametros.add(4);
		parametros.add(funcionSAP);
		parametros.add(ceco);
		parametros.add("");
		parametros.add("");
		parametros.add("");
		parametros.add("");
		parametros.add("");
		parametros.add("");
		parametros.add("");
		parametros.add("");
		parametros.add("");
		parametros.add("");
		parametros.add("");
		parametros.add("");
		parametros.add("");
		parametros.add("");
		parametros.add("");
		parametros.add("");
		parametros.add("");
		parametros.add("");
		
		parametrosWSBean = (ParametrosWSBean) ejecutaFuncion(Enum_Fucniones_MantenimientoUsuariosSap.consultaParamAltaPosiciones, parametros, parametrosWSBean.getClass());
		
		return parametrosWSBean;
	}

	@Override
	public VacantesBean consultaVirtualDisponible(int gerenciaId, int puestoAlta) {
		VacantesBean vacantesBean = new VacantesBean();
		ArrayList<Object> parametros = new  ArrayList<Object>();
		parametros.add(gerenciaId);
		parametros.add(puestoAlta);
		
		vacantesBean = (VacantesBean) ejecutaFuncion(Enum_Fucniones_MantenimientoUsuariosSap.consultaVacanteDisponible, parametros, vacantesBean.getClass());
		
		return vacantesBean;
	}

	@Override
	public SimpleBean registraMovimientoVacantes(String numeroPosicion, String empleadoVirtual, int estatus,
			String numeroEmpleado, String respuestaWS, String descripcionWS, String empleadoOpera, int tipoOperacion) {
		SimpleBean registraMovimientoVacantes = new SimpleBean();
		ArrayList<Object> parametros = new ArrayList<Object>();
		parametros.add(numeroPosicion);
		parametros.add(empleadoVirtual);
		parametros.add(estatus);
		parametros.add(numeroEmpleado);
		parametros.add(respuestaWS);
		parametros.add(descripcionWS);
		parametros.add(numeroPosicion);
		parametros.add(empleadoOpera);
		parametros.add(tipoOperacion);
		
		registraMovimientoVacantes = (SimpleBean) ejecutaFuncion(Enum_Fucniones_MantenimientoUsuariosSap.registraMovimientoVacantes, parametros, registraMovimientoVacantes.getClass());
		
		return registraMovimientoVacantes;
	}

	@Override
	public MensajeTransaccionBean altaEmpleado(String numeroEmpleado, int departamentoId, int puestoId, int plazaId,
			String nombreEmpleado, String empleadoOpera, int segmentoId) {
		MensajeTransaccionBean mensajeTransaccionBean = new MensajeTransaccionBean();
		
		ArrayList<Object> parametros = new ArrayList<Object>();
		parametros.add(numeroEmpleado);
		parametros.add(departamentoId);
		parametros.add(puestoId);
		parametros.add(plazaId);
		parametros.add(nombreEmpleado);
		parametros.add(empleadoOpera);
		parametros.add(segmentoId);
		
		mensajeTransaccionBean = (MensajeTransaccionBean) ejecutaFuncion(Enum_Fucniones_MantenimientoUsuariosSap.altaEmpleado, parametros, mensajeTransaccionBean.getClass());
		
		if(mensajeTransaccionBean.getDescripcionMensaje().contains("Empleado Dado De Alta Correctamente") || mensajeTransaccionBean.getDescripcionMensaje().contains("El Empleado Fue Actualizado Correctamente")) {
			mensajeTransaccionBean.setNumeroMensaje(Enum_Constantes_MantenimientoUsuariosSap.exito);
			mensajeTransaccionBean.setDescripcionMensaje("SE DIO DE ALTA CORRECTAMENTE AL EMPLEADO "+numeroEmpleado+"-"+nombreEmpleado+" EN EL DEPARTAMENTO "+departamentoId);
		}else {
			mensajeTransaccionBean.setNumeroMensaje(Enum_Constantes_MantenimientoUsuariosSap.error);
			mensajeTransaccionBean.setDescripcionMensaje("OCURRIO UN DETALLE EN EL ALTA DEL EMPLEADO DEBIDO A: "+mensajeTransaccionBean.getDescripcionMensaje());
		}
		
		return mensajeTransaccionBean;
	}

}
