package com.bancoazteca.srcu.spring.controladores.administracion.mantenimientoUsuariosCentral;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.ModelAndView;

import com.bancoazteca.srcu.spring.beans.administracion.mantenimientoUsuariosCentral.MantenimientoUsuariosCentralBean;
import com.bancoazteca.srcu.spring.beans.sistema.MensajeTransaccionBean;
import com.bancoazteca.srcu.spring.beans.utilerias.DatosSessionStruts;
import com.bancoazteca.srcu.spring.servicios.administracion.mantenimientoUsuariosCentral.MantenimientoUsuariosCentralServicio;

@Controller
public class MantenimientoUsuariosCentralControlador {
	
	@Autowired
	private MantenimientoUsuariosCentralServicio mantenimientoUsuariosCentralServicio;
	
	@InitBinder
	public void InitBinder(WebDataBinder webDataBinder, WebRequest webRequest) {
		webDataBinder.setDisallowedFields("");
	}
	
	@RequestMapping(value= {"/mantenimientoUsuariosCentralSRCU.htm"}, method=RequestMethod.GET)
	public ModelAndView mantenimientoUsuariosCentral(@ModelAttribute("datosSessionStruts")DatosSessionStruts datosSessionStruts) {
		ModelAndView modelAndView = new ModelAndView();
		MantenimientoUsuariosCentralBean mantenimientoUsuariosCentralBean = new MantenimientoUsuariosCentralBean();
		mantenimientoUsuariosCentralBean.setEmpleadoOpera(datosSessionStruts.getNumeroEmpleado());
		mantenimientoUsuariosCentralBean.setDeptoSeleccionado(datosSessionStruts.getGerenciaId());
		modelAndView.setViewName("administracion/mantenimientoUsuariosCentral/mantenimientoUsuariosCentral");
		modelAndView.addObject("mantenimientoUsuariosCentralBean",mantenimientoUsuariosCentralBean);
		return modelAndView;
	}
	
	@RequestMapping(value= {"/mantenimientoUsuariosCentral.htm"}, method= RequestMethod.POST)
	public ModelAndView mantenimientoUsuariosCentral(@ModelAttribute("mantenimientoUsuariosCentralBean")MantenimientoUsuariosCentralBean mantenimientoUsuariosCentralBean, @RequestParam("tipoOperacion") int tipoOperacion) {
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("sistema/resultadoTransaccion");
		
		MensajeTransaccionBean mensajeTransaccionBean = mantenimientoUsuariosCentralServicio.grabaTransaccion(mantenimientoUsuariosCentralBean, tipoOperacion);
		
		modelAndView.addObject("mensajeTransaccionBean",mensajeTransaccionBean);
		
		return modelAndView;
	}
	
}
