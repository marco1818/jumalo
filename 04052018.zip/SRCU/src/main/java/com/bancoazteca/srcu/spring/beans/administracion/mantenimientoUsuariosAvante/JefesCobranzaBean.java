package com.bancoazteca.srcu.spring.beans.administracion.mantenimientoUsuariosAvante;

import java.math.BigDecimal;

public class JefesCobranzaBean {
	private	String	numeroEmpleado;
	private	String	nombreEmpleado;
	private	String	segmento;
	private String	descripcionSegmento;
	private	int	clientesFocoFraude;
	private	BigDecimal saldo;
	private BigDecimal saldoAtrasado;
	private	BigDecimal moratorios;
	private	String especialistaAsignado;
	private int pagosParciales;
	private int pagosNoAbonados;
	
	public JefesCobranzaBean() {
		
	}

	public String getNumeroEmpleado() {
		return numeroEmpleado;
	}

	public void setNumeroEmpleado(String numeroEmpleado) {
		this.numeroEmpleado = numeroEmpleado;
	}

	public String getNombreEmpleado() {
		return nombreEmpleado;
	}

	public void setNombreEmpleado(String nombreEmpleado) {
		this.nombreEmpleado = nombreEmpleado;
	}
	
	public String getSegmento() {
		return segmento;
	}

	public void setSegmento(String segmento) {
		this.segmento = segmento;
	}

	public int getClientesFocoFraude() {
		return clientesFocoFraude;
	}

	public void setClientesFocoFraude(int clientesFocoFraude) {
		this.clientesFocoFraude = clientesFocoFraude;
	}

	public void setClientesFocoFraude(BigDecimal clientesFocoFraude) {
		this.clientesFocoFraude = clientesFocoFraude.intValue();
	}
	
	public BigDecimal getSaldo() {
		return saldo;
	}

	public void setSaldo(BigDecimal saldo) {
		this.saldo = saldo;
	}

	public BigDecimal getSaldoAtrasado() {
		return saldoAtrasado;
	}

	public void setSaldoAtrasado(BigDecimal saldoAtrasado) {
		this.saldoAtrasado = saldoAtrasado;
	}
	
	public BigDecimal getMoratorios() {
		return moratorios;
	}

	public void setMoratorios(BigDecimal moratorios) {
		this.moratorios = moratorios;
	}

	public String getEspecialistaAsignado() {
		return especialistaAsignado;
	}

	public void setEspecialistaAsignado(String especialistaAsignado) {
		this.especialistaAsignado = especialistaAsignado;
	}

	public String getDescripcionSegmento() {
		return descripcionSegmento;
	}

	public void setDescripcionSegmento(String descripcionSegmento) {
		this.descripcionSegmento = descripcionSegmento;
	}

	public int getPagosParciales() {
		return pagosParciales;
	}

	public void setPagosParciales(int pagosParciales) {
		this.pagosParciales = pagosParciales;
	}

	public void setPagosParciales(BigDecimal pagosParciales) {
		this.pagosParciales = pagosParciales.intValue();
	}

	public int getPagosNoAbonados() {
		return pagosNoAbonados;
	}

	public void setPagosNoAbonados(int pagosNoAbonados) {
		this.pagosNoAbonados = pagosNoAbonados;
	}
	
	public void setPagosNoAbonados(BigDecimal pagosNoAbonados) {
		this.pagosNoAbonados = pagosNoAbonados.intValue();
	}
}
