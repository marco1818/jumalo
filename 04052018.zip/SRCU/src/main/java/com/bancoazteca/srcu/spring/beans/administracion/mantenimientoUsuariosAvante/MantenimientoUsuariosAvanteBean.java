package com.bancoazteca.srcu.spring.beans.administracion.mantenimientoUsuariosAvante;

import java.util.List;

import com.bancoazteca.srcu.spring.beans.utilerias.BaseBean;

public class MantenimientoUsuariosAvanteBean extends BaseBean{
	private	String empleadoOpera;
	private int puestoOperar;
	private int departamentoOperar;
	private	String jefeOperar;
	private String empleadoAlta;
	private String nombreEmpleadoAlta;
	private List<PuestosAvanteBean> puestosAlta;
	private List<DepartamentosAvanteBean> departamentosAlta;
	private List<EmpleadosAvanteBean> jefesAvante;
	private List<EmpleadosAvanteBean> empleadosAvante;
	private String empleadoBaja;
	
	public MantenimientoUsuariosAvanteBean() {
		
	}

	public String getEmpleadoOpera() {
		return empleadoOpera;
	}

	public void setEmpleadoOpera(String empleadoOpera) {
		this.empleadoOpera = empleadoOpera;
	}

	public int getPuestoOperar() {
		return puestoOperar;
	}

	public void setPuestoOperar(int puestoOperar) {
		this.puestoOperar = puestoOperar;
	}

	public int getDepartamentoOperar() {
		return departamentoOperar;
	}

	public void setDepartamentoOperar(int departamentoOperar) {
		this.departamentoOperar = departamentoOperar;
	}
	
	public String getJefeOperar() {
		return jefeOperar;
	}

	public void setJefeOperar(String jefeOperar) {
		this.jefeOperar = jefeOperar;
	}

	public String getEmpleadoAlta() {
		return empleadoAlta;
	}

	public void setEmpleadoAlta(String empleadoAlta) {
		this.empleadoAlta = empleadoAlta;
	}

	public String getNombreEmpleadoAlta() {
		return nombreEmpleadoAlta;
	}

	public void setNombreEmpleadoAlta(String nombreEmpleadoAlta) {
		this.nombreEmpleadoAlta = nombreEmpleadoAlta;
	}

	public List<PuestosAvanteBean> getPuestosAlta() {
		return puestosAlta;
	}

	public void setPuestosAlta(List<PuestosAvanteBean> puestosAlta) {
		this.puestosAlta = puestosAlta;
	}

	public List<DepartamentosAvanteBean> getDepartamentosAlta() {
		return departamentosAlta;
	}

	public void setDepartamentosAlta(List<DepartamentosAvanteBean> departamentosAlta) {
		this.departamentosAlta = departamentosAlta;
	}
	
	public List<EmpleadosAvanteBean> getJefesAvante() {
		return jefesAvante;
	}

	public void setJefesAvante(List<EmpleadosAvanteBean> jefesAvante) {
		this.jefesAvante = jefesAvante;
	}

	public List<EmpleadosAvanteBean> getEmpleadosAvante() {
		return empleadosAvante;
	}

	public void setEmpleadosAvante(List<EmpleadosAvanteBean> empleadosAvante) {
		this.empleadosAvante = empleadosAvante;
	}

	public String getEmpleadoBaja() {
		return empleadoBaja;
	}

	public void setEmpleadoBaja(String empleadoBaja) {
		this.empleadoBaja = empleadoBaja;
	}
	
}
