package com.bancoazteca.srcu.spring.daos.administracion.mantenimientoUsuariosUnificado;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.bancoazteca.srcu.spring.beans.administracion.mantenimientoTelefonos.DatosEmpleadoBean;
import com.bancoazteca.srcu.spring.beans.administracion.mantenimientoUsuariosUnificado.DepartamentosBean;
import com.bancoazteca.srcu.spring.beans.administracion.mantenimientoUsuariosUnificado.EmpleadosBean;
import com.bancoazteca.srcu.spring.beans.administracion.mantenimientoUsuariosUnificado.MantenimientoUsuariosUnificadoBean;
import com.bancoazteca.srcu.spring.beans.administracion.mantenimientoUsuariosUnificado.PuestoBean;
import com.bancoazteca.srcu.spring.beans.administracion.mantenimientoUsuariosUnificado.VacantesxPuestoBean;
import com.bancoazteca.srcu.spring.beans.sistema.MensajeTransaccionBean;
import com.bancoazteca.srcu.spring.beans.utilerias.SimpleBean;
import com.bancoazteca.srcu.spring.daos.utilerias.BaseDAO;

@Repository
public class MantenimientoUsuariosUnificadoDaoImpl extends BaseDAO implements MantenimientoUsuariosUnificadoDAO{

	private interface Funciones{
		String	consultaPuestosPermitidos	=	"MTTO_USUARIOS_UNIFICADO_CONTROL_PUESTOS";
		String	altaEmpleado				=	"MTTO_USUARIOS_UNIFICADO_ALTA_EMPLEADO";
		String 	bajaEmpleado				=	"MTTO_USUARIOS_UNIFICADO_BAJA_EMPLEADO";
		String	bajaxSustitucion			=	"MTTO_USUARIOS_UNIFICADO_BAJA_X_SUSTITUCION";
		String	consultaVirtual				=	"MTTO_USUARIOS_UNIFICADO_CONSULTA_VIRTUAL";
		String	validaBajaEmpleado			=	"MTTO_USUARIOS_UNIFICADO_VALIDA_BAJA_EMPLEADO";
		String	validaAltaEmpleado			=	"MTTO_USUARIOS_UNIFICADO_VALIDA_ALTA_EMPLEADO";
		String	validaBajaxSustitucion		=	"MTTO_USUARIOS_UNIFICADO_VALIDA_BAJA_X_SUSTITUCION";
		String	consultaDepartamentosAdmon	=	"MTTO_USUARIOS_UNIFICADO_CONSULTA_DEPARTAMENTOS_ADMON";
		String	consultaDepartamentosGeo	=	"MTTO_USUARIOS_UNIFICADO_CONSULTA_DEPARTAMENTOS_GEO";
		String	consultaEmpleados			=	"MTTO_USUARIOS_UNIFICADO_CONSULTA_EMPLEADOS";
		String	consultaJefeOracle			=	"MTTO_USUARIOS_UNIFICADO_CONSULTA_JEFE_ORACLE";
		String	consultaVacantesxPuesto		=	"MTTO_USUARIOS_UNIFICADO_CONSULTA_VACANTES_X_PUESTO";	
		String 	consultaDatosGenerales		=	"CONSULTA_GENERAL_DATOS_EMPLEADO";
		String	consultaEmpleadosxPuesto	=	"MTTO_USUARIOS_UNIFICADO_CONSULTA_EMPLEADOS_X_PUESTO_SEGMENTO";
		String	paisxGerencia				=	"GENERAL_PAIS_X_GERENCIA";
		String	validaFuncionSap			=	"MTTO_USUARIOS_UNIFICADO_VALIDA_FUNCION_SAP";
	}	
	
	private interface Constantes{
		int		exito	=	0;
	}
	
	
	@SuppressWarnings("unchecked")
	@Override
	public List<PuestoBean> consultaPuestosOperar(MantenimientoUsuariosUnificadoBean mantenimientoUsuariosUnificadoBean) {
		List<PuestoBean> puestos = new ArrayList<PuestoBean>();
		ArrayList<Object> parametros = new ArrayList<Object>();
		parametros.add(mantenimientoUsuariosUnificadoBean.getEmpleadoOpera());
		
		puestos = (List<PuestoBean>) ejecutaFuncionAll(Funciones.consultaPuestosPermitidos, parametros, new PuestoBean().getClass());
		
		return puestos;
	}

	@Override
	public MensajeTransaccionBean altaEmpleado(MantenimientoUsuariosUnificadoBean mantenimientoUsuariosUnificadoBean) {
		
		int puestoAlta 		= 	mantenimientoUsuariosUnificadoBean.getSegmentoOperar() ==4 || mantenimientoUsuariosUnificadoBean.getSegmentoOperar() == 44?110:mantenimientoUsuariosUnificadoBean.getPuestoOperar();
		int segmentoAlta	=	mantenimientoUsuariosUnificadoBean.getSegmentoOperar()>=119?0:mantenimientoUsuariosUnificadoBean.getSegmentoOperar();
		
		MensajeTransaccionBean mensajeTransaccionBean = new MensajeTransaccionBean();
		ArrayList<Object> parametros = new ArrayList<Object>();
		parametros.add(mantenimientoUsuariosUnificadoBean.getEmpleadoAlta());
		parametros.add(mantenimientoUsuariosUnificadoBean.getDepartamentoOperar());
		parametros.add(puestoAlta);
		parametros.add(mantenimientoUsuariosUnificadoBean.getPlazaId());
		parametros.add(mantenimientoUsuariosUnificadoBean.getNombreEmpleadoAlta());
		parametros.add(mantenimientoUsuariosUnificadoBean.getEmpleadoOpera());
		parametros.add(segmentoAlta);
		
		mensajeTransaccionBean = (MensajeTransaccionBean) ejecutaFuncion(Funciones.altaEmpleado, parametros, mensajeTransaccionBean.getClass());
		
		if(	mensajeTransaccionBean.getDescripcionMensaje().equalsIgnoreCase("Empleado Dado De Alta Correctamente") 
				|| mensajeTransaccionBean.getDescripcionMensaje().equalsIgnoreCase("El Empleado Fue Actualizado Correctamente")) {
			mensajeTransaccionBean.setNumeroMensaje(0);
			mensajeTransaccionBean.setDescripcionMensaje("SE DIO DE ALTA CORRECTAMENTE AL EMPLEADO: "+mantenimientoUsuariosUnificadoBean.getEmpleadoAlta()+"-"+mantenimientoUsuariosUnificadoBean.getNombreEmpleadoAlta()+" EN EL DEPARTAMENTO: "+mantenimientoUsuariosUnificadoBean.getDepartamentoOperar());
		}else {
			mensajeTransaccionBean.setNumeroMensaje(999);
			mensajeTransaccionBean.setDescripcionMensaje("OCURRIO UN DETALLE EN EL ALTA DEL EMPLEADO DEBIDO A: "+mensajeTransaccionBean.getDescripcionMensaje());
		}
		
		return mensajeTransaccionBean;
	}

	@Override
	public MensajeTransaccionBean consultaVacante(String numeroEmpleado) {
		MensajeTransaccionBean mensajeTransaccionBean = new MensajeTransaccionBean();
		ArrayList<Object> parametros = new ArrayList<Object>();
		parametros.add(numeroEmpleado);
		
		mensajeTransaccionBean = (MensajeTransaccionBean) ejecutaFuncion(Funciones.consultaVirtual, parametros, mensajeTransaccionBean.getClass());
		
		if(mensajeTransaccionBean.getMensajeId() == Constantes.exito) {
			mensajeTransaccionBean.setNumeroMensaje(0);
		}else {
			mensajeTransaccionBean.setNumeroMensaje(999);
		}
		
		return mensajeTransaccionBean;
	}

	@Override
	public MensajeTransaccionBean bajaEmpleado(MantenimientoUsuariosUnificadoBean mantenimientoUsuariosUnificadoBean) {
		MensajeTransaccionBean mensajeTransaccionBean = new MensajeTransaccionBean();
		int puestoBaja = 		mantenimientoUsuariosUnificadoBean.getSegmentoOperar() ==4 || mantenimientoUsuariosUnificadoBean.getSegmentoOperar() == 44?110:mantenimientoUsuariosUnificadoBean.getPuestoOperar();
		ArrayList<Object> parametros = new ArrayList<Object>();
		parametros.add(mantenimientoUsuariosUnificadoBean.getEmpleadoBaja());
		parametros.add(mantenimientoUsuariosUnificadoBean.getEmpleadoOpera());
		parametros.add(mantenimientoUsuariosUnificadoBean.getDepartamentoOperar());
		parametros.add(puestoBaja);
		parametros.add(mantenimientoUsuariosUnificadoBean.getPlazaId());
		
		mensajeTransaccionBean = (MensajeTransaccionBean) ejecutaFuncion(Funciones.bajaEmpleado, parametros, mensajeTransaccionBean.getClass());
		
		if(mensajeTransaccionBean.getDescripcionMensaje().equalsIgnoreCase("Empleado dado de baja satisfactoriamente.")) {
			mensajeTransaccionBean.setNumeroMensaje(0);
		}else {
			mensajeTransaccionBean.setNumeroMensaje(999);
		}
		
		return mensajeTransaccionBean;
	}

	@Override
	public MensajeTransaccionBean validaAltaEmpleado(MantenimientoUsuariosUnificadoBean mantenimientoUsuariosUnificadoBean) {
		MensajeTransaccionBean mensajeTransaccionBean = new MensajeTransaccionBean();
		int puestoAlta = 		mantenimientoUsuariosUnificadoBean.getSegmentoOperar() ==4 || mantenimientoUsuariosUnificadoBean.getSegmentoOperar() == 44?110:mantenimientoUsuariosUnificadoBean.getPuestoOperar();
		ArrayList<Object> parametros = new ArrayList<Object>();
		parametros.add(mantenimientoUsuariosUnificadoBean.getEmpleadoAlta());
		parametros.add(mantenimientoUsuariosUnificadoBean.getDepartamentoOperar());
		parametros.add(puestoAlta);
		
		mensajeTransaccionBean = (MensajeTransaccionBean) ejecutaFuncion(Funciones.validaAltaEmpleado, parametros, mensajeTransaccionBean.getClass());
		
		if(mensajeTransaccionBean.getDescripcionMensaje().contains("EL EMPLEADO SE PUEDE DAR DE ALTA")) {
			mensajeTransaccionBean.setNumeroMensaje(0);
		}else {
			mensajeTransaccionBean.setNumeroMensaje(999);
		}
		
		return mensajeTransaccionBean;
	}

	@Override
	public MensajeTransaccionBean validaBajaEmpleado(MantenimientoUsuariosUnificadoBean mantenimientoUsuariosUnificadoBean) {
		MensajeTransaccionBean mensajeTransaccionBean = new MensajeTransaccionBean();
		ArrayList<Object> parametros = new ArrayList<Object>();
		parametros.add(mantenimientoUsuariosUnificadoBean.getEmpleadoBaja());
		
		mensajeTransaccionBean = (MensajeTransaccionBean) ejecutaFuncion(Funciones.validaBajaEmpleado, parametros, mensajeTransaccionBean.getClass());
		
		if(mensajeTransaccionBean.getMensajeId() != Constantes.exito || mensajeTransaccionBean.getMensajeId() != 3 || mensajeTransaccionBean.getMensajeId() != 4) {
			mensajeTransaccionBean.setNumeroMensaje(0);
		}else {
			mensajeTransaccionBean.setNumeroMensaje(999);
		}
		
		return mensajeTransaccionBean;
	}

	@Override
	public MensajeTransaccionBean bajaxSustitucion(	MantenimientoUsuariosUnificadoBean mantenimientoUsuariosUnificadoBean) {
		MensajeTransaccionBean mensajeTransaccionBean = new MensajeTransaccionBean();
		ArrayList<Object> parametros = new ArrayList<Object>();
		parametros.add(mantenimientoUsuariosUnificadoBean.getEmpleadoOrigenEje());
		parametros.add(mantenimientoUsuariosUnificadoBean.getDepartamentoOperar());
		parametros.add(mantenimientoUsuariosUnificadoBean.getPuestoOrigenBS());
		parametros.add(mantenimientoUsuariosUnificadoBean.getEmpleadoDestinoEje());
		parametros.add(mantenimientoUsuariosUnificadoBean.getPuestoDestinoBS());
		parametros.add(mantenimientoUsuariosUnificadoBean.getDepartamentoOperar());
		parametros.add(mantenimientoUsuariosUnificadoBean.getEmpleadoOpera());
		
		mensajeTransaccionBean = (MensajeTransaccionBean) ejecutaFuncion(Funciones.bajaxSustitucion, parametros, mensajeTransaccionBean.getClass());
		
		if(mensajeTransaccionBean.getDescripcionMensaje().contains("Usuario sustituido satisfactoriamente.")
				||mensajeTransaccionBean.getDescripcionMensaje().contains("Operacion exitosa")) {
			mensajeTransaccionBean.setNumeroMensaje(0);
		}else {
			mensajeTransaccionBean.setNumeroMensaje(999);
		}
		
		return mensajeTransaccionBean;
	}

	@Override
	public MensajeTransaccionBean validaBajaxSustitucion(MantenimientoUsuariosUnificadoBean mantenimientoUsuariosUnificadoBean) {
		MensajeTransaccionBean mensajeTransaccionBean = new MensajeTransaccionBean();
		ArrayList<Object> parametros = new ArrayList<Object>();
		parametros.add(mantenimientoUsuariosUnificadoBean.getEmpleadoOrigenEje());
		parametros.add(mantenimientoUsuariosUnificadoBean.getDepartamentoOperar());
		parametros.add(mantenimientoUsuariosUnificadoBean.getPuestoOrigenBS());
		parametros.add(mantenimientoUsuariosUnificadoBean.getEmpleadoDestinoEje());
		parametros.add(mantenimientoUsuariosUnificadoBean.getPuestoDestinoBS());
		parametros.add(mantenimientoUsuariosUnificadoBean.getDepartamentoOperar());
		parametros.add(mantenimientoUsuariosUnificadoBean.getEmpleadoOpera());
		
		mensajeTransaccionBean = (MensajeTransaccionBean) ejecutaFuncion(Funciones.validaBajaxSustitucion, parametros, mensajeTransaccionBean.getClass());
		
		if(mensajeTransaccionBean.getDescripcionMensaje().contains("Usuario sustituido satisfactoriamente.")) {
			mensajeTransaccionBean.setNumeroMensaje(0);
		}else {
			mensajeTransaccionBean.setNumeroMensaje(999);
		}
		
		return mensajeTransaccionBean;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<DepartamentosBean> consultaDepartamentos(MantenimientoUsuariosUnificadoBean mantenimientoUsuariosUnificadoBean) {
		List<DepartamentosBean> departamentosBeans = new ArrayList<DepartamentosBean>();
		ArrayList<Object> parametros = new ArrayList<Object>();
		parametros.add(mantenimientoUsuariosUnificadoBean.getPuestoOperar());
		
		if(	mantenimientoUsuariosUnificadoBean.getPuestoOpera() == 900 	||	mantenimientoUsuariosUnificadoBean.getPuestoOpera() == 817 	||
			mantenimientoUsuariosUnificadoBean.getPuestoOpera() == 1201 ||	mantenimientoUsuariosUnificadoBean.getPuestoOpera() == 1203 ||
			mantenimientoUsuariosUnificadoBean.getPuestoOpera() == 1204 ||	mantenimientoUsuariosUnificadoBean.getPuestoOpera() == 1131 ||
			mantenimientoUsuariosUnificadoBean.getPuestoOpera() == 970) {
			parametros.add(1);
			departamentosBeans = (List<DepartamentosBean>) ejecutaFuncionAll(Funciones.consultaDepartamentosAdmon, parametros, new DepartamentosBean().getClass());
			
			for(int x=0; x < departamentosBeans.size(); x++) {
				departamentosBeans.get(x).setDescripcion(departamentosBeans.get(x).getDeptoDesc()+" / "+departamentosBeans.get(x).getJefe());
			}
			
		}else {
			parametros.add(mantenimientoUsuariosUnificadoBean.getEmpleadoOpera());
			departamentosBeans = (List<DepartamentosBean>) ejecutaFuncionAll(Funciones.consultaDepartamentosGeo, parametros, new DepartamentosBean().getClass());
		}
		
		return departamentosBeans;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<EmpleadosBean> consultaEmpleados(MantenimientoUsuariosUnificadoBean mantenimientoUsuariosUnificadoBean) {
		List<EmpleadosBean> empleados = new ArrayList<EmpleadosBean>();
		ArrayList<Object> parametros = new ArrayList<Object>();
		parametros.add(mantenimientoUsuariosUnificadoBean.getPuestoOperar());
		parametros.add(mantenimientoUsuariosUnificadoBean.getDepartamentoOperar());
		
		empleados = (List<EmpleadosBean>) ejecutaFuncionAll(Funciones.consultaEmpleados, parametros, new EmpleadosBean().getClass());
		
		return empleados;
	}

	@Override
	public EmpleadosBean consultaJefeOracle(MantenimientoUsuariosUnificadoBean mantenimientoUsuariosUnificadoBean) {
		EmpleadosBean	empleadosBean	= new EmpleadosBean();
		int puestoAlta = 		mantenimientoUsuariosUnificadoBean.getSegmentoOperar() ==4 || mantenimientoUsuariosUnificadoBean.getSegmentoOperar() == 44?110:mantenimientoUsuariosUnificadoBean.getPuestoOperar();
		ArrayList<Object> parametros = new ArrayList<Object>();
		parametros.add(mantenimientoUsuariosUnificadoBean.getDepartamentoOperar());
		parametros.add(puestoAlta);
		
		empleadosBean = (EmpleadosBean) ejecutaFuncion(Funciones.consultaJefeOracle, parametros, empleadosBean.getClass());
		
		return empleadosBean;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<VacantesxPuestoBean> consultaVacantesxPuesto(MantenimientoUsuariosUnificadoBean mantenimientoUsuariosUnificadoBean,int tipoConsulta) {
		List<VacantesxPuestoBean>	vacantesxPuesto	=	new ArrayList<VacantesxPuestoBean>();
		ArrayList<Object> parametros = new ArrayList<Object>();
		parametros.add(tipoConsulta);
		parametros.add(mantenimientoUsuariosUnificadoBean.getPuestoOperar());
		
		vacantesxPuesto = (List<VacantesxPuestoBean>) ejecutaFuncionAll(Funciones.consultaVacantesxPuesto, parametros, new VacantesxPuestoBean().getClass());
		
		return vacantesxPuesto;
	}

	@Override
	public DatosEmpleadoBean datosEmpleado(MantenimientoUsuariosUnificadoBean mantenimientoUsuariosUnificadoBean) {
		DatosEmpleadoBean empleadosBean = new DatosEmpleadoBean();
		ArrayList<Object> parametros = new ArrayList<Object>();
		parametros.add(1);
		parametros.add(mantenimientoUsuariosUnificadoBean.getEmpleadoConsulta());
		
		empleadosBean =	(DatosEmpleadoBean) ejecutaFuncion(Funciones.consultaDatosGenerales, parametros, empleadosBean.getClass());
		
		return empleadosBean;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<EmpleadosBean> consultaEmpleadosCambio(MantenimientoUsuariosUnificadoBean mantenimientoUsuariosUnificadoBean) {		
		List<EmpleadosBean>	empleados = new ArrayList<EmpleadosBean>();
		ArrayList<Object> parametros = new ArrayList<Object>();
		parametros.add(mantenimientoUsuariosUnificadoBean.getDepartamentoOperar());
		parametros.add(mantenimientoUsuariosUnificadoBean.getNuevoPuesto());
		parametros.add(mantenimientoUsuariosUnificadoBean.getNuevoSegmento());
		
		empleados = (List<EmpleadosBean>) ejecutaFuncionAll(Funciones.consultaEmpleadosxPuesto, parametros, new EmpleadosBean().getClass());
		
		return empleados;
	}

	@Override
	public SimpleBean paisxGerencia(int gerenciaId) {
		SimpleBean	simpleBean = new SimpleBean();
		ArrayList<Object> parametros = new ArrayList<Object>();
		parametros.add(gerenciaId);
		
		simpleBean = (SimpleBean) ejecutaFuncion(Funciones.paisxGerencia, parametros, simpleBean.getClass());
		
		return simpleBean;
	}

	@Override
	public SimpleBean validaFuncionSap(int segmentoId, int funcionSap) {
		SimpleBean	simpleBean = new SimpleBean();
		ArrayList<Object> parametros = new ArrayList<Object>();
		parametros.add(segmentoId);
		parametros.add(funcionSap);
		
		simpleBean = (SimpleBean) ejecutaFuncion(Funciones.validaFuncionSap, parametros, simpleBean.getClass());
		
		return simpleBean;
	}

}
