/**
 * Beneficiarios.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.bancoazteca.srcu.spring.ws.administracion.empleados.axis;

public class Beneficiarios  implements java.io.Serializable {

	private static final long serialVersionUID = 2812753810420841368L;

	private BeneficiariosEmpleado[] principales;

    private BeneficiariosEmpleado[] secundarios;

    private BeneficiariosEmpleado[] opcionales;

    public Beneficiarios() {
    }

    public Beneficiarios(
           BeneficiariosEmpleado[] principales,
           BeneficiariosEmpleado[] secundarios,
           BeneficiariosEmpleado[] opcionales) {
           this.principales = principales;
           this.secundarios = secundarios;
           this.opcionales = opcionales;
    }


    /**
     * Gets the principales value for this Beneficiarios.
     * 
     * @return principales
     */
    public BeneficiariosEmpleado[] getPrincipales() {
        return principales;
    }


    /**
     * Sets the principales value for this Beneficiarios.
     * 
     * @param principales
     */
    public void setPrincipales(BeneficiariosEmpleado[] principales) {
        this.principales = principales;
    }


    /**
     * Gets the secundarios value for this Beneficiarios.
     * 
     * @return secundarios
     */
    public BeneficiariosEmpleado[] getSecundarios() {
        return secundarios;
    }


    /**
     * Sets the secundarios value for this Beneficiarios.
     * 
     * @param secundarios
     */
    public void setSecundarios(BeneficiariosEmpleado[] secundarios) {
        this.secundarios = secundarios;
    }


    /**
     * Gets the opcionales value for this Beneficiarios.
     * 
     * @return opcionales
     */
    public BeneficiariosEmpleado[] getOpcionales() {
        return opcionales;
    }


    /**
     * Sets the opcionales value for this Beneficiarios.
     * 
     * @param opcionales
     */
    public void setOpcionales(BeneficiariosEmpleado[] opcionales) {
        this.opcionales = opcionales;
    }

    private java.lang.Object __equalsCalc = null;
    @SuppressWarnings("unused")
	public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Beneficiarios)) return false;
        Beneficiarios other = (Beneficiarios) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.principales==null && other.getPrincipales()==null) || 
             (this.principales!=null &&
              java.util.Arrays.equals(this.principales, other.getPrincipales()))) &&
            ((this.secundarios==null && other.getSecundarios()==null) || 
             (this.secundarios!=null &&
              java.util.Arrays.equals(this.secundarios, other.getSecundarios()))) &&
            ((this.opcionales==null && other.getOpcionales()==null) || 
             (this.opcionales!=null &&
              java.util.Arrays.equals(this.opcionales, other.getOpcionales())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getPrincipales() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getPrincipales());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getPrincipales(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getSecundarios() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getSecundarios());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getSecundarios(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getOpcionales() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getOpcionales());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getOpcionales(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Beneficiarios.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Beneficiarios"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("principales");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Principales"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "BeneficiariosEmpleado"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "BeneficiariosEmpleado"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("secundarios");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Secundarios"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "BeneficiariosEmpleado"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "BeneficiariosEmpleado"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("opcionales");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Opcionales"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "BeneficiariosEmpleado"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "BeneficiariosEmpleado"));
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    @SuppressWarnings("rawtypes")
	public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    @SuppressWarnings("rawtypes")
	public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
