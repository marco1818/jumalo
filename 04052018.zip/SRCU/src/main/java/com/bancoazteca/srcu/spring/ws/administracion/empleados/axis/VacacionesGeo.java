/**
 * VacacionesGeo.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.bancoazteca.srcu.spring.ws.administracion.empleados.axis;
@SuppressWarnings({ "unused", "rawtypes", "serial" })
public class VacacionesGeo  implements java.io.Serializable {
    private int empleado;

    private int inicio;

    private int termino;

    private int CC;

    private int funcion;

    public VacacionesGeo() {
    }

    public VacacionesGeo(
           int empleado,
           int inicio,
           int termino,
           int CC,
           int funcion) {
           this.empleado = empleado;
           this.inicio = inicio;
           this.termino = termino;
           this.CC = CC;
           this.funcion = funcion;
    }


    /**
     * Gets the empleado value for this VacacionesGeo.
     * 
     * @return empleado
     */
    public int getEmpleado() {
        return empleado;
    }


    /**
     * Sets the empleado value for this VacacionesGeo.
     * 
     * @param empleado
     */
    public void setEmpleado(int empleado) {
        this.empleado = empleado;
    }


    /**
     * Gets the inicio value for this VacacionesGeo.
     * 
     * @return inicio
     */
    public int getInicio() {
        return inicio;
    }


    /**
     * Sets the inicio value for this VacacionesGeo.
     * 
     * @param inicio
     */
    public void setInicio(int inicio) {
        this.inicio = inicio;
    }


    /**
     * Gets the termino value for this VacacionesGeo.
     * 
     * @return termino
     */
    public int getTermino() {
        return termino;
    }


    /**
     * Sets the termino value for this VacacionesGeo.
     * 
     * @param termino
     */
    public void setTermino(int termino) {
        this.termino = termino;
    }


    /**
     * Gets the CC value for this VacacionesGeo.
     * 
     * @return CC
     */
    public int getCC() {
        return CC;
    }


    /**
     * Sets the CC value for this VacacionesGeo.
     * 
     * @param CC
     */
    public void setCC(int CC) {
        this.CC = CC;
    }


    /**
     * Gets the funcion value for this VacacionesGeo.
     * 
     * @return funcion
     */
    public int getFuncion() {
        return funcion;
    }


    /**
     * Sets the funcion value for this VacacionesGeo.
     * 
     * @param funcion
     */
    public void setFuncion(int funcion) {
        this.funcion = funcion;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof VacacionesGeo)) return false;
        VacacionesGeo other = (VacacionesGeo) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this.empleado == other.getEmpleado() &&
            this.inicio == other.getInicio() &&
            this.termino == other.getTermino() &&
            this.CC == other.getCC() &&
            this.funcion == other.getFuncion();
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += getEmpleado();
        _hashCode += getInicio();
        _hashCode += getTermino();
        _hashCode += getCC();
        _hashCode += getFuncion();
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(VacacionesGeo.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "VacacionesGeo"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("empleado");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Empleado"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("inicio");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Inicio"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("termino");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Termino"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CC");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "CC"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("funcion");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Funcion"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
