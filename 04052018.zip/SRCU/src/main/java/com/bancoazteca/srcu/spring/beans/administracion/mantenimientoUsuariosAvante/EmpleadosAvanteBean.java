package com.bancoazteca.srcu.spring.beans.administracion.mantenimientoUsuariosAvante;

import java.math.BigDecimal;

public class EmpleadosAvanteBean {
	private	String numeroEmpleado;
	private String nombreEmpleado;
	private int departamentoId;
	private String descripcionDepto;
	private int puestoId;
	private String descripcionPuesto;
	private String fechaAlta;
	
	public EmpleadosAvanteBean() {
		
	}

	public String getNumeroEmpleado() {
		return numeroEmpleado;
	}

	public void setNumeroEmpleado(String numeroEmpleado) {
		this.numeroEmpleado = numeroEmpleado;
	}

	public String getNombreEmpleado() {
		return nombreEmpleado;
	}

	public void setNombreEmpleado(String nombreEmpleado) {
		this.nombreEmpleado = nombreEmpleado;
	}

	public int getDepartamentoId() {
		return departamentoId;
	}

	public void setDepartamentoId(int departamentoId) {
		this.departamentoId = departamentoId;
	}

	public void setDepartamentoId(BigDecimal departamentoId) {
		this.departamentoId = departamentoId.intValue();
	}
	
	public int getPuestoId() {
		return puestoId;
	}

	public void setPuestoId(int puestoId) {
		this.puestoId = puestoId;
	}

	public void setPuestoId(BigDecimal puestoId) {
		this.puestoId = puestoId.intValue();
	}
	
	public String getDescripcionPuesto() {
		return descripcionPuesto;
	}

	public void setDescripcionPuesto(String descripcionPuesto) {
		this.descripcionPuesto = descripcionPuesto;
	}

	public String getFechaAlta() {
		return fechaAlta;
	}

	public void setFechaAlta(String fechaAlta) {
		this.fechaAlta = fechaAlta;
	}

	public String getDescripcionDepto() {
		return descripcionDepto;
	}

	public void setDescripcionDepto(String descripcionDepto) {
		this.descripcionDepto = descripcionDepto;
	}
	
}
