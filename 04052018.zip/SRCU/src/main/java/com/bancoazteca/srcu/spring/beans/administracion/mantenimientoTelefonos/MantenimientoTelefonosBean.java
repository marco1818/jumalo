package com.bancoazteca.srcu.spring.beans.administracion.mantenimientoTelefonos;

import java.math.BigDecimal;

public class MantenimientoTelefonosBean {
	private	String	numeroEmpleado;
	private String 	nombreEmpleado;
	private long	telefono;
	private String	correo;
	private int		token;
	private int 	caducidad;
	private int		existeRegistro;
	
	public MantenimientoTelefonosBean() {
		
	}

	public String getNumeroEmpleado() {
		return numeroEmpleado;
	}

	public void setNumeroEmpleado(String numeroEmpleado) {
		this.numeroEmpleado = numeroEmpleado;
	}

	public String getNombreEmpleado() {
		return nombreEmpleado;
	}

	public void setNombreEmpleado(String nombreEmpleado) {
		this.nombreEmpleado = nombreEmpleado;
	}

	public String getCorreo() {
		return correo;
	}

	public void setCorreo(String correo) {
		this.correo = correo;
	}

	public long getTelefono() {
		return telefono;
	}

	public void setTelefono(long telefono) {
		this.telefono = telefono;
	}

	public void setTelefono(BigDecimal telefono) {
		this.telefono = telefono.longValue();
	}
	
	public int getToken() {
		return token;
	}

	public void setToken(int token) {
		this.token = token;
	}

	public void setToken(BigDecimal token) {
		this.token = token.intValue();
	}
	
	public int getCaducidad() {
		return caducidad;
	}

	public void setCaducidad(int caducidad) {
		this.caducidad = caducidad;
	}
	
	public void setCaducidad(BigDecimal caducidad) {
		this.caducidad = caducidad.intValue();
	}

	public int getExisteRegistro() {
		return existeRegistro;
	}

	public void setExisteRegistro(int existeRegistro) {
		this.existeRegistro = existeRegistro;
	}
	
	public void setExisteRegistro(BigDecimal existeRegistro) {
		this.existeRegistro = existeRegistro.intValue();
	}
}
