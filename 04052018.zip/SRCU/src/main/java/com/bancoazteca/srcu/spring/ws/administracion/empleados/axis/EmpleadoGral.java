/**
 * EmpleadoGral.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.bancoazteca.srcu.spring.ws.administracion.empleados.axis;
@SuppressWarnings({ "unused", "rawtypes" })
public class EmpleadoGral  implements java.io.Serializable {
    /**
	 * 
	 */
	private static final long serialVersionUID = 8984475990026774071L;

	private java.lang.String empresa;

    private int numeroEmpleado;

    private java.lang.String idCompa�ia;

    private java.lang.String desCompa�ia;

    private java.lang.String nombreInicial;

    private java.lang.String apellidoPaterno;

    private java.lang.String apellidoMaterno;

    private java.lang.String genero;

    private java.lang.String estadoCivil;

    private java.lang.String idCentroCostos;

    private java.lang.String desCentroCostos;

    private boolean activo;

    private java.lang.String idHorario;

    private java.lang.String desHorario;

    private int idPuesto;

    private java.lang.String desPuesto;

    private java.lang.String desPuestoBreve;

    private java.lang.String periodoPago;

    private java.lang.String idFuncion;

    private java.lang.String desFuncion;

    private int idDependencia;

    private java.lang.String desDependencia;

    private java.lang.String idPais;

    private int idSucursal;

    private java.lang.String idNegocio;

    private java.lang.String desNegocio;

    private Nomina datosNomina;

    private Fecha fechasEmpleado;

    public EmpleadoGral() {
    }

    public EmpleadoGral(
           java.lang.String empresa,
           int numeroEmpleado,
           java.lang.String idCompa�ia,
           java.lang.String desCompa�ia,
           java.lang.String nombreInicial,
           java.lang.String apellidoPaterno,
           java.lang.String apellidoMaterno,
           java.lang.String genero,
           java.lang.String estadoCivil,
           java.lang.String idCentroCostos,
           java.lang.String desCentroCostos,
           boolean activo,
           java.lang.String idHorario,
           java.lang.String desHorario,
           int idPuesto,
           java.lang.String desPuesto,
           java.lang.String desPuestoBreve,
           java.lang.String periodoPago,
           java.lang.String idFuncion,
           java.lang.String desFuncion,
           int idDependencia,
           java.lang.String desDependencia,
           java.lang.String idPais,
           int idSucursal,
           java.lang.String idNegocio,
           java.lang.String desNegocio,
           Nomina datosNomina,
           Fecha fechasEmpleado) {
           this.empresa = empresa;
           this.numeroEmpleado = numeroEmpleado;
           this.idCompa�ia = idCompa�ia;
           this.desCompa�ia = desCompa�ia;
           this.nombreInicial = nombreInicial;
           this.apellidoPaterno = apellidoPaterno;
           this.apellidoMaterno = apellidoMaterno;
           this.genero = genero;
           this.estadoCivil = estadoCivil;
           this.idCentroCostos = idCentroCostos;
           this.desCentroCostos = desCentroCostos;
           this.activo = activo;
           this.idHorario = idHorario;
           this.desHorario = desHorario;
           this.idPuesto = idPuesto;
           this.desPuesto = desPuesto;
           this.desPuestoBreve = desPuestoBreve;
           this.periodoPago = periodoPago;
           this.idFuncion = idFuncion;
           this.desFuncion = desFuncion;
           this.idDependencia = idDependencia;
           this.desDependencia = desDependencia;
           this.idPais = idPais;
           this.idSucursal = idSucursal;
           this.idNegocio = idNegocio;
           this.desNegocio = desNegocio;
           this.datosNomina = datosNomina;
           this.fechasEmpleado = fechasEmpleado;
    }


    /**
     * Gets the empresa value for this EmpleadoGral.
     * 
     * @return empresa
     */
    public java.lang.String getEmpresa() {
        return empresa;
    }


    /**
     * Sets the empresa value for this EmpleadoGral.
     * 
     * @param empresa
     */
    public void setEmpresa(java.lang.String empresa) {
        this.empresa = empresa;
    }


    /**
     * Gets the numeroEmpleado value for this EmpleadoGral.
     * 
     * @return numeroEmpleado
     */
    public int getNumeroEmpleado() {
        return numeroEmpleado;
    }


    /**
     * Sets the numeroEmpleado value for this EmpleadoGral.
     * 
     * @param numeroEmpleado
     */
    public void setNumeroEmpleado(int numeroEmpleado) {
        this.numeroEmpleado = numeroEmpleado;
    }


    /**
     * Gets the idCompa�ia value for this EmpleadoGral.
     * 
     * @return idCompa�ia
     */
    public java.lang.String getIdCompa�ia() {
        return idCompa�ia;
    }


    /**
     * Sets the idCompa�ia value for this EmpleadoGral.
     * 
     * @param idCompa�ia
     */
    public void setIdCompa�ia(java.lang.String idCompa�ia) {
        this.idCompa�ia = idCompa�ia;
    }


    /**
     * Gets the desCompa�ia value for this EmpleadoGral.
     * 
     * @return desCompa�ia
     */
    public java.lang.String getDesCompa�ia() {
        return desCompa�ia;
    }


    /**
     * Sets the desCompa�ia value for this EmpleadoGral.
     * 
     * @param desCompa�ia
     */
    public void setDesCompa�ia(java.lang.String desCompa�ia) {
        this.desCompa�ia = desCompa�ia;
    }


    /**
     * Gets the nombreInicial value for this EmpleadoGral.
     * 
     * @return nombreInicial
     */
    public java.lang.String getNombreInicial() {
        return nombreInicial;
    }


    /**
     * Sets the nombreInicial value for this EmpleadoGral.
     * 
     * @param nombreInicial
     */
    public void setNombreInicial(java.lang.String nombreInicial) {
        this.nombreInicial = nombreInicial;
    }


    /**
     * Gets the apellidoPaterno value for this EmpleadoGral.
     * 
     * @return apellidoPaterno
     */
    public java.lang.String getApellidoPaterno() {
        return apellidoPaterno;
    }


    /**
     * Sets the apellidoPaterno value for this EmpleadoGral.
     * 
     * @param apellidoPaterno
     */
    public void setApellidoPaterno(java.lang.String apellidoPaterno) {
        this.apellidoPaterno = apellidoPaterno;
    }


    /**
     * Gets the apellidoMaterno value for this EmpleadoGral.
     * 
     * @return apellidoMaterno
     */
    public java.lang.String getApellidoMaterno() {
        return apellidoMaterno;
    }


    /**
     * Sets the apellidoMaterno value for this EmpleadoGral.
     * 
     * @param apellidoMaterno
     */
    public void setApellidoMaterno(java.lang.String apellidoMaterno) {
        this.apellidoMaterno = apellidoMaterno;
    }


    /**
     * Gets the genero value for this EmpleadoGral.
     * 
     * @return genero
     */
    public java.lang.String getGenero() {
        return genero;
    }


    /**
     * Sets the genero value for this EmpleadoGral.
     * 
     * @param genero
     */
    public void setGenero(java.lang.String genero) {
        this.genero = genero;
    }


    /**
     * Gets the estadoCivil value for this EmpleadoGral.
     * 
     * @return estadoCivil
     */
    public java.lang.String getEstadoCivil() {
        return estadoCivil;
    }


    /**
     * Sets the estadoCivil value for this EmpleadoGral.
     * 
     * @param estadoCivil
     */
    public void setEstadoCivil(java.lang.String estadoCivil) {
        this.estadoCivil = estadoCivil;
    }


    /**
     * Gets the idCentroCostos value for this EmpleadoGral.
     * 
     * @return idCentroCostos
     */
    public java.lang.String getIdCentroCostos() {
        return idCentroCostos;
    }


    /**
     * Sets the idCentroCostos value for this EmpleadoGral.
     * 
     * @param idCentroCostos
     */
    public void setIdCentroCostos(java.lang.String idCentroCostos) {
        this.idCentroCostos = idCentroCostos;
    }


    /**
     * Gets the desCentroCostos value for this EmpleadoGral.
     * 
     * @return desCentroCostos
     */
    public java.lang.String getDesCentroCostos() {
        return desCentroCostos;
    }


    /**
     * Sets the desCentroCostos value for this EmpleadoGral.
     * 
     * @param desCentroCostos
     */
    public void setDesCentroCostos(java.lang.String desCentroCostos) {
        this.desCentroCostos = desCentroCostos;
    }


    /**
     * Gets the activo value for this EmpleadoGral.
     * 
     * @return activo
     */
    public boolean isActivo() {
        return activo;
    }


    /**
     * Sets the activo value for this EmpleadoGral.
     * 
     * @param activo
     */
    public void setActivo(boolean activo) {
        this.activo = activo;
    }


    /**
     * Gets the idHorario value for this EmpleadoGral.
     * 
     * @return idHorario
     */
    public java.lang.String getIdHorario() {
        return idHorario;
    }


    /**
     * Sets the idHorario value for this EmpleadoGral.
     * 
     * @param idHorario
     */
    public void setIdHorario(java.lang.String idHorario) {
        this.idHorario = idHorario;
    }


    /**
     * Gets the desHorario value for this EmpleadoGral.
     * 
     * @return desHorario
     */
    public java.lang.String getDesHorario() {
        return desHorario;
    }


    /**
     * Sets the desHorario value for this EmpleadoGral.
     * 
     * @param desHorario
     */
    public void setDesHorario(java.lang.String desHorario) {
        this.desHorario = desHorario;
    }


    /**
     * Gets the idPuesto value for this EmpleadoGral.
     * 
     * @return idPuesto
     */
    public int getIdPuesto() {
        return idPuesto;
    }


    /**
     * Sets the idPuesto value for this EmpleadoGral.
     * 
     * @param idPuesto
     */
    public void setIdPuesto(int idPuesto) {
        this.idPuesto = idPuesto;
    }


    /**
     * Gets the desPuesto value for this EmpleadoGral.
     * 
     * @return desPuesto
     */
    public java.lang.String getDesPuesto() {
        return desPuesto;
    }


    /**
     * Sets the desPuesto value for this EmpleadoGral.
     * 
     * @param desPuesto
     */
    public void setDesPuesto(java.lang.String desPuesto) {
        this.desPuesto = desPuesto;
    }


    /**
     * Gets the desPuestoBreve value for this EmpleadoGral.
     * 
     * @return desPuestoBreve
     */
    public java.lang.String getDesPuestoBreve() {
        return desPuestoBreve;
    }


    /**
     * Sets the desPuestoBreve value for this EmpleadoGral.
     * 
     * @param desPuestoBreve
     */
    public void setDesPuestoBreve(java.lang.String desPuestoBreve) {
        this.desPuestoBreve = desPuestoBreve;
    }


    /**
     * Gets the periodoPago value for this EmpleadoGral.
     * 
     * @return periodoPago
     */
    public java.lang.String getPeriodoPago() {
        return periodoPago;
    }


    /**
     * Sets the periodoPago value for this EmpleadoGral.
     * 
     * @param periodoPago
     */
    public void setPeriodoPago(java.lang.String periodoPago) {
        this.periodoPago = periodoPago;
    }


    /**
     * Gets the idFuncion value for this EmpleadoGral.
     * 
     * @return idFuncion
     */
    public java.lang.String getIdFuncion() {
        return idFuncion;
    }


    /**
     * Sets the idFuncion value for this EmpleadoGral.
     * 
     * @param idFuncion
     */
    public void setIdFuncion(java.lang.String idFuncion) {
        this.idFuncion = idFuncion;
    }


    /**
     * Gets the desFuncion value for this EmpleadoGral.
     * 
     * @return desFuncion
     */
    public java.lang.String getDesFuncion() {
        return desFuncion;
    }


    /**
     * Sets the desFuncion value for this EmpleadoGral.
     * 
     * @param desFuncion
     */
    public void setDesFuncion(java.lang.String desFuncion) {
        this.desFuncion = desFuncion;
    }


    /**
     * Gets the idDependencia value for this EmpleadoGral.
     * 
     * @return idDependencia
     */
    public int getIdDependencia() {
        return idDependencia;
    }


    /**
     * Sets the idDependencia value for this EmpleadoGral.
     * 
     * @param idDependencia
     */
    public void setIdDependencia(int idDependencia) {
        this.idDependencia = idDependencia;
    }


    /**
     * Gets the desDependencia value for this EmpleadoGral.
     * 
     * @return desDependencia
     */
    public java.lang.String getDesDependencia() {
        return desDependencia;
    }


    /**
     * Sets the desDependencia value for this EmpleadoGral.
     * 
     * @param desDependencia
     */
    public void setDesDependencia(java.lang.String desDependencia) {
        this.desDependencia = desDependencia;
    }


    /**
     * Gets the idPais value for this EmpleadoGral.
     * 
     * @return idPais
     */
    public java.lang.String getIdPais() {
        return idPais;
    }


    /**
     * Sets the idPais value for this EmpleadoGral.
     * 
     * @param idPais
     */
    public void setIdPais(java.lang.String idPais) {
        this.idPais = idPais;
    }


    /**
     * Gets the idSucursal value for this EmpleadoGral.
     * 
     * @return idSucursal
     */
    public int getIdSucursal() {
        return idSucursal;
    }


    /**
     * Sets the idSucursal value for this EmpleadoGral.
     * 
     * @param idSucursal
     */
    public void setIdSucursal(int idSucursal) {
        this.idSucursal = idSucursal;
    }


    /**
     * Gets the idNegocio value for this EmpleadoGral.
     * 
     * @return idNegocio
     */
    public java.lang.String getIdNegocio() {
        return idNegocio;
    }


    /**
     * Sets the idNegocio value for this EmpleadoGral.
     * 
     * @param idNegocio
     */
    public void setIdNegocio(java.lang.String idNegocio) {
        this.idNegocio = idNegocio;
    }


    /**
     * Gets the desNegocio value for this EmpleadoGral.
     * 
     * @return desNegocio
     */
    public java.lang.String getDesNegocio() {
        return desNegocio;
    }


    /**
     * Sets the desNegocio value for this EmpleadoGral.
     * 
     * @param desNegocio
     */
    public void setDesNegocio(java.lang.String desNegocio) {
        this.desNegocio = desNegocio;
    }


    /**
     * Gets the datosNomina value for this EmpleadoGral.
     * 
     * @return datosNomina
     */
    public Nomina getDatosNomina() {
        return datosNomina;
    }


    /**
     * Sets the datosNomina value for this EmpleadoGral.
     * 
     * @param datosNomina
     */
    public void setDatosNomina(Nomina datosNomina) {
        this.datosNomina = datosNomina;
    }


    /**
     * Gets the fechasEmpleado value for this EmpleadoGral.
     * 
     * @return fechasEmpleado
     */
    public Fecha getFechasEmpleado() {
        return fechasEmpleado;
    }


    /**
     * Sets the fechasEmpleado value for this EmpleadoGral.
     * 
     * @param fechasEmpleado
     */
    public void setFechasEmpleado(Fecha fechasEmpleado) {
        this.fechasEmpleado = fechasEmpleado;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof EmpleadoGral)) return false;
        EmpleadoGral other = (EmpleadoGral) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.empresa==null && other.getEmpresa()==null) || 
             (this.empresa!=null &&
              this.empresa.equals(other.getEmpresa()))) &&
            this.numeroEmpleado == other.getNumeroEmpleado() &&
            ((this.idCompa�ia==null && other.getIdCompa�ia()==null) || 
             (this.idCompa�ia!=null &&
              this.idCompa�ia.equals(other.getIdCompa�ia()))) &&
            ((this.desCompa�ia==null && other.getDesCompa�ia()==null) || 
             (this.desCompa�ia!=null &&
              this.desCompa�ia.equals(other.getDesCompa�ia()))) &&
            ((this.nombreInicial==null && other.getNombreInicial()==null) || 
             (this.nombreInicial!=null &&
              this.nombreInicial.equals(other.getNombreInicial()))) &&
            ((this.apellidoPaterno==null && other.getApellidoPaterno()==null) || 
             (this.apellidoPaterno!=null &&
              this.apellidoPaterno.equals(other.getApellidoPaterno()))) &&
            ((this.apellidoMaterno==null && other.getApellidoMaterno()==null) || 
             (this.apellidoMaterno!=null &&
              this.apellidoMaterno.equals(other.getApellidoMaterno()))) &&
            ((this.genero==null && other.getGenero()==null) || 
             (this.genero!=null &&
              this.genero.equals(other.getGenero()))) &&
            ((this.estadoCivil==null && other.getEstadoCivil()==null) || 
             (this.estadoCivil!=null &&
              this.estadoCivil.equals(other.getEstadoCivil()))) &&
            ((this.idCentroCostos==null && other.getIdCentroCostos()==null) || 
             (this.idCentroCostos!=null &&
              this.idCentroCostos.equals(other.getIdCentroCostos()))) &&
            ((this.desCentroCostos==null && other.getDesCentroCostos()==null) || 
             (this.desCentroCostos!=null &&
              this.desCentroCostos.equals(other.getDesCentroCostos()))) &&
            this.activo == other.isActivo() &&
            ((this.idHorario==null && other.getIdHorario()==null) || 
             (this.idHorario!=null &&
              this.idHorario.equals(other.getIdHorario()))) &&
            ((this.desHorario==null && other.getDesHorario()==null) || 
             (this.desHorario!=null &&
              this.desHorario.equals(other.getDesHorario()))) &&
            this.idPuesto == other.getIdPuesto() &&
            ((this.desPuesto==null && other.getDesPuesto()==null) || 
             (this.desPuesto!=null &&
              this.desPuesto.equals(other.getDesPuesto()))) &&
            ((this.desPuestoBreve==null && other.getDesPuestoBreve()==null) || 
             (this.desPuestoBreve!=null &&
              this.desPuestoBreve.equals(other.getDesPuestoBreve()))) &&
            ((this.periodoPago==null && other.getPeriodoPago()==null) || 
             (this.periodoPago!=null &&
              this.periodoPago.equals(other.getPeriodoPago()))) &&
            ((this.idFuncion==null && other.getIdFuncion()==null) || 
             (this.idFuncion!=null &&
              this.idFuncion.equals(other.getIdFuncion()))) &&
            ((this.desFuncion==null && other.getDesFuncion()==null) || 
             (this.desFuncion!=null &&
              this.desFuncion.equals(other.getDesFuncion()))) &&
            this.idDependencia == other.getIdDependencia() &&
            ((this.desDependencia==null && other.getDesDependencia()==null) || 
             (this.desDependencia!=null &&
              this.desDependencia.equals(other.getDesDependencia()))) &&
            ((this.idPais==null && other.getIdPais()==null) || 
             (this.idPais!=null &&
              this.idPais.equals(other.getIdPais()))) &&
            this.idSucursal == other.getIdSucursal() &&
            ((this.idNegocio==null && other.getIdNegocio()==null) || 
             (this.idNegocio!=null &&
              this.idNegocio.equals(other.getIdNegocio()))) &&
            ((this.desNegocio==null && other.getDesNegocio()==null) || 
             (this.desNegocio!=null &&
              this.desNegocio.equals(other.getDesNegocio()))) &&
            ((this.datosNomina==null && other.getDatosNomina()==null) || 
             (this.datosNomina!=null &&
              this.datosNomina.equals(other.getDatosNomina()))) &&
            ((this.fechasEmpleado==null && other.getFechasEmpleado()==null) || 
             (this.fechasEmpleado!=null &&
              this.fechasEmpleado.equals(other.getFechasEmpleado())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getEmpresa() != null) {
            _hashCode += getEmpresa().hashCode();
        }
        _hashCode += getNumeroEmpleado();
        if (getIdCompa�ia() != null) {
            _hashCode += getIdCompa�ia().hashCode();
        }
        if (getDesCompa�ia() != null) {
            _hashCode += getDesCompa�ia().hashCode();
        }
        if (getNombreInicial() != null) {
            _hashCode += getNombreInicial().hashCode();
        }
        if (getApellidoPaterno() != null) {
            _hashCode += getApellidoPaterno().hashCode();
        }
        if (getApellidoMaterno() != null) {
            _hashCode += getApellidoMaterno().hashCode();
        }
        if (getGenero() != null) {
            _hashCode += getGenero().hashCode();
        }
        if (getEstadoCivil() != null) {
            _hashCode += getEstadoCivil().hashCode();
        }
        if (getIdCentroCostos() != null) {
            _hashCode += getIdCentroCostos().hashCode();
        }
        if (getDesCentroCostos() != null) {
            _hashCode += getDesCentroCostos().hashCode();
        }
        _hashCode += (isActivo() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        if (getIdHorario() != null) {
            _hashCode += getIdHorario().hashCode();
        }
        if (getDesHorario() != null) {
            _hashCode += getDesHorario().hashCode();
        }
        _hashCode += getIdPuesto();
        if (getDesPuesto() != null) {
            _hashCode += getDesPuesto().hashCode();
        }
        if (getDesPuestoBreve() != null) {
            _hashCode += getDesPuestoBreve().hashCode();
        }
        if (getPeriodoPago() != null) {
            _hashCode += getPeriodoPago().hashCode();
        }
        if (getIdFuncion() != null) {
            _hashCode += getIdFuncion().hashCode();
        }
        if (getDesFuncion() != null) {
            _hashCode += getDesFuncion().hashCode();
        }
        _hashCode += getIdDependencia();
        if (getDesDependencia() != null) {
            _hashCode += getDesDependencia().hashCode();
        }
        if (getIdPais() != null) {
            _hashCode += getIdPais().hashCode();
        }
        _hashCode += getIdSucursal();
        if (getIdNegocio() != null) {
            _hashCode += getIdNegocio().hashCode();
        }
        if (getDesNegocio() != null) {
            _hashCode += getDesNegocio().hashCode();
        }
        if (getDatosNomina() != null) {
            _hashCode += getDatosNomina().hashCode();
        }
        if (getFechasEmpleado() != null) {
            _hashCode += getFechasEmpleado().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(EmpleadoGral.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "EmpleadoGral"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("empresa");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Empresa"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroEmpleado");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "NumeroEmpleado"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("idCompa�ia");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "idCompa�ia"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("desCompa�ia");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "DesCompa�ia"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nombreInicial");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "NombreInicial"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("apellidoPaterno");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ApellidoPaterno"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("apellidoMaterno");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "ApellidoMaterno"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("genero");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Genero"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("estadoCivil");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "EstadoCivil"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("idCentroCostos");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "idCentroCostos"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("desCentroCostos");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "DesCentroCostos"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("activo");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Activo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("idHorario");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "idHorario"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("desHorario");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "DesHorario"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("idPuesto");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "idPuesto"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("desPuesto");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "DesPuesto"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("desPuestoBreve");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "DesPuestoBreve"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("periodoPago");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "PeriodoPago"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("idFuncion");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "idFuncion"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("desFuncion");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "DesFuncion"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("idDependencia");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "idDependencia"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("desDependencia");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "DesDependencia"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("idPais");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "idPais"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("idSucursal");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "idSucursal"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("idNegocio");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "idNegocio"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("desNegocio");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "DesNegocio"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("datosNomina");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "DatosNomina"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Nomina"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("fechasEmpleado");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "FechasEmpleado"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Fecha"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
