package com.bancoazteca.srcu.spring.daos.administracion.mantenimientoUsuariosAvante;

import java.util.List;
import com.bancoazteca.srcu.spring.beans.administracion.mantenimientoUsuariosAvante.EmpleadosAvanteBean;
import com.bancoazteca.srcu.spring.beans.administracion.mantenimientoUsuariosAvante.MantenimientoUsuariosAvanteBean;
import com.bancoazteca.srcu.spring.beans.administracion.mantenimientoUsuariosAvante.PuestosAvanteBean;
import com.bancoazteca.srcu.spring.beans.sistema.MensajeTransaccionBean;

public interface MantenimientoUsuariosAvanteDAO {
	public	List<PuestosAvanteBean> consultaPuestosAvante(String empleadoOpera);
	public	List<EmpleadosAvanteBean> consultaCoordinadores();
	public	List<EmpleadosAvanteBean> consultaEmpleados(String numeroEmpleado, int puestoConsultar);
	public	MensajeTransaccionBean altaUsuarioAvante(MantenimientoUsuariosAvanteBean mantenimientoUsuariosAvanteBean);
	public	MensajeTransaccionBean bajaUsuarioAvante(MantenimientoUsuariosAvanteBean mantenimientoUsuariosAvanteBean);
}
