package com.bancoazteca.srcu.spring.servicios.administracion.mantenimientoUsuariosAvante;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bancoazteca.srcu.spring.beans.administracion.mantenimientoUsuariosAvante.AsignacionAvanteBean;
import com.bancoazteca.srcu.spring.beans.sistema.MensajeTransaccionBean;
import com.bancoazteca.srcu.spring.daos.administracion.mantenimientoUsuariosAvante.AsignacionAvanteDAO;
import com.bancoazteca.srcu.spring.servicios.utilerias.BaseServicio;

@Service
public class AsignacionAvanteServicioImpl extends BaseServicio implements AsignacionAvanteServicio{

	@Autowired
	private	AsignacionAvanteDAO	asignacionAvanteDAO;
	
	public interface Enum_Consultas_AsignacionAvanteServicio {
			int	zonas			=	1;
			int	coordinadores	=	2;
			int	regiones		=	3;
			int	gerencias		=	4;
			int	jefesCobranza	=	5;
			int	especialistas	=	6;
	}
	
	public interface Enum_Transacciones_AsignacionAvanteServicio{
		int	insertarAsignacion	=	1;
		int	eliminarAsignacion	=	2;
	}
	

	@Override
	public AsignacionAvanteBean consulta(AsignacionAvanteBean asignacionAvante, int tipoConsulta) {
		AsignacionAvanteBean asignacionAvanteBean = new AsignacionAvanteBean();
		
		switch (tipoConsulta) {
		case Enum_Consultas_AsignacionAvanteServicio.zonas:
			asignacionAvanteBean.setZonas(asignacionAvanteDAO.consultaZonas(asignacionAvante));
			break;
		case Enum_Consultas_AsignacionAvanteServicio.coordinadores:
			asignacionAvanteBean.setCoordinadores(asignacionAvanteDAO.consultaCoordinadores());
			break;
		case Enum_Consultas_AsignacionAvanteServicio.regiones:
			asignacionAvanteBean.setRegiones(asignacionAvanteDAO.consultaRegiones(asignacionAvante));
			break;
		case Enum_Consultas_AsignacionAvanteServicio.gerencias:
			asignacionAvanteBean.setGerencias(asignacionAvanteDAO.consultaGerencias(asignacionAvante));
			break;
		case Enum_Consultas_AsignacionAvanteServicio.jefesCobranza:
			asignacionAvanteBean.setJefesCobranza(asignacionAvanteDAO.jefesCobranza(asignacionAvante));
			break;
		case Enum_Consultas_AsignacionAvanteServicio.especialistas:
			asignacionAvanteBean.setEspecialistasRegion(asignacionAvanteDAO.especialistasRegion(asignacionAvante));
			break;
		default:
			break;
		}
		
		return asignacionAvanteBean;
	}

	@Override
	public MensajeTransaccionBean grabaTransaccion(AsignacionAvanteBean asignacionAvanteBean, int tipoOperacion) {
		MensajeTransaccionBean mensajeTransaccionBean = new MensajeTransaccionBean();
		
		switch (tipoOperacion) {
		case Enum_Transacciones_AsignacionAvanteServicio.insertarAsignacion:
			mensajeTransaccionBean = asignaEspecialistas(asignacionAvanteBean);
			break;
		case Enum_Transacciones_AsignacionAvanteServicio.eliminarAsignacion:
			mensajeTransaccionBean = asignacionAvanteDAO.insertaAsignacion(asignacionAvanteBean);
			break;
		default:
			break;
		}
		
		return mensajeTransaccionBean;
	}

	
	private MensajeTransaccionBean asignaEspecialistas(AsignacionAvanteBean asignacionAvanteBean) {
		MensajeTransaccionBean mensajeTransaccionBean = new MensajeTransaccionBean();
		
		mensajeTransaccionBean = asignacionAvanteDAO.eliminarAsignacion(asignacionAvanteBean);
		
		if(mensajeTransaccionBean.getNumeroMensaje() == 0) {
			mensajeTransaccionBean = asignacionAvanteDAO.insertaAsignacion(asignacionAvanteBean);
		}
		
		return mensajeTransaccionBean;
	}
	

}
