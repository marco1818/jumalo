/**
 * ZRH_REG_CREDHolder.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.bancoazteca.srcu.spring.ws.administracion.posicionesSap.axis.altaBajaPosicionesSap;

public final class ZRH_REG_CREDHolder implements javax.xml.rpc.holders.Holder {
    public ZRH_REG_CRED value;

    public ZRH_REG_CREDHolder() {
    }

    public ZRH_REG_CREDHolder(ZRH_REG_CRED value) {
        this.value = value;
    }

}
