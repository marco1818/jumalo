package com.bancoazteca.srcu.spring.beans.administracion.mantenimientoUsuariosUnificado;

import java.util.List;

import com.bancoazteca.srcu.spring.beans.administracion.mantenimientoTelefonos.DatosEmpleadoBean;
import com.bancoazteca.srcu.spring.beans.utilerias.BaseBean;

public class MantenimientoUsuariosUnificadoBean extends BaseBean{
	private	String	empleadoOpera;
	private int puestoOpera;
	private List<PuestoBean> puestos;
	private List<DepartamentosBean> departamentos;
	private	List<EmpleadosBean> empleados;
	private	List<VacantesxPuestoBean> vacantesxPuesto;
	private	DatosEmpleadoBean datosEmpleado;
	private String empleadoAlta;
	private String nombreEmpleadoAlta;
	private String empleadoBaja;	
	private int	segmentoOrigen;
	private int departamentoOperar;
	private int puestoOperar;
	private int segmentoOperar;
	
	
	private	String empleadoConsulta;
	// para la Baja x Sustitucion
	private String empleadoOrigenBS;
	private int puestoOrigenBS;
	private int puestoDestinoBS;
	private int segmentoDestinoBS;
	private String empleadoDestinoBS;
	// Para el Cambio de Empleado
	private String empleadoOrigenCE;
	private int puestoOrigenCE;
	private int segmentoOrigenCE;
	private String empleadoDestinoCE;
	private int puestoDestinoCE;
	private int segmentoDestinoCE;
	
	// Auxiliares para el Cambio de Empleado
	private String empleadoOrigenEje;
	private String empleadoDestinoEje;
	
	
	
	private String vacanteEje;
	
	
	private int plazaId;
	
//	private String empleadoCambioDestino;
//	private String empleadoJefe;
//	private int puestoOrigen;
//	private int puestoDestinoBS;
	private int nuevoPuesto;
	private	int nuevoSegmento;
//	
	
	public MantenimientoUsuariosUnificadoBean() {
		
	}

	public String getEmpleadoOpera() {
		return empleadoOpera;
	}

	public void setEmpleadoOpera(String empleadoOpera) {
		this.empleadoOpera = empleadoOpera;
	}

	public List<PuestoBean> getPuestos() {
		return puestos;
	}

	public void setPuestos(List<PuestoBean> puestos) {
		this.puestos = puestos;
	}

	public String getEmpleadoAlta() {
		return empleadoAlta;
	}

	public void setEmpleadoAlta(String empleadoAlta) {
		this.empleadoAlta = empleadoAlta;
	}

	public int getDepartamentoOperar() {
		return departamentoOperar;
	}

	public void setDepartamentoOperar(int departamentoOperar) {
		this.departamentoOperar = departamentoOperar;
	}

	public int getPuestoOperar() {
		return puestoOperar;
	}

	public void setPuestoOperar(int puestoOperar) {
		this.puestoOperar = puestoOperar;
	}

	public int getPlazaId() {
		return plazaId;
	}

	public void setPlazaId(int plazaId) {
		this.plazaId = plazaId;
	}

	public String getNombreEmpleadoAlta() {
		return nombreEmpleadoAlta;
	}

	public void setNombreEmpleadoAlta(String nombreEmpleadoAlta) {
		this.nombreEmpleadoAlta = nombreEmpleadoAlta;
	}

	public int getSegmentoOperar() {
		return segmentoOperar;
	}

	public void setSegmentoOperar(int segmentoOperar) {
		this.segmentoOperar = segmentoOperar;
	}


	public String getEmpleadoBaja() {
		return empleadoBaja;
	}

	public void setEmpleadoBaja(String empleadoBaja) {
		this.empleadoBaja = empleadoBaja;
	}

	public String getVacanteEje() {
		return vacanteEje;
	}

	public void setVacanteEje(String vacanteEje) {
		this.vacanteEje = vacanteEje;
	}

	public int getSegmentoOrigen() {
		return segmentoOrigen;
	}

	public void setSegmentoOrigen(int segmentoOrigen) {
		this.segmentoOrigen = segmentoOrigen;
	}

	public String getEmpleadoOrigenEje() {
		return empleadoOrigenEje;
	}

	public void setEmpleadoOrigenEje(String empleadoOrigenEje) {
		this.empleadoOrigenEje = empleadoOrigenEje;
	}

	public String getEmpleadoDestinoEje() {
		return empleadoDestinoEje;
	}

	public void setEmpleadoDestinoEje(String empleadoDestinoEje) {
		this.empleadoDestinoEje = empleadoDestinoEje;
	}

	public List<DepartamentosBean> getDepartamentos() {
		return departamentos;
	}

	public void setDepartamentos(List<DepartamentosBean> departamentos) {
		this.departamentos = departamentos;
	}

	public List<EmpleadosBean> getEmpleados() {
		return empleados;
	}

	public void setEmpleados(List<EmpleadosBean> empleados) {
		this.empleados = empleados;
	}

	public List<VacantesxPuestoBean> getVacantesxPuesto() {
		return vacantesxPuesto;
	}

	public void setVacantesxPuesto(List<VacantesxPuestoBean> vacantesxPuesto) {
		this.vacantesxPuesto = vacantesxPuesto;
	}

	public DatosEmpleadoBean getDatosEmpleado() {
		return datosEmpleado;
	}

	public void setDatosEmpleado(DatosEmpleadoBean datosEmpleado) {
		this.datosEmpleado = datosEmpleado;
	}

	public String getEmpleadoConsulta() {
		return empleadoConsulta;
	}

	public void setEmpleadoConsulta(String empleadoConsulta) {
		this.empleadoConsulta = empleadoConsulta;
	}

	public String getEmpleadoOrigenBS() {
		return empleadoOrigenBS;
	}

	public void setEmpleadoOrigenBS(String empleadoOrigenBS) {
		this.empleadoOrigenBS = empleadoOrigenBS;
	}

	public int getPuestoDestinoBS() {
		return puestoDestinoBS;
	}

	public void setPuestoDestinoBS(int puestoDestinoBS) {
		this.puestoDestinoBS = puestoDestinoBS;
	}

	public int getSegmentoDestinoBS() {
		return segmentoDestinoBS;
	}

	public void setSegmentoDestinoBS(int segmentoDestinoBS) {
		this.segmentoDestinoBS = segmentoDestinoBS;
	}

	public String getEmpleadoDestinoBS() {
		return empleadoDestinoBS;
	}

	public void setEmpleadoDestinoBS(String empleadoDestinoBS) {
		this.empleadoDestinoBS = empleadoDestinoBS;
	}

	public String getEmpleadoOrigenCE() {
		return empleadoOrigenCE;
	}

	public void setEmpleadoOrigenCE(String empleadoOrigenCE) {
		this.empleadoOrigenCE = empleadoOrigenCE;
	}

	public int getPuestoOrigenCE() {
		return puestoOrigenCE;
	}

	public void setPuestoOrigenCE(int puestoOrigenCE) {
		this.puestoOrigenCE = puestoOrigenCE;
	}

	public int getSegmentoOrigenCE() {
		return segmentoOrigenCE;
	}

	public void setSegmentoOrigenCE(int segmentoOrigenCE) {
		this.segmentoOrigenCE = segmentoOrigenCE;
	}

	public String getEmpleadoDestinoCE() {
		return empleadoDestinoCE;
	}

	public void setEmpleadoDestinoCE(String empleadoDestinoCE) {
		this.empleadoDestinoCE = empleadoDestinoCE;
	}

	public int getPuestoDestinoCE() {
		return puestoDestinoCE;
	}

	public void setPuestoDestinoCE(int puestoDestinoCE) {
		this.puestoDestinoCE = puestoDestinoCE;
	}

	public int getSegmentoDestinoCE() {
		return segmentoDestinoCE;
	}

	public void setSegmentoDestinoCE(int segmentoDestinoCE) {
		this.segmentoDestinoCE = segmentoDestinoCE;
	}

	public int getNuevoPuesto() {
		return nuevoPuesto;
	}

	public void setNuevoPuesto(int nuevoPuesto) {
		this.nuevoPuesto = nuevoPuesto;
	}

	public int getNuevoSegmento() {
		return nuevoSegmento;
	}

	public void setNuevoSegmento(int nuevoSegmento) {
		this.nuevoSegmento = nuevoSegmento;
	}

	public int getPuestoOrigenBS() {
		return puestoOrigenBS;
	}

	public void setPuestoOrigenBS(int puestoOrigenBS) {
		this.puestoOrigenBS = puestoOrigenBS;
	}

	public int getPuestoOpera() {
		return puestoOpera;
	}

	public void setPuestoOpera(int puestoOpera) {
		this.puestoOpera = puestoOpera;
	}
	
}
