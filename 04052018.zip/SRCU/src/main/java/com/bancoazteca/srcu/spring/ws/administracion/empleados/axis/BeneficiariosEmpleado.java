/**
 * BeneficiariosEmpleado.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.bancoazteca.srcu.spring.ws.administracion.empleados.axis;

public class BeneficiariosEmpleado  implements java.io.Serializable {

	private static final long serialVersionUID = -4483473650672082720L;

	private java.lang.String nombre;

    private java.lang.String relacion;

    private java.lang.String porcentaje;

    private java.lang.String poliza;

    private java.lang.String miembro;

    public BeneficiariosEmpleado() {
    }

    public BeneficiariosEmpleado(
           java.lang.String nombre,
           java.lang.String relacion,
           java.lang.String porcentaje,
           java.lang.String poliza,
           java.lang.String miembro) {
           this.nombre = nombre;
           this.relacion = relacion;
           this.porcentaje = porcentaje;
           this.poliza = poliza;
           this.miembro = miembro;
    }


    /**
     * Gets the nombre value for this BeneficiariosEmpleado.
     * 
     * @return nombre
     */
    public java.lang.String getNombre() {
        return nombre;
    }


    /**
     * Sets the nombre value for this BeneficiariosEmpleado.
     * 
     * @param nombre
     */
    public void setNombre(java.lang.String nombre) {
        this.nombre = nombre;
    }


    /**
     * Gets the relacion value for this BeneficiariosEmpleado.
     * 
     * @return relacion
     */
    public java.lang.String getRelacion() {
        return relacion;
    }


    /**
     * Sets the relacion value for this BeneficiariosEmpleado.
     * 
     * @param relacion
     */
    public void setRelacion(java.lang.String relacion) {
        this.relacion = relacion;
    }


    /**
     * Gets the porcentaje value for this BeneficiariosEmpleado.
     * 
     * @return porcentaje
     */
    public java.lang.String getPorcentaje() {
        return porcentaje;
    }


    /**
     * Sets the porcentaje value for this BeneficiariosEmpleado.
     * 
     * @param porcentaje
     */
    public void setPorcentaje(java.lang.String porcentaje) {
        this.porcentaje = porcentaje;
    }


    /**
     * Gets the poliza value for this BeneficiariosEmpleado.
     * 
     * @return poliza
     */
    public java.lang.String getPoliza() {
        return poliza;
    }


    /**
     * Sets the poliza value for this BeneficiariosEmpleado.
     * 
     * @param poliza
     */
    public void setPoliza(java.lang.String poliza) {
        this.poliza = poliza;
    }


    /**
     * Gets the miembro value for this BeneficiariosEmpleado.
     * 
     * @return miembro
     */
    public java.lang.String getMiembro() {
        return miembro;
    }


    /**
     * Sets the miembro value for this BeneficiariosEmpleado.
     * 
     * @param miembro
     */
    public void setMiembro(java.lang.String miembro) {
        this.miembro = miembro;
    }

    private java.lang.Object __equalsCalc = null;
    @SuppressWarnings("unused")
	public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof BeneficiariosEmpleado)) return false;
        BeneficiariosEmpleado other = (BeneficiariosEmpleado) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.nombre==null && other.getNombre()==null) || 
             (this.nombre!=null &&
              this.nombre.equals(other.getNombre()))) &&
            ((this.relacion==null && other.getRelacion()==null) || 
             (this.relacion!=null &&
              this.relacion.equals(other.getRelacion()))) &&
            ((this.porcentaje==null && other.getPorcentaje()==null) || 
             (this.porcentaje!=null &&
              this.porcentaje.equals(other.getPorcentaje()))) &&
            ((this.poliza==null && other.getPoliza()==null) || 
             (this.poliza!=null &&
              this.poliza.equals(other.getPoliza()))) &&
            ((this.miembro==null && other.getMiembro()==null) || 
             (this.miembro!=null &&
              this.miembro.equals(other.getMiembro())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getNombre() != null) {
            _hashCode += getNombre().hashCode();
        }
        if (getRelacion() != null) {
            _hashCode += getRelacion().hashCode();
        }
        if (getPorcentaje() != null) {
            _hashCode += getPorcentaje().hashCode();
        }
        if (getPoliza() != null) {
            _hashCode += getPoliza().hashCode();
        }
        if (getMiembro() != null) {
            _hashCode += getMiembro().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(BeneficiariosEmpleado.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "BeneficiariosEmpleado"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nombre");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Nombre"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("relacion");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Relacion"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("porcentaje");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Porcentaje"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("poliza");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Poliza"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("miembro");
        elemField.setXmlName(new javax.xml.namespace.QName("http://SistemasRH.com/DatosGenerales/", "Miembro"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    @SuppressWarnings("rawtypes")
	public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    @SuppressWarnings("rawtypes")
	public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
