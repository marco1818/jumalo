package com.bancoazteca.srcu.spring.controladores.administracion.mantenimientoUsuariosAvante;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.ModelAndView;

import com.bancoazteca.srcu.spring.beans.administracion.mantenimientoUsuariosAvante.AsignacionAvanteBean;
import com.bancoazteca.srcu.spring.beans.sistema.MensajeTransaccionBean;
import com.bancoazteca.srcu.spring.beans.utilerias.DatosSessionStruts;
import com.bancoazteca.srcu.spring.servicios.administracion.mantenimientoUsuariosAvante.AsignacionAvanteServicio;

@Controller
public class AsignacionAvanteControlador {
	
	@Autowired
	private AsignacionAvanteServicio asignacionAvanteServicio;
	
	@InitBinder
	public void InitBinder(WebDataBinder webDataBinder, WebRequest webRequest) {
		webDataBinder.setDisallowedFields("");
	}
	
	@RequestMapping(value= {"/asignacionAvanteSRCU.htm"}, method= RequestMethod.GET)
	public ModelAndView mantenimientoUsuariosAvante(@ModelAttribute("datosSessionStruts")DatosSessionStruts datosSessionStruts) {
		AsignacionAvanteBean asignacionAvanteBean = new AsignacionAvanteBean();
		asignacionAvanteBean.setEmpleadoOpera(datosSessionStruts.getNumeroEmpleado());
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("administracion/mantenimientoUsuariosAvante/asignacionAvante");
		asignacionAvanteBean.setZonas(asignacionAvanteServicio.consulta(asignacionAvanteBean, 1).getZonas());
		
		modelAndView.addObject("asignacionAvanteBean",asignacionAvanteBean);
		return modelAndView;
	}
	
	@RequestMapping(value= {"/asignacionAvanteSRCU.htm"}, method= RequestMethod.POST)
	public ModelAndView asignacionAvante(@ModelAttribute("asignacionAvanteBean")AsignacionAvanteBean asignacionAvanteBean, @RequestParam("tipoOperacion") int tipoOperacion) {
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("sistema/resultadoTransaccion");
		
		MensajeTransaccionBean mensajeTransaccionBean = asignacionAvanteServicio.grabaTransaccion(asignacionAvanteBean, tipoOperacion);
		
		modelAndView.addObject("mensajeTransaccionBean",mensajeTransaccionBean);
		
		return modelAndView;
	}
	
}
