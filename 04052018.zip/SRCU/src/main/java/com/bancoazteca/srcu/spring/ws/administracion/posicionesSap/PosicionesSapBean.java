package com.bancoazteca.srcu.spring.ws.administracion.posicionesSap;

public class PosicionesSapBean {
	private String centroCostos;
	private int funcionSAP;
	private String posicionId;
	private String empleadoAsociado;
	
	public PosicionesSapBean() {
		
	}
	
	public PosicionesSapBean(String centroCostos, int funcionSAP, String posicionId, String empleadoAsociado) {
		this.centroCostos 		= 	centroCostos;
		this.funcionSAP			=	funcionSAP;
		this.posicionId			=	posicionId;
		this.empleadoAsociado	=	empleadoAsociado;
	}
	
	public String getCentroCostos() {
		return centroCostos;
	}
	public void setCentroCostos(String centroCostos) {
		this.centroCostos = centroCostos;
	}
	public int getFuncionSAP() {
		return funcionSAP;
	}
	public void setFuncionSAP(int funcionSAP) {
		this.funcionSAP = funcionSAP;
	}
	public String getPosicionId() {
		return posicionId;
	}
	public void setPosicionId(String posicionId) {
		this.posicionId = posicionId;
	}
	public String getEmpleadoAsociado() {
		return empleadoAsociado;
	}
	public void setEmpleadoAsociado(String empleadoAsociado) {
		this.empleadoAsociado = empleadoAsociado;
	}
	
	

}
