
$( document ).ready(function() {

$('input:empty, textarea:empty').closest('label').addClass('empty');

$('input').keyup(function () {
  if ($(this).val().trim() !== '') {
    $(this).closest('label').removeClass('empty');
  } else {
    $(this).closest('label').addClass('empty');
  }
});

$('#ajustes').mouseover(function(){
	$(this).find('img').attr('src','../../imagenes/seguridad/llave_over.png');

});

$('#ajustes').mouseout(function(){
	$(this).find('img').attr('src','../../imagenes/seguridad/llave.png');

});

$('#notifica').mouseover(function(){
	$(this).attr('src','../../imagenes/seguridad/bell_over.png');

});

$('#notifica').mouseout(function(){
	$(this).attr('src','../../imagenes/seguridad/bell.png');

});

$('#menu').mouseover(function(){
	$(this).find('img').attr('src','../../imagenes/seguridad/menu_over.png');

});

$('#menu').mouseout(function(){
	$(this).find('img').attr('src','../../imagenes/seguridad/menu.png');

});



});

