$(document).ready(function(){
	
	cargaPantalla();
	
	$('#insertarDatos').click(function(){
		$('#tipoOperacion').val("1");
		grabaTransaccionRecarga('mantenimientoTelefonos','contenido','mensaje','funcionRecarga','');
	});
	
	$('#actualizaDatos').click(function(){
		$('#tipoOperacion').val("2");
		grabaTransaccionRecarga('mantenimientoTelefonos','contenido','mensaje','funcionRecarga','');
	});
	
	function cargaPantalla(){
		if($('#existeRegistro').val() == 1){
			$('#actualizaDatos').show();
			$('#insertarDatos').hide();
		}else{
			$('#insertarDatos').show();
			$('#actualizaDatos').hide();
		}
	}

});

function funcionRecarga(){
	var consultaEmpleado	=	1;
	var mantenimientoTelefonosBean = {
		'numeroEmpleado' : $('#numeroEmpleado').val()
	}
	MantenimientoTelefonosServicioImpl.consulta(consultaEmpleado,mantenimientoTelefonosBean,function(mantenimientoTelefonos){
		if(mantenimientoTelefonos!=null){
			$('#numeroEmpleado').val(mantenimientoTelefonos.numeroEmpleado);
			$('#nombreEmpleado').val(mantenimientoTelefonos.nombreEmpleado);
			$('#telefono').val(mantenimientoTelefonos.telefono);
			$('#correo').val(mantenimientoTelefonos.correo);
			if(mantenimientoTelefonos.existeRegistro == 1){
				$('#actualizaDatos').show();
				$('#insertarDatos').hide();
			}else{
				$('#insertarDatos').show();
				$('#actualizaDatos').hide();
			}
		}
	});
}
