$(document).ready(function(){
	
	$("#consultaVacantesSAP").click(function(){
		consultaVacantesSap();
	});
	
	function consultaVacantesSap(){
		bloqueaPantalla('contenido','mensaje');
		var tablaPersonalActivo	=	creaEncabezadoComparacion();
		PersonalActivoServicioImpl.comparacionSap($('#gerenciaId').val(),function(personalActivo){
			if(personalActivo != null ){				
				for (var i = 0; i < personalActivo.length; i++) {
					tablaPersonalActivo += creaFilaComparacion(personalActivo[i],i);
			    }
				$('#tituloComparacion').show();
				tablaPersonalActivo	+= '</table>';
				$('#divComparacionSAP').html(tablaPersonalActivo);
			}else{
				alert("INFORMACION NO DISPONIBLE POR EL MOMENTO, INTENTELO MAS TARDE.");
			}
			desbloqueaPantalla('contenido');
		});
		
	}
	
	function creaEncabezadoComparacion(){
		var	tabla=	'<table class="tabla" style="width:60%">'
			+	'<tr class="encabezadoTabla">'
			+		'<td style="border-radius: 10px 0 0 0; width: 15%;" >'
			+			'<label>SEGMENTO</label>'
			+		'</td>'
			+		'<td style="width: 15%; ">'
			+			'<label>FUNCION SAP</label>'
			+		'</td>'
			+		'<td style="width: 15%; ">'
			+			'<label>VACANTES EN SRU</label>'
			+		'</td>'
			+		'<td style="width: 15%; ">'
			+			'<label>VACANTES EN SAP</label>'
			+		'</td>'
			+		'<td style="border-radius: 0 10px 0 0; width: 15%; ">'
			+			'<label>POSICIONES A CONCILIAR</label>'
			+		'</td>'			
			+	'</tr>';
			return tabla;
	}
	
	function creaFilaComparacion(comparacionSap,index){
		var colorTr = 'trOscuro';
		if(index%2==0){
			colorTr = 'trClaro';
		}
		var	fila=	'<tr class="'+colorTr+'">'
				+	'	<td class="columnaCentrada"><label>'+comparacionSap.segmentoDesc+'</label></td>'
				+	'	<td class="columnaCentrada"><label>'+comparacionSap.funcionSap+'</label></td>'
				+	'	<td class="columnaCentrada"><label>'+comparacionSap.vacantesSrcu+'</label></td>'
				+	'	<td class="columnaCentrada"><label>'+comparacionSap.vacantesSap+'</label></td>'
				+	'	<td class="columnaCentrada"><label>'+(comparacionSap.diferencia!=0?(comparacionSap.diferencia>0?("LIMITAR "+comparacionSap.diferencia+" POSICIONES"):("CREAR "+comparacionSap.diferencia+" POSICIONES")):" ")+'</label></td>'
				+	'</tr>';
		return fila;
	}
	
});