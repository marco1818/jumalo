$(document).ready(function (){
	
	var	Cat_Acciones = {
			'AltaUsuario'	:	'btnAltaEmpleado',
			'BajaUsuario'	:	'btnBajaEmpleado'
		}
	
	var cat_Transacciones = {
			'altaUsuario'	:	1,
			'bajaUsuario'	:	2
	}
	
	// Definicion de Eventos
	$('#aceptarAlert').click(function(){
		$('#contenido').unblock();
	});
	
	$('#empleadoAlta').keyup(function(){
		$('#nombreEmpleadoAlta').val('');
		$('#nombreEmpleadoAlta').attr('disabled',true);
	});
	
	$('#puestoOperar').change(function(){
		if($('#puestoOperar').val() > 0){
			bloqueaPantalla('contenido', 'mensaje');
			$('#divLogoEmpleados').hide();
			$('#divEmpleados').html('');
			dwr.util.removeAllOptions('jefeOperar'); 
			dwr.util.addOptions('jefeOperar',{'0':'SELECCIONE UN COORDINADOR'});
			if($('#puestoOperar').val() != 2001){
				$('#lblCoordinador').show();
				$('#jefeOperar').show();
				consultaCoordinadores();
			}else{
				$('#lblCoordinador').hide();
				$('#jefeOperar').hide();
				consultaEmpleados();
			}
			
		}else{
			dwr.util.removeAllOptions('jefeOperar'); 
			dwr.util.addOptions('jefeOperar',{'0':'SELECCIONE UN COORDINADOR'});
			$('#divLogoEmpleados').hide();
			$('#divEmpleados').html('');
		}
	});
	
	$('#jefeOperar').change(function(){
		bloqueaPantalla('contenido', 'mensaje');
		consultaEmpleados();
	});
	
	$('#btnAltaEmpleado').click(function(){
		muestraAltaUsuario();
	});

	$('#btnBuscarEmpleado').click(function (){
		bloqueaPantalla('contenido','mensaje');
		consultaEmpleadoSap();
	});
	
	$('#btnAceptarAltaEmpleado').click(function(){
		if(validaAltaUsuario()){
			$('#nombreEmpleadoAlta').attr('disabled',false);
			$('#tipoOperacion').val(cat_Transacciones.altaUsuario);
			grabaTransaccionRecarga('mantenimientoUsuariosAvanteBean','contenido','mensaje','recargaExito','');
		}else{
			$('#nombreEmpleadoAlta').attr('disabled',true);
		}
		
	});
	
	$('#btnBajaEmpleado').click(function(){		
		if(validaSeccion()){
			if(validaBaja() > 0){
				$('#tipoOperacion').val(cat_Transacciones.bajaUsuario);
				grabaTransaccionRecarga('mantenimientoUsuariosAvanteBean','contenido','mensaje','recargaExito','');	
			}else{
				mensajeModal('contenido','Debe de seleccionar un Empleado.');
			}
		}
	});
	
	// Definicion de Metodos
	
	function consultaCoordinadores(){
		$('#divLogoEmpleados').hide();
		$('#divEmpleados').html('');
		var consultaCoordinadores	=	2;
		var	mantenimientoUsuariosAvanteBean ={
				'puestoOperar' 			:	$('#puestoOperar').val(),
				'empleadoOpera' 		: 	$('#empleadoOpera').val()
		}
		dwr.util.removeAllOptions('jefeOperar'); 
		dwr.util.addOptions('jefeOperar',{'0':'SELECCIONE UN COORDINADOR'});
		MantenimientoUsuariosAvanteServicioImpl.consulta(mantenimientoUsuariosAvanteBean,consultaCoordinadores, function(mantenimientoUsuariosAvante){
			if(mantenimientoUsuariosAvante.jefesAvante != null){
				dwr.util.addOptions('jefeOperar', mantenimientoUsuariosAvante.jefesAvante, 'numeroEmpleado','nombreEmpleado');
				if(mantenimientoUsuariosAvante.jefesAvante.length == 1){
					dwr.util.removeAllOptions('jefeOperar'); 
					dwr.util.addOptions('jefeOperar', mantenimientoUsuariosAvante.jefesAvante, 'numeroEmpleado','nombreEmpleado');
					consultaEmpleados();
				}else{
					desbloqueaPantalla('contenido');
				}
				
			}else{
				desbloqueaPantalla('contenido');
			}
		});
	}
	
	function consultaEmpleados(){
		var consultaEmpleados	=	3;
		
		var	mantenimientoUsuariosAvanteBean ={
				'puestoOperar' 			:	$('#puestoOperar').val(),
				'jefeOperar' 			:	$('#jefeOperar').val()
		}
		MantenimientoUsuariosAvanteServicioImpl.consulta(mantenimientoUsuariosAvanteBean,consultaEmpleados, function(mantenimientoUsuariosSap){
			if(mantenimientoUsuariosSap.empleadosAvante != null){
				var tablaEmpleados = creaEncabezadoTablaEmpleados();
				for (var i = 0; i < mantenimientoUsuariosSap.empleadosAvante.length; i++) {
					
					tablaEmpleados += creaFilaTablaEmpleados(mantenimientoUsuariosSap.empleadosAvante[i],i);
			    }
				
				tablaEmpleados	+= '</table><br>';
				$('#divConsultaEmpleados').show();
				$('#divLogoEmpleados').show();
				$('#divEmpleados').show();
				$('#divEmpleados').html(tablaEmpleados);
				desbloqueaPantalla('contenido');
			}else{
				desbloqueaPantalla('contenido');
			}
		});
		
	}
	
	function validaSeccion(operacion){
		if($('#puestoOperar').val() <= 0){
			mensajeModal('contenido','Debe de seleccionar un Puesto.');
			return false;
		}
		
		if($('#departamentoOperar').val() <=0){
			mensajeModal('contenido','Debe de seleccionar una Departamento.');
			return false;
		}

		if($('#puestoOperar').val() != 2001){
			if($('#jefeOperar').val() == 0){
				mensajeModal('contenido','Debe de seleccionar un Coordinador.');
				return false;
			}
		}
		
		return true;
	}
	
	function muestraAltaUsuario(){
		activaBoton('btnAltaEmpleado');
		$('#btnAceptarAltaEmpleado').hide();
		$('#divAltaUsuario').show();
		desbloqueaPantalla('contenido');
	}

	function activaBoton(nombreBoton){
		$('#btnAltaEmpleado').removeClass('btnActivo');
		$('#btnBajaEmpleado').removeClass('btnActivo');

		switch (nombreBoton) {
			case Cat_Acciones.AltaUsuario:
				$('#btnAltaEmpleado').addClass('btnActivo');
				break;
			case Cat_Acciones.BajaUsuario:
				$('#btnBajaEmpleado').addClass('btnActivo');	
				break;
			default:
				break;
		}
	}
	
	function validaAltaUsuario(){
		if($.trim($('#empleadoAlta').val()) == ''){
			mensajeModal('contenido','El Numero de Empleado no puede estar Vacio.');
			return false;
		}
		
		if($.trim($('#nombreEmpleadoAlta').val()) == ''){
			mensajeModal('contenido','El Nombre del Empleado no puede esta Vacio.');
			return false;
		}
		if($('#puestoOperar').val() <= 0){
			mensajeModal('contenido','Debe de seleccionar un Puesto.');
			return false;
		}

		if($('#puestoOperar').val() != 2001){
			if($('#jefeOperar').val() == 0){
				mensajeModal('contenido','Debe de seleccionar un Coordinador.');
				return false;
			}
		}
		
		return true;
	}
	
	function validaBaja(operacion){
		var checks = 0;
		$( "input[name^='empleadoConsulta']" ).each(function( index ) {
			var empleadoConsulta = "#empleadoConsulta"+index;
			
			if($(empleadoConsulta).is(":checked")){
				checks++;
			}
		});
		return checks;
	}
	
	function consultaEmpleadoSap(){
		DatosEmpleadoImpl.consultaEmpleadoSap($('#empleadoAlta').val(),function(empleadoSap){
			if(empleadoSap != null && empleadoSap.numeroEmpleado != 0){
				$('#btnAceptarAltaEmpleado').show();
				$('#nombreEmpleadoAlta').val(empleadoSap.nombreInicial+' '+empleadoSap.apellidoPaterno+' '+empleadoSap.apellidoMaterno);
				desbloqueaPantalla('contenido');
			}else{
				mensajeModal('contenido','No se encontro informacion del Empleado en SAP.');
				$('#btnAceptarAltaEmpleado').hide();
				$('#nombreEmpleadoAlta').val('');
			}
		});
	}
	
});

function creaEncabezadoTablaEmpleados(){
	var	tabla=	
		'<table class="tablaEmpleados">'
		+	'<tr>'
		+		'<td style="width: 5%;" class="tituloColumna">'
		+			'<label>SELECCIONAR</label>'
		+		'</td>'		
		+		'<td style="width: 10%;" class="tituloColumna">'
		+			'<label>EMPLEADO</label>'
		+		'</td>'
		+		'<td style="width: 25%; " class="tituloColumna">'
		+			'<label>NOMBRE</label>'
		+		'</td>'
		+		'<td style="width: 10%;" class="tituloColumna">'
		+			'<label>FECHA ALTA</label>'
		+		'</td>'
		+	'</tr>';
		return tabla;
}

function seleccionaBaja(numeroEmpleado,seleccion){
	$('#btnAltaEmpleado').removeClass('btnActivo');
	$('#divAltaUsuario').hide();
	$('#empleadoAlta').val('');
	$('#nombreEmpleadoAlta').val('');
	$('#empleadoBaja').val(numeroEmpleado);
	$( "input[name^='empleadoConsulta']" ).each(function( index ) {
		if(seleccion != index){
			$('#empleadoConsulta'+index).attr('checked',false);
		}
	});
}

function creaFilaTablaEmpleados(empleado,index){
	var colorTr = 'trOscuro';
	if(index%2==0){
		colorTr = 'trClaro';
	}
	
	var	fila=	'<tr class="'+colorTr+'">'
	+	'	<td class="columnaCentrada"><input id="empleadoConsulta'+index+'" name="empleadoConsulta" type="checkbox" onclick="seleccionaBaja('+empleado.numeroEmpleado+','+index+');"></td>'
	+	'	<td class="columnaCentrada"><label>'+empleado.numeroEmpleado+'</label></td>'
	+	'	<td class="columnaCentrada"><label>'+empleado.nombreEmpleado+'</label></td>'
	+	'	<td class="columnaCentrada"><label>'+empleado.fechaAlta+'</label></td>'		
	+	'</tr>';
	return fila;
}

function recargaExito(){
	$('#divEmpleados').html('');
	$('#divAltaUsuario').hide();
	$('#btnAltaEmpleado').removeClass('btnActivo');
	$('#empleadoAlta').val('');
	$('#nombreEmpleadoAlta').val('');
	$('#empleadoBaja').val('');
	$('#tipoOperacion').val('');
	$('#nombreEmpleadoAlta').attr('disabled',true);
	var consultaEmpleados	=	3;
	var	mantenimientoUsuariosAvanteBean ={
			'puestoOperar' 			:	$('#puestoOperar').val(),
			'jefeOperar' 			:	$('#jefeOperar').val()
	}
	MantenimientoUsuariosAvanteServicioImpl.consulta(mantenimientoUsuariosAvanteBean,consultaEmpleados, function(mantenimientoUsuariosSap){
		if(mantenimientoUsuariosSap.empleadosAvante != null){
			var tablaEmpleados = creaEncabezadoTablaEmpleados();
			for (var i = 0; i < mantenimientoUsuariosSap.empleadosAvante.length; i++) {
				
				tablaEmpleados += creaFilaTablaEmpleados(mantenimientoUsuariosSap.empleadosAvante[i],i);
		    }
			
			tablaEmpleados	+= '</table><br></fieldset>';
			$('#divEmpleados').html(tablaEmpleados);
			$('#divEmpleados').show();
			$('#divConsultaEmpleados').show();
		}
	});
}