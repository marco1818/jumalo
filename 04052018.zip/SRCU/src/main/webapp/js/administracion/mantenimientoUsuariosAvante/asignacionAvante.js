	// Definicion de Constantes
	
	var cat_Consultas	=	{
		'consultaCoordinadores'	:	2,
		'consultaRegiones'		:	3,
		'consultaGerencias'		:	4,
		'jefesCobranza'			:	5,
		'especialistas'			:	6
	}
	
	
$(document).ready(function(){

	// Definicion de Eventos
	$('#zonaOperar').change(function(){
		$('#txtZonaOperar').text('');
		$('#txtRegionOperar').text('');
		$('#txtGerenciaOperar').text('');
		if($('#zonaOperar').val()>0){
			bloqueaPantalla('contenido','mensaje');
			consultaCoordinadores();
		}else{
			dwr.util.removeAllOptions('coordinadorOperar'); 
			dwr.util.addOptions('coordinadorOperar',{'0':'SELECCIONE UN COORDINADOR'});
			$('#divRegiones').html('');
			$('#divRegionesOperar').hide();
			$('#divGerencias').html('');
			$('#divRegionOperar').hide();
			$('#divJefesCobranza').html('');
			$('#divJefesCobranzaOperar').hide();
		}
		
	});
	
	$('#coordinadorOperar').change(function(){
		if($('#coordinadorOperar').val() !='0'){
			bloqueaPantalla('contenido','mensaje');
			consultaRegiones();
		}else{
			$('#divRegiones').html('');
			$('#divRegionesOperar').hide();
			$('#divGerencias').html('');
			$('#divRegionOperar').hide();
			$('#divJefesCobranza').html('');
			$('#divJefesCobranzaOperar').hide();
		}
	});
	
	$('#btnRegresarRegiones').click(function (){
		bloqueaPantalla('contenido','mensaje');
		$('#divGerencias').html('');
		$('#divRegionOperar').hide();
		$('#txtRegionOperar').text('');
		consultaRegiones();
	});
	
	$('#btnRegresarGerencia').click(function (){		
		bloqueaPantalla('contenido','mensaje');
		$('#divJefesCobranza').html('');
		$('#divJefesCobranzaOperar').hide();
		$('#txtGerenciaOperar').text('');
		consultaGerencias($('#regionOperar').val(),$('#txtEspecialistasAsignados').text(),$('#txtRegionOperar').text());
	});
	
	$('#btnAceptarAsignacion').click(function(){
		$('#tipoOperacion').val("1");
		grabaTransaccionRecarga('asignacionAvanteBean','contenido','mensaje','funcionRecarga','');
	});
	
	// Definicion de Metodos
	function consultaCoordinadores(){
		$('#divRegiones').html('');
		$('#divRegionesOperar').hide();
		$('#divGerencias').html('');
		$('#divRegionOperar').hide();
		$('#divJefesCobranza').html('');
		$('#divJefesCobranzaOperar').hide();
		
		var asignacionAvanteBean = {
		}
		
		dwr.util.removeAllOptions('coordinadorOperar'); 
		dwr.util.addOptions('coordinadorOperar',{'0':'SELECCIONE UN COORDINADOR'});
		AsignacionAvanteServicioImpl.consulta(asignacionAvanteBean,cat_Consultas.consultaCoordinadores, function(asignacionAvante){
			if(asignacionAvante.coordinadores.length > 0){
				dwr.util.addOptions('coordinadorOperar', asignacionAvante.coordinadores, 'numeroEmpleado','nombreEmpleado');
				desbloqueaPantalla('contenido');
			}else{
				desbloqueaPantalla('contenido');
			}
		});
	}
	
	function consultaRegiones(){

		$('#divGerencias').html('');
		$('#divRegionOperar').hide();
		$('#divJefesCobranza').html('');
		$('#divJefesCobranzaOperar').hide();
		
		var asignacionAvanteBean = {
			'coordinadorOperar' : 	$('#coordinadorOperar').val(),
			'zonaOperar'		:	$('#zonaOperar').val()
		}

		AsignacionAvanteServicioImpl.consulta(asignacionAvanteBean,cat_Consultas.consultaRegiones, function(asignacionAvante){
			if(asignacionAvante.regiones.length > 0){
				var tablaRegiones = crearEncabezadoTablaRegiones();
				for (var i = 0; i < asignacionAvante.regiones.length; i++) {
					tablaRegiones += creaFilaRegiones(asignacionAvante.regiones[i],i);
					
				}
				tablaRegiones	+= '</table><br>';
				$('#txtZonaOperar').text($('#zonaOperar option:selected').text());
				$('#divRegiones').html(tablaRegiones);
				$('#divRegiones').show();
				$('#divRegionesOperar').show();
				desbloqueaPantalla('contenido');
			}else{
				desbloqueaPantalla('contenido');
			}
		});
	}

	function crearEncabezadoTablaRegiones(){
		var encabezado =	'<table class="tablaRegiones">'
			+				'<tr>'
			+					'<td class="tituloColumna" width="16%">'
			+						'<label>Region</label>'		
			+					'</td>'
			+					'<td class="tituloColumna" width="8%">'
			+						'<label>Total Clientes<br>Foco al Fraude</label>'
			+					'</td>'
			+					'<td class="tituloColumna" width="8%">'
			+						'<label>Pagos Parciales</label>'
			+					'</td>'
			+					'<td class="tituloColumna" width="8%">'
			+						'<label>Nunca Abonados</label>'
			+					'</td>'
			+					'<td class="tituloColumna" width="12%">'
			+						'<label>Saldo Original</label>'
			+					'</td>'
			+					'<td class="tituloColumna" width="13%">'
			+						'<label>Saldo Atrasado</label>'
			+					'</td>'			
			+					'<td class="tituloColumna" width="13%">'
			+						'<label>Moratorios</label>'
			+					'</td>'
			+					'<td class="tituloColumna" width="15%">'
			+						'<table width="100%">'
			+							'<tr>'
			+								'<td colspan="2">'
			+									'<label>Especialistas</label>'
			+								'</td>'
			+							'</tr>'
			+							'<tr>'
			+								'<td>'
			+									'<label>Asignados</label>'
			+								'</td>'
			+								'<td>'
			+									'<label>No Asignaddos</label>'
			+								'</td>'
			+							'</tr>'
			+						'</table>'
			+					'</td>'
			+					'<td class="tituloColumna" width="6%">'
			+						'<label>Seleccionar</label>'
			+					'</td>'
			+				'</tr>';
		
		return encabezado;
	}
	
	function creaFilaRegiones(region, index){
		var colorTr = 'trOscuro';
		if(index%2==0){
			colorTr = 'trClaro';
		}
		
		var	fila=	'<tr class="'+colorTr+'">'
				+		'<td class="columnaIzquierda">'
				+			'<label>'+region.descripcionDepto+'</label>'
				+		'</td>'
				+		'<td class="columnaCentrada">'
				+			'<label>'+region.clientesFocoFraude+'</label>'
				+		'</td>'
				+		'<td class="columnaCentrada">'
				+			'<label>'+region.pagosParciales+'</label>'
				+		'</td>'
				+		'<td class="columnaCentrada">'
				+			'<label>'+region.pagosNoAbonados+'</label>'
				+		'</td>'
				+		'<td class="columnaCentrada">'
				+			'<label name="saldos">'+formatCurrency(region.saldo)+'</label>'
				+		'</td>'
				+		'<td class="columnaCentrada">'
				+			'<label>'+formatCurrency(region.saldoAtrasado)+'</label>'
				+		'</td>'				
				+		'<td class="columnaCentrada">'
				+			'<label>'+formatCurrency(region.moratorios)+'</label>'
				+		'</td>'
				+		'<td class="columnaCentrada">'
				+			'<table width="100%">'
				+				'<tr>'
				+					'<td width="50%" style="border-right: 1px solid #ccd5de;">'
				+						'<label>'+region.especialistasAsignados+'</label>'
				+					'</td>'
				+					'<td width="50%">'
				+						'<label>'+region.especialistasNoAsignados+'</label>'
				+					'</td>'
				+				'</tr>'
				+			'</table>'
				+		'</td>'
				+		'<td class="columnaCentrada">'
				+			'<img class="img" src="/SRCU/imagenes/administracion/mantenimientoUsuariosAvante/asignacionAvante/editar.png" height="15px" onclick="consultaGerencias('+region.departamentoId+','+region.especialistasNoAsignados+',\''+region.descripcionDepto+'\')">'
				+		'</td>'
				+	'</tr>'
		return fila;
	}
		
});
	
function consultaGerencias(departamentoId,noAsignados,descripcionDepartamento){
	bloqueaPantalla('contenido','mensaje');
	$('#regionOperar').val(departamentoId);	
	$('#txtRegionOperar').text(descripcionDepartamento);
	$('#txtEspecialistasAsignados').text(noAsignados);
	$('#divRegionesOperar').hide();
	$('#divRegiones').html('');
	$('#txtGerenciaOperar').val();
	
	var asignacionAvanteBean = {
		'coordinadorOperar'	:	$('#coordinadorOperar').val(),
		'regionOperar'		:	$('#regionOperar').val()
	}

	AsignacionAvanteServicioImpl.consulta(asignacionAvanteBean,cat_Consultas.consultaGerencias, function(asignacionAvante){
		if(asignacionAvante.gerencias.length > 0){
			var tablaGerencias = crearEncabezadoTablaGerencias();
			for (var i = 0; i < asignacionAvante.gerencias.length; i++) {
				tablaGerencias += creaFilaGerencias(asignacionAvante.gerencias[i],i);
				
			}
			tablaGerencias	+= '</table><br>';
			$('#divGerencias').html(tablaGerencias);
			$('#divRegionOperar').show();
			$('#divGerencias').show();
			desbloqueaPantalla('contenido');
		}else{
			desbloqueaPantalla('contenido');
		}
	});
}

function consultaJefesCobranza(departamentoId,descripcionDepartamento){
	bloqueaPantalla('contenido','mensaje');
	$('#gerenciaOperar').val(departamentoId);
	$('#txtGerenciaOperar').text(descripcionDepartamento);
	$('#divRegionOperar').hide();
	$('#divGerencias').html('');
	
	var asignacionAvanteBean = {
		'gerenciaOperar' : $('#gerenciaOperar').val(),
		'coordinadorOperar'	:	$('#coordinadorOperar').val()
	}

	AsignacionAvanteServicioImpl.consulta(asignacionAvanteBean,cat_Consultas.jefesCobranza, function(asignacionAvante){
		if(asignacionAvante.jefesCobranza.length > 0){
			var tablaJefesCobranza = crearEncabezadoTablaJefesCobranza();
			for (var i = 0; i < asignacionAvante.jefesCobranza.length; i++) {
				tablaJefesCobranza += creaFilaJefesCobranza(asignacionAvante.jefesCobranza[i],i);
				
			}
			tablaJefesCobranza	+= '</table><br>';
			$('#divJefesCobranza').html(tablaJefesCobranza);
			$('#divJefesCobranza').show();
			$('#divJefesCobranzaOperar').show();
			seleccionaEspecialista();
			desbloqueaPantalla('contenido');
		}else{
			desbloqueaPantalla('contenido');
		}
	});
}
	
function crearEncabezadoTablaGerencias(){
	var encabezado =	'<table class="tablaGerencias">'
		+				'<tr>'
		+					'<td class="tituloColumna" width="17%">'
		+						'<label>Gerencia</label>'
		+					'</td>'
		+					'<td class="tituloColumna" width="9%">'
		+						'<label>Total Clientes<br>Foco al Fraude</label>'
		+					'</td>'
		+					'<td class="tituloColumna" width="8%">'
		+						'<label>Pagos Parciales</label>'
		+					'</td>'
		+					'<td class="tituloColumna" width="8%">'
		+						'<label>Nunca Abonados</label>'
		+					'</td>'
		+					'<td class="tituloColumna" width="12%">'
		+						'<label>Saldo Original</label>'
		+					'</td>'
		+					'<td class="tituloColumna" width="13%">'
		+						'<label>Saldo Atrasado</label>'
		+					'</td>'			
		+					'<td class="tituloColumna" width="13%">'
		+						'<label>Moratorios</label>'
		+					'</td>'
		+					'<td class="tituloColumna" width="17%">'
		+						'<label># Especialistas<br>Asignados</label>'
		+					'</td>'
		+					'<td class="tituloColumna" width="7%">'
		+						'<label>Seleccionar</label>'
		+					'</td>'
		+				'</tr>'
	
	return encabezado;
}
	
function creaFilaGerencias(gerencia, index){
	var colorTr = 'trOscuro';
	if(index%2==0){
		colorTr = 'trClaro';
	}
	
	var	fila=	'<tr class="'+colorTr+'">'
			+		'<td class="columnaIzquierda">'
			+			'<label>'+gerencia.descripcionDepto+'</label>'
			+		'</td>'
			+		'<td class="columnaCentrada">'
			+			'<label>'+gerencia.clientesFocoFraude+'</label>'
			+		'</td>'
			+		'<td class="columnaCentrada">'
			+			'<label>'+gerencia.pagosParciales+'</label>'
			+		'</td>'
			+		'<td class="columnaCentrada">'
			+			'<label>'+gerencia.pagosNoAbonados+'</label>'
			+		'</td>'
			+		'<td class="columnaCentrada">'
			+			'<label>'+formatCurrency(gerencia.saldo)+'</label>'
			+		'</td>'
			+		'<td class="columnaCentrada">'
			+			'<label>'+formatCurrency(gerencia.saldoAtrasado)+'</label>'
			+		'</td>'				
			+		'<td class="columnaCentrada">'
			+			'<label>'+formatCurrency(gerencia.moratorios)+'</label>'
			+		'</td>'
			+		'<td class="columnaCentrada">'
			+			'<label>'+gerencia.especialistasAsignados+'</label>'
			+		'</td>'
			+		'<td class="columnaCentrada">'
			+			'<img class="img" src="/SRCU/imagenes/administracion/mantenimientoUsuariosAvante/asignacionAvante/editar.png" height="15px" onclick="consultaJefesCobranza('+gerencia.departamentoId+',\''+gerencia.descripcionDepto+'\')">'
			+		'</td>'
			+	'</tr>'
	return fila;
}

function crearEncabezadoTablaJefesCobranza(){
	var encabezado =	'<table class="tablaGerencias">'
		+				'<tr>'
		+					'<td class="tituloColumna" width="17%">'
		+						'<label>Jefe de Cobranza</label>'
		+					'</td>'
		+					'<td class="tituloColumna" width="9%">'
		+						'<label>Segmento</label>'
		+					'</td>'		
		+					'<td class="tituloColumna" width="9%">'
		+						'<label>Total Clientes<br>Foco al Fraude</label>'
		+					'</td>'
		+					'<td class="tituloColumna" width="8%">'
		+						'<label>Pagos Parciales</label>'
		+					'</td>'
		+					'<td class="tituloColumna" width="8%">'
		+						'<label>Nunca Abonados</label>'
		+					'</td>'
		+					'<td class="tituloColumna" width="13%">'
		+						'<label>Saldo Original</label>'
		+					'</td>'
		+					'<td class="tituloColumna" width="13%">'
		+						'<label>Saldo Atrasado</label>'
		+					'</td>'			
		+					'<td class="tituloColumna" width="13%">'
		+						'<label>Moratorios</label>'
		+					'</td>'
		+					'<td class="tituloColumna" width="17%">'
		+						'<label>Asignar Especialista</label>'
		+					'</td>'
		+				'</tr>'
	
	return encabezado;
}
	
function creaFilaJefesCobranza(jefeCobranza, index){
	var colorTr = 'trOscuro';
	if(index%2==0){
		colorTr = 'trClaro';
	}
	
	var	fila=	'<tr class="'+colorTr+'">'
			+		'<td class="columnaIzquierda">'
			+			'<label>'+jefeCobranza.numeroEmpleado+'-'+jefeCobranza.nombreEmpleado+'</label>'
			+			'<input type="hidden" id="jcsAsignar'+index+'" name="jcsAsignar" value="'+jefeCobranza.numeroEmpleado+'"  >'
			+		'</td>'
			+		'<td class="columnaCentrada">'
			+			'<label>'+jefeCobranza.descripcionSegmento+'</label>'
			+		'</td>'
			+		'<td class="columnaCentrada">'
			+			'<label>'+jefeCobranza.clientesFocoFraude+'</label>'
			+		'</td>'
			+		'<td class="columnaCentrada">'
			+			'<label>'+jefeCobranza.pagosParciales+'</label>'
			+		'</td>'
			+		'<td class="columnaCentrada">'
			+			'<label>'+jefeCobranza.pagosNoAbonados+'</label>'
			+		'</td>'
			+		'<td class="columnaCentrada">'
			+			'<label>'+formatCurrency(jefeCobranza.saldo)+'</label>'
			+		'</td>'				
			+		'<td class="columnaCentrada">'
			+			'<label>'+formatCurrency(jefeCobranza.saldoAtrasado)+'</label>'
			+		'</td>'
			+		'<td class="columnaCentrada">'
			+			'<label>'+formatCurrency(jefeCobranza.moratorios)+'</label>'
			+		'</td>'
			+		'<td class="columnaCentrada">'
			+			'<select id="especialistaAsignar'+index+'" name="especialistaAsignar" onchange="consultaEspecialista('+jefeCobranza.numeroEmpleado+','+index+')">'
			+			'<input type="hidden" id="espeacialistaAsignado'+index+'" name="espeacialistaAsignado" value="'+$.trim(jefeCobranza.especialistaAsignado)+'"  >'
			+		'</td>'
	return fila;
}

function seleccionaEspecialista(){
	var asignacionAvanteBean = {
		'coordinadorOperar' : 	$('#coordinadorOperar').val(),
		'regionOperar'		:	$('#regionOperar').val()
	}
	
	AsignacionAvanteServicioImpl.consulta(asignacionAvanteBean,cat_Consultas.especialistas, function(asignacionAvante){
		if(asignacionAvante.especialistasRegion.length > 0){
			$( "select[name^='especialistaAsignar']" ).each(function( index ) {
				var comboEspecialista = "especialistaAsignar"+index;
				dwr.util.removeAllOptions(comboEspecialista); 
				dwr.util.addOptions(comboEspecialista,{'0':'SIN ASIGNAR'});
				dwr.util.addOptions(comboEspecialista, asignacionAvante.especialistasRegion, 'numeroEmpleado','nombreEmpleado');
				$('#'+comboEspecialista).val($('#espeacialistaAsignado'+index).val());
			});
			
			
		}
	});
	

}



function funcionRecarga(){
	$('#gerenciaOperar').val($('#gerenciaOperar').val());
	//$('#txtGerenciaOperar').text($('#txtGerenciaOperar').val());
	$('#divRegionOperar').hide();
	$('#divGerencias').html('');
	
	var asignacionAvanteBean = {
		'gerenciaOperar' : $('#gerenciaOperar').val(),
		'coordinadorOperar'	:	$('#coordinadorOperar').val()
	}

	AsignacionAvanteServicioImpl.consulta(asignacionAvanteBean,cat_Consultas.jefesCobranza, function(asignacionAvante){
		if(asignacionAvante.jefesCobranza.length > 0){
			var tablaJefesCobranza = crearEncabezadoTablaJefesCobranza();
			for (var i = 0; i < asignacionAvante.jefesCobranza.length; i++) {
				tablaJefesCobranza += creaFilaJefesCobranza(asignacionAvante.jefesCobranza[i],i);
				
			}
			tablaJefesCobranza	+= '</table><br>';
			$('#divJefesCobranza').html(tablaJefesCobranza);
			$('#divJefesCobranza').show();
			$('#divJefesCobranzaOperar').show();
			seleccionaEspecialista();
		}
	});
}