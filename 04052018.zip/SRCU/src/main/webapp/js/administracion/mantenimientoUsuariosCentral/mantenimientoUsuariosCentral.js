$(document).ready(function (){
	var cat_Consultas	=	{
			'datosEmpleado'	:	1
	}
	
	$('#aceptarAlert').click(function(){
		$('#contenido').unblock();
	});
	
	$('#numeroEmpleado').keyup(function(){
		$('#nombreEmpleado').val('');
		$('#puesto').val('');
		$('#departamento').val('');
		$('#btnReiniciar').hide();
		$('#btnDesbloquear').hide();
	});
	
	$('#btnBuscarEmpleado').click(function(){
		bloqueaPantalla('contenido','mensaje');
		consultaEmpleado();
	});
	
	$('#btnReiniciar').click(function(){
		bloqueaPantalla('contenido','mensaje');
		cifrar();
		$('#tipoOperacion').val(1);
		grabaTransaccionRecarga('mantenimientoUsuariosCentralBean','contenido','mensaje','','');
	});
	
	$('#btnDesbloquear').click(function(){
		bloqueaPantalla('contenido','mensaje');
		$('#tipoOperacion').val(2);
		grabaTransaccionRecarga('mantenimientoUsuariosCentralBean','contenido','mensaje','','');
	});
	
	function consultaEmpleado(){
		var mantenimientoUsuariosCentralBean = {
				'numeroEmpleado' : 	$('#numeroEmpleado').val()
			}
		
		MantenimientoUsuariosCentralServicioImpl.consulta(mantenimientoUsuariosCentralBean, cat_Consultas.datosEmpleado, function(mantenimientoUsuariosCentral){
			var datosEmpleado = mantenimientoUsuariosCentral.datosEmpleado;
			if(datosEmpleado.idMensaje != 0 ){
				$('#nombreEmpleado').val(datosEmpleado.nombreEmpleado);
				$('#puesto').val(datosEmpleado.puestoId+'-'+datosEmpleado.puestoDesc);
				$('#departamento').val(datosEmpleado.deptoId+'-'+datosEmpleado.deptoDesc);
				$('#btnReiniciar').show();
				$('#btnDesbloquear').show();
				desbloqueaPantalla('contenido');
			}else{
				mensajeModal('contenido','No se encontro informacion del empleado.');
				$('#nombreEmpleado').val('');
				$('#puesto').val('');
				$('#departamento').val('');
				$('#btnReiniciar').hide();
				$('#btnDesbloquear').hide();
			}
		});
	}
	
	function cifrar(){
		$('#pwdSha').val(sha256($('#numeroEmpleado').val()));
		alert(sha256($('#numeroEmpleado').val()));
	}
	
});