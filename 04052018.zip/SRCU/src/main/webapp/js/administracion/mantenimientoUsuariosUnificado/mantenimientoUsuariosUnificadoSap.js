$(document).ready(function(){
	$('#tdAltaVacante').hide();
	$('#tdAltausuario').hide();
	$('#tdBajaUsuario').hide();
	$('#tdCambiaEmpleado').hide();
	
	// DEFINICION DE EVENTOS
	$('#aceptarAlert').click(function(){
		$('#contenido').unblock();
	});
	
	$('#puestoOperar').change(function (){
		bloqueaPantalla('contenido','mensaje');
		recargaForm();
		$('#tdAltaVacante').hide();
		$('#tdAltausuario').hide();
		$('#tdBajaUsuario').hide();
		$('#tdCambiaEmpleado').hide();
		consultaDepartamentos();
	});
	
	$('#departamentoOperar').change(function(){
		bloqueaPantalla('contenido','mensaje');
		recargaForm();
		$('#tdAltaVacante').show();
		$('#tdAltausuario').show();
		$('#tdBajaUsuario').hide();
		$('#tdCambiaEmpleado').hide();
		consultaEmpleados();
	});
	
	$('#btnAltaVacante').click(function(){
		if(validaAlta()){
			bloqueaPantalla('contenido','mensaje');
			ocultaAltaEmpleado();
			ocultaCambioEmpleado();			
			consultaEmpleados();
			$('#tdBajaUsuario').hide();
			$('#tdCambiaEmpleado').hide();
			consultaVacantesxPuesto('segmentoVacante','#divSegmentosVacante',4);			
		}

	});
	
	$('#btnAceptarVacante').click(function(){
		
		if($('#segmentoVacante').val() > 0){
			$('#tipoOperacion').val("1");
			$('#segmentoOperar').val($("#segmentoVacante").val());
			grabaTransaccionRecarga('mantenimientoUsuariosUnificadoBean','contenido','mensaje','exitoAlta','');
		}else{
			mensajeModal('contenido','Debe de seleccionar un Segmento.');
			$('#tipoOperacion').val("0");
		}
		
	});
	
	$('#btnAltaEmpleado').click(function(){
		if(validaAlta()){
			bloqueaPantalla('contenido','mensaje');
			ocultaAltaVacante();
			ocultaCambioEmpleado();
			consultaEmpleados();			
			$('#tdBajaUsuario').hide();
			$('#tdCambiaEmpleado').hide();
			consultaVacantesxPuesto('segmentoEmpleado','#divAltaEmpleado',5);			
		}
	});
	
	$('#btnBuscarEmpleado').click(function(){
		bloqueaPantalla('contenido','mensaje');
		consultaEmpleadoSap();
	});
	
	$('#btnAltaEmpleadoAceptar').click(function(){
		if($('#segmentoEmpleado').val() > 0){
			if($.trim($('#empleadoAlta').val()) != ''){
				$('#tipoOperacion').val("2");
				$('#segmentoOperar').val($("#segmentoEmpleado").val());
				grabaTransaccionRecarga('mantenimientoUsuariosUnificadoBean','contenido','mensaje','exitoAlta','');
			}else{
				mensajeModal('contenido','Debe Introducir un Numero de Empleado Valido.');
				$('#tipoOperacion').val("0");
			}
			
		}else{
			mensajeModal('contenido','Debe de seleccionar un Segmento.');
			$('#tipoOperacion').val("0");
		}
		
		
	});
	
	$('#empleadoAlta').keyup(function(){
		$('#nombreEmpleadoAlta').val('');
		$('#btnAltaEmpleadoAceptar').hide();
	});
	
	$('#btnBajaEmpleado').click(function(){
		$('#tipoOperacion').val("3");
		grabaTransaccionRecarga('mantenimientoUsuariosUnificadoBean','contenido','mensaje','exitoAlta','');
	});
	
	$('#btnCambioEmpleado').click(function(){
		bloqueaPantalla('contenido','mensaje');
		consultaCambioEmpleado();
	});
	
	$('#btnBuscarEmpleadoCambio').click(function(){
		bloqueaPantalla('contenido','mensaje');
		consultaBajaxSustitucion();
	});
	
	$('#empleadoBajaxSustitucion').keyup(function(){
		$('#empleadoDestinoBS').val('');
	});
	
	$('#btnAceptarBajaxSustitucion').click(function (){
		if($.trim($('#empleadoDestinoBS').val()) != ''){
			$('#tipoOperacion').val("4");
			grabaTransaccionRecarga('mantenimientoUsuariosUnificadoBean','contenido','mensaje','exitoCambioEmpleado','');
		}else{
			mensajeModal('contenido','Debe Seleccionar Introducir un Numero de Empleado Valido.');
		}
		
	});
	
	
	$('#btnCancelarBajaxSustitucion').click(function (){
		cancelarCambio();
	});
	
	$('#btnCancelarCambio').click(function (){
		cancelarCambio();
	});
	
	$('#btnAceptarCambio').click(function (){
		if(validaCambioEmpleado()){
			$('#tipoOperacion').val("5");
			grabaTransaccionRecarga('mantenimientoUsuariosUnificadoBean','contenido','mensaje','exitoCambioEmpleado','');
		}else{
			mensajeModal('contenido','Debe Seleccionar un Empleado.');
		}
		
		
	});
		
	// DEFINICION DE METODOS
	function consultaDepartamentos(){
		var mantenimientoUsuariosUnificadoBean	=	{
			'puestoOperar'	:	$('#puestoOperar').val(),
			'puestoOpera'	:	$('#puestoOpera').val(),
			'empleadoOpera'	:	$('#empleadoOpera').val()
		}
		dwr.util.removeAllOptions('departamentoOperar'); 
		dwr.util.addOptions('departamentoOperar',{'0':'SELECCIONE UN DEPARTAMENTO'});
		
		MantenimientoUsuariosUnificadoServicioImpl.consulta(mantenimientoUsuariosUnificadoBean,2,function(mantenimientoUsuariosUnificado){
			
			if(mantenimientoUsuariosUnificado.departamentos.length > 0){
				dwr.util.addOptions('departamentoOperar', mantenimientoUsuariosUnificado.departamentos, 'departamentoId','descripcion');
				desbloqueaPantalla('contenido');
			}else{
				desbloqueaPantalla('contenido');
			}
		});
	}
	

	
	function consultaVacantesxPuesto(idCombo,idDiv,consulta){
		var tipoConsulta = 0;
		var mantenimientoUsuariosUnificadoBean	=	{
				'puestoOperar'			:	$('#puestoOperar').val()
			}
		
		dwr.util.removeAllOptions(idCombo); 
		dwr.util.addOptions(idCombo,{'0':'SELECCIONE UN SEGMENTO'});
		$(idDiv).show();
		
		MantenimientoUsuariosUnificadoServicioImpl.consulta(mantenimientoUsuariosUnificadoBean,consulta,function(mantenimientoUsuariosUnificado){
			if(mantenimientoUsuariosUnificado.vacantesxPuesto.length > 0){
				dwr.util.addOptions(idCombo, mantenimientoUsuariosUnificado.vacantesxPuesto, 'segmentoId','segmentoDesc');
				desbloqueaPantalla('contenido');
			}else{
				desbloqueaPantalla('contenido');
			}
		});

	}
	
	function consultaEmpleadoSap(){
		DatosEmpleadoImpl.consultaEmpleadoSap($('#empleadoAlta').val(),function(empleadoSap){
			if(empleadoSap != null && empleadoSap.numeroEmpleado != 0){
				$('#btnAltaEmpleadoAceptar').show();
				$('#nombreEmpleadoAlta').val(empleadoSap.nombreInicial+' '+empleadoSap.apellidoPaterno+' '+empleadoSap.apellidoMaterno);
				desbloqueaPantalla('contenido');
			}else{
				mensajeModal('contenido','No se encontro informacion del Empleado en SAP.');
				$('#btnAltaEmpleadoAceptar').hide();
				$('#nombreEmpleadoAlta').val('');
			}
		});
	}
	
	function	recargaForm(){
		ocultaAltaEmpleado();
		ocultaAltaVacante();
		ocultaConsultaEmpleados();
		ocultaCambioEmpleado();		
	}
	
	function	validaAlta(){
		if($('#puestoOperar').val() <= 0	){
			mensajeModal('contenido','Debe Seleccionar un Puesto.');
			return false;
		}
		
		if($('#departamentoOperar').val() <= 0	){
			mensajeModal('contenido','Debe Seleccionar un Departamento.');
			return false;
		}
		return true;
	}
	
	function consultaCambioEmpleado(){
		
		var mantenimientoUsuariosUnificadoBean	=	{
				'departamentoOperar'		:	$('#departamentoOperar').val(),
				'empleadoConsulta'			:	$('#empleadoConsultar').val()
			}
		var tablaEmpleados = creaEncabezadoTablaNuevosEmpleados();
		MantenimientoUsuariosUnificadoServicioImpl.consulta(mantenimientoUsuariosUnificadoBean,7,function(mantenimientoUsuariosUnificado){
			$('#divEmpleados').html('');
			$('#divConsultaEmpleados').hide();
			$('#lblEmpleadoCambio').text(mantenimientoUsuariosUnificado.datosEmpleado.numeroEmpleado);
			$('#lblNombreCambio').text(mantenimientoUsuariosUnificado.datosEmpleado.nombreEmpleado);
			$('#lblPuestoCambio').text(mantenimientoUsuariosUnificado.datosEmpleado.puestoId);
			$('#lblSegmentoCambio').text(mantenimientoUsuariosUnificado.datosEmpleado.puestoDesc);
			$('#lblFechaCambio').text(mantenimientoUsuariosUnificado.datosEmpleado.fechaAlta);
			// Campos para tratar la Baja x Sustitucion
			$('#empleadoOrigenBS').val(mantenimientoUsuariosUnificado.datosEmpleado.numeroEmpleado);
			$('#puestoOrigenBS').val(mantenimientoUsuariosUnificado.datosEmpleado.puestoId);
			$('#puestoDestinoBS').val(mantenimientoUsuariosUnificado.datosEmpleado.puestoId);
			$('#segmentoDestinoBS').val(mantenimientoUsuariosUnificado.datosEmpleado.segmento);
			// Campos para tratar el cambio de Usuario
			$('#empleadoOrigenCE').val(mantenimientoUsuariosUnificado.datosEmpleado.numeroEmpleado);
			$('#puestoOrigenCE').val(mantenimientoUsuariosUnificado.datosEmpleado.puestoId);
			$('#segmentoOrigenCE').val(mantenimientoUsuariosUnificado.datosEmpleado.segmento);
			
			if(mantenimientoUsuariosUnificado.empleados.length > 0){
				for (var i = 0; i < mantenimientoUsuariosUnificado.empleados.length; i++) {
					tablaEmpleados += creaFilaTablaEmpleadosNuevos(mantenimientoUsuariosUnificado.empleados[i],i);
			    }
				tablaEmpleados	+= '</table><br>';
			}
			$('#divConsultaEmpleadosCambio').html(tablaEmpleados);
			$('#divCambiosEmpleado').show();
			$('#divCambioPuesto').show();
			desbloqueaPantalla('contenido');
		});
		
	}
	
	function consultaBajaxSustitucion(){
		var mantenimientoUsuariosUnificadoBean	=	{
				'empleadoConsulta'		:	$('#empleadoBajaxSustitucion').val()
			}
		
		MantenimientoUsuariosUnificadoServicioImpl.consulta(mantenimientoUsuariosUnificadoBean,6,function(mantenimientoUsuariosUnificado){
			$('#lblEmpleadoBajaxSustitucion').text(mantenimientoUsuariosUnificado.datosEmpleado.numeroEmpleado);
			$('#lblNombreBajaxSustitucion').text(mantenimientoUsuariosUnificado.datosEmpleado.nombreEmpleado);
			$('#lblPuestoBajaxSustitucion').text(mantenimientoUsuariosUnificado.datosEmpleado.puestoId);
			$('#lblSegmentoBajaxSustitucion').text(mantenimientoUsuariosUnificado.datosEmpleado.puestoDesc);
			$('#lblFechaBajaxSustitucion').text(mantenimientoUsuariosUnificado.datosEmpleado.fechaAlta);
			$('#empleadoDestinoBS').val(mantenimientoUsuariosUnificado.datosEmpleado.numeroEmpleado);
			$('#divConsultaEmpleadosCambio').html('');
			$('#divCambiosEmpleado').hide();
			$('#divBajaxSustitucion').show();
			desbloqueaPantalla('contenido');
		});
	}
	
});

function consultaEmpleados(){
	var mantenimientoUsuariosUnificadoBean	=	{
			'puestoOperar'			:	$('#puestoOperar').val(),
			'departamentoOperar'	:	$('#departamentoOperar').val()
		}
	var tablaEmpleados = creaEncabezadoTablaEmpleados();
	MantenimientoUsuariosUnificadoServicioImpl.consulta(mantenimientoUsuariosUnificadoBean,3,function(mantenimientoUsuariosUnificado){
		if(mantenimientoUsuariosUnificado.empleados.length > 0){
			
			for (var i = 0; i < mantenimientoUsuariosUnificado.empleados.length; i++) {
				tablaEmpleados += creaFilaTablaEmpleados(mantenimientoUsuariosUnificado.empleados[i],i);
		    }
			tablaEmpleados	+= '</table><br>';
			$('#divEmpleados').html(tablaEmpleados);
			$('#divEmpleados').show();
			$('#divConsultaEmpleados').show();
			desbloqueaPantalla('contenido');
		}else{
			tablaEmpleados	+= '</table><br>';
			$('#divEmpleados').html(tablaEmpleados);
			$('#divEmpleados').show();
			$('#divConsultaEmpleados').show();
			desbloqueaPantalla('contenido');
		}
	});
	
}

function seleccionaEmpleado(seleccion,empleado,segmentoOrigen,puestoOrigen){
	$('#divSegmentosVacante').hide();
	dwr.util.removeAllOptions('segmentoVacante');
	$('#divAltaEmpleado').hide();
	$('#empleadoAlta').val('');
	$('#nombreEmpleadoAlta').val('');
	dwr.util.removeAllOptions('segmentoEmpleado');
	
	$( "input[name^='empleadoConsulta']" ).each(function( index ) {
		if(seleccion == index){
			$('#empleadoBaja').val(empleado);
			$('#segmentoOrigen').val(segmentoOrigen);
			$('#puestoOrigen').val(puestoOrigen);
			$('#empleadoConsultar').val(empleado);
		}else{
			$('#empleadoConsulta'+index).attr('checked',false);
		}
	});
	
	if(muestraAcciones() > 0){
		$('#tdBajaUsuario').show();
		$('#tdCambiaEmpleado').show();
	}else{
		$('#tdBajaUsuario').hide();
		$('#tdCambiaEmpleado').hide();
	}
}

function muestraAcciones(){
	var checks = 0;
	$( "input[name^='empleadoConsulta']" ).each(function( index ) {
		var empleadoSeleccionado = "#empleadoConsulta"+index;
		
		if($(empleadoSeleccionado).is(":checked")){
			checks++;
		}
	});
	
	return checks;
}

function creaEncabezadoTablaEmpleados(){
	var	tabla=	
		'<table class="tablaEmpleados">'
		+	'<tr>'
		+		'<td style="width: 7%;" class="tituloColumna">'
		+			'<label>SELECCIONAR</label>'
		+		'</td>'		
		+		'<td style="width: 12%;" class="tituloColumna">'
		+			'<label>EMPLEADO</label>'
		+		'</td>'
		+		'<td style="width: 24%; " class="tituloColumna">'
		+			'<label>NOMBRE</label>'
		+		'</td>'
		+		'<td style="width: 24%;" class="tituloColumna">'
		+			'<label>GERENCIA</label>'
		+		'</td>'
		+		'<td style="width: 13%;" class="tituloColumna">'
		+			'<label>PUESTO</label>'
		+		'</td>'
		+		'<td style="width: 10%;" class="tituloColumna">'
		+			'<label>SEGMENTO</label>'
		+		'</td>'
		+		'<td style="width: 10%;" class="tituloColumna">'
		+			'<label>FECHA ALTA</label>'
		+		'</td>'
		+	'</tr>';
		return tabla;
}

function creaFilaTablaEmpleados(empleado,index){
	var colorTr = 'trOscuro';
	if(index%2==0){
		colorTr = 'trClaro';
	}
	
	var	fila=	'<tr class="'+colorTr+'">'
	+	'	<td class="columnaCentrada"><input id="empleadoConsulta'+index+'" name="empleadoConsulta" type="checkbox" onclick="seleccionaEmpleado('+index+',\''+$.trim(empleado.numeroEmpleado)+'\','+empleado.segmentoId+','+empleado.puestoId+');"></td>'
	+	'	<td class="columnaCentrada"><label>'+empleado.numeroEmpleado+'</label></td>'
	+	'	<td class="columnaCentrada"><label>'+empleado.nombreEmpleado+'</label></td>'
	+	'	<td class="columnaCentrada"><label>'+empleado.desptoDesc+'</label></td>'
	+	'	<td class="columnaCentrada"><label>'+empleado.puestoDesc+'</label></td>'	
	+	'	<td class="columnaCentrada"><label>'+empleado.segmentoDesc+'</label></td>'	
	+	'	<td class="columnaCentrada"><label>'+empleado.fechaAlta+'</label></td>'	
	+	'</tr>';
	return fila;
}

function creaEncabezadoTablaNuevosEmpleados(){
	var	tabla=	
		'<table class="tablaEmpleadosNuevos">'
		+	'<tr>'
		+		'<td style="width: 7%;" class="tituloColumna">'
		+			'<label>SELECCIONAR</label>'
		+		'</td>'		
		+		'<td style="width: 15%;" class="tituloColumna">'
		+			'<label>EMPLEADO</label>'
		+		'</td>'
		+		'<td style="width: 25%; " class="tituloColumna">'
		+			'<label>NOMBRE</label>'
		+		'</td>'
		+		'<td style="width: 7%%;" class="tituloColumna">'
		+			'<label>PUESTO</label>'
		+		'</td>'
		+		'<td style="width: 16%;" class="tituloColumna">'
		+			'<label>SEGMENTO</label>'
		+		'</td>'
		+		'<td style="width: 15%;" class="tituloColumna">'
		+			'<label>FECHA ALTA</label>'
		+		'</td>'
		+	'</tr>';
		return tabla;
}

function creaFilaTablaEmpleadosNuevos(empleado,index){
	var colorTr = 'trOscuro';
	if(index%2==0){
		colorTr = 'trClaro';
	}

	var	fila=	'<tr class="'+colorTr+'">'
	+	'	<td class="columnaCentrada"><input id="empleadoNuevo'+index+'" name="empleadoNuevo" type="checkbox" onclick="seleccionaCE('+index+',\''+$.trim(empleado.numeroEmpleado)+'\','+empleado.segmentoId+','+empleado.puestoId+');"></td>'
	+	'	<td class="columnaCentrada"><label>'+empleado.numeroEmpleado+'</label></td>'
	+	'	<td class="columnaCentrada"><label>'+empleado.nombreEmpleado+'</label></td>'
	+	'	<td class="columnaCentrada"><label>'+empleado.puestoId+'</label></td>'
	+	'	<td class="columnaCentrada"><label>'+empleado.puestoDesc+'</label></td>'	
	+	'	<td class="columnaCentrada"><label>'+empleado.fechaAlta+'</label></td>'	
	+	'</tr>';
	return fila;
}

function seleccionaCE(seleccion,empleado,segmentoOrigen,puestoOrigen){
	$('#empleadoDestinoCE').val(empleado);
	$('#segmentoDestinoCE').val(segmentoOrigen);
	$('#puestoDestinoCE').val(puestoOrigen);
	
	$( "input[name^='empleadoNuevo']" ).each(function( index ) {
		if(seleccion != index){
			$('#empleadoNuevo'+index).attr('checked',false);
		}
	});
		
}


function exitoAlta(){
	$('#divEmpleados').html('');
	$('#divAltaEmpleado').hide();
	$('#empleadoAlta').val('');
	$('#nombreEmpleadoAlta').val('');
	dwr.util.removeAllOptions('segmentoEmpleado'); 
	$('#btnAltaEmpleadoAceptar').hide();
	$('#divSegmentosVacante').hide();
	dwr.util.removeAllOptions('segmentoVacante'); 
	$('#tdBajaUsuario').hide();
	$('#tdCambiaEmpleado').hide();
	
	var mantenimientoUsuariosUnificadoBean	=	{
			'puestoOperar'			:	$('#puestoOperar').val(),
			'departamentoOperar'	:	$('#departamentoOperar').val()
		}
	
	MantenimientoUsuariosUnificadoServicioImpl.consulta(mantenimientoUsuariosUnificadoBean,3,function(mantenimientoUsuariosUnificado){
		if(mantenimientoUsuariosUnificado.empleados.length > 0){
			var tablaEmpleados = creaEncabezadoTablaEmpleados();
			for (var i = 0; i < mantenimientoUsuariosUnificado.empleados.length; i++) {
				tablaEmpleados += creaFilaTablaEmpleados(mantenimientoUsuariosUnificado.empleados[i],i);
		    }
			tablaEmpleados	+= '</table><br>';
			$('#divEmpleados').html(tablaEmpleados);
			$('#divEmpleados').show();
			$('#divConsultaEmpleados').show();
		}
	});
}


function exitoCambioEmpleado(){
	$('#divEmpleados').html('');
	ocultaCambioEmpleado();
	$('#tdBajaUsuario').hide();
	$('#tdCambiaEmpleado').hide();
	
	var mantenimientoUsuariosUnificadoBean	=	{
			'puestoOperar'			:	$('#puestoOperar').val(),
			'departamentoOperar'	:	$('#departamentoOperar').val()
		}
	
	MantenimientoUsuariosUnificadoServicioImpl.consulta(mantenimientoUsuariosUnificadoBean,3,function(mantenimientoUsuariosUnificado){
		if(mantenimientoUsuariosUnificado.empleados.length > 0){
			var tablaEmpleados = creaEncabezadoTablaEmpleados();
			for (var i = 0; i < mantenimientoUsuariosUnificado.empleados.length; i++) {
				tablaEmpleados += creaFilaTablaEmpleados(mantenimientoUsuariosUnificado.empleados[i],i);
		    }
			tablaEmpleados	+= '</table><br>';
			$('#divEmpleados').html(tablaEmpleados);
			$('#divEmpleados').show();
			$('#divConsultaEmpleados').show();
		}
	});
}


function cancelarCambio(){
	$('#divEmpleados').html('');
	ocultaCambioEmpleado();
	
	
	var mantenimientoUsuariosUnificadoBean	=	{
			'puestoOperar'			:	$('#puestoOperar').val(),
			'departamentoOperar'	:	$('#departamentoOperar').val()
		}
	
	MantenimientoUsuariosUnificadoServicioImpl.consulta(mantenimientoUsuariosUnificadoBean,3,function(mantenimientoUsuariosUnificado){
		if(mantenimientoUsuariosUnificado.empleados.length > 0){
			var tablaEmpleados = creaEncabezadoTablaEmpleados();
			for (var i = 0; i < mantenimientoUsuariosUnificado.empleados.length; i++) {
				tablaEmpleados += creaFilaTablaEmpleados(mantenimientoUsuariosUnificado.empleados[i],i);
		    }
			tablaEmpleados	+= '</table><br>';
			$('#divEmpleados').html(tablaEmpleados);
			$('#divEmpleados').show();
			$('#divConsultaEmpleados').show();
		}
	});

}

function ocultaCambioEmpleado(){
	$('#divCambioPuesto').hide();
	$('#empleadoBajaxSustitucion').val('');
	$('#lblEmpleadoCambio').text('');
	$('#lblNombreCambio').text('');
	$('#lblPuestoCambio').text('');
	$('#lblSegmentoCambio').text('');
	$('#lblFechaCambio').text('');
	$('#divCambiosEmpleado').hide();
	$('#divConsultaEmpleadosCambio').html('');
	$('#divBajaxSustitucion').hide();
	$('#lblEmpleadoBajaxSustitucion').text('');
	$('#lblNombreBajaxSustitucion').text('');
	$('#lblPuestoBajaxSustitucion').text('');
	$('#lblSegmentoBajaxSustitucion').text('');
	$('#lblFechaBajaxSustitucion').text('');
}

function ocultaAltaEmpleado(){
	$('#divAltaEmpleado').hide();
	$('#empleadoAlta').val('');
	$('#nombreEmpleadoAlta').val('');
	dwr.util.removeAllOptions('segmentoEmpleado');
	$('#btnAltaEmpleadoAceptar').hide();	
}

function ocultaAltaVacante(){
	$('#divSegmentosVacante').hide();
	dwr.util.removeAllOptions('segmentoVacante'); 
	$('#divAltaEmpleado').hide();
}

function ocultaConsultaEmpleados(){
	$('#divConsultaEmpleados').hide();
	$('#divEmpleados').hide();
}

function validaCambioEmpleado(){
	var checks = 0;
	$( "input[name^='empleadoNuevo']" ).each(function( index ) {
		var empleadoSeleccionado = "#empleadoNuevo"+index;
		
		if($(empleadoSeleccionado).is(":checked")){
			checks++;
		}
	});
		
	return checks;
}