$(document).ready(function(){
	
	var	Cat_Acciones = {
		'AltaVacante'	:	'btnAltaVacante',
		'AltaUsuario'	:	'btnAltaEmpleado',
		'BajaUsuario'	:	'btnBajaEmpleado',
		'CambioUsuario'	:	'btnCambioEmpleado'
	}
	
	var cat_Transacciones = {
			'altaVacante'	:	1
	}
	
	$('#aceptarAlert').click(function(){
		$('#contenido').unblock();
	});
	
	$('#btnAltaVacante').click(function(){
		if(validaSeccion()){
			bloqueaPantalla('contenido', 'mensaje');
			muestraAltaVacante();
		}
	});
	
	$('#btnAltaEmpleado').click(function(){
		if(validaSeccion()){
			activaBoton('btnAltaEmpleado');
			$('#divAltaUsuario').show();
		}
	});

	$('#btnCambioEmpleado').click(function(){
		if(validaSeccion()){
			activaBoton('btnCambioEmpleado');
			$('#divAltaUsuario').show();
		}
	});
	
	$('#btnBuscarUsuario').click(function(){
		bloqueaPantalla('contenido','mensaje');
		consultaEmpleadoSap();
	});
	
	$('#puestoConsultar').change(function(){
		bloqueaPantalla('contenido', 'mensaje');
		$('#divConsultaEmpleados').hide();
		$('#divAltaVacante').hide();
		activaBoton('');
		activaOperaciones();
		consultaDepartamentos();
	});
	
	$('#gerenciaConsultar').change(function(){
		bloqueaPantalla('contenido', 'mensaje');
		consultaEmpleados();
	});
	
	$('#buscarGerencia').click(function(){
		consultaGerencia();
	});
	
	$('#btnAceptarAltaVacante').click(function(){
		
		if($('#segmentoOperar').val() > 0){
			$('#tipoOperacion').val(cat_Transacciones.altaVacante);
			grabaTransaccionRecarga('mantenimientoUsuariosSapBean','contenido','mensaje','','');
		}else{
			mensajeModal('contenido','Debe seleccionar un Segmento.');
		}
		
		
	});
	
	$('#btnCancelarAltaVacante').click(function(){
		$('#divAltaVacante').hide();
		$('#segmentoOperar').val('0');
		activaBoton('');
	});
	
	
	function activaBoton(nombreBoton){
		$('#btnAltaVacante').removeClass('btnActivo');
		$('#btnAltaEmpleado').removeClass('btnActivo');
		$('#btnBajaEmpleado').removeClass('btnActivo');
		$('#btnCambioEmpleado').removeClass('btnActivo');
		
		switch (nombreBoton) {
			case Cat_Acciones.AltaVacante:
				$('#btnAltaVacante').addClass('btnActivo');
				break;
			case Cat_Acciones.AltaUsuario:
				$('#btnAltaEmpleado').addClass('btnActivo');	
				break;
			case Cat_Acciones.BajaUsuario:
				$('#btnBajaEmpleado').addClass('btnActivo');
				break;
			case Cat_Acciones.CambioUsuario:
				$('#btnCambioEmpleado').addClass('btnActivo');
				break;
			default:
				break;
		}
	}

	function consultaDepartamentos(){
		var consultaDepartamentos	=	3;
		
		var	mantenimientoUsuariosSapBean ={
				'puestoConsultar' : $('#puestoConsultar').val(),
				'empleadoDelegado': $('#empleadoDelegado').val(),
				'puestoDelegado'  :	$('#puestoDelegado').val()
		}
		dwr.util.removeAllOptions('gerenciaConsultar'); 
		dwr.util.addOptions('gerenciaConsultar',{'0':'SELECCIONE UNA GERENCIA'});
		MantenimientoUsuariosSapImpl.consulta(mantenimientoUsuariosSapBean,consultaDepartamentos, function(mantenimientoUsuariosSapBean){
			if(mantenimientoUsuariosSapBean.departamentos != null){
				dwr.util.addOptions('gerenciaConsultar', mantenimientoUsuariosSapBean.departamentos, 'deptoId','descripcionDepto');
				desbloqueaPantalla('contenido');
			}else{
				desbloqueaPantalla('contenido');
			}
			
		});
	}

	function consultaEmpleados(){
		var consultaEmpleados	=	4;
		var	mantenimientoUsuariosSapBean ={
				'puestoConsultar' 	:	$('#puestoConsultar').val(),
				'gerenciaConsultar'	:	$('#gerenciaConsultar').val() 
		}
		MantenimientoUsuariosSapImpl.consulta(mantenimientoUsuariosSapBean,consultaEmpleados, function(mantenimientoUsuariosSapBean){
			if(mantenimientoUsuariosSapBean.empleadosOperar != null){
				var tablaEmpleados = creaEncabezadoTablaEmpleados();
				for (var i = 0; i < mantenimientoUsuariosSapBean.empleadosOperar.length; i++) {
					
					tablaEmpleados += creaFilaTablaEmpleados(mantenimientoUsuariosSapBean.empleadosOperar[i],i);
			    }
				
				tablaEmpleados	+= '</table>';
				$('#divEmpleados').html(tablaEmpleados);
				$('#divConsultaEmpleados').show();
				desbloqueaPantalla('contenido');
			}else{
				desbloqueaPantalla('contenido');
			}
		});
		
	}
	
	function creaEncabezadoTablaEmpleados(){
		var	tabla='<table class="tablaEmpleados" style="width:97%;margin: 0 auto;">'
			+	'<tr>'
			+		'<td style="width: 7%;" class="tituloColumna">'
			+			'<label>SELECCIONAR</label>'
			+		'</td>'			
			+		'<td style="width: 10%;" class="tituloColumna">'
			+			'<label>EMPLEADO</label>'
			+		'</td>'
			+		'<td style="width: 25%;" class="tituloColumna">'
			+			'<label>NOMBRE</label>'
			+		'</td>'
			+		'<td style="width: 23%;" class="tituloColumna">'
			+			'<label>GERENCIA</label>'
			+		'</td>'
			+		'<td style="width: 15%;" class="tituloColumna">'
			+			'<label>PUESTO</label>'
			+		'</td>'
			+		'<td style="width: 10%;" class="tituloColumna">'
			+			'<label>SEGMENTO</label>'
			+		'</td>'			
			+		'<td style="width: 10%;" class="tituloColumna">'
			+			'<label>FECHA ALTA</label>'
			+		'</td>'
			+	'</tr>';
			return tabla;
	}
	
	function creaFilaTablaEmpleados(empleado,index){
		var colorTr = 'trOscuro';
		if(index%2==0){
			colorTr = 'trClaro';
		}
		
		var	fila=	'<tr class="'+colorTr+'">'
		+	'	<td class="columnaCentrada">'
		+	'		<input type="checkbox" id="empleado'+index+'" name="empleado" value="0">'
		+	'		<input type="hidden" id="esVirual'+index+'" name="esVirtual" value="'+empleado.esVirtual+'">'
		+	'	</td>'
		+	'	<td class="columnaCentrada"><label>'+empleado.numeroEmpleado+'</label></td>'
		+	'	<td class="columnaCentrada"><label>'+empleado.nombreEmpleado+'</label></td>'
		+	'	<td class="columnaCentrada"><label>'+empleado.descripcionDepto+'</label></td>'
		+	'	<td class="columnaCentrada"><label>'+empleado.descripcionPuestoId+'</label></td>'
		+	'	<td class="columnaCentrada"><label>'+empleado.descripcionSegmentoId+'</label></td>'
		+	'	<td class="columnaCentrada"><label>'+empleado.fechaAlta+'</label></td>'		
		+	'</tr>';
		return fila;
	}
	
	function validaChecks(){
		
	}
	
	function muestraAltaVacante(){
		activaBoton('btnAltaVacante');
		$('#divAltaVacante').show();
		desbloqueaPantalla('contenido');
	}
	
	function validaSeccion(){
		if($('#puestoConsultar').val() <= 0){
			mensajeModal('contenido','Debe de seleccionar un Puesto.');
			return false;
		}
		
		if($('#gerenciaConsultar').val() <=0){
			mensajeModal('contenido','Debe de seleccionar una Gerencia.');
			return false;
		}
		return true;
	}
	
	function activaOperaciones(){

		$('#tdAltaVacante').hide();
		$('#tdAltausuario').hide();
		$('#tdBajaUsuario').hide();
		$('#tdCambiaEmpleado').hide();

		switch ($('#puestoConsultar').val()) {
		case '110':
			$('#tdAltaVacante').show();
			$('#tdCambiaEmpleado').show();
			break;
		case '115':
		case '119':
		case '138':
		case '1120':
		case '1130':
			$('#tdAltaVacante').show();
			$('#tdAltausuario').show();
			$('#tdBajaUsuario').show();
			$('#tdCambiaEmpleado').show();
			break;
		case '129':
			$('#tdCambiaEmpleado').show();
			break;	
		default:
			break;
		}
	}
	
	function consultaEmpleadoSap(){
		DatosEmpleadoImpl.consultaEmpleadoSap($('#empleadoAlta').val(),function(empleadoSap){
			if(empleadoSap != null && empleadoSap.numeroEmpleado != 0){
				$('#btnAceptarAltaUsuario').show();
				$('#nombreEmpleadoAlta').val(empleadoSap.nombreInicial+' '+empleadoSap.apellidoPaterno+' '+empleadoSap.apellidoMaterno);
				desbloqueaPantalla('contenido');
			}else{
				mensajeModal('contenido','No se encontro informacion del Empleado en SAP.');
				$('#btnAceptarAltaUsuario').hide();
				$('#nombreEmpleadoAlta').val('');
			}
		});
	}
	
});