package com.bancoazteca.srcu.spring.cartera.portafolioCliente.webService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.bancoazteca.srcu.spring.cartera.portafolioCliente.bean.PortafolioClienteBean;
import com.bancoazteca.srcu.spring.cartera.portafolioCliente.servicios.PortafolioClienteServicio;

@RestController
@RequestMapping("/api/v1/portafolios")
public class PortafolioClienteWS {
	
	@Autowired
	PortafolioClienteServicio portafolioClienteServicio;
	
	@RequestMapping(value = "/gerencias/{gerenciaId}/segmentos/{segmentoId}", method = RequestMethod.GET)
	@ResponseBody
	public PortafolioClienteBean consulta(@PathVariable("gerenciaId") int gerenciaId, @PathVariable("segmentoId") int segmentoId) {
		PortafolioClienteBean portafolioClienteBean	= new PortafolioClienteBean();
		portafolioClienteBean.setDepartamentoId(gerenciaId);
		portafolioClienteBean.setSegmento(segmentoId);
		
		portafolioClienteBean = portafolioClienteServicio.consulta(portafolioClienteBean, 1);
		
		return portafolioClienteBean;
	}
	
	
	@RequestMapping(value = "/gerencias/{gerenciaId}/empleados/{numeroEmpleado}/segmentos/{segmentoId}", method = RequestMethod.GET)
	@ResponseBody
	public PortafolioClienteBean consulta(@PathVariable("gerenciaId") int gerenciaId, @PathVariable("numeroEmpleado") String numeroEmpleado, @PathVariable("segmentoId") int segmentoId) {
		PortafolioClienteBean portafolioClienteBean	= new PortafolioClienteBean();
		portafolioClienteBean.setDepartamentoId(gerenciaId);
		portafolioClienteBean.setNumeroEmpleado(numeroEmpleado);
		portafolioClienteBean.setSegmento(segmentoId);
		
		portafolioClienteBean = portafolioClienteServicio.consulta(portafolioClienteBean, 2);
		
		return portafolioClienteBean;
	}
	
	@RequestMapping(value = "/clientes/{paisId}-{canalId}-{sucursalId}-{folioId}", method = RequestMethod.GET)
	@ResponseBody
	public PortafolioClienteBean consulta(@PathVariable("paisId") int paisId, @PathVariable("canalId") int canalId, @PathVariable("sucursalId") int sucursalId, @PathVariable("folioId") int folioId) {
		PortafolioClienteBean portafolioClienteBean	= new PortafolioClienteBean();
		portafolioClienteBean.setPaisId(paisId);
		portafolioClienteBean.setCanalId(canalId);
		portafolioClienteBean.setSucursalId(sucursalId);
		portafolioClienteBean.setFolioId(folioId);
		
		portafolioClienteBean = portafolioClienteServicio.consulta(portafolioClienteBean, 3);
		
		return portafolioClienteBean;
	}
	
}
