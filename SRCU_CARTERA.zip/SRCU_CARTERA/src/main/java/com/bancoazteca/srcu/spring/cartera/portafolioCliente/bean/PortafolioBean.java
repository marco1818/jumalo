package com.bancoazteca.srcu.spring.cartera.portafolioCliente.bean;

import java.math.BigDecimal;

public class PortafolioBean {
	private String numeroEmpleado;
	private String nombreEmpleado;
	private int departamentoId;
	private int tipoDeptoId;
	private int zonasGeograficas;
	private int totalClientes;
	private BigDecimal saldo;
	private BigDecimal saldoAtrasado;
	private BigDecimal moratorios;
	private BigDecimal saldoRequerido;
	private String tipoZona;
	
	public PortafolioBean() {
		
	}

	public String getNumeroEmpleado() {
		return numeroEmpleado;
	}

	public void setNumeroEmpleado(String numeroEmpleado) {
		this.numeroEmpleado = numeroEmpleado;
	}

	public String getNombreEmpleado() {
		return nombreEmpleado;
	}

	public void setNombreEmpleado(String nombreEmpleado) {
		this.nombreEmpleado = nombreEmpleado;
	}

	public int getDepartamentoId() {
		return departamentoId;
	}

	public void setDepartamentoId(int departamentoId) {
		this.departamentoId = departamentoId;
	}

	public void setDepartamentoId(BigDecimal departamentoId) {
		this.departamentoId = departamentoId.intValue();
	}
	
	public int getTipoDeptoId() {
		return tipoDeptoId;
	}

	public void setTipoDeptoId(int tipoDeptoId) {
		this.tipoDeptoId = tipoDeptoId;
	}

	public void setTipoDeptoId(BigDecimal tipoDeptoId) {
		this.tipoDeptoId = tipoDeptoId.intValue();
	}
	
	public int getZonasGeograficas() {
		return zonasGeograficas;
	}

	public void setZonasGeograficas(int zonasGeograficas) {
		this.zonasGeograficas = zonasGeograficas;
	}
	
	public void setZonasGeograficas(BigDecimal zonasGeograficas) {
		this.zonasGeograficas = zonasGeograficas.intValue();
	}

	public int getTotalClientes() {
		return totalClientes;
	}

	public void setTotalClientes(int totalClientes) {
		this.totalClientes = totalClientes;
	}
	
	public void setTotalClientes(BigDecimal totalClientes) {
		this.totalClientes = totalClientes.intValue();
	}

	public BigDecimal getSaldo() {
		return saldo;
	}

	public void setSaldo(BigDecimal saldo) {
		this.saldo = saldo;
	}

	public BigDecimal getSaldoAtrasado() {
		return saldoAtrasado;
	}

	public void setSaldoAtrasado(BigDecimal saldoAtrasado) {
		this.saldoAtrasado = saldoAtrasado;
	}

	public BigDecimal getMoratorios() {
		return moratorios;
	}

	public void setMoratorios(BigDecimal moratorios) {
		this.moratorios = moratorios;
	}

	public BigDecimal getSaldoRequerido() {
		return saldoRequerido;
	}

	public void setSaldoRequerido(BigDecimal saldoRequerido) {
		this.saldoRequerido = saldoRequerido;
	}

	public String getTipoZona() {
		return tipoZona;
	}

	public void setTipoZona(String tipoZona) {
		this.tipoZona = tipoZona;
	}
}
