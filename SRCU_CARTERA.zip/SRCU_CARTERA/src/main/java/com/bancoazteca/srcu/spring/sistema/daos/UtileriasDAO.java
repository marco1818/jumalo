package com.bancoazteca.srcu.spring.sistema.daos;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.bancoazteca.srcu.spring.sistema.beans.CatalogoBean;
import com.bancoazteca.srcu.spring.sistema.beans.MensajeTransaccionBean;

@Repository
public class UtileriasDAO extends BaseDAO{
	private interface Funciones{
		String	consultaItem	=	"CONSULTA_CAT_UNICO_2";
		String	consultaSubItem	=	"CONSULTA_SUBITEMID_CAT_UNICO2";
		String	altaCatUnico2	=	"UTILERIAS_INSERTA_CAT_UNICO_2";
	}
	
	@SuppressWarnings("unchecked")
	public List<CatalogoBean> consultaItem(int catalogoId){
		List<CatalogoBean> catalogo = new ArrayList<CatalogoBean>();
		ArrayList<Object> parametros = new ArrayList<Object>();
		parametros.add(catalogoId);
		parametros.add("ES");
		
		catalogo = (List<CatalogoBean>) ejecutaFuncionAll(Funciones.consultaItem, parametros, CatalogoBean.class);
		
		return catalogo;
	}
	
	public CatalogoBean	consultaSubItem(int catalogoId,	int subItemid) {
		CatalogoBean catalogoBean = null;
		ArrayList<Object> parametros = new ArrayList<Object>();
		parametros.add(2);
		parametros.add(catalogoId);
		parametros.add(subItemid);
		
		catalogoBean = (CatalogoBean) ejecutaFuncion(Funciones.consultaSubItem, parametros, CatalogoBean.class);
		
		return catalogoBean;
	}
	
	@SuppressWarnings("unchecked")
	public List<CatalogoBean>	consultaItemFront(int catalogoId,	int subItemid) {
		List<CatalogoBean> catalogoBean = null;
		ArrayList<Object> parametros = new ArrayList<Object>();
		parametros.add(3);
		parametros.add(catalogoId);
		parametros.add(subItemid);
		
		catalogoBean = (List<CatalogoBean>) ejecutaFuncionAll(Funciones.consultaSubItem, parametros, CatalogoBean.class);
		
		return catalogoBean;
	}
	
	public CatalogoBean	consultaSubItemFront(int catalogoId,	int subItemid) {
		CatalogoBean catalogoBean = null;
		ArrayList<Object> parametros = new ArrayList<Object>();
		parametros.add(4);
		parametros.add(catalogoId);
		parametros.add(subItemid);
		
		catalogoBean = (CatalogoBean) ejecutaFuncion(Funciones.consultaSubItem, parametros, CatalogoBean.class);
		
		return catalogoBean;
	}
	 
	public MensajeTransaccionBean altaCatUnico2(int itemId, int subItemId, String descripcionCorta, String descripcionLarga, int estatus, String empleadoModifico) {
		MensajeTransaccionBean mensajeTransaccionBean = null;
		ArrayList<Object> parametros = new ArrayList<Object>();
		parametros.add(itemId);
		parametros.add(subItemId);
		parametros.add(descripcionCorta);
		parametros.add(descripcionLarga);
		parametros.add(estatus);
		parametros.add(empleadoModifico);
		parametros.add(1);
		
		mensajeTransaccionBean = (MensajeTransaccionBean) ejecutaFuncion(Funciones.altaCatUnico2, parametros, MensajeTransaccionBean.class);
	
		return mensajeTransaccionBean;
	 }
	 
	public CatalogoBean obtieneCatunicoTDA(int opcionConsulta, int itemId, int subItemId) {
		CatalogoBean catalogoBean = new CatalogoBean();
		ArrayList<Object> parametros = new ArrayList<Object>();
		parametros.add(opcionConsulta);
		parametros.add(itemId);
		parametros.add(subItemId);
		
		catalogoBean = (CatalogoBean) ejecutaFuncion(Funciones.consultaSubItem, parametros, catalogoBean.getClass());
		return catalogoBean;
	}
}
