package com.bancoazteca.srcu.spring.cartera.portafolioCliente.daos;

import java.util.List;

import com.bancoazteca.srcu.spring.cartera.portafolioCliente.bean.ClientesBean;
import com.bancoazteca.srcu.spring.cartera.portafolioCliente.bean.PedidosClientesBean;
import com.bancoazteca.srcu.spring.cartera.portafolioCliente.bean.PortafolioBean;
import com.bancoazteca.srcu.spring.cartera.portafolioCliente.bean.PortafolioClienteBean;

public interface PortafolioClienteDAO {
	public List<PortafolioBean> consultaPortafoliosGerencia(PortafolioClienteBean portafolioClienteBean);
	public List<ClientesBean>	consultaPortafolioEmpleado(PortafolioClienteBean portafolioClienteBean);
	public List<PedidosClientesBean> consultaPedidosCliente(PortafolioClienteBean portafolioClienteBean);
	
}
