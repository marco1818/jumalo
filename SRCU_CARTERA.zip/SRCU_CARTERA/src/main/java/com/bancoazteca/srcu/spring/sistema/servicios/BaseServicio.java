package com.bancoazteca.srcu.spring.sistema.servicios;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.List;
import java.util.Properties;
import java.util.logging.Logger;

import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bancoazteca.srcu.spring.sistema.beans.CatalogoBean;
import com.bancoazteca.srcu.spring.sistema.beans.MensajeTransaccionBean;
import com.bancoazteca.srcu.spring.sistema.daos.UtileriasDAO;

@Component
public class BaseServicio {
	private final static Logger logger = Logger.getLogger("BaseServicio");
	private Properties properties;
	private Session session;
	
	public BaseServicio() {
		properties = new Properties();
		properties.put("mail.pop3.host", "pop3.nosuchhost.nosuchdomain.com");
	    properties.put("mail.store.protocol", "pop3");
	    properties.put("mail.transport.protocol", "smtp");
	    properties.put("mail.user", "");
	    properties.put("mail.smtp.port", "25");
        properties.put("mail.smtp.host", "10.63.200.79");
        session = Session.getDefaultInstance(properties);
	}
	
	private interface Contantes{
		String remitente	=	"pcj@bancoazteca.com.mx";
		int    opcionPorCatunicoTDA = 6;
	}
	
	@Autowired
	private UtileriasDAO utileriasDAO;
	
	
	public	List<CatalogoBean> consultaItem(int itemId){
		return utileriasDAO.consultaItem(itemId);
	}
	
	public	CatalogoBean consultaSubItem(int itemId,int subItemId){
		CatalogoBean catalogoBean = new CatalogoBean();
		
		catalogoBean = utileriasDAO.consultaSubItem(itemId, subItemId);
		
		if(catalogoBean == null) {
			catalogoBean = new CatalogoBean();
		}
		
		return catalogoBean;
	}
	
	public	List<CatalogoBean>  consultaItemFront(int itemId,int subItemId){

		
		return utileriasDAO.consultaItemFront(itemId, subItemId);

	}
	
	public	CatalogoBean consultaSubItemFront(int itemId,int subItemId){
		CatalogoBean catalogoBean = new CatalogoBean();
		
		catalogoBean = utileriasDAO.consultaSubItemFront(itemId, subItemId);
		
		if(catalogoBean == null) {
			catalogoBean = new CatalogoBean();
		}
		
		return catalogoBean;
	}
	
	public boolean obtieneCatunicoTDA(int itemId, int subItemId) {
		CatalogoBean catalogoBean = new CatalogoBean();
		
		catalogoBean = utileriasDAO.obtieneCatunicoTDA(Contantes.opcionPorCatunicoTDA,itemId, subItemId);
		
		if(catalogoBean != null && catalogoBean.getSubItemId() == subItemId && catalogoBean.getSubItemStat() ==1) {
			return true;
		}
		
		return false;
	}

	public int consultaPais() {
		try {
			logger.info("Verificando Pais...:"+java.net.InetAddress.getLocalHost().getCanonicalHostName().toLowerCase());
			logger.info("Verificando Pais...:"+InetAddress.getLocalHost().getHostAddress());
			String ip = InetAddress.getLocalHost().getHostAddress();
			 InetAddress addr = InetAddress.getByName(ip);
			 logger.info(addr.getHostName());
		} catch (UnknownHostException e) {
		}
		return 1;
	}
	
	public void enviarCorreo(String destinatario, String asunto, String cuerpoCorreo) {
		MimeMessage message = new MimeMessage(session);
		try {
			message.setFrom(new InternetAddress(Contantes.remitente));
			
			if(destinatario.indexOf(',')>0){
				message.addRecipients(Message.RecipientType.TO, InternetAddress.parse(destinatario));
		    } 
		    else{
		    	message.addRecipient(Message.RecipientType.TO, new InternetAddress(destinatario));
		    } 
			
			message.setSubject(asunto);
			BodyPart messageBodyPart = new MimeBodyPart();
			messageBodyPart.setContent(cuerpoCorreo+"<br><br>","text/html");
			Multipart multipart = new MimeMultipart();
			multipart.addBodyPart(messageBodyPart);
			message.setContent(multipart);
			Transport.send(message);
			logger.info("Envio de correo Exitoso a: "+destinatario);
		} catch (AddressException e) {
			logger.info("Ocurrio un detalle en el envio de correo a: "+destinatario);
		} catch (MessagingException e) {
			logger.info("Ocurrio un detalle en el envio de correo a: "+destinatario);
		}
		
	}
    
   
	public	MensajeTransaccionBean altaCatUnico2(int itemId, int subItemId, String descripcionCorta, String descripcionLarga, int estatus, String empleadoModifico) {
		MensajeTransaccionBean mensajeTransaccionBean = null;
		
		mensajeTransaccionBean = utileriasDAO.altaCatUnico2(itemId, subItemId, descripcionCorta, descripcionLarga, estatus, empleadoModifico);
		
		return mensajeTransaccionBean;
	}
}
