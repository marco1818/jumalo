package com.bancoazteca.srcu.spring.cartera.portafolioCliente.bean;

import java.math.BigDecimal;

public class ClientesBean {
	private	String clienteUnico;
	private String nombreCliente;
	private int numeroPedidos;
	private BigDecimal saldo;
	private BigDecimal saldoAtrasado;
	private BigDecimal moratorios;
	private int periodosAtraso;
	private int atrasoMinimo;
	private BigDecimal pagoRequerido;
	private String telefono;
	private int inactividad;
	private String zonaGeografica;
	private int diasAtraso;
	private int planPago;
	private String diaPago;
	private String estadoPortafolio;
	private String estadoPortafolioDesc;

	public ClientesBean() {
		
 	}

	public String getClienteUnico() {
		return clienteUnico;
	}

	public void setClienteUnico(String clienteUnico) {
		this.clienteUnico = clienteUnico;
	}

	public String getNombreCliente() {
		return nombreCliente;
	}

	public void setNombreCliente(String nombreCliente) {
		this.nombreCliente = nombreCliente;
	}

	public int getNumeroPedidos() {
		return numeroPedidos;
	}

	public void setNumeroPedidos(int numeroPedidos) {
		this.numeroPedidos = numeroPedidos;
	}

	public void setNumeroPedidos(BigDecimal numeroPedidos) {
		this.numeroPedidos = numeroPedidos.intValue();
	}
	
	public BigDecimal getSaldo() {
		return saldo;
	}

	public void setSaldo(BigDecimal saldo) {
		this.saldo = saldo;
	}

	public BigDecimal getSaldoAtrasado() {
		return saldoAtrasado;
	}

	public void setSaldoAtrasado(BigDecimal saldoAtrasado) {
		this.saldoAtrasado = saldoAtrasado;
	}

	public BigDecimal getMoratorios() {
		return moratorios;
	}

	public void setMoratorios(BigDecimal moratorios) {
		this.moratorios = moratorios;
	}

	public int getPeriodosAtraso() {
		return periodosAtraso;
	}

	public void setPeriodosAtraso(int periodosAtraso) {
		this.periodosAtraso = periodosAtraso;
	}

	public void setPeriodosAtraso(BigDecimal periodosAtraso) {
		this.periodosAtraso = periodosAtraso.intValue();
	}
	
	public int getAtrasoMinimo() {
		return atrasoMinimo;
	}

	public void setAtrasoMinimo(int atrasoMinimo) {
		this.atrasoMinimo = atrasoMinimo;
	}

	public void setAtrasoMinimo(BigDecimal atrasoMinimo) {
		this.atrasoMinimo = atrasoMinimo.intValue();
	}
	
	public BigDecimal getPagoRequerido() {
		return pagoRequerido;
	}

	public void setPagoRequerido(BigDecimal pagoRequerido) {
		this.pagoRequerido = pagoRequerido;
	}

	public String getTelefono() {
		return telefono;
	}

	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}

	public int getInactividad() {
		return inactividad;
	}

	public void setInactividad(int inactividad) {
		this.inactividad = inactividad;
	}

	public void setInactividad(BigDecimal inactividad) {
		this.inactividad = inactividad.intValue();
	}
	
	public String getZonaGeografica() {
		return zonaGeografica;
	}

	public void setZonaGeografica(String zonaGeografica) {
		this.zonaGeografica = zonaGeografica;
	}

	public int getDiasAtraso() {
		return diasAtraso;
	}

	public void setDiasAtraso(int diasAtraso) {
		this.diasAtraso = diasAtraso;
	}

	public void setDiasAtraso(BigDecimal diasAtraso) {
		this.diasAtraso = diasAtraso.intValue();
	}
	
	public int getPlanPago() {
		return planPago;
	}

	public void setPlanPago(int planPago) {
		this.planPago = planPago;
	}

	public void setPlanPago(BigDecimal planPago) {
		this.planPago = planPago.intValue();
	}
	
	public String getDiaPago() {
		return diaPago;
	}

	public void setDiaPago(String diaPago) {
		this.diaPago = diaPago;
	}

	public String getEstadoPortafolio() {
		return estadoPortafolio;
	}

	public void setEstadoPortafolio(String estadoPortafolio) {
		this.estadoPortafolio = estadoPortafolio;
	}

	public String getEstadoPortafolioDesc() {
		return estadoPortafolioDesc;
	}

	public void setEstadoPortafolioDesc(String estadoPortafolioDesc) {
		this.estadoPortafolioDesc = estadoPortafolioDesc;
	}
	
}
 