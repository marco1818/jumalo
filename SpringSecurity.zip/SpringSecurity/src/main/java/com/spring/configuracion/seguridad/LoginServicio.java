package com.spring.configuracion.seguridad;

import java.util.List;

import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.stereotype.Component;

@Component
public class LoginServicio implements AuthenticationProvider{

	@Override
	public Authentication authenticate(Authentication authentication) throws AuthenticationException {
		List<GrantedAuthority> authorities = null;
		
		System.out.println("1.-"+authentication.getPrincipal()+"----"+authentication.getCredentials());
		
		if(String.valueOf(authentication.getPrincipal()).equalsIgnoreCase("mluis")) {
			return  new UsernamePasswordAuthenticationToken(String.valueOf(authentication.getPrincipal()),String.valueOf(authentication.getCredentials()),authorities);	

		}else {
			return null;
		}
		
	}

	@Override
	public boolean supports(Class<?> authentication) {
		return true;
	}

}
