package com.spring.configuracion;

import org.springframework.security.web.context.AbstractSecurityWebApplicationInitializer;

public class InicializadorSeguridad extends AbstractSecurityWebApplicationInitializer{

}
