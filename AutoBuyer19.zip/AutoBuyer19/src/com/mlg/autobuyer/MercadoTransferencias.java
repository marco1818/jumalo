package com.mlg.autobuyer;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.swing.JOptionPane;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class MercadoTransferencias {
	private WebDriver webDriver;
	private WebElement element;
	private List<String> jugadores;
	private int tamanioListaObjetivos;
	
	public MercadoTransferencias(WebDriver webDriver, List<String> jugadores, int tamanioListaObjetivos) {
		this.webDriver = webDriver;
		this.jugadores = jugadores;
		this.tamanioListaObjetivos = tamanioListaObjetivos;
		login();
	}
	
	private void login() {
		esperarElementoClick("/html/body/div[1]/div[2]/ul/li[4]/a", "uno");
		ingresarDatosEsperar("//*[@id=\"email\"]", "marcoalm2424@mail.com", "dos");
		ingresarDatosEsperar("//*[@id=\"password\"]", "Wallbounce260189", "tres");
		esperarElementoClick("//*[@id=\"btnLogin\"]", "cuatro");
		esperarElementoClick("//*[@id=\"btnSendCode\"]", "cinco");
		String codigo = JOptionPane.showInputDialog(null, "Ingrese el Codigo de Seguridad...");
		ingresarDatosEsperar("//*[@id=\"oneTimeCode\"]",codigo ,"seis");
		esperarElementoClick("//*[@id=\"btnSubmit\"]","siete");
		esperarElementoClick("//*[@id=\"marquee\"]/div[3]/div/div/div[2]/a","ocho");
		esperarElementoClick("//*[@id=\"Login\"]/div/div/button[1]","nueve");
		ingresarDatosEsperar("//*[@id=\"password\"]", "Wallbounce260189","diez");
		esperarElementoClick("//*[@id=\"btnLogin\"]","once");
		tradearJugadores();
	}
	
	public void irTraspasos() {
		System.out.println("Dirigiendo a Traspasos");
		esperarElementoClick("/html/body/section/section/nav/button[3]","Traspasos");
			
	}
	
	public void tradearJugadores() {
		boolean tradear = true;
		
		while(tradear) {
			int listaUsada = listaUsada();
			int ganados = listaUsada();
			irTraspasos();
			irMercado();
			esperarElementoClick("//*[@id=\"ut-search-wrapper\"]/div[2]/div/div[1]/div[1]/div[2]/div/div", "Calidad");
			esperarElementoClick("//*[@id=\"ut-search-wrapper\"]/div[2]/div/div[1]/div[1]/div[2]/div/ul/li[4]","Calidad Oro");
			ingresarDatosEsperar("//*[@id=\"ut-search-wrapper\"]/div[2]/div/div[1]/div[2]/div[3]/div[2]/div/input", "  300", "Precio Inicial Maximo");
			esperarElementoClick("//*[@id=\"ut-search-wrapper\"]/div[2]/div/div[2]/button[2]", "Buscar Jugadores");
			while(listaUsada<tamanioListaObjetivos && ganados <= 30) {
				int intentos = 1;
				while(intentos<16) {
					listaUsada++;
					//Pujar
					esperarElementoClick("/html/body/section/section/section/div[2]/section/div/section[1]/div/ul/li["+intentos+"]/div", ("Jugador"+intentos));
					pausar(100);
					esperarElementoClick("/html/body/section/section/section/div[2]/section/div/section[2]/div/div/div[2]/div[2]/button[1]", ("Pujando Jugador"+intentos));
					if(listaUsada>=tamanioListaObjetivos) {
						esperarPujas();
						listaUsada = listaUsada();
						ganados = listaUsada();
						irTraspasos();
						irMercado();
						esperarElementoClick("//*[@id=\"ut-search-wrapper\"]/div[2]/div/div[2]/button[2]", "Buscar Jugadores");

						break;
					}
					//CambiarPagina
					if(intentos == 15) {
						esperarElementoClick("/html/body/section/section/section/div[2]/section/div/section[1]/div/div[1]/button[2]", "Cambiando Pagina");
						intentos = 1;
						continue;
					}
					intentos++;
				}
			}
			venderJugadores();
			DateFormat hourFormat = new SimpleDateFormat("HH:mm:ss dd/MM/yyyy");
			System.out.println("====================Pausando Pujas=============="+hourFormat.format(new Date()));
			pausar(900000);
			limpiarVendidos();
			System.out.println("====================Reanudando Pujas=============="+hourFormat.format(new Date()));
		}
		
	}
	
	private void limpiarVendidos() {
		irTraspasos();
		esperarElementoClick("/html/body/section/section/section/div[2]/div/div/div[3]", "Lista de Transferencia");
		
	   try {
		   System.out.println("Eliminado articulos no Vendidos");
		   pausar(2000);
		   element = webDriver.findElement(By.xpath("//*[@id=\"TradePile\"]/section[1]/header/button"));
		   element.click();
		   System.out.println("=======================EXITO==============================");
	   }catch (Throwable e) {
		   System.out.println("=======================ERROR==============================");
	   }
	}
	
	private void venderJugadores() {
		int articulos = 1;
		irTraspasos();
		irObjetivosMercado();
		while(articulos < (tamanioListaObjetivos-9)) {
			esperarElementoClick("/html/body/section/section/section/div[2]/section/div/div/section[3]/ul/li[1]/div", "Seleccionando al Jugador "+articulos);
			esperarElementoClick("/html/body/section/section/section/div[2]/section/div/section/div/div/div[2]/div[2]/div[1]/button", "Poner en Transferibles");
			pausar(1000);
			ingresarDatosEsperar("/html/body/section/section/section/div[2]/section/div/section/div/div/div[2]/div[2]/div[2]/div[3]/div[2]/div/input", " 450", "Precio Jugador"+articulos);
			esperarElementoClick("/html/body/section/section/section/div[2]/section/div/section/div/div/div[2]/div[2]/div[2]/button", "Enviando a Transferibles");
		}
	}
	
	private void esperarPujas() {
		irTraspasos();
		boolean esperar = true;
		irObjetivosMercado();
		while(esperar) {
			System.out.println("Esperando a la Finalizacion de las Pujas.");
			try {
				element = webDriver.findElement(By.xpath("/html/body/section/section/section/div[2]/section/div/div/section[1]/section"));
				esperar = false;
				pausar(2000);
			}catch (Throwable e) {
				System.out.println("Aun hay pujas Activas.");
				pausar(10000);
			}
		}
		esperarElementoClick("/html/body/section/section/section/div[2]/section/div/div/section[4]/header/button", "Elementos no Ganados.");		
	}
	
	public int listaUsada() {
		int usados = 0;
		irTraspasos();
		
		usados = Integer.parseInt(obtenerTextoEspera("/html/body/section/section/section/div[2]/div/div/div[4]/div[2]/div/div[1]/span[1]", "Tamanio Lista Objetivos."));
		
		return usados;
	}
	
	private int elementosGanados() {
		irTraspasos();
		
		return Integer.parseInt(obtenerTextoEspera("/html/body/section/section/section/div[2]/div/div/div[4]/div[2]/div/div[2]/span[2]", "Elementos Ganados."));
	}
	
	public void irMercado() {
		esperarElementoClick("/html/body/section/section/section/div[2]/div/div/div[2]", "Mercado");
	}
	
	private void irObjetivosMercado() {
		esperarElementoClick("/html/body/section/section/section/div[2]/div/div/div[4]", "Objetivos de Mercado");
	}
	
	private void irListaTransferencias() {
		esperarElementoClick("/html/body/section/section/section/div[2]/div/div/div[3]", "Lista Transferencias");
	}
	
	private void ingresarDatosEsperar(String elemento,String datos, String mensaje) {
		boolean esperar = true;
		System.out.println("Ingresando Datos a:"+mensaje);
		while(esperar) {
			try {
				element = webDriver.findElement(By.xpath(elemento));
				if(!element.isEnabled()) {
					System.out.println("Se repite por Enabled");
					continue;
				}
					
				if(!element.isDisplayed()) {
					System.out.println("Se repite por Displayed");
					continue;
				}
					
				esperar=false;
			}catch (Throwable e) {
				System.out.println("No fue posible Ingresar datos en:"+mensaje);
				pausar(1000);
				continue;
			}
		}
		element.clear();
		element.sendKeys(datos);
		
	}
	
	private void esperarElementoClick(String elemento,String mensaje) {
		boolean esperar = true;
		System.out.println("Obteniendo el Boton:"+mensaje);
		while(esperar) {
			try {
				element = webDriver.findElement(By.xpath(elemento));
				element.click();
				esperar = false;
			}catch (Throwable e) {
				System.out.println("No se pudo encontrar el Boton:"+mensaje);
				pausar(1000);
			}
		}
	}
	
	private String obtenerTextoEspera(String elemento,String mensaje) {
		boolean esperar = true;
		System.out.println("Obteniendo Texto de:"+mensaje);
		while(esperar) {
			try {
				element = webDriver.findElement(By.xpath(elemento));
				esperar = false;
				return element.getText();
			}catch (Throwable e) {
				System.out.println("No se pudo encontrar el Texto de:"+mensaje);
				pausar(1000);
			}
		}
		return "";
	}
	
	private void pausar(int tiempo) {
		try {
			Thread.sleep(tiempo);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
}
