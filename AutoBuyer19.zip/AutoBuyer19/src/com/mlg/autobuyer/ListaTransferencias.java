package com.mlg.autobuyer;

public class ListaTransferencias {

}
