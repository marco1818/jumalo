package com.mlg.autobuyer;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Principal {
	public static void main(String [] args) {
		System.setProperty("webdriver.chrome.driver","/home/marco/Documentos/Librerias/Selenium/chromedriver");
		String url = "https://www.easports.com/es/fifa/ultimate-team/fut-app";
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get(url);
		MercadoTransferencias mercadoTransferencias = new MercadoTransferencias(driver, null,50);
	}
}
