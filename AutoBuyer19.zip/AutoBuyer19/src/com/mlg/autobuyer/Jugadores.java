package com.mlg.autobuyer;

public class Jugadores {
	private String nombre;
	private int inicialMinimo;
	private int inicialMaximo;
	private int comprarMinimo;
	private int comprarMaximo;
	
	public Jugadores() {
		
	}

	public int getInicialMinimo() {
		return inicialMinimo;
	}

	public void setInicialMinimo(int inicialMinimo) {
		this.inicialMinimo = inicialMinimo;
	}

	public int getInicialMaximo() {
		return inicialMaximo;
	}

	public void setInicialMaximo(int inicialMaximo) {
		this.inicialMaximo = inicialMaximo;
	}

	public int getComprarMinimo() {
		return comprarMinimo;
	}

	public void setComprarMinimo(int comprarMinimo) {
		this.comprarMinimo = comprarMinimo;
	}

	public int getComprarMaximo() {
		return comprarMaximo;
	}

	public void setComprarMaximo(int comprarMaximo) {
		this.comprarMaximo = comprarMaximo;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	
}
