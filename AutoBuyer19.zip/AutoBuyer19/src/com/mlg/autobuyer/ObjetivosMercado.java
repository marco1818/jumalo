package com.mlg.autobuyer;

public class ObjetivosMercado {

}
