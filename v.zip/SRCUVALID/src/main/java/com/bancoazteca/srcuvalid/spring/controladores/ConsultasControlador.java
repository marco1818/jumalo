package com.bancoazteca.srcuvalid.spring.controladores;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.bancoazteca.srcuvalid.spring.dao.utilerias.BaseDAO;

@Controller
public class ConsultasControlador extends BaseDAO{

	@RequestMapping(value= {"/ambienteEmpleadoCR.htm"}, method= RequestMethod.GET)
	public ModelAndView consultas() {
		ModelAndView modelAndView = new ModelAndView();
		
		metadatosTabla("EMPLEADO_CR","SELECT * FROM RCREDITO.EMPLEADO_CR");
		
		modelAndView.setViewName("query/consulta");
		return modelAndView;
	}
	
	@RequestMapping(value= {"/ambienteZonaCobzaEmp.htm"}, method= RequestMethod.GET)
	public ModelAndView consultas1() {
		ModelAndView modelAndView = new ModelAndView();
		
		metadatosTabla("ZONA_COBZAEMP","SELECT * FROM RCREDITO.ZONA_COBZAEMP");
		
		modelAndView.setViewName("query/consulta");
		return modelAndView;
	}
	
	@RequestMapping(value= {"/ambienteZonaCobzaGeografia.htm"}, method= RequestMethod.GET)
	public ModelAndView consultas2() {
		ModelAndView modelAndView = new ModelAndView();
		
		metadatosTabla("ZONA_COBZAGEOGRAFIA","SELECT * FROM RCREDITO.ZONA_COBZAGEOGRAFIA WHERE ROWNUM <1000001");
		
		modelAndView.setViewName("query/consulta");
		return modelAndView;
	}
	
}
