package com.bancoazteca.srcuvalid.spring.dao.utilerias;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.CallableStatementCallback;
import org.springframework.jdbc.core.CallableStatementCreator;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

@Component
public class BaseDAO {
	
	public interface Enum_Tipos_Datos_Oracle{
		int character	=	1;
		int number		=	2;
		int varchar2	=	12;
		int date		=	93;
	}
	
	StringBuilder concatenar = new StringBuilder();
	StringBuilder concatenarDelete = new StringBuilder();
	int actual = 10000;
	int nuevoArchivo = 50000;
	int consecutivo = 0;
	int rowNum = 1;
	
	@Autowired
	protected JdbcTemplate jdbcTemplate;
	
	public BaseDAO() {		
	}

	public BaseDAO(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}
	
	public void metadatosTabla(final String nombreTabla,final String query) {
		System.out.println("Iniciando");
		rowNum = 0;
		jdbcTemplate.execute(new CallableStatementCreator() {
			@Override
			public CallableStatement createCallableStatement(Connection con) throws SQLException {
				CallableStatement callableStatement	=	con.prepareCall("{? = call RCREDITO.FNADSSLG0999(?) }");
				callableStatement.registerOutParameter(1, -10);
				callableStatement.setObject(2, query);
				return callableStatement;
			}
		}, new CallableStatementCallback<Object>() {

			@Override
			public Object doInCallableStatement(CallableStatement cs) throws SQLException, DataAccessException {
				cs.execute();
				ResultSet rs = (ResultSet) cs.getObject(1);
				while(rs.next()) {
				String insert = "INSERT INTO RCREDITO."+nombreTabla+" (";
				String delete = "DELETE FROM RCREDITO."+nombreTabla+" WHERE ";
				for(int x = 1; x <= rs.getMetaData().getColumnCount(); x++) {
					insert += rs.getMetaData().getColumnName(x)+",";
					
				}
				
				insert = insert.substring(0,insert.length()-1);
				insert+=") VALUES (";
				
					String fila="";
					for(int r=1;r<=rs.getMetaData().getColumnCount();r++) {
						if(rs.getString(r)!=null ) {
							if(!rs.getString(r).contains("\n")) {
								delete += rs.getMetaData().getColumnName(r)+"=";
							}
						}
						
						switch (rs.getMetaData().getColumnType(r)) {
						case Enum_Tipos_Datos_Oracle.character:
							fila 	+= "'"+rs.getString(r)+"',";
							if(rs.getString(r)!=null ) {
								if(!rs.getString(r).contains("\n")) {
									delete	+= "'"+rs.getString(r).replaceAll("&", "")+"' AND ";
								}
								
							}
							break;
						case Enum_Tipos_Datos_Oracle.date:
							fila 	+= "TO_DATE('"+rs.getString(r)+"','YYYY-MM-DD HH24:MI:SS'),";	
							if(rs.getString(r)!=null ) {
								if(!rs.getString(r).contains("\n")) {
									delete	+= "TO_DATE('"+rs.getString(r)+"','YYYY-MM-DD HH24:MI:SS') AND ";
								}
								
							}
							
							break;
						case Enum_Tipos_Datos_Oracle.number:
							fila 	+= rs.getString(r)+",";
							if(rs.getString(r)!=null) {
								if(!rs.getString(r).contains("\n")) {
									delete 	+= rs.getString(r)+" AND ";
								}
								
							}
							break;
						case Enum_Tipos_Datos_Oracle.varchar2:
							fila 	+= "'"+rs.getString(r)+"',";
							if(rs.getString(r)!=null) {
								if(!rs.getString(r).contains("\n")) {
									delete	+= "'"+rs.getString(r).replaceAll("&", "")+"' AND ";
								}
								
							}
							break;
							
						default:
							break;
						}
						

					}
					fila = fila.substring(0,fila.length()-1);
					delete = delete.substring(0,delete.length()-4);
					fila+=");\n";
					delete+=";\n";
					insert += fila;
					rowNum++;
					concatenar(insert,delete,rowNum,nombreTabla);
					
				}
				return null;
			}
		});
		String strDelete = "/home/jboss/DELETE_"+nombreTabla+consecutivo+".sql";
		String srtInsert = "/home/jboss/INSERT_"+nombreTabla+consecutivo+".sql";
		
//		String strDelete = "E:\\Users\\b190048\\Documents\\AMBIENTES\\DELETE_"+nombreTabla+consecutivo+".sql";
//		String srtInsert = "E:\\Users\\b190048\\Documents\\AMBIENTES\\INSERT_"+nombreTabla+consecutivo+".sql";
		File deleteFile = new File(strDelete);
		File insertFile = new File(srtInsert);
		FileWriter escribirDelete = null;
		FileWriter escribirInsert = null;
		try {
			escribirInsert=new FileWriter(insertFile,true);
			escribirInsert.write(concatenar.toString());
			escribirInsert.close();
			escribirDelete=new FileWriter(deleteFile,true);
			escribirDelete.write(concatenarDelete.toString());
			escribirDelete.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		System.out.println("Terminado:");
		
	}
	
	public void concatenar(String cadena,String delete,int rownum,String nombreTabla) {
		if(rownum == actual) {
			String strDelete = "/home/jboss/DELETE_"+nombreTabla+consecutivo+".sql";
			String srtInsert = "/home/jboss/INSERT_"+nombreTabla+consecutivo+".sql";
//			String strDelete = "E:\\Users\\b190048\\Documents\\AMBIENTES\\DELETE_"+nombreTabla+consecutivo+".sql";
//			String srtInsert = "E:\\Users\\b190048\\Documents\\AMBIENTES\\INSERT_"+nombreTabla+consecutivo+".sql";
			
			File deleteFile = new File(strDelete);
			File insertFile = new File(srtInsert);
			FileWriter escribirDelete = null;
			FileWriter escribirInsert = null;
			try {
				escribirInsert=new FileWriter(insertFile,true);
				escribirInsert.write(concatenar.toString());
				escribirInsert.close();
				escribirDelete=new FileWriter(deleteFile,true);
				escribirDelete.write(concatenarDelete.toString());
				escribirDelete.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
			
			System.out.println("Escribiendo en:"+actual+"---NuevoArchivo:"+nuevoArchivo);
			actual +=10000;
			concatenar = new StringBuilder();
			concatenarDelete = new StringBuilder();
			if(nuevoArchivo == rownum) {
				nuevoArchivo+=50000;
				consecutivo++;
			}
		}
		concatenar.append(cadena);
		concatenarDelete.append(delete);
	}
}
