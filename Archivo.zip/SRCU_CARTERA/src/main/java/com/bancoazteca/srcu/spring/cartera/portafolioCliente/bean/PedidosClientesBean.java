package com.bancoazteca.srcu.spring.cartera.portafolioCliente.bean;

import java.math.BigDecimal;

public class PedidosClientesBean {
	private String nombreCliente;
	private int pais;
	private int canal;
	private int sucursal;
	private int pedido;
	private int segmento;
	private BigDecimal saldoAnterior;
	private BigDecimal saldoCapital;
	private BigDecimal moratorios;
	private int periodoAtraso;
	private BigDecimal saldoAtrasado;
	private BigDecimal saldoAtrasado2;
	private int semanasAtraso;
	private int unidadNegocio;
	private BigDecimal total;
	private BigDecimal saldoTotal;
	private String desSucursal;
	private String descCanal;
	private int inactividad;
	private BigDecimal ultimoAbono;
	private int unidadNegocio2;
	private int saldoTotal2;
	private BigDecimal pagoRequerido;
	private int diasAtraso;
	private int planPago;
	private String diaPago;
	
	public PedidosClientesBean() {
		
	}

	public String getNombreCliente() {
		return nombreCliente;
	}

	public void setNombreCliente(String nombreCliente) {
		this.nombreCliente = nombreCliente;
	}

	public int getPais() {
		return pais;
	}

	public void setPais(int pais) {
		this.pais = pais;
	}

	public void setPais(BigDecimal pais) {
		this.pais = pais.intValue();
	}
	
	public int getCanal() {
		return canal;
	}

	public void setCanal(int canal) {
		this.canal = canal;
	}

	public void setCanal(BigDecimal canal) {
		this.canal = canal.intValue();
	}

	public int getSucursal() {
		return sucursal;
	}
	
	public void setSucursal(int sucursal) {
		this.sucursal = sucursal;
	}

	public void setSucursal(BigDecimal sucursal) {
		this.sucursal = sucursal.intValue();
	}

	public int getPedido() {
		return pedido;
	}
	
	public void setPedido(int pedido) {
		this.pedido = pedido;
	}

	public void setPedido(BigDecimal pedido) {
		this.pedido = pedido.intValue();
	}

	public int getSegmento() {
		return segmento;
	}
	
	public void setSegmento(int segmento) {
		this.segmento = segmento;
	}

	public void setSegmento(BigDecimal segmento) {
		this.segmento = segmento.intValue();
	}

	public BigDecimal getSaldoAnterior() {
		return saldoAnterior;
	}

	public void setSaldoAnterior(BigDecimal saldoAnterior) {
		this.saldoAnterior = saldoAnterior;
	}

	public BigDecimal getSaldoCapital() {
		return saldoCapital;
	}

	public void setSaldoCapital(BigDecimal saldoCapital) {
		this.saldoCapital = saldoCapital;
	}

	public BigDecimal getMoratorios() {
		return moratorios;
	}

	public void setMoratorios(BigDecimal moratorios) {
		this.moratorios = moratorios;
	}

	public int getPeriodoAtraso() {
		return periodoAtraso;
	}
	
	public void setPeriodoAtraso(int periodoAtraso) {
		this.periodoAtraso = periodoAtraso;
	}

	public void setPeriodoAtraso(BigDecimal periodoAtraso) {
		this.periodoAtraso = periodoAtraso.intValue();
	}

	public BigDecimal getSaldoAtrasado() {
		return saldoAtrasado;
	}

	public void setSaldoAtrasado(BigDecimal saldoAtrasado) {
		this.saldoAtrasado = saldoAtrasado;
	}

	public BigDecimal getSaldoAtrasado2() {
		return saldoAtrasado2;
	}

	public void setSaldoAtrasado2(BigDecimal saldoAtrasado2) {
		this.saldoAtrasado2 = saldoAtrasado2;
	}

	public int getSemanasAtraso() {
		return semanasAtraso;
	}

	public void setSemanasAtraso(int semanasAtraso) {
		this.semanasAtraso = semanasAtraso;
	}

	public void setSemanasAtraso(BigDecimal semanasAtraso) {
		this.semanasAtraso = semanasAtraso.intValue();
	}
	
	public int getUnidadNegocio() {
		return unidadNegocio;
	}

	public void setUnidadNegocio(int unidadNegocio) {
		this.unidadNegocio = unidadNegocio;
	}
	
	public void setUnidadNegocio(BigDecimal unidadNegocio) {
		this.unidadNegocio = unidadNegocio.intValue();
	}

	public BigDecimal getTotal() {
		return total;
	}

	public void setTotal(BigDecimal total) {
		this.total = total;
	}

	public BigDecimal getSaldoTotal() {
		return saldoTotal;
	}

	public void setSaldoTotal(BigDecimal saldoTotal) {
		this.saldoTotal = saldoTotal;
	}

	public String getDesSucursal() {
		return desSucursal;
	}

	public void setDesSucursal(String desSucursal) {
		this.desSucursal = desSucursal;
	}

	public String getDescCanal() {
		return descCanal;
	}

	public void setDescCanal(String descCanal) {
		this.descCanal = descCanal;
	}

	public int getInactividad() {
		return inactividad;
	}

	public void setInactividad(int inactividad) {
		this.inactividad = inactividad;
	}
	
	public void setInactividad(BigDecimal inactividad) {
		this.inactividad = inactividad.intValue();
	}

	public BigDecimal getUltimoAbono() {
		return ultimoAbono;
	}

	public void setUltimoAbono(BigDecimal ultimoAbono) {
		this.ultimoAbono = ultimoAbono;
	}

	public int getUnidadNegocio2() {
		return unidadNegocio2;
	}

	public void setUnidadNegocio2(int unidadNegocio2) {
		this.unidadNegocio2 = unidadNegocio2;
	}
	
	public void setUnidadNegocio2(BigDecimal unidadNegocio2) {
		this.unidadNegocio2 = unidadNegocio2.intValue();
	}

	public int getSaldoTotal2() {
		return saldoTotal2;
	}

	public void setSaldoTotal2(int saldoTotal2) {
		this.saldoTotal2 = saldoTotal2;
	}
	
	public void setSaldoTotal2(BigDecimal saldoTotal2) {
		this.saldoTotal2 = saldoTotal2.intValue();
	}

	public BigDecimal getPagoRequerido() {
		return pagoRequerido;
	}

	public void setPagoRequerido(BigDecimal pagoRequerido) {
		this.pagoRequerido = pagoRequerido;
	}

	public int getDiasAtraso() {
		return diasAtraso;
	}

	public void setDiasAtraso(int diasAtraso) {
		this.diasAtraso = diasAtraso;
	}

	public void setDiasAtraso(BigDecimal diasAtraso) {
		this.diasAtraso = diasAtraso.intValue();
	}
	
	public int getPlanPago() {
		return planPago;
	}

	public void setPlanPago(int planPago) {
		this.planPago = planPago;
	}
	
	public void setPlanPago(BigDecimal planPago) {
		this.planPago = planPago.intValue();
	}

	public String getDiaPago() {
		return diaPago;
	}

	public void setDiaPago(String diaPago) {
		this.diaPago = diaPago;
	}

}

 