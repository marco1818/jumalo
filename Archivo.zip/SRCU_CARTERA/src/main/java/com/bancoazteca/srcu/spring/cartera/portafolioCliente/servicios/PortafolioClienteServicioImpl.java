package com.bancoazteca.srcu.spring.cartera.portafolioCliente.servicios;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bancoazteca.srcu.spring.cartera.portafolioCliente.bean.PortafolioBean;
import com.bancoazteca.srcu.spring.cartera.portafolioCliente.bean.PortafolioClienteBean;
import com.bancoazteca.srcu.spring.cartera.portafolioCliente.daos.PortafolioClienteDAO;
import com.bancoazteca.srcu.spring.sistema.beans.CatalogoBean;
import com.bancoazteca.srcu.spring.sistema.servicios.BaseServicio;

@Service
public class PortafolioClienteServicioImpl extends BaseServicio implements PortafolioClienteServicio{

	private interface Consultas{
		int	portafolios			=	1;
		int portafolioEmpleado	=	2;
		int pedidosCliente		=	3;
	}
	
	@Autowired
	PortafolioClienteDAO portafolioClienteDAO;
	
	@Override
	public PortafolioClienteBean consulta(PortafolioClienteBean portafolioClienteBean, int tipoConsulta) {
		
		switch (tipoConsulta) {
		case Consultas.portafolios:
			portafolioClienteBean.setGerenciaJP(gerenciaJP(portafolioClienteBean.getDepartamentoId()));
			portafolioClienteBean.setSegmentos(consultaSegmentos(portafolioClienteBean));
			portafolioClienteBean.setPortafolios(portafolios(portafolioClienteBean));
			break;
		case Consultas.portafolioEmpleado:
			portafolioClienteBean.setClientes(portafolioClienteDAO.consultaPortafolioEmpleado(portafolioClienteBean));
			break;
		case Consultas.pedidosCliente:
			portafolioClienteBean.setPedidos(portafolioClienteDAO.consultaPedidosCliente(portafolioClienteBean));
			break;

		default:
			break;
		}
		
		return portafolioClienteBean;
	}

	private List<CatalogoBean> consultaSegmentos(PortafolioClienteBean portafolioClienteBean){
		List<CatalogoBean> segmentos = null;
		
		if(portafolioClienteBean.getDepartamentoId() >= 4000 && portafolioClienteBean.getDepartamentoId() <= 5000) {
			segmentos = (List<CatalogoBean>) consultaItemFront(483, 0);
			return segmentos;
		}
		
		if(obtieneCatunicoTDA(224, portafolioClienteBean.getDepartamentoId())) {
			segmentos = (List<CatalogoBean>) consultaItemFront(482, 0);
			return segmentos;
		}
		
		segmentos = (List<CatalogoBean>) consultaItemFront(481, 0);
		
		return segmentos;
	}
	
	private int gerenciaJP(int departamentoId) {
		
		return obtieneCatunicoTDA(224, departamentoId)?1:0;
	}
	
	private List<PortafolioBean> portafolios(PortafolioClienteBean portafolioClienteBean) {
		if(portafolioClienteBean.getTipoConsulta() == 1) {
			return portafolioClienteDAO.consultaPortafoliosGerencia055(portafolioClienteBean);
		}
		
		return portafolioClienteDAO.consultaPortafoliosGerencia(portafolioClienteBean);
		
	}
}
