package com.bancoazteca.srcu.spring.cartera.portafolioCliente.daos;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.bancoazteca.srcu.spring.cartera.portafolioCliente.bean.ClientesBean;
import com.bancoazteca.srcu.spring.cartera.portafolioCliente.bean.PedidosClientesBean;
import com.bancoazteca.srcu.spring.cartera.portafolioCliente.bean.PortafolioBean;
import com.bancoazteca.srcu.spring.cartera.portafolioCliente.bean.PortafolioClienteBean;
import com.bancoazteca.srcu.spring.sistema.daos.BaseDAO;

@Repository
public class PortafolioClienteDAOImpl extends BaseDAO implements PortafolioClienteDAO{

	private interface Funciones{
		String	consultaPortafoliosGerencia		=	"PORTAFOLIO_CLIENTE_CONSULTA_PORTAFOLIOS_GERENCIA";
		String	consultaPortafoliosGerencia055	=	"PORTAFOLIO_CLIENTE_CONSULTA_PORTAFOLIOS_GERENCIA_0_55";
		String	consultaPortafolioEmpleado		=	"PORTAFOLIO_CLIENTE_CONSULTA_PORTAFOLIO_EMPLEADO";
		String	consultaPedidosCliente			=	"PORTAFOLIO_CLIENTE_CONSULTA_PEDIDOS_CLIENTE";
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<PortafolioBean> consultaPortafoliosGerencia(PortafolioClienteBean portafolioClienteBean) {
		List<PortafolioBean> portafolios = new ArrayList<PortafolioBean>();
		ArrayList<Object> parametros = new ArrayList<Object>();
		parametros.add(portafolioClienteBean.getDepartamentoId());
		parametros.add(portafolioClienteBean.getSegmentoOperar());
		
		portafolios = (List<PortafolioBean>) ejecutaFuncionAll(Funciones.consultaPortafoliosGerencia, parametros, PortafolioBean.class);
		
		return portafolios;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<PortafolioBean> consultaPortafoliosGerencia055(PortafolioClienteBean portafolioClienteBean) {
		List<PortafolioBean> portafolios = new ArrayList<PortafolioBean>();
		ArrayList<Object> parametros = new ArrayList<Object>();
		parametros.add(portafolioClienteBean.getDepartamentoId());
		
		portafolios = (List<PortafolioBean>) ejecutaFuncionAll(Funciones.consultaPortafoliosGerencia055, parametros, PortafolioBean.class);
		
		return portafolios;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<ClientesBean> consultaPortafolioEmpleado(PortafolioClienteBean portafolioClienteBean) {
		List<ClientesBean> clientes = new ArrayList<ClientesBean>();
		ArrayList<Object> parametros = new ArrayList<Object>();
		parametros.add(portafolioClienteBean.getNumeroEmpleado());
		parametros.add(portafolioClienteBean.getDepartamentoId());
		parametros.add(portafolioClienteBean.getSegmentoEmpleado());
		
		clientes = (List<ClientesBean>) ejecutaFuncionAll(Funciones.consultaPortafolioEmpleado, parametros, ClientesBean.class);
		
		return clientes;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<PedidosClientesBean> consultaPedidosCliente(PortafolioClienteBean portafolioClienteBean) {
		List<PedidosClientesBean> pedidos = new ArrayList<PedidosClientesBean>();
		ArrayList<Object> parametros = new ArrayList<Object>();
		parametros.add(portafolioClienteBean.getPaisId());
		parametros.add(portafolioClienteBean.getCanalId());
		parametros.add(portafolioClienteBean.getSucursalId());
		parametros.add(portafolioClienteBean.getFolioId());
		
		pedidos = (List<PedidosClientesBean>) ejecutaFuncionAll(Funciones.consultaPedidosCliente, parametros, PedidosClientesBean.class);
		
		return pedidos;
	}
	
}
