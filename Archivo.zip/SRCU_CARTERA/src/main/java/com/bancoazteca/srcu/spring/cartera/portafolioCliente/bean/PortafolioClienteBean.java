package com.bancoazteca.srcu.spring.cartera.portafolioCliente.bean;

import java.util.List;

import com.bancoazteca.srcu.spring.sistema.beans.BaseBean;
import com.bancoazteca.srcu.spring.sistema.beans.CatalogoBean;

public class PortafolioClienteBean extends BaseBean{
	private int departamentoId;
	private int segmentoOperar;
	private String numeroEmpleado;
	private int segmentoEmpleado;
	private int gerenciaJP;
	private int tipoConsulta;
	private int paisId;
	private int canalId;
	private int sucursalId;
	private int folioId;
	private	List<CatalogoBean> segmentos;
	private List<PortafolioBean> portafolios;
	private List<ClientesBean> clientes;
	private List<PedidosClientesBean> pedidos;
	
	public PortafolioClienteBean() {
		
	}

	public int getDepartamentoId() {
		return departamentoId;
	}

	public void setDepartamentoId(int departamentoId) {
		this.departamentoId = departamentoId;
	}
	
	public int getSegmentoOperar() {
		return segmentoOperar;
	}

	public void setSegmentoOperar(int segmentoOperar) {
		this.segmentoOperar = segmentoOperar;
	}

	public int getSegmentoEmpleado() {
		return segmentoEmpleado;
	}

	public void setSegmentoEmpleado(int segmentoEmpleado) {
		this.segmentoEmpleado = segmentoEmpleado;
	}

	public List<PortafolioBean> getPortafolios() {
		return portafolios;
	}

	public void setPortafolios(List<PortafolioBean> portafolios) {
		this.portafolios = portafolios;
	}

	public String getNumeroEmpleado() {
		return numeroEmpleado;
	}

	public void setNumeroEmpleado(String numeroEmpleado) {
		this.numeroEmpleado = numeroEmpleado;
	}

	public List<ClientesBean> getClientes() {
		return clientes;
	}

	public void setClientes(List<ClientesBean> clientes) {
		this.clientes = clientes;
	}

	public int getPaisId() {
		return paisId;
	}

	public void setPaisId(int paisId) {
		this.paisId = paisId;
	}

	public int getCanalId() {
		return canalId;
	}

	public void setCanalId(int canalId) {
		this.canalId = canalId;
	}

	public int getSucursalId() {
		return sucursalId;
	}

	public void setSucursalId(int sucursalId) {
		this.sucursalId = sucursalId;
	}

	public int getFolioId() {
		return folioId;
	}

	public void setFolioId(int folioId) {
		this.folioId = folioId;
	}

	public List<PedidosClientesBean> getPedidos() {
		return pedidos;
	}

	public void setPedidos(List<PedidosClientesBean> pedidos) {
		this.pedidos = pedidos;
	}

	public List<CatalogoBean> getSegmentos() {
		return segmentos;
	}

	public void setSegmentos(List<CatalogoBean> segmentos) {
		this.segmentos = segmentos;
	}

	public int getGerenciaJP() {
		return gerenciaJP;
	}

	public void setGerenciaJP(int gerenciaJP) {
		this.gerenciaJP = gerenciaJP;
	}

	public int getTipoConsulta() {
		return tipoConsulta;
	}

	public void setTipoConsulta(int tipoConsulta) {
		this.tipoConsulta = tipoConsulta;
	}

	
	
}
