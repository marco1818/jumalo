package com.bancoazteca.srcu.spring.cartera.portafolioCliente.servicios;

import com.bancoazteca.srcu.spring.cartera.portafolioCliente.bean.PortafolioClienteBean;

public interface PortafolioClienteServicio {
	public	PortafolioClienteBean consulta(PortafolioClienteBean portafolioClienteBean, int tipoConsulta);
}
