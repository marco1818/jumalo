package com.bancoazteca.srcu.spring.originacion.solicitudes.dobleAutorizacion.restControllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.bancoazteca.srcu.spring.originacion.solicitudes.dobleAutorizacion.beans.DobleAutorizacionBean;
import com.bancoazteca.srcu.spring.originacion.solicitudes.dobleAutorizacion.servicios.DobleAutorizacionServicio;
import com.bancoazteca.srcu.spring.sistema.beans.MensajeTransaccionBean;

@RestController
@RequestMapping("/api/v1/solicitudes/dobleautorizacion")
public class DobleAutorizacionRestController {

	@Autowired
	DobleAutorizacionServicio dobleAutorizacionServicio;
	
	@PostMapping(value="/autorizar")
	@ResponseBody
	public MensajeTransaccionBean autorizaSolicitudes(@RequestBody DobleAutorizacionBean dobleAutorizacionBean ) {
		MensajeTransaccionBean mensajeTransaccionBean = null;
		
		mensajeTransaccionBean = dobleAutorizacionServicio.grabaTransaccion(dobleAutorizacionBean, 1);
		
		return mensajeTransaccionBean;
	}
	
	@PostMapping(value="/rechazar")
	@ResponseBody
	public MensajeTransaccionBean rechazaSolicitudes(@RequestBody DobleAutorizacionBean dobleAutorizacionBean) {
		MensajeTransaccionBean mensajeTransaccionBean = null;
		
		mensajeTransaccionBean = dobleAutorizacionServicio.grabaTransaccion(dobleAutorizacionBean, 2);
		
		return mensajeTransaccionBean;
	} 
	

}
