package com.bancoazteca.srcu.spring.originacion.solicitudes.dobleAutorizacion.beans;


public class RespuestaMOCBean {
	private int codigo;
	private String descripcion;
	private String status;
	private Boolean error;
	private	DataMOCBean data;
	
	public RespuestaMOCBean() {
	}
	
	public int getCodigo() {
		return codigo;
	}
	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}
	public String getDescripcion() {
		return descripcion;
	}
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Boolean getError() {
		return error;
	}
	public void setError(Boolean error) {
		this.error = error;
	}

	public DataMOCBean getData() {
		return data;
	}

	public void setData(DataMOCBean data) {
		this.data = data;
	}
	
}
