package com.bancoazteca.srcu.spring.sistema.servicios;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

import org.springframework.stereotype.Service;

import com.bancoazteca.srcu.spring.originacion.solicitudes.dobleAutorizacion.beans.RespuestaMOCBean;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

@Service
public class RestBaseServicio {
	
	public RespuestaMOCBean	consumirMocPost(String endPoint,Map<String,String> pathVariable,Object parametrosJson ,Class<?> clase) {
    
		if(!pathVariable.isEmpty()) {
			Iterator<Entry<String, String>> iterator = pathVariable.entrySet().iterator();
			endPoint+="?";
			int posicion = 0;
			while(iterator.hasNext()) {
				
				if(posicion>0) {
					endPoint+="&";
				}
				
				Map.Entry<String, String> parametros = (Map.Entry<String, String>)iterator.next();
				endPoint+=parametros.getKey()+"="+parametros.getValue();
				posicion++;
			}
		}
		
		Gson gson = new GsonBuilder().create(); 
		RespuestaMOCBean respuestaMOCBean = new RespuestaMOCBean();
		StringBuilder result = new StringBuilder();
		HttpURLConnection conn = null;
		BufferedReader br = null;
		InputStreamReader isr = null;
		InputStream is = null;
		String output ="";
		try {

			URL url = new URL(endPoint);
			conn = (HttpURLConnection) url.openConnection();
			conn.setDoOutput(true);
			conn.setRequestMethod("POST");
			conn.setRequestProperty("Content-Type", "application/json");
			conn.setConnectTimeout(60000);
		if (conn.getResponseCode() != 200) {
			respuestaMOCBean.setCodigo(conn.getResponseCode());
			respuestaMOCBean.setDescripcion("OCURRIO UN DETALLE AL CONSUMIR EL SERVICIO DE LA MOC.REF.-"+conn.getResponseCode());
		}
		is = conn.getInputStream();
		isr = new InputStreamReader(is);
		br = new BufferedReader(isr);
		while ((output = br.readLine()) != null) {
				result.append(output);
		}
		 
		 respuestaMOCBean = gson.fromJson(String.valueOf(result), RespuestaMOCBean.class);
		} catch (Exception e) {
		}finally {
			safeClose(conn);
			safeClose(isr);
			safeClose(is);
			safeClose(br);
		}
		
		return respuestaMOCBean;
	}
	
	public void safeClose(OutputStream fis) {
		if (fis != null) {
			try {
				fis.close();
			} catch (Exception e) {
				// logger.error(e);
			}
		}
	}

	public void safeClose(BufferedReader fis) {
		if (fis != null) {
			try {
				fis.close();
			} catch (Exception e) {
				// logger.error(e);
			}
		}
	}

	public void safeClose(InputStreamReader fis) {
		if (fis != null) {
			try {
				fis.close();
			} catch (Exception e) {
				// logger.error(e);
			}
		}
	}

	public void safeClose(HttpURLConnection fis) {
		if (fis != null) {
			try {
				fis.disconnect();
			} catch (Exception e) {
				// logger.error(e);
			}
		}
	}

	public void safeClose(InputStream fis) {
		if (fis != null) {
			try {
				fis.close();
			} catch (Exception e) {
			}
		}
	}
}
