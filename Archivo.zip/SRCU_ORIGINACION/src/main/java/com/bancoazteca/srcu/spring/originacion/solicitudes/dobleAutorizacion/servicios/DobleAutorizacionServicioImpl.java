package com.bancoazteca.srcu.spring.originacion.solicitudes.dobleAutorizacion.servicios;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bancoazteca.srcu.spring.originacion.solicitudes.dobleAutorizacion.beans.DobleAutorizacionBean;
import com.bancoazteca.srcu.spring.originacion.solicitudes.dobleAutorizacion.beans.RespuestaMOCBean;
import com.bancoazteca.srcu.spring.originacion.solicitudes.dobleAutorizacion.daos.DobleAutorizacionDAO;
import com.bancoazteca.srcu.spring.sistema.beans.MensajeTransaccionBean;
import com.bancoazteca.srcu.spring.sistema.beans.SimpleBean;
import com.bancoazteca.srcu.spring.sistema.servicios.BaseServicio;
import com.bancoazteca.srcu.spring.sistema.servicios.RestBaseServicio;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

@Service
public class DobleAutorizacionServicioImpl extends BaseServicio implements DobleAutorizacionServicio{
	
	private interface Consultas{
		int solicitudes	=	1;
	} 
	
	private interface Transacciones{
		int	autorizar	=	1;
		int rechazar		=	2;
	}
	
	private interface Constantes{
		int	error					=	999;
		int	autorizar				=	6;
		int rechazar					=	9;
		int obligadoSolidario		=	208;
		int	exitoAutorizacionMOC		=	2;
		int	exitoRechazoMOC			=	2;
	}
	
	@Autowired 
	RestBaseServicio restBaseServicio;
	
	@Autowired
	DobleAutorizacionDAO dobleAutorizacionDAO;
	
	@Override
	public DobleAutorizacionBean consulta(DobleAutorizacionBean dobleAutorizacionBean, int tipoConsulta) {

		switch (tipoConsulta) {
		case Consultas.solicitudes:
			
			break;

		default:
			break;
		}
		
		
		return dobleAutorizacionBean;
	}

	@Override
	public MensajeTransaccionBean grabaTransaccion(DobleAutorizacionBean dobleAutorizacionBean, int tipoTransaccion) {
		MensajeTransaccionBean mensajeTransaccionBean = new MensajeTransaccionBean();
		switch (tipoTransaccion) {
		case Transacciones.autorizar:
			mensajeTransaccionBean = autorizarSolicitudes(dobleAutorizacionBean);
			break;
			
		case Transacciones.rechazar:
			mensajeTransaccionBean = rechazaSolicitudes(dobleAutorizacionBean);
			break;

		default:
			break;
		}
		
		return mensajeTransaccionBean;
	}
	
	
	private MensajeTransaccionBean autorizarSolicitudes(DobleAutorizacionBean dobleAutorizacionBean) {
		MensajeTransaccionBean mensajeTransaccionBean = null;
		SimpleBean simpleBean = null;
		
		simpleBean = dobleAutorizacionDAO.validaSolicitudesMoc(dobleAutorizacionBean);
		
		if(simpleBean.getCodigo()>0) {
			simpleBean = dobleAutorizacionDAO.consultaDatosSolicitud(dobleAutorizacionBean);
			dobleAutorizacionBean.setTipoSolicitud(simpleBean.getCodigo());
			
			return autorizaSolicitudMOC(dobleAutorizacionBean);
		}
		try {
			dobleAutorizacionBean.setRespuestaIdMOC(0);
			dobleAutorizacionBean.setRespuestaMOC("NO SE RINDE EN MOC.");
			dobleAutorizacionBean.setEstatusRendicion(0);
			dobleAutorizacionBean.setCodigoHttp(0);
			
			dobleAutorizacionDAO.bitacoraSolicitudes(dobleAutorizacionBean);
		}catch (Throwable e) {
			
		}
		
		mensajeTransaccionBean = dobleAutorizacionDAO.autorizaSolicitudes(dobleAutorizacionBean);
		
		return mensajeTransaccionBean;
	}
	
	private MensajeTransaccionBean rechazaSolicitudes(DobleAutorizacionBean dobleAutorizacionBean) {
		MensajeTransaccionBean mensajeTransaccionBean = null;
		SimpleBean simpleBean = null;
		simpleBean = dobleAutorizacionDAO.validaSolicitudesMoc(dobleAutorizacionBean);
		if(simpleBean.getCodigo()>0) {
			simpleBean = dobleAutorizacionDAO.consultaDatosSolicitud(dobleAutorizacionBean);
			dobleAutorizacionBean.setTipoSolicitud(simpleBean.getCodigo());
			
			return rechazaSolicitudMOC(dobleAutorizacionBean);
		}
		
		try {
			dobleAutorizacionBean.setRespuestaIdMOC(0);
			dobleAutorizacionBean.setRespuestaMOC("NO SE RINDE EN MOC.");
			dobleAutorizacionBean.setEstatusRendicion(9);
			dobleAutorizacionBean.setCodigoHttp(0);
			
			mensajeTransaccionBean = dobleAutorizacionDAO.bitacoraSolicitudes(dobleAutorizacionBean);
		}catch (Throwable e) {
			
		}
		
		mensajeTransaccionBean = dobleAutorizacionDAO.rechazaSolicitudes(dobleAutorizacionBean);
		
		return mensajeTransaccionBean;
	}
	
	private MensajeTransaccionBean autorizaSolicitudMOC(DobleAutorizacionBean dobleAutorizacionBean) {
		MensajeTransaccionBean mensajeTransaccionBean = new MensajeTransaccionBean();
		String endPoint = "http://10.53.37.56:8084/OriginacionCentralizada/originacion/actualizaStatusTienda/actualizarStatus";
		JsonObject solicitudes = new JsonObject();
		JsonArray solicitud = new JsonArray();
		JsonObject datosSolicitud = new JsonObject();
		Map<String,String> pathVariable = new HashMap<String, String>();
		RespuestaMOCBean respuestaMOCBean = null;
		
		datosSolicitud.addProperty("pais", dobleAutorizacionBean.getPaisId());
		datosSolicitud.addProperty("canal", dobleAutorizacionBean.getCanalId());
		datosSolicitud.addProperty("sucursal", dobleAutorizacionBean.getSucursalId());
		datosSolicitud.addProperty("idSolicitud", dobleAutorizacionBean.getSolicitudId());
		datosSolicitud.addProperty("statusSolicitud", Constantes.autorizar);
		datosSolicitud.addProperty("observaciones", dobleAutorizacionBean.getObservaciones());
		datosSolicitud.addProperty("fechaRendicion", dobleAutorizacionBean.getFechaRendicion());
		datosSolicitud.addProperty("idEmpleado", dobleAutorizacionBean.getEmpleadoOpera());
		solicitud.add(datosSolicitud);
		solicitudes.add("solicitudes", solicitud);
		
		Gson gson = new Gson();
		String jsonParams = gson.toJson(solicitudes);
		try {
			pathVariable.put("jsonActualizar", URLEncoder.encode(jsonParams, "UTF-8"));
		} catch (UnsupportedEncodingException e) {
		}
		pathVariable.put("tipoPersonaSolicitud", String.valueOf(dobleAutorizacionBean.getTipoSolicitud()==Constantes.obligadoSolidario?1:0));
		
		respuestaMOCBean = restBaseServicio.consumirMocPost(endPoint, pathVariable, null, RespuestaMOCBean.class);
		String mensaje =  dobleAutorizacionBean.getPaisId()+"-"+dobleAutorizacionBean.getCanalId()+"-"+dobleAutorizacionBean.getSucursalId()+"-"+dobleAutorizacionBean.getSolicitudId()+"<br><br>";
		mensaje +="Peticion:"+endPoint+"?jsonActualizar="+jsonParams+"&tipoPersonaSolicitud="+String.valueOf(dobleAutorizacionBean.getTipoSolicitud()==Constantes.obligadoSolidario?1:0)+"<br><br>";
		
		if(respuestaMOCBean.getCodigo() != Constantes.exitoAutorizacionMOC) {

			dobleAutorizacionBean.setRespuestaIdMOC(respuestaMOCBean.getCodigo());
			dobleAutorizacionBean.setRespuestaMOC(respuestaMOCBean.getDescripcion());
			dobleAutorizacionBean.setEstatusRendicion(Constantes.autorizar);
			dobleAutorizacionBean.setCodigoHttp(200);
			
			mensaje+="Codigo Moc"+respuestaMOCBean.getCodigo()+"<br>";
			mensaje+="Mensaje MOC"+respuestaMOCBean.getDescripcion()+"<br>";

			mensajeTransaccionBean.setMensajeId(respuestaMOCBean.getCodigo());
			mensajeTransaccionBean.setNumeroMensaje(Constantes.error);
			mensajeTransaccionBean.setDescripcionMensaje(respuestaMOCBean.getDescripcion());
			enviarCorreo("mluis@elektra.com.mx", "RENDICION MOC.",mensaje);
			dobleAutorizacionDAO.bitacoraSolicitudes(dobleAutorizacionBean);
			return mensajeTransaccionBean;
		}
		
		dobleAutorizacionBean.setRespuestaIdMOC(respuestaMOCBean.getCodigo());
		dobleAutorizacionBean.setRespuestaMOC(respuestaMOCBean.getDescripcion());
		dobleAutorizacionBean.setEstatusRendicion(Constantes.autorizar);
		dobleAutorizacionBean.setCodigoHttp(200);
		
		mensaje+="Codigo MOC:"+respuestaMOCBean.getCodigo()+"<br>";
		mensaje+="Mensaje MOC:"+respuestaMOCBean.getDescripcion();
		enviarCorreo("mluis@elektra.com.mx", "RENDICION MOC.",mensaje);
		
		mensajeTransaccionBean.setMensajeId(respuestaMOCBean.getCodigo());
		mensajeTransaccionBean.setNumeroMensaje(0);
		mensajeTransaccionBean.setDescripcionMensaje(respuestaMOCBean.getDescripcion());
		dobleAutorizacionDAO.bitacoraSolicitudes(dobleAutorizacionBean);

		mensajeTransaccionBean = dobleAutorizacionDAO.autorizaSolicitudes(dobleAutorizacionBean);
		
		return mensajeTransaccionBean;
	}
	
	private MensajeTransaccionBean rechazaSolicitudMOC(DobleAutorizacionBean dobleAutorizacionBean) {
		MensajeTransaccionBean mensajeTransaccionBean = new MensajeTransaccionBean();
		String endPoint = "http://10.53.37.56:8084/OriginacionCentralizada/originacion/actualizaStatusTienda/actualizarStatus";
		JsonObject solicitudes = new JsonObject();
		JsonArray solicitud = new JsonArray();
		JsonObject datosSolicitud = new JsonObject();
		Map<String,String> pathVariable = new HashMap<String, String>();
		RespuestaMOCBean respuestaMOCBean = null;
		
		datosSolicitud.addProperty("pais", dobleAutorizacionBean.getPaisId());
		datosSolicitud.addProperty("canal", dobleAutorizacionBean.getCanalId());
		datosSolicitud.addProperty("sucursal", dobleAutorizacionBean.getSucursalId());
		datosSolicitud.addProperty("idSolicitud", dobleAutorizacionBean.getSolicitudId());
		datosSolicitud.addProperty("statusSolicitud", Constantes.rechazar);
		datosSolicitud.addProperty("observaciones", dobleAutorizacionBean.getObservaciones());
		datosSolicitud.addProperty("fechaRendicion", dobleAutorizacionBean.getFechaRendicion());
		datosSolicitud.addProperty("idEmpleado", dobleAutorizacionBean.getEmpleadoOpera());
		solicitud.add(datosSolicitud);
		solicitudes.add("solicitudes", solicitud);
		
		Gson gson = new Gson();
		String jsonParams = gson.toJson(solicitudes);
		
		try {
			pathVariable.put("jsonActualizar", URLEncoder.encode(jsonParams, "UTF-8"));
		} catch (UnsupportedEncodingException e) {
		}
		pathVariable.put("tipoPersonaSolicitud", String.valueOf(dobleAutorizacionBean.getTipoSolicitud()==Constantes.obligadoSolidario?1:0));
		
		respuestaMOCBean = restBaseServicio.consumirMocPost(endPoint, pathVariable, null, RespuestaMOCBean.class);
		String mensaje =  dobleAutorizacionBean.getPaisId()+"-"+dobleAutorizacionBean.getCanalId()+"-"+dobleAutorizacionBean.getSucursalId()+"-"+dobleAutorizacionBean.getSolicitudId()+"<br><br>";
		mensaje +="Peticion:"+endPoint+"?jsonActualizar="+solicitudes+"&tipoPersonaSolicitud="+String.valueOf(dobleAutorizacionBean.getTipoSolicitud()==Constantes.obligadoSolidario?1:0)+"<br><br>";

		
		if(respuestaMOCBean.getCodigo() != Constantes.exitoRechazoMOC) {

			dobleAutorizacionBean.setRespuestaIdMOC(respuestaMOCBean.getCodigo());
			dobleAutorizacionBean.setRespuestaMOC(respuestaMOCBean.getDescripcion());
			dobleAutorizacionBean.setEstatusRendicion(Constantes.rechazar);
			dobleAutorizacionBean.setCodigoHttp(200);

			mensaje+="Codigo Moc"+respuestaMOCBean.getCodigo()+"<br>";
			mensaje+="Mensaje MOC"+respuestaMOCBean.getDescripcion()+"<br>";
			
			dobleAutorizacionDAO.bitacoraSolicitudes(dobleAutorizacionBean);
			
			mensajeTransaccionBean.setMensajeId(respuestaMOCBean.getCodigo());
			mensajeTransaccionBean.setNumeroMensaje(Constantes.error);
			mensajeTransaccionBean.setDescripcionMensaje(respuestaMOCBean.getDescripcion());
			enviarCorreo("mluis@elektra.com.mx", "RENDICION MOC.",mensaje);
			return mensajeTransaccionBean;
		}
		
		dobleAutorizacionBean.setRespuestaIdMOC(respuestaMOCBean.getCodigo());
		dobleAutorizacionBean.setRespuestaMOC(respuestaMOCBean.getDescripcion());
		dobleAutorizacionBean.setEstatusRendicion(9);
		dobleAutorizacionBean.setCodigoHttp(200);
		
		mensaje+="Codigo MOC:"+respuestaMOCBean.getCodigo()+"<br>";
		mensaje+="Mensaje MOC:"+respuestaMOCBean.getDescripcion();
		enviarCorreo("mluis@elektra.com.mx", "RENDICION MOC.",mensaje);
		
		mensajeTransaccionBean.setMensajeId(respuestaMOCBean.getCodigo());
		mensajeTransaccionBean.setNumeroMensaje(0);
		mensajeTransaccionBean.setDescripcionMensaje(respuestaMOCBean.getDescripcion());
		
		dobleAutorizacionDAO.bitacoraSolicitudes(dobleAutorizacionBean);
		
		mensajeTransaccionBean = dobleAutorizacionDAO.rechazaSolicitudes(dobleAutorizacionBean);
		
		return mensajeTransaccionBean;
	}

}
