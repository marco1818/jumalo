package com.bancoazteca.srcu.spring.originacion.solicitudes.dobleAutorizacion.beans;

import java.util.ArrayList;
import java.util.List;

public class DataMOCBean {
	private List<SolicitudesMOCBean> solicitudes;
	
	public DataMOCBean() {
		solicitudes = new ArrayList<>();
	}

	public List<SolicitudesMOCBean> getSolicitudes() {
		return solicitudes;
	}

	public void setSolicitudes(List<SolicitudesMOCBean> solicitudes) {
		this.solicitudes = solicitudes;
	}
	
}
