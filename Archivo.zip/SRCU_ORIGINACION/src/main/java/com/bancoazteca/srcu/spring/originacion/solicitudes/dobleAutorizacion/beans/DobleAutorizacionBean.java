package com.bancoazteca.srcu.spring.originacion.solicitudes.dobleAutorizacion.beans;

import com.bancoazteca.srcu.spring.sistema.beans.BaseBean;

public class DobleAutorizacionBean extends BaseBean{
	private String empleadoOpera;
	private int puestoOpera;
	private int departamentoOpera;
	private int paisId;
	private int canalId;
	private int sucursalId;
	private int solicitudId;
	private int tipoSolicitud;
	private String observaciones;
	private String fechaRendicion;
	private int respuestaIdMOC;
	private String respuestaMOC;
	private int estatusRendicion;
	private String peticionMOC;
	private int codigoHttp;
	private int motivoRechazo;
	
	public DobleAutorizacionBean() {
		
	}

	public String getEmpleadoOpera() {
		return empleadoOpera;
	}

	public void setEmpleadoOpera(String empleadoOpera) {
		this.empleadoOpera = empleadoOpera;
	}

	public int getPuestoOpera() {
		return puestoOpera;
	}

	public void setPuestoOpera(int puestoOpera) {
		this.puestoOpera = puestoOpera;
	}

	public int getPaisId() {
		return paisId;
	}

	public void setPaisId(int paisId) {
		this.paisId = paisId;
	}

	public int getCanalId() {
		return canalId;
	}

	public void setCanalId(int canalId) {
		this.canalId = canalId;
	}

	public int getSucursalId() {
		return sucursalId;
	}

	public void setSucursalId(int sucursalId) {
		this.sucursalId = sucursalId;
	}

	public int getSolicitudId() {
		return solicitudId;
	}

	public void setSolicitudId(int solicitudId) {
		this.solicitudId = solicitudId;
	}

	public String getObservaciones() {
		return observaciones;
	}

	public void setObservaciones(String observaciones) {
		this.observaciones = observaciones;
	}

	public String getFechaRendicion() {
		return fechaRendicion;
	}

	public void setFechaRendicion(String fechaRendicion) {
		this.fechaRendicion = fechaRendicion;
	}

	public int getTipoSolicitud() {
		return tipoSolicitud;
	}

	public void setTipoSolicitud(int tipoSolicitud) {
		this.tipoSolicitud = tipoSolicitud;
	}

	public int getDepartamentoOpera() {
		return departamentoOpera;
	}

	public void setDepartamentoOpera(int departamentoOpera) {
		this.departamentoOpera = departamentoOpera;
	}

	

	public int getRespuestaIdMOC() {
		return respuestaIdMOC;
	}

	public void setRespuestaIdMOC(int respuestaIdMOC) {
		this.respuestaIdMOC = respuestaIdMOC;
	}

	public String getRespuestaMOC() {
		return respuestaMOC;
	}

	public void setRespuestaMOC(String respuestaMOC) {
		this.respuestaMOC = respuestaMOC;
	}

	public int getEstatusRendicion() {
		return estatusRendicion;
	}

	public void setEstatusRendicion(int estatusRendicion) {
		this.estatusRendicion = estatusRendicion;
	}

	public String getPeticionMOC() {
		return peticionMOC;
	}

	public void setPeticionMOC(String peticionMOC) {
		this.peticionMOC = peticionMOC;
	}

	public int getCodigoHttp() {
		return codigoHttp;
	}

	public void setCodigoHttp(int codigoHttp) {
		this.codigoHttp = codigoHttp;
	}

	public int getMotivoRechazo() {
		return motivoRechazo;
	}

	public void setMotivoRechazo(int motivoRechazo) {
		this.motivoRechazo = motivoRechazo;
	}

}
