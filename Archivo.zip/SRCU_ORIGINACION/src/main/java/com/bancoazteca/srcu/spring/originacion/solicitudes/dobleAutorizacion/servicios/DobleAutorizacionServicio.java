package com.bancoazteca.srcu.spring.originacion.solicitudes.dobleAutorizacion.servicios;

import com.bancoazteca.srcu.spring.originacion.solicitudes.dobleAutorizacion.beans.DobleAutorizacionBean;
import com.bancoazteca.srcu.spring.sistema.beans.MensajeTransaccionBean;

public interface DobleAutorizacionServicio {
	public DobleAutorizacionBean consulta(DobleAutorizacionBean dobleAutorizacionBean, int tipoConsulta);
	public MensajeTransaccionBean grabaTransaccion(DobleAutorizacionBean dobleAutorizacionBean, int tipoTransaccion);
}
