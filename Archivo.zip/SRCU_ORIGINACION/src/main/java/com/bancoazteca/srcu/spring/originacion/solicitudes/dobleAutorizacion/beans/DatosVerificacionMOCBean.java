package com.bancoazteca.srcu.spring.originacion.solicitudes.dobleAutorizacion.beans;

public class DatosVerificacionMOCBean {
	private	int verificacionHuella;
	private int verificacionFacial;
	private DesacuerdoJvcMOCBean desacuerdoJVC;
	public int getVerificacionHuella() {
		return verificacionHuella;
	}
	public void setVerificacionHuella(int verificacionHuella) {
		this.verificacionHuella = verificacionHuella;
	}
	public int getVerificacionFacial() {
		return verificacionFacial;
	}
	public void setVerificacionFacial(int verificacionFacial) {
		this.verificacionFacial = verificacionFacial;
	}
	public DesacuerdoJvcMOCBean getDesacuerdoJVC() {
		return desacuerdoJVC;
	}
	public void setDesacuerdoJVC(DesacuerdoJvcMOCBean desacuerdoJVC) {
		this.desacuerdoJVC = desacuerdoJVC;
	}
	
}
