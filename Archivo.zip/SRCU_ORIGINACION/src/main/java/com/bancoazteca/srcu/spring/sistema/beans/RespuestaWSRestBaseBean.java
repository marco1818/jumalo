package com.bancoazteca.srcu.spring.sistema.beans;

public class RespuestaWSRestBaseBean {
	private int codigoRespuesta;
	private String mensaje;
	private Object respuesta;
	
	public int getCodigoRespuesta() {
		return codigoRespuesta;
	}
	
	public void setCodigoRespuesta(int codigoRespuesta) {
		this.codigoRespuesta = codigoRespuesta;
	}
	
	public String getMensaje() {
		return mensaje;
	}
	
	public void setMensaje(String mensaje) {
		this.mensaje = mensaje;
	}
	
	public Object getRespuesta() {
		return respuesta;
	}
	
	public void setRespuesta(Object respuesta) {
		this.respuesta = respuesta;
	}
	
}
