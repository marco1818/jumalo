package com.bancoazteca.srcu.spring.originacion.solicitudes.dobleAutorizacion.daos;

import com.bancoazteca.srcu.spring.originacion.solicitudes.dobleAutorizacion.beans.DobleAutorizacionBean;
import com.bancoazteca.srcu.spring.sistema.beans.MensajeTransaccionBean;
import com.bancoazteca.srcu.spring.sistema.beans.SimpleBean;

public interface DobleAutorizacionDAO {
	public	SimpleBean	validaSolicitudesMoc(DobleAutorizacionBean dobleAutorizacionBean);
	public 	SimpleBean	consultaDatosSolicitud(DobleAutorizacionBean dobleAutorizacionBean);
	public	MensajeTransaccionBean	autorizaSolicitudes(DobleAutorizacionBean dobleAutorizacionBean);
	public	MensajeTransaccionBean	rechazaSolicitudes(DobleAutorizacionBean dobleAutorizacionBean);
	public	MensajeTransaccionBean	bitacoraSolicitudes(DobleAutorizacionBean dobleAutorizacionBean);
}
