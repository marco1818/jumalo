package com.bancoazteca.srcu.spring.originacion.solicitudes.dobleAutorizacion.daos;

import java.util.ArrayList;

import org.springframework.stereotype.Repository;

import com.bancoazteca.srcu.spring.originacion.solicitudes.dobleAutorizacion.beans.DobleAutorizacionBean;
import com.bancoazteca.srcu.spring.sistema.beans.MensajeTransaccionBean;
import com.bancoazteca.srcu.spring.sistema.beans.SimpleBean;
import com.bancoazteca.srcu.spring.sistema.daos.BaseDAO;

@Repository
public class DobleAutorizacionDAOImpl extends BaseDAO implements DobleAutorizacionDAO{

	private interface Funciones{
		String 	validaSolicitudesMOC	=	"DOBLE_AUTORIZACION_VALIDA_SOLICITUDES_MOC";
		String 	consultaDatosSolicitud	=	"DOBLE_AUTORIZACION_CONSULTA_DATOS_SOLICITUD";
		String	autorizaSolicitud		=	"DOBLE_AUTORIZACION_AUTORIZACION_SOLICITUDES";
		String	bitacoraSolicitudes		=	"DOBLE_AUTORIZACION_BITACORA_SOLICITUDES";
	}
	
	private interface Constantes{
		int	marcaMOC		=	214;
		int	autorizada	=	20;
		int	rechazada	=	9;
		int motivo		=	0;
		int tipo			=	1;
	}
	
	@Override
	public SimpleBean validaSolicitudesMoc(DobleAutorizacionBean dobleAutorizacionBean) {
		SimpleBean simpleBean = null;
		ArrayList<Object> parametros = new ArrayList<Object>();
		parametros.add(dobleAutorizacionBean.getPaisId());
		parametros.add(dobleAutorizacionBean.getCanalId());
		parametros.add(dobleAutorizacionBean.getSucursalId());
		parametros.add(dobleAutorizacionBean.getSolicitudId());
		parametros.add(Constantes.marcaMOC);
		
		simpleBean = (SimpleBean) ejecutaFuncion(Funciones.validaSolicitudesMOC, parametros, SimpleBean.class);
		
		return simpleBean;
	}

	@Override
	public SimpleBean consultaDatosSolicitud(DobleAutorizacionBean dobleAutorizacionBean) {
		SimpleBean simpleBean = null;
		ArrayList<Object> parametros = new ArrayList<Object>();
		parametros.add(dobleAutorizacionBean.getPaisId());
		parametros.add(dobleAutorizacionBean.getCanalId());
		parametros.add(dobleAutorizacionBean.getSucursalId());
		parametros.add(dobleAutorizacionBean.getSolicitudId());
		
		simpleBean = (SimpleBean) ejecutaFuncion(Funciones.consultaDatosSolicitud, parametros, SimpleBean.class);
		
		return simpleBean;
	}

	@Override
	public MensajeTransaccionBean autorizaSolicitudes(DobleAutorizacionBean dobleAutorizacionBean) {
		MensajeTransaccionBean mensajeTransaccionBean = null;
		ArrayList<Object> parametros = new ArrayList<Object>();
		parametros.add(dobleAutorizacionBean.getCanalId());
		parametros.add(dobleAutorizacionBean.getSucursalId());
		parametros.add(dobleAutorizacionBean.getSolicitudId());
		parametros.add(Constantes.autorizada);
		parametros.add(Constantes.motivo);
		parametros.add(dobleAutorizacionBean.getEmpleadoOpera());
		parametros.add(dobleAutorizacionBean.getPuestoOpera());
		parametros.add(dobleAutorizacionBean.getPaisId());
		parametros.add(dobleAutorizacionBean.getDepartamentoOpera());
		parametros.add(Constantes.tipo);
		parametros.add(dobleAutorizacionBean.getObservaciones());
		
		mensajeTransaccionBean = (MensajeTransaccionBean) ejecutaFuncion(Funciones.autorizaSolicitud, parametros, MensajeTransaccionBean.class);
		
		mensajeTransaccionBean.setDescripcionMensaje(mensajeTransaccionBean.getDescripcionMensaje().toUpperCase());
		
		return mensajeTransaccionBean;
	}

	@Override
	public MensajeTransaccionBean bitacoraSolicitudes(DobleAutorizacionBean dobleAutorizacionBean) {
		MensajeTransaccionBean mensajeTransaccionBean = null;
		ArrayList<Object> parametros = new ArrayList<Object>();
		parametros.add(dobleAutorizacionBean.getPaisId());
		parametros.add(dobleAutorizacionBean.getCanalId());
		parametros.add(dobleAutorizacionBean.getSucursalId());
		parametros.add(dobleAutorizacionBean.getSolicitudId());
		parametros.add(dobleAutorizacionBean.getPaisId());
		parametros.add(dobleAutorizacionBean.getCanalId());
		parametros.add(dobleAutorizacionBean.getSucursalId());
		parametros.add(0);
		parametros.add(dobleAutorizacionBean.getRespuestaIdMOC());
		parametros.add(dobleAutorizacionBean.getEstatusRendicion());
		parametros.add(dobleAutorizacionBean.getEmpleadoOpera());
		parametros.add(dobleAutorizacionBean.getFechaRendicion());
		parametros.add(dobleAutorizacionBean.getObservaciones());
		parametros.add(1);
		parametros.add(0);
		parametros.add(dobleAutorizacionBean.getRespuestaIdMOC());
		parametros.add(dobleAutorizacionBean.getRespuestaMOC());
		parametros.add(dobleAutorizacionBean.getCodigoHttp());
		parametros.add(1);
		
		mensajeTransaccionBean = (MensajeTransaccionBean) ejecutaFuncion(Funciones.bitacoraSolicitudes, parametros, MensajeTransaccionBean.class);
		
		return mensajeTransaccionBean;
	}

	@Override
	public MensajeTransaccionBean rechazaSolicitudes(DobleAutorizacionBean dobleAutorizacionBean) {
		MensajeTransaccionBean mensajeTransaccionBean = null;
		ArrayList<Object> parametros = new ArrayList<Object>();
		parametros.add(dobleAutorizacionBean.getCanalId());
		parametros.add(dobleAutorizacionBean.getSucursalId());
		parametros.add(dobleAutorizacionBean.getSolicitudId());
		parametros.add(Constantes.rechazada);
		parametros.add(dobleAutorizacionBean.getMotivoRechazo());
		parametros.add(dobleAutorizacionBean.getEmpleadoOpera());
		parametros.add(dobleAutorizacionBean.getPuestoOpera());
		parametros.add(dobleAutorizacionBean.getPaisId());
		parametros.add(dobleAutorizacionBean.getDepartamentoOpera());
		parametros.add(Constantes.tipo);
		parametros.add(dobleAutorizacionBean.getObservaciones());
		
		mensajeTransaccionBean = (MensajeTransaccionBean) ejecutaFuncion(Funciones.autorizaSolicitud, parametros, MensajeTransaccionBean.class);
		
		mensajeTransaccionBean.setDescripcionMensaje(mensajeTransaccionBean.getDescripcionMensaje().toUpperCase());
		
		return mensajeTransaccionBean;
	}

}
