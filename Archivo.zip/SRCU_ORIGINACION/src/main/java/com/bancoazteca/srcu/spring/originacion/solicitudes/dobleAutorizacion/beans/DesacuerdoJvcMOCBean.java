package com.bancoazteca.srcu.spring.originacion.solicitudes.dobleAutorizacion.beans;

public class DesacuerdoJvcMOCBean {
	private int statusDesacuerdo;
	private int motivoDesacuerdo;
	private String motivo;
	public int getStatusDesacuerdo() {
		return statusDesacuerdo;
	}
	public void setStatusDesacuerdo(int statusDesacuerdo) {
		this.statusDesacuerdo = statusDesacuerdo;
	}
	public int getMotivoDesacuerdo() {
		return motivoDesacuerdo;
	}
	public void setMotivoDesacuerdo(int motivoDesacuerdo) {
		this.motivoDesacuerdo = motivoDesacuerdo;
	}
	public String getMotivo() {
		return motivo;
	}
	public void setMotivo(String motivo) {
		this.motivo = motivo;
	}
	
}
