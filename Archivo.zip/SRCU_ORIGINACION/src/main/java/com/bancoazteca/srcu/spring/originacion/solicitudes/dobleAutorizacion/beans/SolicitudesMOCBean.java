package com.bancoazteca.srcu.spring.originacion.solicitudes.dobleAutorizacion.beans;

public class SolicitudesMOCBean {

}
