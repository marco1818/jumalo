package com.bancoazteca.srcu.spring.puestos.servicios;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.bancoazteca.srcu.spring.puestos.bean.MantenimientoPuestosBean;
import com.bancoazteca.srcu.spring.puestos.bean.MensajeTransaccionBean;
import com.bancoazteca.srcu.spring.puestos.bean.PuestosBean;
import com.bancoazteca.srcu.spring.puestos.daos.MantenimientoPuestosDAO;
import com.bancoazteca.srcu.spring.sistema.servicios.BaseServicio;
@Service
public class MantenimientoPuestosServicioImpl extends BaseServicio implements MantenimientoPuestosServicio{

	
	@Autowired
	MantenimientoPuestosDAO puestoDAO;

	private interface Transacciones{
		int	altaPuesto			=	1;
		int	modificacionPuesto		=	2;
		int	bajaPuesto		=	3;
	}
	@Override
	public MantenimientoPuestosBean consultaPuestos() {
		return puestoDAO.consultaPuestos();
	}

	@Override
	public MensajeTransaccionBean grabaTransaccion(MantenimientoPuestosBean mantenimientoBean, int tipoOperacion) {
		MensajeTransaccionBean mensajeTransaccionBean = new MensajeTransaccionBean();
		
		switch (tipoOperacion) {
		case Transacciones.altaPuesto:
			mensajeTransaccionBean	=	altaPuesto(mantenimientoBean);
			break;
		case Transacciones.modificacionPuesto:
			mensajeTransaccionBean=	modificacionPuesto(mantenimientoBean);
			//mensajeTransaccionBean	=	altaEmpleado(mantenimientoUsuariosUnificadoBean);
			break;
		case Transacciones.bajaPuesto:
			mensajeTransaccionBean	=	bajaPuesto(mantenimientoBean);
			//mensajeTransaccionBean	=	bajaEmpleado(mantenimientoUsuariosUnificadoBean);
			break;
		default:
		}
		
		return mensajeTransaccionBean;
	}
	
	private MensajeTransaccionBean altaPuesto(MantenimientoPuestosBean mpBean) {
		
		MensajeTransaccionBean mensajeTransaccionBean;
		mensajeTransaccionBean=puestoDAO.altaPuesto(mpBean);
		if(mensajeTransaccionBean.getMensajeId()==0)
			
		{			
			
			if(mpBean.isDsiEstatus()) {
				if	(puestoDAO.altaPuestoDSIDCT(mpBean).getMensajeId()==0) {
				return puestoDAO.altaPuestoDSIDSS(mpBean);
				}
			}
		}
		return mensajeTransaccionBean;
		
	}



	
	private MensajeTransaccionBean modificacionPuesto(MantenimientoPuestosBean mpBean) {
		PuestosBean pb= new PuestosBean();
		MensajeTransaccionBean mensajeTransaccionBean=new MensajeTransaccionBean();
		// TODO Auto-generated method stub
		mensajeTransaccionBean=puestoDAO.modificacionPuesto(mpBean);
		 
		return   mensajeTransaccionBean;
	}



	
	


	private MensajeTransaccionBean bajaPuesto(MantenimientoPuestosBean mpBean) {
		// TODO Auto-generated method stub
		MensajeTransaccionBean mensajeTransaccionBean=new MensajeTransaccionBean();
		if (puestoDAO.bajaPuestoDSS(mpBean).getMensajeId()==0) {
			mensajeTransaccionBean =puestoDAO.bajaPuestoDCT(mpBean);
		}
		return mensajeTransaccionBean ;
	}
	


}
