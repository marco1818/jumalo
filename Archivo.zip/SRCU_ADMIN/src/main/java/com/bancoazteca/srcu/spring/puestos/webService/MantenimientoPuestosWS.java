package com.bancoazteca.srcu.spring.puestos.webService;

import java.util.ArrayList;
import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.bancoazteca.srcu.spring.puestos.bean.MantenimientoPuestosBean;
import com.bancoazteca.srcu.spring.puestos.bean.MensajeTransaccionBean;
import com.bancoazteca.srcu.spring.puestos.bean.PuestosBean;
import com.bancoazteca.srcu.spring.puestos.servicios.MantenimientoPuestosServicio;




@RestController
@RequestMapping("/api/v1/puestos")
public class MantenimientoPuestosWS {
	@Autowired
	MantenimientoPuestosServicio puestoServicio;
	
	@RequestMapping(value = "/consulta", method = RequestMethod.GET)
	@ResponseBody
	public MantenimientoPuestosBean consultaPuestos() {
		System.out.println("Entro a recopilar los puestos");
		return puestoServicio.consultaPuestos();
	}
	
	@RequestMapping(value="/inserta", method= RequestMethod.POST)
	@ResponseBody
	public MensajeTransaccionBean  insertarPuesto(@RequestBody MantenimientoPuestosBean pbBean) {
		//MensajeTransaccionBean mb= new MensajeTransaccionBean();		
	    return	puestoServicio.grabaTransaccion(pbBean,1);	
	}

	@RequestMapping(value="/actualiza", method= RequestMethod.PUT)
	@ResponseBody
	public MensajeTransaccionBean  actualizarPuesto(@RequestBody MantenimientoPuestosBean mpBean) {
		return puestoServicio.grabaTransaccion(mpBean,2);
	}
	
	@RequestMapping(value="/elimina", method= RequestMethod.DELETE)
	@ResponseBody
	public MensajeTransaccionBean  eliminarPuesto(@RequestBody MantenimientoPuestosBean mpBean) {
		return puestoServicio.grabaTransaccion(mpBean,3);
	}
	
	
	
	
}
