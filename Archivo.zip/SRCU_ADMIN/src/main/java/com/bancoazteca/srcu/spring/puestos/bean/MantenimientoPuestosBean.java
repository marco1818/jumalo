package com.bancoazteca.srcu.spring.puestos.bean;


import java.io.Serializable;
import java.util.List;

public class MantenimientoPuestosBean implements Serializable {

	private int idPuesto;
	
	private String numEmpleado;
	
	private  boolean dsiEstatus;
	
	private String descPuesto;
	
	private int nivel;
	
	private int tipoPuesto;
	
	private int descTipoPuesto;
	
	private String descPuestoCorto;
	
	
	private List<PuestosBean> puestos;


	public int getIdPuesto() {
		return idPuesto;
	}


	public void setIdPuesto(int idPuesto) {
		this.idPuesto = idPuesto;
	}


	public String getDescPuesto() {
		return descPuesto;
	}


	public void setDescPuesto(String descPuesto) {
		this.descPuesto = descPuesto;
	}


	public int getNivel() {
		return nivel;
	}


	public void setNivel(int nivel) {
		this.nivel = nivel;
	}


	public int getDescTipoPuesto() {
		return descTipoPuesto;
	}


	public void setDescTipoPuesto(int descTipoPuesto) {
		this.descTipoPuesto = descTipoPuesto;
	}


	public String getDescPuestoCorto() {
		return descPuestoCorto;
	}


	public void setDescPuestoCorto(String descPuestoCorto) {
		this.descPuestoCorto = descPuestoCorto;
	}


	public List<PuestosBean> getPuestos() {
		return puestos;
	}


	public void setPuestos(List<PuestosBean> puestos) {
		this.puestos = puestos;
	}


	public int getTipoPuesto() {
		return tipoPuesto;
	}


	public void setTipoPuesto(int tipoPuesto) {
		this.tipoPuesto = tipoPuesto;
	}


	public String getNumEmpleado() {
		return numEmpleado;
	}


	public void setNumEmpleado(String numEmpleado) {
		this.numEmpleado = numEmpleado;
	}


	public boolean isDsiEstatus() {
		return dsiEstatus;
	}


	public void setDsiEstatus(boolean dsiEstatus) {
		this.dsiEstatus = dsiEstatus;
	}


	@Override
	public String toString() {
		return "MantenimientoPuestosBean [idPuesto=" + idPuesto + ", numEmpleado=" + numEmpleado + ", dsiEstatus="
				+ dsiEstatus + ", descPuesto=" + descPuesto + ", nivel=" + nivel + ", tipoPuesto=" + tipoPuesto
				+ ", descTipoPuesto=" + descTipoPuesto + ", descPuestoCorto=" + descPuestoCorto + "]";
	}


	


	
	
	
	
	
}
