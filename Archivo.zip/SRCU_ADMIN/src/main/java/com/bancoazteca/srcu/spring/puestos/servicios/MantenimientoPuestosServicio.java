package com.bancoazteca.srcu.spring.puestos.servicios;

import com.bancoazteca.srcu.spring.puestos.bean.MantenimientoPuestosBean;
import com.bancoazteca.srcu.spring.puestos.bean.MensajeTransaccionBean;




public interface MantenimientoPuestosServicio {
	public MantenimientoPuestosBean consultaPuestos();
	public MensajeTransaccionBean grabaTransaccion(MantenimientoPuestosBean mantenimientoBean, int tipoOperacion);

}
