package com.bancoazteca.srcu.spring.sistema.servicios;

import java.util.logging.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.bancoazteca.srcu.spring.sistema.FuncionesSistema;

@Component
public class CargaRecursosSistema {
	private final static Logger logger = Logger.getLogger("CargaRecursosSistema");

	@SuppressWarnings("unused")
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	public CargaRecursosSistema(JdbcTemplate jdbcTemplate) {
		super();
		this.jdbcTemplate = jdbcTemplate;
		inizializaSistema();
	}
	
	private void inizializaSistema() {
		logger.info("Inizializando Recursos del Sistema.....");
		FuncionesSistema.getInstance();
	}
	
}
