package com.bancoazteca.srcu.spring.sistema.beans;

import java.security.SecureRandom;

public class BaseBean {
	private SecureRandom versionador = new SecureRandom();
	private String viewName;
	private	double	version;
	
	public BaseBean() {
		version = versionador.nextDouble();
	}

	public double getVersion() {
		return version;
	}

	public void setVersion(double version) {
		this.version = version;
	}

	public String getViewName() {
		return viewName;
	}

	public void setViewName(String viewName) {
		this.viewName = viewName;
	}
}
