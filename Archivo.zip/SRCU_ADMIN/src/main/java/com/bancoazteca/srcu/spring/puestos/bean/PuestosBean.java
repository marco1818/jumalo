package com.bancoazteca.srcu.spring.puestos.bean;


import java.math.BigDecimal;

public class PuestosBean{

	private BigDecimal idPuesto;
	
	private String descPuesto;
	
	private BigDecimal nivel;
	
	private BigDecimal tipoPuesto;
	
	private String descPuestoCorto ;
	
	private String clasificacionPuesto;
	
	
	public BigDecimal getIdPuesto() {
		return idPuesto;
	}

	public void setIdPuesto(BigDecimal idPuesto) {
		this.idPuesto = idPuesto;
	}

	public String getDescPuesto() {
		return descPuesto;
	}

	public void setDescPuesto(String descPuesto) {
		this.descPuesto = descPuesto;
	}

	public BigDecimal getNivel() {
		return nivel;
	}

	public BigDecimal getTipoPuesto() {
		return tipoPuesto;
	}

	public void setTipoPuesto(BigDecimal tipoPuesto) {
		this.tipoPuesto = tipoPuesto;
	}

	public String getDescPuestoCorto() {
		return descPuestoCorto;
	}

	public void setDescPuestoCorto(String descPuestoCorto) {
		this.descPuestoCorto = descPuestoCorto;
	}

	public String getClasificacionPuesto() {
		return clasificacionPuesto;
	}

	public void setClasificacionPuesto(String clasificacionPuesto) {
		this.clasificacionPuesto = clasificacionPuesto;
	}

	public void setNivel(BigDecimal nivel) {
		this.nivel = nivel;
	}

	@Override
	public String toString() {
		return "PuestoBean [idPuesto=" + idPuesto + ", descPuesto=" + descPuesto + ", nivel=" + nivel + ", tipoPuesto="
				+ tipoPuesto + ", descPuestoCorto=" + descPuestoCorto + ", clasificacionPuesto=" + clasificacionPuesto
				+ "]";
	}

	
}
