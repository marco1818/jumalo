package com.bancoazteca.srcu.spring.puestos.daos;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.bancoazteca.srcu.spring.puestos.bean.MantenimientoPuestosBean;
import com.bancoazteca.srcu.spring.puestos.bean.MensajeTransaccionBean;
import com.bancoazteca.srcu.spring.puestos.bean.PuestosBean;
import com.bancoazteca.srcu.spring.sistema.daos.BaseDAO;
@Repository
public class MantenimientoPuestosDAOImpl extends BaseDAO implements MantenimientoPuestosDAO {

	private interface Funciones{
	     String	consultaPuestos	="PUESTOS_CONSULTA";
	     String insertaPuestos="PUESTOS_INSERTA";
	     String insertaPuestosDSIUno="PUESTOS_INSERTA_DSI_UNO";
	     String insertaPuestosDSIDos="PUESTOS_INSERTA_DSI_DOS";
	     String actualizaPuesto="PUESTOS_ACTUALIZA";
	     String eliminaPuestoUno="PUESTOS_ELIMINA";	
	     String eliminaPuestoDos="PUESTOS_ELIMINA_DOS";
	     }
	
	@SuppressWarnings("unchecked")
	@Override
	public MantenimientoPuestosBean consultaPuestos() {
		MantenimientoPuestosBean mpBean= new MantenimientoPuestosBean();
		List<PuestosBean> puestos = new ArrayList<PuestosBean>();
		ArrayList<Object> parametros = new ArrayList<Object>();
		parametros.add(1);
		parametros.add(0);
		parametros.add("");
		parametros.add(0);
		parametros.add(0);
		parametros.add("");
		parametros.add(0);
		
		puestos = (List<PuestosBean>) ejecutaFuncionAll(Funciones.consultaPuestos, parametros, PuestosBean.class);		
		mpBean.setPuestos(puestos);
		return mpBean;
	}
	
	
	@SuppressWarnings("unchecked")
	@Override
	public MensajeTransaccionBean  altaPuesto(MantenimientoPuestosBean mpBean) {
		ArrayList<Object> parametros = new ArrayList<Object>();
		MensajeTransaccionBean mb= new MensajeTransaccionBean();
		PuestosBean pb = new PuestosBean();
		parametros.add(2);
		parametros.add(mpBean.getIdPuesto()); //id puesto
		parametros.add(mpBean.getDescPuesto()); // descripcion
		parametros.add(mpBean.getTipoPuesto()); // clasificacion
		parametros.add(3);
		parametros.add(""+mpBean.getIdPuesto());//descripcion corta
		parametros.add(mpBean.getTipoPuesto()); // clasificacion
		mb=(MensajeTransaccionBean) ejecutaFuncion(Funciones.insertaPuestos, parametros,mb.getClass());	
		return mb;
		
	}
	
	
	@SuppressWarnings("unchecked")
	@Override
	public MensajeTransaccionBean altaPuestoDSIDCT(MantenimientoPuestosBean mpBean) {
		PuestosBean pb = new PuestosBean();
		ArrayList<Object> parametros = new ArrayList<Object>();
		MensajeTransaccionBean mb= new MensajeTransaccionBean();
		parametros.add(214);
		parametros.add(mpBean.getIdPuesto());
		parametros.add(""+mpBean.getIdPuesto());
		parametros.add(mpBean.getDescPuesto());
		parametros.add(1);
		parametros.add(2);
		mb=(MensajeTransaccionBean) ejecutaFuncion(Funciones.insertaPuestosDSIUno, parametros,mb.getClass());	
		return mb;
	}
	
	
	@SuppressWarnings("unchecked")
	@Override
	public MensajeTransaccionBean altaPuestoDSIDSS(MantenimientoPuestosBean mpBean) {
		ArrayList<Object> parametros = new ArrayList<Object>();
		MensajeTransaccionBean mb= new MensajeTransaccionBean();
		parametros.add(4);
		parametros.add(99);
		parametros.add(mpBean.getIdPuesto());
		parametros.add(""+mpBean.getIdPuesto());
		parametros.add(mpBean.getDescPuesto());
		parametros.add(1);
		parametros.add(mpBean.getNumEmpleado());
		mb=(MensajeTransaccionBean) ejecutaFuncion(Funciones.insertaPuestosDSIDos, parametros,mb.getClass());	
		return mb;
	}
	
	
	@SuppressWarnings("unchecked")
	@Override
	public MensajeTransaccionBean  modificacionPuesto(MantenimientoPuestosBean mpBean) {
		PuestosBean pb = new PuestosBean();
		ArrayList<Object> parametros = new ArrayList<Object>();
		MensajeTransaccionBean mb= new MensajeTransaccionBean();
		parametros.add(3);
		parametros.add(mpBean.getIdPuesto()); //id puesto
		parametros.add(mpBean.getDescPuesto()); // descripcion
		parametros.add(mpBean.getTipoPuesto()); // clasificacion
		parametros.add(3);
		parametros.add(""+mpBean.getIdPuesto());//descripcion corta
		parametros.add(mpBean.getTipoPuesto()); // clasificacion
		mb=(MensajeTransaccionBean) ejecutaFuncion(Funciones.actualizaPuesto, parametros,MensajeTransaccionBean.class);	
		return mb;
		
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public MensajeTransaccionBean  bajaPuestoDSS(MantenimientoPuestosBean mpBean) {
		PuestosBean pb = new PuestosBean();
		ArrayList<Object> parametros = new ArrayList<Object>();
		MensajeTransaccionBean mb= new MensajeTransaccionBean();
		parametros.add(4);
		parametros.add(mpBean.getIdPuesto()); //id puesto
		parametros.add(mpBean.getDescPuesto()); // descripcion
		parametros.add(mpBean.getTipoPuesto()); // clasificacion
		parametros.add(3);
		parametros.add(""+mpBean.getIdPuesto());//descripcion corta
		parametros.add(mpBean.getTipoPuesto()); // clasificacion
		mb=(MensajeTransaccionBean) ejecutaFuncion(Funciones.eliminaPuestoUno, parametros,MensajeTransaccionBean.class);	
		return mb;
		
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public MensajeTransaccionBean  bajaPuestoDCT(MantenimientoPuestosBean mpBean) {
		ArrayList<Object> parametros = new ArrayList<Object>();
		MensajeTransaccionBean mb= new MensajeTransaccionBean();
		parametros.add(214);
		parametros.add(mpBean.getIdPuesto()); //id puesto
		parametros.add(""+mpBean.getIdPuesto());//descripcion corta
		parametros.add(mpBean.getDescPuesto()); // descripcion
		parametros.add(1); // clasificacion
		parametros.add(3);
		mb=(MensajeTransaccionBean) ejecutaFuncion(Funciones.eliminaPuestoDos, parametros,mb.getClass());	
		return mb;
		
	}
	
	
}
