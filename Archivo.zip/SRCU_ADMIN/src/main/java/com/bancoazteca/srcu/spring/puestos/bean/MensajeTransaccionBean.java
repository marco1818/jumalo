package com.bancoazteca.srcu.spring.puestos.bean;

import java.math.BigDecimal;

public class MensajeTransaccionBean {
	private int numeroMensaje;
	private int mensajeId;
	private String descripcionMensaje;
	
	public MensajeTransaccionBean() {
		
	}

	public int getNumeroMensaje() {
		return numeroMensaje;
	}

	public void setNumeroMensaje(int numeroMensaje) {
		this.numeroMensaje = numeroMensaje;
	}

	public void setNumeroMensaje(BigDecimal numeroMensaje) {
		this.numeroMensaje = numeroMensaje.intValue();
	}

	public int getMensajeId() {
		return mensajeId;
	}

	public void setMensajeId(int mensajeId) {
		this.mensajeId = mensajeId;
	}
	
	public void setMensajeId(BigDecimal mensajeId) {
		this.mensajeId = mensajeId.intValue();
	}
	
	public String getDescripcionMensaje() {
		return descripcionMensaje;
	}

	public void setDescripcionMensaje(String descripcionMensaje) {
		this.descripcionMensaje = descripcionMensaje;
	}
	
	
}
