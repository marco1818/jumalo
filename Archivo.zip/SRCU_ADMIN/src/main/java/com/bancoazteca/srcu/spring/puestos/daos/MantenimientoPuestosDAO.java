package com.bancoazteca.srcu.spring.puestos.daos;


import com.bancoazteca.srcu.spring.puestos.bean.MantenimientoPuestosBean;
import com.bancoazteca.srcu.spring.puestos.bean.MensajeTransaccionBean;
import com.bancoazteca.srcu.spring.puestos.bean.PuestosBean;




public interface MantenimientoPuestosDAO {

public MantenimientoPuestosBean consultaPuestos();
public MensajeTransaccionBean  altaPuesto(MantenimientoPuestosBean mpBean);
public MensajeTransaccionBean altaPuestoDSIDCT(MantenimientoPuestosBean mpBean);
public MensajeTransaccionBean  modificacionPuesto(MantenimientoPuestosBean mpBean);
public MensajeTransaccionBean altaPuestoDSIDSS(MantenimientoPuestosBean mpBean);
public MensajeTransaccionBean  bajaPuestoDSS(MantenimientoPuestosBean mpBean);
public MensajeTransaccionBean  bajaPuestoDCT(MantenimientoPuestosBean mpBean);
}
